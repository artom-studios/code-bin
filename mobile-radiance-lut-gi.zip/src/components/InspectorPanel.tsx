import { GlassPanel, Section, Stat, fmtBytes } from "./ui";
import type { BakeState } from "@/gi/useBaker";
import { cn } from "@/utils/cn";

function MemBar({ label, bytes, max, tone, note }: { label: string; bytes: number; max: number; tone: string; note?: string }) {
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between text-[11px]">
        <span className="text-slate-300">{label}</span>
        <span className="font-mono text-slate-100">{fmtBytes(bytes)}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-white/5">
        <div className={cn("h-full rounded-full transition-all duration-500", tone)} style={{ width: `${Math.max(2, (bytes / max) * 100)}%` }} />
      </div>
      {note && <div className="mt-0.5 text-[10px] text-slate-500">{note}</div>}
    </div>
  );
}

export function InspectorPanel({ bake, fps, tileN, step }: { bake: BakeState; fps: number; tileN: number; step: number }) {
  const s = bake.stats;
  const v = bake.validation;
  const max = s ? Math.max(s.totalBytes, s.lightmapBytes, s.volumeBytes) : 1;
  const redundancy = (tileN * tileN) / ((tileN - 1) * (tileN - 1));
  const pct = (x: number) => `${(x * 100).toFixed(1)}%`;
  return (
    <GlassPanel title="LUT inspector" className="flex max-h-full flex-col overflow-hidden" right={<span className="font-mono text-[11px] text-slate-400">{fps.toFixed(0)} fps</span>}>
      <div className="min-h-0 flex-1 divide-y divide-white/5 overflow-y-auto">
        <Section title="Bake" hint={bake.phase === "done" ? "converged" : bake.phase === "error" ? "error" : "progressive"}>
          <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-300 to-orange-400 transition-all"
              style={{ width: `${bake.phase === "done" ? 100 : ((bake.pass + bake.frac) / bake.passes) * 100}%` }}
            />
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            <Stat label="Pass" value={`${bake.pass}/${bake.passes}`} />
            <Stat label="Samples" value={`${bake.totalSpp}`} sub="spp / point" />
            <Stat label="Time" value={`${(bake.elapsedMs / 1000).toFixed(1)}s`} sub={bake.firstUsableMs ? `usable @ ${(bake.firstUsableMs / 1000).toFixed(1)}s` : "…"} />
          </div>
          {bake.error && <pre className="max-h-24 overflow-auto rounded bg-red-500/10 p-2 text-[10px] text-red-300">{bake.error}</pre>}
        </Section>

        {s && (
          <>
            <Section title="Table" hint="key = (cell xyz, face)">
              <div className="grid grid-cols-2 gap-1.5">
                <Stat label="Tiles (keys)" value={s.entries.toLocaleString()} sub={`${tileN}×${tileN} texels each`} />
                <Stat label="Radiance texels" value={(s.entries * tileN * tileN).toLocaleString()} sub={`${s.corners.toLocaleString()} unique samples`} />
                <Stat label="Hash slots" value={s.slots.toLocaleString()} sub={`load ${pct(s.load)} · 0 collisions`} />
                <Stat label="Tile size" value={`${(step * (tileN - 1) * 100).toFixed(0)} cm`} sub={`${(step * 100).toFixed(1)} cm texels`} />
              </div>
              <div className="rounded-lg bg-white/[0.04] px-2.5 py-2 text-[11px] leading-relaxed text-slate-400">
                Perfect hash built in <span className="font-mono text-slate-200">{s.attempts}</span> attempt{s.attempts > 1 ? "s" : ""}, max displacement{" "}
                <span className="font-mono text-slate-200">{s.maxDisp}</span>, index table{" "}
                <span className="font-mono text-slate-200">{fmtBytes(s.dispBytes)}</span>.
              </div>
            </Section>

            <Section title="Memory" hint="same texel density, 3 light channels">
              <div className="space-y-2.5">
                <MemBar label="RadLUT (this)" bytes={s.totalBytes} max={max} tone="bg-gradient-to-r from-amber-300 to-orange-400" note={`${redundancy.toFixed(2)}× tile border redundancy · ${pct(s.load)} slot load · RGB9E5`} />
                <MemBar label="UV lightmap (ideal)" bytes={s.lightmapBytes} max={max} tone="bg-slate-400" note="needs UV unwrap · +35% gutters/packing assumed" />
                <MemBar label="Irradiance volume" bytes={s.volumeBytes} max={max} tone="bg-slate-600" note="dense ambient cube · scales with volume³" />
              </div>
              <p className="text-[10px] leading-relaxed text-slate-500">
                Honest read: a perfectly packed lightmap is still smaller. RadLUT pays {s.totalBytes > s.lightmapBytes ? (s.totalBytes / s.lightmapBytes).toFixed(1) + "×" : "about the same"} to drop UVs, seams and
                per-mesh texel density, and to get relightable channels.
              </p>
            </Section>

            <Section title="Runtime cost / pixel">
              <div className="grid grid-cols-2 gap-1.5">
                <Stat label="Flat surface" value="1 + 3" sub="int fetch + bilinear" />
                <Stat label="Curved (worst)" value="3 + 9" sub="3 faces blended" />
              </div>
              <p className="text-[10px] leading-relaxed text-slate-500">
                No loops, no probing, no 8-tap probe interpolation. The displacement table ({fmtBytes(s.dispBytes)}) stays in L1; a lightmap would be 1–3 fetches plus a UV
                interpolator.
              </p>
            </Section>
          </>
        )}

        <Section title="Accuracy vs path tracer" hint="held-out random points">
          {v ? (
            <div className="grid grid-cols-2 gap-1.5">
              <Stat label="Mean error" value={pct(v.meanRelErr)} sub={`${v.points} points`} />
              <Stat label="Median / P90" value={`${(v.medianRelErr * 100).toFixed(1)} / ${(v.p90RelErr * 100).toFixed(0)}%`} />
              <Stat label="Key coverage" value={pct(v.coverage)} sub="LUT hit on every point" />
              <Stat label="Bake noise" value="denoised" sub="lattice-space filter" />
            </div>
          ) : (
            <div className="text-[11px] text-slate-500">{bake.phase === "error" ? "—" : "Validating once the bake converges…"}</div>
          )}
          <p className="text-[10px] leading-relaxed text-slate-500">
            Error of the filtered, hashed, RGB9E5-packed lookup against 768-sample ground truth at points that are <em>not</em> lattice samples. Use “Compare” to
            see it against a live GPU path tracer.
          </p>
        </Section>
      </div>
    </GlassPanel>
  );
}
