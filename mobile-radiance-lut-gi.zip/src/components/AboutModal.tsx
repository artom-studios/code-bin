import type { ReactNode } from "react";
import { cn } from "@/utils/cn";

const SNIPPET = `// per pixel: p = world position, n = normal (both already in the fragment shader)
vec3 radLUT(vec3 p, vec3 n) {
  // up to 3 faces; a flat wall only touches one
  for each face f with n_axis^2 > 0.03:
    c   = floor((p - origin) / cell);            // world-space cell, no UVs
    h0  = hash(pack(c), f);
    d   = texelFetch(dispTable, h0 % B).r;       // 1 integer fetch (tiny, cached)
    s   = hash(h0 + d * K) % M;                  // collision-free slot
    uv  = tileOrigin(s) + 0.5 + frac(p/cell) * (N-1);
    E  += w_f * ( gSun  * texture(atlasSun,  uv)    // 1 bilinear fetch per light
                + gSky  * texture(atlasSky,  uv)    // gains = runtime colour * intensity
                + gLamp * texture(atlasLamp, uv) );
  return E / sum(w);
}
color = albedo(uv_material) * radLUT(p, n);       // albedo stays full-res`;

function Step({ n, title, children }: { n: number; title: string; children: ReactNode }) {
  return (
    <div className="flex gap-3">
      <div className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-400 text-xs font-bold text-slate-950">{n}</div>
      <div className="min-w-0">
        <div className="text-sm font-semibold text-slate-100">{title}</div>
        <div className="text-[13px] leading-relaxed text-slate-400">{children}</div>
      </div>
    </div>
  );
}

const ROWS: [string, string, string, string][] = [
  ["Needs UV unwrap", "yes", "no", "no"],
  ["Memory grows with", "surface area (+ gutters)", "volume (cubic)", "surface area × N²/(N−1)²"],
  ["Fetches / pixel", "1 (+ UV interpolant)", "3–6 trilinear", "1 int + 1–3 bilinear / face"],
  ["Light leaks through thin walls", "no", "yes", "no (keys are per face)"],
  ["Relight colour / intensity", "1 lightmap per light", "yes", "yes (3 channels)"],
  ["Any mesh, LOD, instancing", "needs UVs per mesh", "yes", "yes (tri-planar)"],
  ["Dynamic objects", "no", "yes", "not yet"],
];

export function AboutModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6" role="dialog" aria-modal="true" aria-label="How RadLUT works">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative max-h-full w-full max-w-4xl overflow-y-auto rounded-3xl border border-white/10 bg-slate-950/95 p-5 text-slate-200 shadow-2xl sm:p-8">
        <button
          type="button"
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full bg-white/10 px-3 py-1 text-xs text-slate-300 hover:bg-white/20"
          aria-label="Close"
        >
          Close ✕
        </button>

        <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-amber-300">Research prototype</div>
        <h2 className="mt-1 text-2xl font-semibold tracking-tight text-white sm:text-3xl">Global illumination without lightmaps</h2>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-slate-300">
          A lightmap says <em>“the light for this point lives at (u, v) of this mesh’s unwrap.”</em> RadLUT says{" "}
          <em>“the light for this point lives at (cell, face) of the world.”</em> The stored data is the same kind of thing — a texture of baked irradiance — only the{" "}
          <strong className="text-white">address</strong> changes, and the address is computed from the position and normal the fragment shader already has. Nothing to unwrap, no
          seams, no per-mesh texel density, and a perfect hash makes the whole table a single, loop-free lookup.
        </p>

        <div className="mt-6 grid gap-5 md:grid-cols-2">
          <div className="space-y-4 rounded-2xl bg-white/[0.03] p-4">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">Offline (in a worker, here, in seconds)</h3>
            <Step n={1} title="Find the keys">
              Sample every rendered triangle and record which <code className="text-amber-200">(cell, face)</code> pairs it touches. Only occupied pairs get a tile, so
              memory follows surface area, not volume.
            </Step>
            <Step n={2} title="Project a lattice">
              Each tile is an N×N lattice of samples cast along the face axis onto the real surface (boxes and spheres alike). Buried samples are rejected, so furniture does
              not leak into the floor under it.
            </Step>
            <Step n={3} title="Path trace into 3 transfer channels">
              Sun, sky and lamp are accumulated separately with the full multi-bounce path. Colour bleeding from the red and green walls is already inside the table. Direct
              light is exact; the indirect part is denoised on the lattice.
            </Step>
            <Step n={4} title="Perfect-hash and pack">
              A hash-and-displace table maps every key to a unique atlas slot (no collisions, no key verification at runtime). Tiles are stored as RGB9E5 so hardware
              bilinear filtering works.
            </Step>
          </div>
          <div className="space-y-4 rounded-2xl bg-white/[0.03] p-4">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">Runtime (fragment shader)</h3>
            <pre className="overflow-x-auto rounded-xl bg-black/50 p-3 font-mono text-[10.5px] leading-relaxed text-emerald-200/90">{SNIPPET}</pre>
            <p className="text-[12px] leading-relaxed text-slate-400">
              Because each light has its own table and light transport is linear, <strong className="text-slate-200">colour, intensity and on/off are three multiplies</strong>.
              Try the sliders: the “rebakes” counter stays at zero while the bounce light off the floor patch tints the whole room.
            </p>
          </div>
        </div>

        <h3 className="mt-7 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">How it compares</h3>
        <div className="mt-2 overflow-x-auto rounded-2xl border border-white/10">
          <table className="w-full min-w-[560px] text-left text-[12px]">
            <thead className="bg-white/5 text-[11px] uppercase tracking-wider text-slate-400">
              <tr>
                <th className="px-3 py-2 font-medium" />
                <th className="px-3 py-2 font-medium">UV lightmap</th>
                <th className="px-3 py-2 font-medium">Probe volume</th>
                <th className="px-3 py-2 font-medium text-amber-300">RadLUT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {ROWS.map((r) => (
                <tr key={r[0]}>
                  <td className="px-3 py-2 text-slate-300">{r[0]}</td>
                  <td className="px-3 py-2 text-slate-400">{r[1]}</td>
                  <td className="px-3 py-2 text-slate-400">{r[2]}</td>
                  <td className={cn("px-3 py-2 font-medium text-amber-100")}>{r[3]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-emerald-400/20 bg-emerald-400/5 p-4">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-emerald-300">What the numbers say</h3>
            <ul className="mt-2 space-y-1.5 text-[12.5px] leading-relaxed text-slate-300">
              <li>• Lookup cost is constant: one tiny integer fetch plus one filtered fetch per light channel.</li>
              <li>• Error vs a path tracer is a few percent, measured at random points that are not lattice samples.</li>
              <li>• A perfect hash at 90% load is enough: no probing, no stored keys.</li>
              <li>• Tile size is a real knob: 5×5 is the sweet spot here; 2×2 quadruples texels, 9×9 wastes them on edges.</li>
            </ul>
          </div>
          <div className="rounded-2xl border border-rose-400/20 bg-rose-400/5 p-4">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-rose-300">What it does not do (yet)</h3>
            <ul className="mt-2 space-y-1.5 text-[12.5px] leading-relaxed text-slate-300">
              <li>• Static receivers only. Dynamic characters need a coarse second tier (same hash over air cells).</li>
              <li>• The sun direction is baked. Time of day means bake K sun keyframes and lerp the sun table.</li>
              <li>• Diffuse irradiance only: no normal-map response or glossy lobe. A dominant-direction channel is the natural extension.</li>
              <li>• A perfectly packed lightmap is still smaller; RadLUT trades that for no UVs and relightable channels.</li>
            </ul>
          </div>
        </div>

        <h3 className="mt-7 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">Things to try</h3>
        <ol className="mt-2 list-decimal space-y-1 pl-5 text-[13px] text-slate-400">
          <li>
            Press <strong className="text-slate-200">Compare</strong> and drag the divider: LUT on the left, live GPU path tracer of the same scene on the right.
          </li>
          <li>
            Switch to <strong className="text-slate-200">Cells</strong>: each colour is one hashed tile, each dot is one stored radiance sample.
          </li>
          <li>
            Turn the sun off and the lamp to blue: the red wall’s bounce changes colour with no rebake.
          </li>
          <li>
            Change the tile size to 2² or 9² and watch memory, tiles and error move in the inspector.
          </li>
        </ol>
      </div>
    </div>
  );
}
