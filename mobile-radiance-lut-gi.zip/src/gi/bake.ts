// RadLUT baker.
//
//   1. enumerate (cell, face) keys touched by the rendered surfaces         -> sparse set of tiles
//   2. every tile is an NxN lattice of radiance samples projected on the surface along the face axis
//   3. path trace the lattice samples (progressively, light split in 3 transfer channels)
//   4. denoise the indirect part on the lattice, add exact direct light
//   5. build a perfect hash  key -> atlas slot   and pack tiles into RGB9E5 atlases
//
import { buildMesh, bakedSurfaceArea, ROOM, DEFAULT_LIGHTS, type Mesh, type V3 } from "./scene";
import { buildPerfectHash, cellBits, lookupSlot, packRGB9E5, hash32, type PerfectHash } from "./hash";
import { axisCast, insideSolid, directAt, directFiltered, pathIndirect, seedRng, EPS, type AxisHit } from "./trace";

export interface BakeConfig {
  step: number; // lattice spacing in metres
  N: number; // texels per tile side
}

export interface LutLayout {
  step: number;
  cell: number;
  N: number;
  n: number;
  M: number;
  B: number;
  seed: number;
  SW: number; // tiles per atlas row
  atlasW: number;
  atlasH: number;
  GO: V3;
  disp: Uint16Array;
  dispW: number;
  dispH: number;
}

export interface BakeStats {
  entries: number;
  slots: number;
  load: number;
  corners: number;
  maxDisp: number;
  attempts: number;
  atlasBytes: number;
  dispBytes: number;
  totalBytes: number;
  area: number;
  lightmapBytes: number;
  volumeBytes: number;
  enumSamples: number;
  prepMs: number;
}

export interface Validation {
  points: number;
  meanRelErr: number;
  medianRelErr: number;
  p90RelErr: number;
  coverage: number;
}

const SW = 128;
const DISP_W = 256;

/** samples-per-lattice-point of every progressive pass (the table is usable after the first one) */
export const BAKE_PASSES = [8, 8, 16, 32, 64, 64];

export class RadBaker {
  readonly cfg: BakeConfig;
  readonly cell: number;
  readonly GO: V3;
  readonly mesh: Mesh;

  n = 0;
  corners = 0;
  totalSpp = 0;
  passIndex = 0;
  hash!: PerfectHash;
  stats!: BakeStats;

  private entryMap = new Map<number, number>();
  private ecx: number[] = [];
  private ecy: number[] = [];
  private ecz: number[] = [];
  private ef: number[] = [];
  private ecid!: Int32Array;
  private slotEntry!: Int32Array;

  private cpos!: Float64Array;
  private cnrm!: Float64Array;
  private direct!: Float32Array;
  private acc!: Float64Array;
  private nbr!: Int32Array;
  private final!: Float32Array;

  constructor(cfg: BakeConfig) {
    this.cfg = cfg;
    this.cell = cfg.step * (cfg.N - 1);
    this.GO = [0.137 * this.cell, 0.291 * this.cell, 0.419 * this.cell];
    this.mesh = buildMesh();
  }

  private keyNum(cx: number, cy: number, cz: number, f: number) {
    return (((cz + 512) * 1024 + (cy + 512)) * 1024 + (cx + 512)) * 8 + f;
  }

  // ---------------------------------------------------------------------------------------------
  prepare() {
    const t0 = performance.now();
    const { cell, GO } = this;
    const { N, step } = this.cfg;
    const { pos, nrm, mat, idx } = this.mesh;

    // ---- 1. enumerate keys ------------------------------------------------------------------
    const h = step / 3;
    const dil = 0.5 * h + 0.01;
    const cnt: number[] = [];
    const sp: number[] = []; // 3 per entry
    const sn: number[] = [];
    let enumSamples = 0;

    const register = (px: number, py: number, pz: number, nx: number, ny: number, nz: number) => {
      const p = [px, py, pz];
      const nv = [nx, ny, nz];
      for (let ax = 0; ax < 3; ax++) {
        const nn = nv[ax];
        if (nn * nn < 0.01) continue;
        const f = 2 * ax + (nn < 0 ? 1 : 0);
        const x0 = Math.floor((px - dil - GO[0]) / cell);
        const x1 = Math.floor((px + dil - GO[0]) / cell);
        const y0 = Math.floor((py - dil - GO[1]) / cell);
        const y1 = Math.floor((py + dil - GO[1]) / cell);
        const z0 = Math.floor((pz - dil - GO[2]) / cell);
        const z1 = Math.floor((pz + dil - GO[2]) / cell);
        for (let cz = z0; cz <= z1; cz++)
          for (let cy = y0; cy <= y1; cy++)
            for (let cx = x0; cx <= x1; cx++) {
              const key = this.keyNum(cx, cy, cz, f);
              let id = this.entryMap.get(key);
              if (id === undefined) {
                id = this.ecx.length;
                this.entryMap.set(key, id);
                this.ecx.push(cx);
                this.ecy.push(cy);
                this.ecz.push(cz);
                this.ef.push(f);
                cnt.push(0);
                sp.push(0, 0, 0);
                sn.push(0, 0, 0);
              }
              cnt[id]++;
              sp[id * 3] += p[0];
              sp[id * 3 + 1] += p[1];
              sp[id * 3 + 2] += p[2];
              sn[id * 3] += nx;
              sn[id * 3 + 1] += ny;
              sn[id * 3 + 2] += nz;
            }
        void p;
      }
    };

    for (let t = 0; t < idx.length; t += 3) {
      const i0 = idx[t];
      const i1 = idx[t + 1];
      const i2 = idx[t + 2];
      if (mat[i0] < 0) continue;
      const e1x = pos[i1 * 3] - pos[i0 * 3];
      const e1y = pos[i1 * 3 + 1] - pos[i0 * 3 + 1];
      const e1z = pos[i1 * 3 + 2] - pos[i0 * 3 + 2];
      const e2x = pos[i2 * 3] - pos[i0 * 3];
      const e2y = pos[i2 * 3 + 1] - pos[i0 * 3 + 1];
      const e2z = pos[i2 * 3 + 2] - pos[i0 * 3 + 2];
      const n1 = Math.max(1, Math.ceil(Math.hypot(e1x, e1y, e1z) / h));
      const n2 = Math.max(1, Math.ceil(Math.hypot(e2x, e2y, e2z) / h));
      for (let i = 0; i <= n1; i++) {
        const a = i / n1;
        for (let j = 0; j <= n2; j++) {
          const b = j / n2;
          if (a + b > 1 + 1e-9) continue;
          const w0 = 1 - a - b;
          const px = pos[i0 * 3] + e1x * a + e2x * b;
          const py = pos[i0 * 3 + 1] + e1y * a + e2y * b;
          const pz = pos[i0 * 3 + 2] + e1z * a + e2z * b;
          let nx = nrm[i0 * 3] * w0 + nrm[i1 * 3] * a + nrm[i2 * 3] * b;
          let ny = nrm[i0 * 3 + 1] * w0 + nrm[i1 * 3 + 1] * a + nrm[i2 * 3 + 1] * b;
          let nz = nrm[i0 * 3 + 2] * w0 + nrm[i1 * 3 + 2] * a + nrm[i2 * 3 + 2] * b;
          const il = 1 / Math.hypot(nx, ny, nz);
          nx *= il;
          ny *= il;
          nz *= il;
          register(px, py, pz, nx, ny, nz);
          enumSamples++;
        }
      }
    }
    const n = this.ecx.length;
    this.n = n;

    // ---- 2. perfect hash --------------------------------------------------------------------
    const bits = new Uint32Array(n);
    const faces = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      bits[i] = cellBits(this.ecx[i], this.ecy[i], this.ecz[i]);
      faces[i] = this.ef[i];
    }
    this.hash = buildPerfectHash(bits, faces, 0.9, 3);
    this.slotEntry = new Int32Array(this.hash.M).fill(-1);
    for (let i = 0; i < n; i++) {
      const s = this.hash.slotOf[i];
      if (lookupSlot(this.hash, bits[i], faces[i]) !== s) throw new Error("hash mismatch");
      this.slotEntry[s] = i;
    }

    // ---- 3. lattice corners -----------------------------------------------------------------
    const NN = N * N;
    this.ecid = new Int32Array(n * NN).fill(-1);
    const cornerMap = new Map<number, number>();
    const cpos: number[] = [0, 0, 0];
    const cnrm: number[] = [0, 1, 0];
    const cF: number[] = [0];
    const cI: number[] = [0];
    const cJ: number[] = [0];
    const cFree: boolean[] = [true]; // fallback samples are not part of the lattice (no denoiser neighbours)
    let thinFallbacks = 0;
    const hitOut: AxisHit = { h: 0, nx: 0, ny: 0, nz: 0 };
    const mar = 0.5 * step;
    const tol = 0.6 * cell;
    const nbCells = [0, 0, 0];

    for (let e = 0; e < n; e++) {
      const f = this.ef[e];
      const a = f >> 1;
      const u = (a + 1) % 3;
      const v = (a + 2) % 3;
      nbCells[0] = this.ecx[e];
      nbCells[1] = this.ecy[e];
      nbCells[2] = this.ecz[e];
      const slabLo = GO[a] + nbCells[a] * cell;
      const lo = slabLo - mar;
      const hi = slabLo + cell + mar;
      const href = sp[e * 3 + a] / cnt[e];
      const base = e * NN;
      for (let j = 0; j < N; j++) {
        for (let i = 0; i < N; i++) {
          const lu = GO[u] + nbCells[u] * cell + i * step;
          const lv = GO[v] + nbCells[v] * cell + j * step;
          if (!axisCast(f, lu, lv, lo, hi, href, tol, hitOut)) continue;
          const p = [0, 0, 0];
          p[u] = lu;
          p[v] = lv;
          p[a] = hitOut.h;
          if (insideSolid(p[0] + hitOut.nx * EPS, p[1] + hitOut.ny * EPS, p[2] + hitOut.nz * EPS)) continue;
          const I = nbCells[u] * (N - 1) + i;
          const J = nbCells[v] * (N - 1) + j;
          const Q = Math.round(hitOut.h * 1000) + 8192;
          const ckey = (((f * 4096 + (I + 2048)) * 4096 + (J + 2048)) * 16384) + Q;
          let cid = cornerMap.get(ckey);
          if (cid === undefined) {
            cid = cF.length;
            cornerMap.set(ckey, cid);
            cpos.push(p[0], p[1], p[2]);
            cnrm.push(hitOut.nx, hitOut.ny, hitOut.nz);
            cF.push(f);
            cI.push(I);
            cJ.push(J);
            cFree.push(false);
          }
          this.ecid[base + j * N + i] = cid;
        }
      }
      // Features thinner than the lattice step (table legs, ...) may miss every lattice point:
      // fall back to one sample at the tile's mean surface point so the face is not black.
      let anyValid = false;
      for (let k = 0; k < NN; k++) if (this.ecid[base + k] >= 0) anyValid = true;
      if (!anyValid) {
        const rx = sp[e * 3] / cnt[e];
        const ry = sp[e * 3 + 1] / cnt[e];
        const rz = sp[e * 3 + 2] / cnt[e];
        let qx = sn[e * 3];
        let qy = sn[e * 3 + 1];
        let qz = sn[e * 3 + 2];
        const ql = Math.hypot(qx, qy, qz) || 1;
        qx /= ql;
        qy /= ql;
        qz /= ql;
        if (!insideSolid(rx + qx * EPS, ry + qy * EPS, rz + qz * EPS)) {
          const cid = cF.length;
          cpos.push(rx, ry, rz);
          cnrm.push(qx, qy, qz);
          cF.push(f);
          cI.push(0);
          cJ.push(0);
          cFree.push(true);
          this.ecid.fill(cid, base, base + NN);
          thinFallbacks++;
        }
      }
      // fill invalid texels from valid neighbours (buried / off-surface lattice points)
      for (let it = 0; it < N; it++) {
        let changed = false;
        const snapshot = this.ecid.slice(base, base + NN);
        for (let j = 0; j < N; j++)
          for (let i = 0; i < N; i++) {
            if (snapshot[j * N + i] >= 0) continue;
            let c = -1;
            if (i > 0 && snapshot[j * N + i - 1] >= 0) c = snapshot[j * N + i - 1];
            else if (i < N - 1 && snapshot[j * N + i + 1] >= 0) c = snapshot[j * N + i + 1];
            else if (j > 0 && snapshot[(j - 1) * N + i] >= 0) c = snapshot[(j - 1) * N + i];
            else if (j < N - 1 && snapshot[(j + 1) * N + i] >= 0) c = snapshot[(j + 1) * N + i];
            if (c >= 0) {
              this.ecid[base + j * N + i] = c;
              changed = true;
            }
          }
        if (!changed) break;
      }
      for (let k = 0; k < NN; k++) if (this.ecid[base + k] < 0) this.ecid[base + k] = 0; // fully buried: black
    }

    const C = cF.length;
    this.corners = C;
    this.cpos = Float64Array.from(cpos);
    this.cnrm = Float64Array.from(cnrm);

    // ---- 4. lattice adjacency for the denoiser ---------------------------------------------
    const lat = new Map<number, number[]>();
    for (let c = 1; c < C; c++) {
      if (cFree[c]) continue;
      const k = (cF[c] * 4096 + (cI[c] + 2048)) * 4096 + (cJ[c] + 2048);
      const l = lat.get(k);
      if (l) l.push(c);
      else lat.set(k, [c]);
    }
    this.nbr = new Int32Array(C * 8).fill(-1);
    const offs = [
      [-1, 0],
      [1, 0],
      [0, -1],
      [0, 1],
      [-1, -1],
      [1, -1],
      [-1, 1],
      [1, 1],
    ];
    for (let c = 1; c < C; c++) {
      if (cFree[c]) continue;
      for (let o = 0; o < 8; o++) {
        const k = (cF[c] * 4096 + (cI[c] + offs[o][0] + 2048)) * 4096 + (cJ[c] + offs[o][1] + 2048);
        const l = lat.get(k);
        if (!l) continue;
        const expect = step * (o < 4 ? 1 : Math.SQRT2);
        let best = -1;
        let bd = expect * 1.5;
        for (const q of l) {
          const d = Math.hypot(
            this.cpos[q * 3] - this.cpos[c * 3],
            this.cpos[q * 3 + 1] - this.cpos[c * 3 + 1],
            this.cpos[q * 3 + 2] - this.cpos[c * 3 + 2],
          );
          const nd =
            this.cnrm[q * 3] * this.cnrm[c * 3] + this.cnrm[q * 3 + 1] * this.cnrm[c * 3 + 1] + this.cnrm[q * 3 + 2] * this.cnrm[c * 3 + 2];
          if (d < bd && nd > 0.8) {
            bd = d;
            best = q;
          }
        }
        this.nbr[c * 8 + o] = best;
      }
    }

    // ---- 5. exact direct light on every lattice point ---------------------------------------
    this.direct = new Float32Array(C * 9);
    this.acc = new Float64Array(C * 9);
    this.final = new Float32Array(C * 9);
    const d9 = new Float64Array(9);
    for (let c = 1; c < C; c++) {
      d9.fill(0);
      directFiltered(
        this.cpos[c * 3],
        this.cpos[c * 3 + 1],
        this.cpos[c * 3 + 2],
        this.cnrm[c * 3],
        this.cnrm[c * 3 + 1],
        this.cnrm[c * 3 + 2],
        cFree[c] ? 0.5 * step : 1.25 * step,
        d9,
      );
      for (let q = 0; q < 9; q++) this.direct[c * 9 + q] = d9[q];
    }
    this.final.set(this.direct);

    // ---- stats ------------------------------------------------------------------------------
    const M = this.hash.M;
    const rows = Math.ceil(M / SW);
    const atlasBytes = SW * N * rows * N * 4 * 3;
    const dispBytes = this.hash.B * 2;
    const area = bakedSurfaceArea(this.mesh);
    const vol = (ROOM.max[0] - ROOM.min[0]) * (ROOM.max[1] - ROOM.min[1]) * (ROOM.max[2] - ROOM.min[2]);
    this.stats = {
      entries: n,
      slots: M,
      load: n / M,
      corners: C - 1,
      maxDisp: this.hash.maxDisp,
      attempts: this.hash.attempts,
      atlasBytes,
      dispBytes,
      totalBytes: atlasBytes + dispBytes,
      area,
      lightmapBytes: (area / (step * step)) * 1.35 * 4 * 3,
      volumeBytes: (vol / (step * step * step)) * 6 * 4 * 3,
      enumSamples,
      prepMs: performance.now() - t0,
    };
    void thinFallbacks;
  }

  layout(): LutLayout {
    const { N, step } = this.cfg;
    const M = this.hash.M;
    const rows = Math.ceil(M / SW);
    const dispH = Math.ceil(this.hash.B / DISP_W);
    const disp = new Uint16Array(DISP_W * dispH);
    disp.set(this.hash.disp);
    return {
      step,
      cell: this.cell,
      N,
      n: this.n,
      M,
      B: this.hash.B,
      seed: this.hash.seed,
      SW,
      atlasW: SW * N,
      atlasH: rows * N,
      GO: this.GO,
      disp,
      dispW: DISP_W,
      dispH,
    };
  }

  // ---------------------------------------------------------------------------------------------
  runPass(spp: number, onProgress?: (f: number) => void) {
    const C = this.corners;
    const tmp = new Float64Array(9);
    const base = this.totalSpp;
    for (let c = 1; c < C; c++) {
      seedRng(Math.imul(c, 2654435761) ^ Math.imul(this.passIndex + 1, 0x9e3779b1));
      const ou = hash32(c * 7 + 1) / 4294967296;
      const ov = hash32(c * 13 + 5) / 4294967296;
      tmp.fill(0);
      pathIndirect(this.cpos[c * 3], this.cpos[c * 3 + 1], this.cpos[c * 3 + 2], this.cnrm[c * 3], this.cnrm[c * 3 + 1], this.cnrm[c * 3 + 2], spp, base, ou, ov, tmp);
      const o = c * 9;
      for (let q = 0; q < 9; q++) this.acc[o + q] += tmp[q];
      if (onProgress && (c & 255) === 0) onProgress(c / C);
    }
    this.totalSpp += spp;
    this.passIndex++;
    this.refresh();
  }

  /** denoise (lattice blur of the indirect part) + add exact direct light */
  private refresh() {
    const C = this.corners;
    const inv = 1 / this.totalSpp;
    let src = new Float32Array(C * 9);
    for (let i = 0; i < src.length; i++) src[i] = this.acc[i] * inv;
    const iters = this.totalSpp < 32 ? 2 : 1;
    for (let it = 0; it < iters; it++) {
      const dst = new Float32Array(C * 9);
      for (let c = 1; c < C; c++) {
        let w = 4;
        const o = c * 9;
        for (let q = 0; q < 9; q++) dst[o + q] = src[o + q] * 4;
        for (let k = 0; k < 8; k++) {
          const nb = this.nbr[c * 8 + k];
          if (nb < 0) continue;
          const wk = k < 4 ? 2 : 1;
          w += wk;
          for (let q = 0; q < 9; q++) dst[o + q] += src[nb * 9 + q] * wk;
        }
        const iw = 1 / w;
        for (let q = 0; q < 9; q++) dst[o + q] *= iw;
      }
      src = dst;
    }
    for (let i = 0; i < src.length; i++) this.final[i] = src[i] + this.direct[i];
  }

  /** pack the three transfer channels into RGB9E5 atlases (what the GPU samples) */
  pack(): Uint32Array[] {
    const { N } = this.cfg;
    const M = this.hash.M;
    const rows = Math.ceil(M / SW);
    const W = SW * N;
    const H = rows * N;
    const out = [new Uint32Array(W * H), new Uint32Array(W * H), new Uint32Array(W * H)];
    for (let e = 0; e < this.n; e++) {
      const slot = this.hash.slotOf[e];
      const tx = (slot % SW) * N;
      const ty = Math.floor(slot / SW) * N;
      for (let j = 0; j < N; j++)
        for (let i = 0; i < N; i++) {
          const cid = this.ecid[e * N * N + j * N + i];
          const o = cid * 9;
          const at = (ty + j) * W + tx + i;
          for (let ch = 0; ch < 3; ch++) {
            out[ch][at] = packRGB9E5(this.final[o + ch * 3], this.final[o + ch * 3 + 1], this.final[o + ch * 3 + 2]);
          }
        }
    }
    return out;
  }

  // ---------------------------------------------------------------------------------------------
  /** CPU mirror of the fragment shader lookup (float, un-packed). Returns false when a key is missing. */
  evalLut(px: number, py: number, pz: number, nx: number, ny: number, nz: number, out: Float64Array): boolean {
    const { N } = this.cfg;
    const nv = [nx, ny, nz];
    out.fill(0);
    let ws = 0;
    let ok = true;
    for (let ax = 0; ax < 3; ax++) {
      const w = nv[ax] * nv[ax];
      if (w <= 0.03) continue;
      const f = 2 * ax + (nv[ax] < 0 ? 1 : 0);
      const q = [(px - this.GO[0]) / this.cell, (py - this.GO[1]) / this.cell, (pz - this.GO[2]) / this.cell];
      const c = [Math.floor(q[0]), Math.floor(q[1]), Math.floor(q[2])];
      const fr = [q[0] - c[0], q[1] - c[1], q[2] - c[2]];
      if (!this.entryMap.has(this.keyNum(c[0], c[1], c[2], f))) ok = false;
      const slot = lookupSlot(this.hash, cellBits(c[0], c[1], c[2]), f);
      const e = this.slotEntry[slot];
      ws += w;
      if (e < 0) continue;
      const fu = fr[(ax + 1) % 3] * (N - 1);
      const fv = fr[(ax + 2) % 3] * (N - 1);
      const i0 = Math.min(Math.floor(fu), N - 2);
      const j0 = Math.min(Math.floor(fv), N - 2);
      const tu = fu - i0;
      const tv = fv - j0;
      const b = e * N * N;
      const c00 = this.ecid[b + j0 * N + i0] * 9;
      const c10 = this.ecid[b + j0 * N + i0 + 1] * 9;
      const c01 = this.ecid[b + (j0 + 1) * N + i0] * 9;
      const c11 = this.ecid[b + (j0 + 1) * N + i0 + 1] * 9;
      for (let k = 0; k < 9; k++) {
        const v0 = this.final[c00 + k] * (1 - tu) + this.final[c10 + k] * tu;
        const v1 = this.final[c01 + k] * (1 - tu) + this.final[c11 + k] * tu;
        out[k] += w * (v0 * (1 - tv) + v1 * tv);
      }
    }
    if (ws > 0) for (let k = 0; k < 9; k++) out[k] /= ws;
    return ok;
  }

  /** Compare the LUT against fresh high-sample path tracing at random held-out surface points. */
  validate(points = 160, spp = 768): Validation {
    const { pos, nrm, mat, idx } = this.mesh;
    const tris: number[] = [];
    const cum: number[] = [];
    let total = 0;
    for (let t = 0; t < idx.length; t += 3) {
      const i0 = idx[t];
      if (mat[i0] < 0) continue;
      const i1 = idx[t + 1];
      const i2 = idx[t + 2];
      const ax = pos[i1 * 3] - pos[i0 * 3];
      const ay = pos[i1 * 3 + 1] - pos[i0 * 3 + 1];
      const az = pos[i1 * 3 + 2] - pos[i0 * 3 + 2];
      const bx = pos[i2 * 3] - pos[i0 * 3];
      const by = pos[i2 * 3 + 1] - pos[i0 * 3 + 1];
      const bz = pos[i2 * 3 + 2] - pos[i0 * 3 + 2];
      total += 0.5 * Math.hypot(ay * bz - az * by, az * bx - ax * bz, ax * by - ay * bx);
      tris.push(t);
      cum.push(total);
    }
    seedRng(0xc0ffee);
    let s = 0x1234567;
    const rand = () => {
      s ^= s << 13;
      s ^= s >>> 17;
      s ^= s << 5;
      return (s >>> 0) / 4294967296;
    };
    const lut = new Float64Array(9);
    const gt = new Float64Array(9);
    const g = [DEFAULT_LIGHTS.sun, DEFAULT_LIGHTS.sky, DEFAULT_LIGHTS.lamp].map((l) => l.color.map((c) => c * l.intensity));
    const lum = (v: Float64Array) => {
      let L = 0;
      for (let ch = 0; ch < 3; ch++) L += 0.2126 * g[ch][0] * v[ch * 3] + 0.7152 * g[ch][1] * v[ch * 3 + 1] + 0.0722 * g[ch][2] * v[ch * 3 + 2];
      return L;
    };
    const errs: number[] = [];
    let covered = 0;
    let tested = 0;
    let sumAbs = 0;
    let sumGt = 0;
    let guard = 0;
    while (tested < points && guard++ < points * 20) {
      const r = rand() * total;
      let lo = 0;
      let hi = cum.length - 1;
      while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (cum[mid] < r) lo = mid + 1;
        else hi = mid;
      }
      const t = tris[lo];
      const i0 = idx[t];
      const i1 = idx[t + 1];
      const i2 = idx[t + 2];
      let a = rand();
      let b = rand();
      if (a + b > 1) {
        a = 1 - a;
        b = 1 - b;
      }
      const w0 = 1 - a - b;
      const px = pos[i0 * 3] * w0 + pos[i1 * 3] * a + pos[i2 * 3] * b;
      const py = pos[i0 * 3 + 1] * w0 + pos[i1 * 3 + 1] * a + pos[i2 * 3 + 1] * b;
      const pz = pos[i0 * 3 + 2] * w0 + pos[i1 * 3 + 2] * a + pos[i2 * 3 + 2] * b;
      let nx = nrm[i0 * 3] * w0 + nrm[i1 * 3] * a + nrm[i2 * 3] * b;
      let ny = nrm[i0 * 3 + 1] * w0 + nrm[i1 * 3 + 1] * a + nrm[i2 * 3 + 1] * b;
      let nz = nrm[i0 * 3 + 2] * w0 + nrm[i1 * 3 + 2] * a + nrm[i2 * 3 + 2] * b;
      const il = 1 / Math.hypot(nx, ny, nz);
      nx *= il;
      ny *= il;
      nz *= il;
      if (insideSolid(px + nx * EPS, py + ny * EPS, pz + nz * EPS)) continue; // buried face
      tested++;
      const ok = this.evalLut(px, py, pz, nx, ny, nz, lut);
      if (ok) covered++;
      gt.fill(0);
      directAt(px, py, pz, nx, ny, nz, gt);
      const ind = new Float64Array(9);
      pathIndirect(px, py, pz, nx, ny, nz, spp, 0, rand(), rand(), ind);
      for (let k = 0; k < 9; k++) gt[k] += ind[k] / spp;
      const a1 = lum(lut);
      const b1 = lum(gt);
      sumAbs += Math.abs(a1 - b1);
      sumGt += b1;
      errs.push(Math.abs(a1 - b1) / Math.max(b1, 1e-3));
    }
    errs.sort((x, y) => x - y);
    return {
      points: tested,
      meanRelErr: sumAbs / Math.max(sumGt, 1e-9),
      medianRelErr: errs[Math.floor(errs.length / 2)] ?? 0,
      p90RelErr: errs[Math.floor(errs.length * 0.9)] ?? 0,
      coverage: tested ? covered / tested : 1,
    };
  }
}
