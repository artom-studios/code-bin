// CPU path tracer for the analytic scene. Allocation-free hot loops (used inside the bake worker).
import { BOXES, SPHERES, SUN_DIR, LAMP_POS, skyInto } from "./scene";
import { hash32 } from "./hash";

const NB = BOXES.length;
const NS = SPHERES.length;
const bmin = new Float64Array(NB * 3);
const bmax = new Float64Array(NB * 3);
const balb = new Float64Array(NB * 3);
const sc = new Float64Array(NS * 4);
const salb = new Float64Array(NS * 3);
BOXES.forEach((b, i) => {
  for (let k = 0; k < 3; k++) {
    bmin[i * 3 + k] = b.min[k];
    bmax[i * 3 + k] = b.max[k];
    balb[i * 3 + k] = b.albedo[k];
  }
});
SPHERES.forEach((s, i) => {
  sc[i * 4] = s.center[0];
  sc[i * 4 + 1] = s.center[1];
  sc[i * 4 + 2] = s.center[2];
  sc[i * 4 + 3] = s.radius;
  for (let k = 0; k < 3; k++) salb[i * 3 + k] = s.albedo[k];
});

export const EPS = 3e-3;
export const MAX_BOUNCES = 4;
const INV_PI = 1 / Math.PI;
const SX = SUN_DIR[0];
const SY = SUN_DIR[1];
const SZ = SUN_DIR[2];

// ---- RNG -------------------------------------------------------------------------------------
let rs = 1;
export function seedRng(s: number) {
  rs = hash32(s) | 1;
}
function rnd(): number {
  rs ^= rs << 13;
  rs ^= rs >>> 17;
  rs ^= rs << 5;
  return (rs >>> 0) * 2.3283064365386963e-10;
}

// ---- hit scratch -----------------------------------------------------------------------------
const hit = { t: 0, nx: 0, ny: 0, nz: 0, ar: 0, ag: 0, ab: 0 };
let hitPrim = -1;
let hitAxis = 0;

function closest(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, tmax: number): boolean {
  let best = tmax;
  hitPrim = -1;
  const ix = 1 / (dx === 0 ? 1e-30 : dx);
  const iy = 1 / (dy === 0 ? 1e-30 : dy);
  const iz = 1 / (dz === 0 ? 1e-30 : dz);
  for (let i = 0; i < NB; i++) {
    const i3 = i * 3;
    let t1 = (bmin[i3] - ox) * ix;
    let t2 = (bmax[i3] - ox) * ix;
    const tnx = t1 < t2 ? t1 : t2;
    const tfx = t1 < t2 ? t2 : t1;
    t1 = (bmin[i3 + 1] - oy) * iy;
    t2 = (bmax[i3 + 1] - oy) * iy;
    const tny = t1 < t2 ? t1 : t2;
    const tfy = t1 < t2 ? t2 : t1;
    t1 = (bmin[i3 + 2] - oz) * iz;
    t2 = (bmax[i3 + 2] - oz) * iz;
    const tnz = t1 < t2 ? t1 : t2;
    const tfz = t1 < t2 ? t2 : t1;
    let tn = tnx;
    let ax = 0;
    if (tny > tn) {
      tn = tny;
      ax = 1;
    }
    if (tnz > tn) {
      tn = tnz;
      ax = 2;
    }
    let tf = tfx;
    if (tfy < tf) tf = tfy;
    if (tfz < tf) tf = tfz;
    if (tn < best && tn > 1e-5 && tn <= tf) {
      best = tn;
      hitPrim = i;
      hitAxis = ax;
    }
  }
  for (let i = 0; i < NS; i++) {
    const i4 = i * 4;
    const ocx = ox - sc[i4];
    const ocy = oy - sc[i4 + 1];
    const ocz = oz - sc[i4 + 2];
    const b = ocx * dx + ocy * dy + ocz * dz;
    const r = sc[i4 + 3];
    const c = ocx * ocx + ocy * ocy + ocz * ocz - r * r;
    const disc = b * b - c;
    if (disc > 0) {
      const t = -b - Math.sqrt(disc);
      if (t > 1e-5 && t < best) {
        best = t;
        hitPrim = NB + i;
      }
    }
  }
  if (hitPrim < 0) return false;
  hit.t = best;
  if (hitPrim < NB) {
    hit.nx = 0;
    hit.ny = 0;
    hit.nz = 0;
    if (hitAxis === 0) hit.nx = dx > 0 ? -1 : 1;
    else if (hitAxis === 1) hit.ny = dy > 0 ? -1 : 1;
    else hit.nz = dz > 0 ? -1 : 1;
    hit.ar = balb[hitPrim * 3];
    hit.ag = balb[hitPrim * 3 + 1];
    hit.ab = balb[hitPrim * 3 + 2];
  } else {
    const s = hitPrim - NB;
    const i4 = s * 4;
    const inv = 1 / sc[i4 + 3];
    hit.nx = (ox + dx * best - sc[i4]) * inv;
    hit.ny = (oy + dy * best - sc[i4 + 1]) * inv;
    hit.nz = (oz + dz * best - sc[i4 + 2]) * inv;
    hit.ar = salb[s * 3];
    hit.ag = salb[s * 3 + 1];
    hit.ab = salb[s * 3 + 2];
  }
  return true;
}

export function occluded(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, tmax: number): boolean {
  const ix = 1 / (dx === 0 ? 1e-30 : dx);
  const iy = 1 / (dy === 0 ? 1e-30 : dy);
  const iz = 1 / (dz === 0 ? 1e-30 : dz);
  for (let i = 0; i < NB; i++) {
    const i3 = i * 3;
    let t1 = (bmin[i3] - ox) * ix;
    let t2 = (bmax[i3] - ox) * ix;
    let tn = t1 < t2 ? t1 : t2;
    let tf = t1 < t2 ? t2 : t1;
    t1 = (bmin[i3 + 1] - oy) * iy;
    t2 = (bmax[i3 + 1] - oy) * iy;
    const tny = t1 < t2 ? t1 : t2;
    const tfy = t1 < t2 ? t2 : t1;
    if (tny > tn) tn = tny;
    if (tfy < tf) tf = tfy;
    t1 = (bmin[i3 + 2] - oz) * iz;
    t2 = (bmax[i3 + 2] - oz) * iz;
    const tnz = t1 < t2 ? t1 : t2;
    const tfz = t1 < t2 ? t2 : t1;
    if (tnz > tn) tn = tnz;
    if (tfz < tf) tf = tfz;
    if (tn <= tf && tn > 1e-5 && tn < tmax) return true;
  }
  for (let i = 0; i < NS; i++) {
    const i4 = i * 4;
    const ocx = ox - sc[i4];
    const ocy = oy - sc[i4 + 1];
    const ocz = oz - sc[i4 + 2];
    const b = ocx * dx + ocy * dy + ocz * dz;
    const r = sc[i4 + 3];
    const c = ocx * ocx + ocy * ocy + ocz * ocz - r * r;
    const disc = b * b - c;
    if (disc > 0) {
      const t = -b - Math.sqrt(disc);
      if (t > 1e-5 && t < tmax) return true;
    }
  }
  return false;
}

/** True when the point lies strictly inside a solid primitive (used to reject buried lattice samples). */
export function insideSolid(x: number, y: number, z: number): boolean {
  for (let i = 0; i < NB; i++) {
    const i3 = i * 3;
    if (
      x > bmin[i3] + 1e-4 &&
      x < bmax[i3] - 1e-4 &&
      y > bmin[i3 + 1] + 1e-4 &&
      y < bmax[i3 + 1] - 1e-4 &&
      z > bmin[i3 + 2] + 1e-4 &&
      z < bmax[i3 + 2] - 1e-4
    )
      return true;
  }
  for (let i = 0; i < NS; i++) {
    const i4 = i * 4;
    const dx = x - sc[i4];
    const dy = y - sc[i4 + 1];
    const dz = z - sc[i4 + 2];
    const r = sc[i4 + 3] - 1e-4;
    if (dx * dx + dy * dy + dz * dz < r * r) return true;
  }
  return false;
}

export interface AxisHit {
  h: number;
  nx: number;
  ny: number;
  nz: number;
}

/**
 * Cast an axis-aligned ray through one LUT lattice column of face `f`.
 * lu/lv: lateral world coords (axes (a+1)%3, (a+2)%3). lo/hi: accepted range along the axis.
 * Of all front-facing surfaces in range we keep the one closest to `href` (the cell's reference height).
 */
export function axisCast(f: number, lu: number, lv: number, lo: number, hi: number, href: number, tol: number, out: AxisHit): boolean {
  const a = f >> 1;
  const positive = (f & 1) === 0;
  const u = (a + 1) % 3;
  const v = (a + 2) % 3;
  let best = Infinity;
  for (let i = 0; i < NB; i++) {
    const i3 = i * 3;
    if (lu < bmin[i3 + u] || lu > bmax[i3 + u] || lv < bmin[i3 + v] || lv > bmax[i3 + v]) continue;
    const h = positive ? bmax[i3 + a] : bmin[i3 + a];
    if (h < lo || h > hi) continue;
    const d = Math.abs(h - href);
    if (d < best) {
      best = d;
      out.h = h;
      out.nx = 0;
      out.ny = 0;
      out.nz = 0;
      if (a === 0) out.nx = positive ? 1 : -1;
      else if (a === 1) out.ny = positive ? 1 : -1;
      else out.nz = positive ? 1 : -1;
    }
  }
  for (let i = 0; i < NS; i++) {
    const i4 = i * 4;
    const r = sc[i4 + 3];
    const du = lu - sc[i4 + u];
    const dv = lv - sc[i4 + v];
    const d2 = du * du + dv * dv;
    if (d2 >= r * r) continue;
    const s = Math.sqrt(r * r - d2);
    const h = sc[i4 + a] + (positive ? s : -s);
    if (h < lo || h > hi) continue;
    const d = Math.abs(h - href);
    if (d < best) {
      best = d;
      out.h = h;
      const n = [0, 0, 0];
      n[u] = du / r;
      n[v] = dv / r;
      n[a] = (positive ? s : -s) / r;
      out.nx = n[0];
      out.ny = n[1];
      out.nz = n[2];
    }
  }
  return best <= tol;
}

// ---- lighting --------------------------------------------------------------------------------
// Output layout (9 floats): [0..2] sun RGB, [3..5] sky RGB, [6..8] lamp RGB.  Unit lights (S = 1, I = 1).
// Values are "radiance for albedo 1", i.e. irradiance / pi.

/** Exact (noise free) direct lighting from the sun and the point lamp at a surface point. Adds into out. */
export function directAt(px: number, py: number, pz: number, nx: number, ny: number, nz: number, out: Float64Array | Float32Array) {
  const ox = px + nx * EPS;
  const oy = py + ny * EPS;
  const oz = pz + nz * EPS;
  const cs = nx * SX + ny * SY + nz * SZ;
  if (cs > 0 && !occluded(ox, oy, oz, SX, SY, SZ, 1e9)) {
    const v = cs * INV_PI;
    out[0] += v;
    out[1] += v;
    out[2] += v;
  }
  const lx = LAMP_POS[0] - ox;
  const ly = LAMP_POS[1] - oy;
  const lz = LAMP_POS[2] - oz;
  const r2 = lx * lx + ly * ly + lz * lz;
  const r = Math.sqrt(r2);
  const cl = (nx * lx + ny * ly + nz * lz) / r;
  if (cl > 0 && !occluded(ox, oy, oz, lx / r, ly / r, lz / r, r)) {
    const v = (cl * INV_PI) / r2;
    out[6] += v;
    out[7] += v;
    out[8] += v;
  }
}

// 9-tap tent weights (end taps are zero -> 7x7 effective visibility samples per lattice point)
const TAPS = 9;
const HALF = (TAPS - 1) / 2;
const TENT = Array.from({ length: TAPS }, (_, i) => 1 - Math.abs(i - HALF) / HALF);

/**
 * Direct light with visibility pre-filtered over the lattice-point footprint (tent filter of radius `radius`).
 * Without this, bilinear filtering of a hard 0/1 shadow edge produces stair-steps.
 * Cosine / distance terms are evaluated exactly at the point; only visibility is filtered. Adds into out.
 */
export function directFiltered(
  px: number,
  py: number,
  pz: number,
  nx: number,
  ny: number,
  nz: number,
  radius: number,
  out: Float64Array | Float32Array,
) {
  const cs = nx * SX + ny * SY + nz * SZ;
  const lx0 = LAMP_POS[0] - px;
  const ly0 = LAMP_POS[1] - py;
  const lz0 = LAMP_POS[2] - pz;
  const r2 = lx0 * lx0 + ly0 * ly0 + lz0 * lz0;
  const cl = (nx * lx0 + ny * ly0 + nz * lz0) / Math.sqrt(r2);
  if (cs <= 0 && cl <= 0) return;
  // tangent frame
  let tx: number, ty: number, tz: number;
  if (Math.abs(nx) > 0.9) {
    tx = -nz;
    ty = 0;
    tz = nx;
  } else {
    tx = 0;
    ty = nz;
    tz = -ny;
  }
  const tl = 1 / Math.sqrt(tx * tx + ty * ty + tz * tz);
  tx *= tl;
  ty *= tl;
  tz *= tl;
  const bx = ny * tz - nz * ty;
  const by = nz * tx - nx * tz;
  const bz = nx * ty - ny * tx;
  let wSum = 0;
  let sunVis = 0;
  let lampVis = 0;
  for (let j = 0; j < TAPS; j++) {
    const wj = TENT[j];
    if (wj === 0) continue;
    const oj = ((j - HALF) / HALF) * radius;
    for (let i = 0; i < TAPS; i++) {
      const wi = TENT[i];
      if (wi === 0) continue;
      const oi = ((i - HALF) / HALF) * radius;
      const ox = px + tx * oi + bx * oj + nx * EPS;
      const oy = py + ty * oi + by * oj + ny * EPS;
      const oz = pz + tz * oi + bz * oj + nz * EPS;
      if (insideSolid(ox, oy, oz)) continue; // footprint pokes into a neighbouring solid
      const w = wi * wj;
      wSum += w;
      if (cs > 0 && !occluded(ox, oy, oz, SX, SY, SZ, 1e9)) sunVis += w;
      if (cl > 0) {
        const lx = LAMP_POS[0] - ox;
        const ly = LAMP_POS[1] - oy;
        const lz = LAMP_POS[2] - oz;
        const l = Math.sqrt(lx * lx + ly * ly + lz * lz);
        if (!occluded(ox, oy, oz, lx / l, ly / l, lz / l, l)) lampVis += w;
      }
    }
  }
  if (wSum <= 0) return;
  if (cs > 0) {
    const v = ((cs * INV_PI) * sunVis) / wSum;
    out[0] += v;
    out[1] += v;
    out[2] += v;
  }
  if (cl > 0) {
    const v = ((cl * INV_PI) / r2) * (lampVis / wSum);
    out[6] += v;
    out[7] += v;
    out[8] += v;
  }
}

const tmpSky = new Float64Array(3);

/** Sum (not mean) of `spp` indirect path samples. Uses an R2 sequence for the first bounce. */
export function pathIndirect(
  px: number,
  py: number,
  pz: number,
  nx: number,
  ny: number,
  nz: number,
  spp: number,
  kBase: number,
  ou: number,
  ov: number,
  out: Float64Array,
) {
  for (let s = 0; s < spp; s++) {
    const k = kBase + s;
    let r1 = (ou + k * 0.7548776662466927) % 1;
    let r2 = (ov + k * 0.5698402909980532) % 1;
    let cx = px + nx * EPS;
    let cy = py + ny * EPS;
    let cz = pz + nz * EPS;
    let cnx = nx;
    let cny = ny;
    let cnz = nz;
    let tr = 1;
    let tg = 1;
    let tb = 1;
    for (let b = 0; b < MAX_BOUNCES; b++) {
      // cosine weighted direction around (cn)
      let tx: number, ty: number, tz: number;
      if (Math.abs(cnx) > 0.9) {
        tx = -cnz;
        ty = 0;
        tz = cnx;
      } else {
        tx = 0;
        ty = cnz;
        tz = -cny;
      }
      const tl = 1 / Math.sqrt(tx * tx + ty * ty + tz * tz);
      tx *= tl;
      ty *= tl;
      tz *= tl;
      const bx = cny * tz - cnz * ty;
      const by = cnz * tx - cnx * tz;
      const bz = cnx * ty - cny * tx;
      const phi = 6.283185307179586 * r1;
      const sr = Math.sqrt(r2);
      const cp = Math.cos(phi) * sr;
      const sp = Math.sin(phi) * sr;
      const cz1 = Math.sqrt(1 - r2);
      const dx = tx * cp + bx * sp + cnx * cz1;
      const dy = ty * cp + by * sp + cny * cz1;
      const dz = tz * cp + bz * sp + cnz * cz1;

      if (!closest(cx, cy, cz, dx, dy, dz, 1e9)) {
        skyInto(dx, dy, dz, tmpSky);
        out[3] += tr * tmpSky[0];
        out[4] += tg * tmpSky[1];
        out[5] += tb * tmpSky[2];
        break;
      }
      const hx = cx + dx * hit.t;
      const hy = cy + dy * hit.t;
      const hz = cz + dz * hit.t;
      cnx = hit.nx;
      cny = hit.ny;
      cnz = hit.nz;
      tr *= hit.ar;
      tg *= hit.ag;
      tb *= hit.ab;
      cx = hx + cnx * EPS;
      cy = hy + cny * EPS;
      cz = hz + cnz * EPS;

      // next event estimation at the hit
      const cs = cnx * SX + cny * SY + cnz * SZ;
      if (cs > 0 && !occluded(cx, cy, cz, SX, SY, SZ, 1e9)) {
        const v = cs * INV_PI;
        out[0] += tr * v;
        out[1] += tg * v;
        out[2] += tb * v;
      }
      const lx = LAMP_POS[0] - cx;
      const ly = LAMP_POS[1] - cy;
      const lz = LAMP_POS[2] - cz;
      const l2 = lx * lx + ly * ly + lz * lz;
      const l = Math.sqrt(l2);
      const cl = (cnx * lx + cny * ly + cnz * lz) / l;
      if (cl > 0 && !occluded(cx, cy, cz, lx / l, ly / l, lz / l, l)) {
        const v = (cl * INV_PI) / l2;
        out[6] += tr * v;
        out[7] += tg * v;
        out[8] += tb * v;
      }
      r1 = rnd();
      r2 = rnd();
    }
  }
}
