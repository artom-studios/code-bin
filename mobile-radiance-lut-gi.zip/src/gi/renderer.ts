import { buildMesh, type V3 } from "./scene";
import { FlyCamera } from "./camera";
import { FULLSCREEN_VS, SKY_FS, SCENE_VS, SCENE_FS, REF_FS, COMPOSITE_FS } from "./shaders";
import type { LutLayout } from "./bake";

export interface RenderParams {
  mode: number; // 0 final, 1 irradiance only, 2 cells, 3 no GI
  exposure: number;
  gains: [V3, V3, V3]; // colour * intensity per transfer channel (sun, sky, lamp)
  skyGain: V3;
  bulb: V3;
  refOn: boolean;
  split: number; // fraction of the width (from the left) that shows the LUT; the rest shows the reference
}

export interface FrameStats {
  fps: number;
  refSamples: number;
}

class Prog {
  p: WebGLProgram;
  private cache = new Map<string, WebGLUniformLocation | null>();
  constructor(
    private gl: WebGL2RenderingContext,
    vs: string,
    fs: string,
    attribs: string[] = [],
  ) {
    const mk = (type: number, src: string) => {
      const s = gl.createShader(type)!;
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
        const log = gl.getShaderInfoLog(s);
        const numbered = src
          .split("\n")
          .map((l, i) => `${i + 1}: ${l}`)
          .join("\n");
        throw new Error(`shader compile failed:\n${log}\n${numbered.slice(0, 6000)}`);
      }
      return s;
    };
    this.p = gl.createProgram()!;
    gl.attachShader(this.p, mk(gl.VERTEX_SHADER, vs));
    gl.attachShader(this.p, mk(gl.FRAGMENT_SHADER, fs));
    attribs.forEach((a, i) => gl.bindAttribLocation(this.p, i, a));
    gl.linkProgram(this.p);
    if (!gl.getProgramParameter(this.p, gl.LINK_STATUS)) throw new Error("link failed: " + gl.getProgramInfoLog(this.p));
  }
  use() {
    this.gl.useProgram(this.p);
  }
  u(name: string) {
    let l = this.cache.get(name);
    if (l === undefined) {
      l = this.gl.getUniformLocation(this.p, name);
      this.cache.set(name, l);
    }
    return l;
  }
}

export class RadRenderer {
  readonly cam = new FlyCamera();
  readonly gl: WebGL2RenderingContext;
  refSupported = false;
  lutReady = false;
  params: RenderParams = {
    mode: 0,
    exposure: 1,
    gains: [
      [1, 1, 1],
      [1, 1, 1],
      [1, 1, 1],
    ],
    skyGain: [1, 1, 1],
    bulb: [1, 1, 1],
    refOn: false,
    split: 0.5,
  };
  onStats?: (s: FrameStats) => void;
  onInteract?: () => void;

  private canvas: HTMLCanvasElement;
  private sky: Prog;
  private scene: Prog;
  private ref: Prog;
  private comp: Prog;
  private emptyVao: WebGLVertexArrayObject;
  private meshVao: WebGLVertexArrayObject;
  private indexCount: number;

  private layout: LutLayout | null = null;
  private dispTex: WebGLTexture;
  private atlasTex: WebGLTexture[];

  private refTex: WebGLTexture[] = [];
  private refFbo: WebGLFramebuffer[] = [];
  private refW = 0;
  private refH = 0;
  private refCur = 0;
  private refFrame = 0;
  private refKey = "";
  private readonly REF_MAX = 1200;

  private raf = 0;
  private last = performance.now();
  private fpsAcc = 0;
  private fpsN = 0;
  private statT = 0;
  private disposed = false;
  private cleanup: (() => void)[] = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const gl = canvas.getContext("webgl2", { antialias: true, alpha: false, powerPreference: "high-performance" });
    if (!gl) throw new Error("WebGL2 is not available in this browser.");
    this.gl = gl;

    this.sky = new Prog(gl, FULLSCREEN_VS, SKY_FS);
    this.scene = new Prog(gl, SCENE_VS, SCENE_FS, ["aPos", "aNrm", "aAlb", "aMat"]);
    this.ref = new Prog(gl, FULLSCREEN_VS, REF_FS);
    this.comp = new Prog(gl, FULLSCREEN_VS, COMPOSITE_FS);
    this.emptyVao = gl.createVertexArray()!;

    // mesh
    const mesh = buildMesh();
    this.meshVao = gl.createVertexArray()!;
    gl.bindVertexArray(this.meshVao);
    const attr = (loc: number, data: Float32Array, size: number) => {
      const b = gl.createBuffer()!;
      gl.bindBuffer(gl.ARRAY_BUFFER, b);
      gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0);
    };
    attr(0, mesh.pos, 3);
    attr(1, mesh.nrm, 3);
    attr(2, mesh.alb, 3);
    attr(3, mesh.mat, 1);
    const ib = gl.createBuffer()!;
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, mesh.idx, gl.STATIC_DRAW);
    this.indexCount = mesh.idx.length;
    gl.bindVertexArray(null);

    // LUT textures
    this.dispTex = gl.createTexture()!;
    this.atlasTex = [gl.createTexture()!, gl.createTexture()!, gl.createTexture()!];

    this.refSupported = !!(gl.getExtension("EXT_color_buffer_float") || gl.getExtension("EXT_color_buffer_half_float"));

    this.bindInput();
    const ro = new ResizeObserver(() => this.resize());
    ro.observe(canvas);
    this.cleanup.push(() => ro.disconnect());
    this.resize();
    this.raf = requestAnimationFrame(this.frame);
  }

  // -------------------------------------------------------------------------------------------
  setParams(p: Partial<RenderParams>) {
    this.params = { ...this.params, ...p };
  }

  setLUT(layout: LutLayout | null, atlases: Uint32Array[]) {
    const gl = this.gl;
    if (layout) {
      this.layout = layout;
      gl.bindTexture(gl.TEXTURE_2D, this.dispTex);
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.R16UI, layout.dispW, layout.dispH, 0, gl.RED_INTEGER, gl.UNSIGNED_SHORT, layout.disp);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 4);
    }
    if (!this.layout) return;
    for (let ch = 0; ch < 3; ch++) {
      gl.bindTexture(gl.TEXTURE_2D, this.atlasTex[ch]);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB9_E5, this.layout.atlasW, this.layout.atlasH, 0, gl.RGB, gl.UNSIGNED_INT_5_9_9_9_REV, atlases[ch]);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    }
    this.lutReady = true;
    this.refFrame = 0; // reference does not depend on the LUT, but keep views in sync
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.cleanup.forEach((f) => f());
  }

  // -------------------------------------------------------------------------------------------
  private W = 2;
  private H = 2;

  private resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(2, Math.floor(this.canvas.clientWidth * dpr));
    const h = Math.max(2, Math.floor(this.canvas.clientHeight * dpr));
    if (w !== this.W || h !== this.H || this.canvas.width !== w) {
      this.W = w;
      this.H = h;
      this.canvas.width = w;
      this.canvas.height = h;
    }
  }

  private bindInput() {
    const c = this.canvas;
    let dragging = false;
    let lx = 0;
    let ly = 0;
    const down = (e: PointerEvent) => {
      dragging = true;
      lx = e.clientX;
      ly = e.clientY;
      c.setPointerCapture(e.pointerId);
      this.onInteract?.();
    };
    const move = (e: PointerEvent) => {
      if (!dragging) return;
      this.cam.look(e.clientX - lx, e.clientY - ly);
      lx = e.clientX;
      ly = e.clientY;
    };
    const up = (e: PointerEvent) => {
      dragging = false;
      if (c.hasPointerCapture(e.pointerId)) c.releasePointerCapture(e.pointerId);
    };
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      this.cam.dolly(-e.deltaY * 0.0025);
      this.onInteract?.();
    };
    const kd = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === "INPUT" || (e.target as HTMLElement)?.tagName === "SELECT") return;
      const k = e.key.toLowerCase();
      this.cam.keys.add(k);
      if (e.shiftKey) this.cam.keys.add("shift");
      if (["w", "a", "s", "d", "q", "e", "arrowup", "arrowdown", "arrowleft", "arrowright"].includes(k)) this.onInteract?.();
    };
    const ku = (e: KeyboardEvent) => {
      this.cam.keys.delete(e.key.toLowerCase());
      if (!e.shiftKey) this.cam.keys.delete("shift");
    };
    const blur = () => this.cam.keys.clear();
    c.addEventListener("pointerdown", down);
    c.addEventListener("pointermove", move);
    c.addEventListener("pointerup", up);
    c.addEventListener("pointercancel", up);
    c.addEventListener("wheel", wheel, { passive: false });
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    window.addEventListener("blur", blur);
    this.cleanup.push(() => {
      c.removeEventListener("pointerdown", down);
      c.removeEventListener("pointermove", move);
      c.removeEventListener("pointerup", up);
      c.removeEventListener("pointercancel", up);
      c.removeEventListener("wheel", wheel);
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      window.removeEventListener("blur", blur);
    });
  }

  private ensureRefTargets(w: number, h: number) {
    const gl = this.gl;
    if (this.refW === w && this.refH === h && this.refTex.length) return true;
    this.refTex.forEach((t) => gl.deleteTexture(t));
    this.refFbo.forEach((f) => gl.deleteFramebuffer(f));
    this.refTex = [];
    this.refFbo = [];
    for (let i = 0; i < 2; i++) {
      const t = gl.createTexture()!;
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, w, h, 0, gl.RGBA, gl.HALF_FLOAT, null);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      const f = gl.createFramebuffer()!;
      gl.bindFramebuffer(gl.FRAMEBUFFER, f);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
      if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) {
        this.refSupported = false;
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        return false;
      }
      this.refTex.push(t);
      this.refFbo.push(f);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    this.refW = w;
    this.refH = h;
    this.refFrame = 0;
    return true;
  }

  private setCameraUniforms(p: Prog, aspect: number) {
    const gl = this.gl;
    const { f, r, u } = this.cam.basis();
    gl.uniform3f(p.u("uCamR"), r[0], r[1], r[2]);
    gl.uniform3f(p.u("uCamU"), u[0], u[1], u[2]);
    gl.uniform3f(p.u("uCamF"), f[0], f[1], f[2]);
    gl.uniform1f(p.u("uTanHalf"), Math.tan(this.cam.fov / 2));
    gl.uniform1f(p.u("uAspect"), aspect);
  }

  private frame = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.frame);
    const dt = Math.min(0.1, (now - this.last) / 1000);
    this.last = now;
    this.fpsAcc += dt;
    this.fpsN++;
    this.statT += dt;
    this.cam.update(dt);
    this.resize();
    try {
      this.draw();
    } catch (e) {
      console.error(e);
    }
    if (this.statT > 0.5) {
      this.onStats?.({ fps: this.fpsN / this.fpsAcc, refSamples: this.refFrame });
      this.fpsAcc = 0;
      this.fpsN = 0;
      this.statT = 0;
    }
  };

  private draw() {
    const gl = this.gl;
    const { W, H } = this;
    const P = this.params;
    const aspect = W / H;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, W, H);
    gl.clearColor(0, 0, 0, 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // --- sky
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.CULL_FACE);
    this.sky.use();
    this.setCameraUniforms(this.sky, aspect);
    gl.uniform2f(this.sky.u("uRes"), W, H);
    gl.uniform1f(this.sky.u("uExposure"), P.exposure);
    gl.uniform3f(this.sky.u("uSkyGain"), P.skyGain[0], P.skyGain[1], P.skyGain[2]);
    gl.bindVertexArray(this.emptyVao);
    gl.drawArrays(gl.TRIANGLES, 0, 3);

    // --- scene with the radiance LUT
    if (this.lutReady && this.layout) {
      const L = this.layout;
      gl.enable(gl.DEPTH_TEST);
      gl.enable(gl.CULL_FACE);
      gl.cullFace(gl.BACK);
      const s = this.scene;
      s.use();
      gl.uniformMatrix4fv(s.u("uVP"), false, this.cam.viewProj(aspect));
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.dispTex);
      for (let i = 0; i < 3; i++) {
        gl.activeTexture(gl.TEXTURE1 + i);
        gl.bindTexture(gl.TEXTURE_2D, this.atlasTex[i]);
      }
      gl.uniform1i(s.u("uDisp"), 0);
      gl.uniform1i(s.u("uAtlas0"), 1);
      gl.uniform1i(s.u("uAtlas1"), 2);
      gl.uniform1i(s.u("uAtlas2"), 3);
      gl.uniform3f(s.u("uGO"), L.GO[0], L.GO[1], L.GO[2]);
      gl.uniform1f(s.u("uCell"), L.cell);
      gl.uniform1f(s.u("uTileN"), L.N);
      gl.uniform2f(s.u("uAtlasSize"), L.atlasW, L.atlasH);
      gl.uniform1ui(s.u("uM"), L.M);
      gl.uniform1ui(s.u("uB"), L.B);
      gl.uniform1ui(s.u("uSeed"), L.seed);
      gl.uniform1ui(s.u("uSW"), L.SW);
      gl.uniform3f(s.u("uGain0"), P.gains[0][0], P.gains[0][1], P.gains[0][2]);
      gl.uniform3f(s.u("uGain1"), P.gains[1][0], P.gains[1][1], P.gains[1][2]);
      gl.uniform3f(s.u("uGain2"), P.gains[2][0], P.gains[2][1], P.gains[2][2]);
      gl.uniform1i(s.u("uMode"), P.mode);
      gl.uniform1f(s.u("uExposure"), P.exposure);
      gl.uniform3f(s.u("uBulb"), P.bulb[0], P.bulb[1], P.bulb[2]);
      gl.bindVertexArray(this.meshVao);
      gl.drawElements(gl.TRIANGLES, this.indexCount, gl.UNSIGNED_INT, 0);
      gl.bindVertexArray(null);
      gl.activeTexture(gl.TEXTURE0);
    }

    // --- reference path tracer (right side of the split)
    if (P.refOn && this.refSupported) {
      const rw = Math.max(2, Math.floor(W * 0.5));
      const rh = Math.max(2, Math.floor(H * 0.5));
      if (!this.ensureRefTargets(rw, rh)) return;
      const key = [this.cam.version, W, H, JSON.stringify(P.gains), JSON.stringify(P.skyGain), JSON.stringify(P.bulb)].join("|");
      if (key !== this.refKey) {
        this.refKey = key;
        this.refFrame = 0;
      }
      if (this.refFrame < this.REF_MAX) {
        this.refFrame++;
        const src = this.refCur;
        const dst = 1 - this.refCur;
        gl.bindFramebuffer(gl.FRAMEBUFFER, this.refFbo[dst]);
        gl.viewport(0, 0, rw, rh);
        gl.disable(gl.DEPTH_TEST);
        gl.disable(gl.CULL_FACE);
        const r = this.ref;
        r.use();
        this.setCameraUniforms(r, aspect);
        const pos = this.cam.pos;
        gl.uniform3f(r.u("uCamPos"), pos[0], pos[1], pos[2]);
        gl.uniform2f(r.u("uRes"), rw, rh);
        gl.uniform1f(r.u("uFrame"), this.refFrame);
        gl.uniform3f(r.u("uSunGain"), P.gains[0][0], P.gains[0][1], P.gains[0][2]);
        gl.uniform3f(r.u("uSkyGain"), P.gains[1][0], P.gains[1][1], P.gains[1][2]);
        gl.uniform3f(r.u("uLampGain"), P.gains[2][0], P.gains[2][1], P.gains[2][2]);
        gl.uniform3f(r.u("uBulb"), P.bulb[0], P.bulb[1], P.bulb[2]);
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, this.refTex[src]);
        gl.uniform1i(r.u("uPrev"), 0);
        gl.bindVertexArray(this.emptyVao);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
        this.refCur = dst;
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        gl.viewport(0, 0, W, H);
      }
      const c = this.comp;
      c.use();
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.refTex[this.refCur]);
      gl.uniform1i(c.u("uTex"), 0);
      gl.uniform2f(c.u("uRes"), W, H);
      gl.uniform1f(c.u("uSplitPx"), P.split * W);
      gl.uniform1f(c.u("uExposure"), P.exposure);
      gl.bindVertexArray(this.emptyVao);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    }
  }
}
