// Perfect hashing for the radiance LUT.
//
// key  = (cell.x, cell.y, cell.z, face)          -- world-space, no UVs
// slot = (hash2(h0 + disp[h0 % B] * K)) % M       -- "hash & displace" (CHD style), collision free by construction
//
// The same integer ops are reproduced bit-for-bit in GLSL (uint arithmetic wraps mod 2^32).

export const KMUL = 0x9e3779b1;
export const KADD = 0x7f4a7c15;
export const CELL_BIAS = 512;

export function hash32(x: number): number {
  x >>>= 0;
  x ^= x >>> 16;
  x = Math.imul(x, 0x7feb352d) >>> 0;
  x ^= x >>> 15;
  x = Math.imul(x, 0x846ca68b) >>> 0;
  x ^= x >>> 16;
  return x >>> 0;
}

export function cellBits(cx: number, cy: number, cz: number): number {
  return ((cx + CELL_BIAS) & 1023) | (((cy + CELL_BIAS) & 1023) << 10) | (((cz + CELL_BIAS) & 1023) << 20);
}

export function baseHash(bits: number, face: number, seed: number): number {
  return hash32((bits ^ hash32((Math.imul(face, KMUL) + seed) >>> 0)) >>> 0);
}

export function slotFrom(h0: number, d: number, M: number): number {
  return hash32((h0 + Math.imul(d, KMUL) + KADD) >>> 0) % M;
}

export interface PerfectHash {
  seed: number;
  M: number; // number of slots in the data atlas
  B: number; // number of displacement buckets
  disp: Uint16Array; // length B
  slotOf: Int32Array; // slot per input key
  maxDisp: number;
  attempts: number;
}

export function buildPerfectHash(bits: Uint32Array, faces: Uint8Array, load = 0.9, lambda = 3): PerfectHash {
  const n = bits.length;
  const M = Math.max(8, Math.ceil(n / load));
  const B = Math.max(1, Math.ceil(n / lambda));

  for (let attempt = 0; attempt < 48; attempt++) {
    const seed = (0xa511e9b3 + Math.imul(attempt + 1, KMUL)) >>> 0;
    const h0 = new Uint32Array(n);
    const bucketCount = new Int32Array(B);
    for (let i = 0; i < n; i++) {
      h0[i] = baseHash(bits[i], faces[i], seed);
      bucketCount[h0[i] % B]++;
    }
    // CSR buckets
    const start = new Int32Array(B + 1);
    for (let b = 0; b < B; b++) start[b + 1] = start[b] + bucketCount[b];
    const fill = new Int32Array(B);
    const items = new Int32Array(n);
    for (let i = 0; i < n; i++) {
      const b = h0[i] % B;
      items[start[b] + fill[b]++] = i;
    }
    // process big buckets first
    const order = Array.from({ length: B }, (_, i) => i).sort((a, b) => bucketCount[b] - bucketCount[a]);

    const taken = new Uint8Array(M);
    const stamp = new Int32Array(M);
    let stampId = 0;
    const disp = new Uint16Array(B);
    const slotOf = new Int32Array(n).fill(-1);
    let maxDisp = 0;
    let ok = true;

    for (const b of order) {
      const cnt = bucketCount[b];
      if (cnt === 0) continue;
      let found = false;
      for (let d = 0; d < 65535; d++) {
        stampId++;
        let good = true;
        for (let k = 0; k < cnt; k++) {
          const s = slotFrom(h0[items[start[b] + k]], d, M);
          if (taken[s] || stamp[s] === stampId) {
            good = false;
            break;
          }
          stamp[s] = stampId;
        }
        if (good) {
          for (let k = 0; k < cnt; k++) {
            const it = items[start[b] + k];
            const s = slotFrom(h0[it], d, M);
            taken[s] = 1;
            slotOf[it] = s;
          }
          disp[b] = d;
          if (d > maxDisp) maxDisp = d;
          found = true;
          break;
        }
      }
      if (!found) {
        ok = false;
        break;
      }
    }
    if (ok) return { seed, M, B, disp, slotOf, maxDisp, attempts: attempt + 1 };
  }
  throw new Error("perfect hash construction failed");
}

/** Mirror of the GLSL lookup: key -> atlas slot. */
export function lookupSlot(ph: PerfectHash, bits: number, face: number): number {
  const h0 = baseHash(bits, face, ph.seed);
  const d = ph.disp[h0 % ph.B];
  return slotFrom(h0, d, ph.M);
}

// --- RGB9_E5 shared exponent encoding (OpenGL spec 8.5.2) -------------------------------------
const RGB9E5_MAX = (511 / 512) * Math.pow(2, 31 - 15);
export function packRGB9E5(r: number, g: number, b: number): number {
  r = r > 0 ? Math.min(r, RGB9E5_MAX) : 0;
  g = g > 0 ? Math.min(g, RGB9E5_MAX) : 0;
  b = b > 0 ? Math.min(b, RGB9E5_MAX) : 0;
  const maxc = Math.max(r, g, b);
  if (maxc <= 0) return 0;
  let exp = Math.max(-16, Math.floor(Math.log2(maxc))) + 1 + 15;
  let denom = Math.pow(2, exp - 15 - 9);
  if (Math.floor(maxc / denom + 0.5) === 512) {
    exp++;
    denom *= 2;
  }
  const rm = Math.floor(r / denom + 0.5);
  const gm = Math.floor(g / denom + 0.5);
  const bm = Math.floor(b / denom + 0.5);
  return ((exp << 27) | (bm << 18) | (gm << 9) | rm) >>> 0;
}
