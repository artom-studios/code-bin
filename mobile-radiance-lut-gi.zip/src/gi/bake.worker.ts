/// <reference lib="webworker" />
import { RadBaker, BAKE_PASSES, type BakeConfig, type BakeStats, type LutLayout, type Validation } from "./bake";

export type WorkerIn = { type: "bake"; cfg: BakeConfig };
export type WorkerOut =
  | { type: "layout"; layout: LutLayout; stats: BakeStats; t: number }
  | { type: "progress"; pass: number; frac: number }
  | { type: "pass"; pass: number; spp: number; totalSpp: number; atlases: Uint32Array[]; t: number }
  | { type: "done"; validation: Validation; t: number }
  | { type: "error"; message: string };

const PASSES = BAKE_PASSES;

const ctx = self as unknown as DedicatedWorkerGlobalScope;

ctx.onmessage = (ev: MessageEvent<WorkerIn>) => {
  if (ev.data.type !== "bake") return;
  try {
    const t0 = performance.now();
    const baker = new RadBaker(ev.data.cfg);
    baker.prepare();
    const post = (m: WorkerOut, tr?: Transferable[]) => ctx.postMessage(m, tr ?? []);
    post({ type: "layout", layout: baker.layout(), stats: baker.stats, t: performance.now() - t0 });
    PASSES.forEach((spp, k) => {
      baker.runPass(spp, (frac) => post({ type: "progress", pass: k, frac }));
      const atlases = baker.pack();
      post(
        { type: "pass", pass: k, spp, totalSpp: baker.totalSpp, atlases, t: performance.now() - t0 },
        atlases.map((a) => a.buffer),
      );
    });
    const validation = baker.validate();
    post({ type: "done", validation, t: performance.now() - t0 });
  } catch (e) {
    ctx.postMessage({ type: "error", message: String((e as Error)?.stack ?? e) } satisfies WorkerOut);
  }
};
