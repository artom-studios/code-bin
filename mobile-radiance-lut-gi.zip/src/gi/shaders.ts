import { sceneGLSL } from "./scene";

const HEAD = `#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
precision highp usampler2D;
`;

const COMMON = HEAD + sceneGLSL();

// ---------------------------------------------------------------------------------------------
// Full-screen triangle (no attributes)
// ---------------------------------------------------------------------------------------------
export const FULLSCREEN_VS = `#version 300 es
void main() {
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
`;

// ---------------------------------------------------------------------------------------------
// Sky backdrop (visible through the window)
// ---------------------------------------------------------------------------------------------
export const SKY_FS =
  COMMON +
  `
uniform vec3 uCamR, uCamU, uCamF;
uniform float uTanHalf, uAspect, uExposure;
uniform vec2 uRes;
uniform vec3 uSkyGain;
out vec4 fragColor;
void main() {
  vec2 ndc = gl_FragCoord.xy / uRes * 2.0 - 1.0;
  vec3 d = normalize(uCamF + uCamR * (ndc.x * uTanHalf * uAspect) + uCamU * (ndc.y * uTanHalf));
  fragColor = vec4(tonemapACES(uSkyGain * skyRadiance(d) * uExposure), 1.0);
}
`;

// ---------------------------------------------------------------------------------------------
// Scene rasteriser with the RadLUT lookup
// ---------------------------------------------------------------------------------------------
export const SCENE_VS = `#version 300 es
precision highp float;
in vec3 aPos;
in vec3 aNrm;
in vec3 aAlb;
in float aMat;
uniform mat4 uVP;
out vec3 vP;
out vec3 vN;
out vec3 vAlb;
flat out float vMat;
void main() {
  vP = aPos;
  vN = aNrm;
  vAlb = aAlb;
  vMat = aMat;
  gl_Position = uVP * vec4(aPos, 1.0);
}
`;

export const SCENE_FS =
  COMMON +
  `
// ---- RadLUT ----------------------------------------------------------------------------------
uniform usampler2D uDisp;     // displacement table of the perfect hash (R16UI)
uniform sampler2D uAtlas0;    // sun   transfer tiles (RGB9E5)
uniform sampler2D uAtlas1;    // sky   transfer tiles
uniform sampler2D uAtlas2;    // lamp  transfer tiles
uniform vec3  uGO;            // grid origin
uniform float uCell;          // tile size in metres
uniform float uTileN;         // texels per tile side
uniform vec2  uAtlasSize;
uniform uint  uM, uB, uSeed, uSW;
uniform vec3  uGain0, uGain1, uGain2;   // runtime light colour * intensity
uniform int   uMode;
uniform float uExposure;
uniform vec3  uBulb;

uint hash32(uint x) {
  x ^= x >> 16; x *= 0x7feb352du;
  x ^= x >> 15; x *= 0x846ca68bu;
  x ^= x >> 16;
  return x;
}

uint entryHash(ivec3 c, int f) {
  uint k = (uint(c.x + 512) & 1023u) | ((uint(c.y + 512) & 1023u) << 10) | ((uint(c.z + 512) & 1023u) << 20);
  return hash32(k ^ hash32(uint(f) * 0x9e3779b1u + uSeed));
}

// one tile: 1 integer fetch (displacement) + 1 bilinear fetch per light channel
vec3 lutEntry(vec3 p, int f) {
  vec3 q = (p - uGO) / uCell;
  vec3 fl = floor(q);
  ivec3 c = ivec3(fl);
  vec3 fr = q - fl;
  uint h0 = entryHash(c, f);
  uint b = h0 % uB;
  uint d = texelFetch(uDisp, ivec2(int(b & 255u), int(b >> 8u)), 0).r;
  uint slot = hash32(h0 + d * 0x9e3779b1u + 0x7f4a7c15u) % uM;
  int a = f >> 1;
  vec2 t = vec2(fr[(a + 1) % 3], fr[(a + 2) % 3]);
  vec2 tile = vec2(float(slot % uSW), float(slot / uSW)) * uTileN;
  vec2 uv = (tile + 0.5 + t * (uTileN - 1.0)) / uAtlasSize;
  return uGain0 * textureLod(uAtlas0, uv, 0.0).rgb
       + uGain1 * textureLod(uAtlas1, uv, 0.0).rgb
       + uGain2 * textureLod(uAtlas2, uv, 0.0).rgb;
}

// tri-planar blend over the (up to) three faces the normal points to; flat walls only touch one
vec3 radLUT(vec3 p, vec3 n) {
  vec3 w = n * n;
  vec3 acc = vec3(0.0);
  float ws = 0.0;
  if (w.x > 0.03) { acc += w.x * lutEntry(p, n.x < 0.0 ? 1 : 0); ws += w.x; }
  if (w.y > 0.03) { acc += w.y * lutEntry(p, n.y < 0.0 ? 3 : 2); ws += w.y; }
  if (w.z > 0.03) { acc += w.z * lutEntry(p, n.z < 0.0 ? 5 : 4); ws += w.z; }
  return acc / max(ws, 1e-4);
}

vec3 cellView(vec3 p, vec3 n) {
  vec3 an = abs(n);
  int a = an.x > an.y ? (an.x > an.z ? 0 : 2) : (an.y > an.z ? 1 : 2);
  int f = 2 * a + (n[a] < 0.0 ? 1 : 0);
  vec3 q = (p - uGO) / uCell;
  vec3 fl = floor(q);
  vec3 fr = q - fl;
  uint h0 = entryHash(ivec3(fl), f);
  vec3 cc = 0.3 + 0.7 * vec3(float(h0 & 255u), float((h0 >> 8u) & 255u), float((h0 >> 16u) & 255u)) / 255.0;
  vec2 t = vec2(fr[(a + 1) % 3], fr[(a + 2) % 3]);
  vec2 ts = t * (uTileN - 1.0);
  float aa = clamp(max(fwidth(ts.x), fwidth(ts.y)), 0.001, 0.2);
  float dd = length(ts - floor(ts + 0.5));
  float dotm = 1.0 - smoothstep(0.16 - aa, 0.16 + aa, dd);
  vec2 edge = min(t, 1.0 - t);
  float ew = max(fwidth(t.x), fwidth(t.y)) * 1.2;
  float line = 1.0 - smoothstep(ew * 0.5, ew * 1.5, min(edge.x, edge.y));
  vec3 E = radLUT(p, n);
  float l = clamp(dot(E, vec3(0.3, 0.6, 0.1)) * 0.35, 0.0, 1.0);
  vec3 col = cc * (0.28 + 0.72 * l);
  col = mix(col, vec3(0.02), dotm * 0.85);
  col = mix(col, vec3(1.0), line * 0.9);
  return pow(col, vec3(1.0 / 2.2));
}

in vec3 vP;
in vec3 vN;
in vec3 vAlb;
flat in float vMat;
out vec4 fragColor;

void main() {
  vec3 n = normalize(vN);
  vec3 col;
  if (vMat < -1.5) {
    col = vec3(0.01);
  } else if (vMat < -0.5) {
    col = uBulb;
  } else {
    vec3 alb = vAlb * albedoPattern(int(vMat + 0.5), vP);
    if (uMode == 1) alb = vec3(0.7);
    if (uMode == 2) {
      fragColor = vec4(cellView(vP, n), 1.0);
      return;
    }
    vec3 E;
    if (uMode == 3) {
      // classic cheap fallback: flat hemispherical ambient, no occlusion, no bounce
      E = mix(vec3(0.06, 0.055, 0.05), vec3(0.2, 0.21, 0.23), n.y * 0.5 + 0.5);
    } else {
      E = radLUT(vP, n);
    }
    col = alb * E;
  }
  fragColor = vec4(tonemapACES(col * uExposure), 1.0);
}
`;

// ---------------------------------------------------------------------------------------------
// Reference: progressive GPU path tracer of the very same analytic scene
// ---------------------------------------------------------------------------------------------
export const REF_FS =
  COMMON +
  `
uniform vec3 uCamPos, uCamR, uCamU, uCamF;
uniform float uTanHalf, uAspect, uFrame;
uniform vec2 uRes;
uniform sampler2D uPrev;
uniform vec3 uSunGain, uSkyGain, uLampGain, uBulb;
out vec4 fragColor;

uint rngS;
uint pcg(uint v) {
  uint state = v * 747796405u + 2891336453u;
  uint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;
  return (word >> 22u) ^ word;
}
float rnd() {
  rngS = pcg(rngS);
  return min(float(rngS) * (1.0 / 4294967296.0), 0.99999994);
}

bool intersect(vec3 ro, vec3 rd, out float tHit, out vec3 nHit, out vec3 albHit, out int matHit) {
  float best = 1e20;
  bool found = false;
  vec3 inv = 1.0 / rd;
  for (int i = 0; i < NB; i++) {
    vec3 t1 = (B_MIN[i] - ro) * inv;
    vec3 t2 = (B_MAX[i] - ro) * inv;
    vec3 tmn = min(t1, t2);
    vec3 tmx = max(t1, t2);
    float tn = max(max(tmn.x, tmn.y), tmn.z);
    float tf = min(min(tmx.x, tmx.y), tmx.z);
    if (tn <= tf && tn > 1e-4 && tn < best) {
      best = tn;
      found = true;
      nHit = -sign(rd) * step(tmn.yzx, tmn.xyz) * step(tmn.zxy, tmn.xyz);
      albHit = B_ALB[i];
      matHit = B_MAT[i];
    }
  }
  for (int i = 0; i < NS; i++) {
    vec3 oc = ro - S_C[i].xyz;
    float b = dot(oc, rd);
    float c = dot(oc, oc) - S_C[i].w * S_C[i].w;
    float disc = b * b - c;
    if (disc > 0.0) {
      float t = -b - sqrt(disc);
      if (t > 1e-4 && t < best) {
        best = t;
        found = true;
        nHit = (ro + rd * t - S_C[i].xyz) / S_C[i].w;
        albHit = S_ALB[i];
        matHit = S_MAT[i];
      }
    }
  }
  tHit = best;
  return found;
}

bool occluded(vec3 ro, vec3 rd, float tmax) {
  vec3 inv = 1.0 / rd;
  for (int i = 0; i < NB; i++) {
    vec3 t1 = (B_MIN[i] - ro) * inv;
    vec3 t2 = (B_MAX[i] - ro) * inv;
    vec3 tmn = min(t1, t2);
    vec3 tmx = max(t1, t2);
    float tn = max(max(tmn.x, tmn.y), tmn.z);
    float tf = min(min(tmx.x, tmx.y), tmx.z);
    if (tn <= tf && tn > 1e-4 && tn < tmax) return true;
  }
  for (int i = 0; i < NS; i++) {
    vec3 oc = ro - S_C[i].xyz;
    float b = dot(oc, rd);
    float c = dot(oc, oc) - S_C[i].w * S_C[i].w;
    float disc = b * b - c;
    if (disc > 0.0) {
      float t = -b - sqrt(disc);
      if (t > 1e-4 && t < tmax) return true;
    }
  }
  return false;
}

vec3 cosDir(vec3 n) {
  float r1 = rnd();
  float r2 = rnd();
  float phi = 6.2831853 * r1;
  float sr = sqrt(r2);
  vec3 t = abs(n.x) > 0.9 ? vec3(-n.z, 0.0, n.x) : vec3(0.0, n.z, -n.y);
  t = normalize(t);
  vec3 b = cross(n, t);
  return normalize(t * (cos(phi) * sr) + b * (sin(phi) * sr) + n * sqrt(1.0 - r2));
}

vec3 trace(vec3 ro, vec3 rd) {
  vec3 L = vec3(0.0);
  vec3 thr = vec3(1.0);
  for (int b = 0; b <= 4; b++) {
    float t; vec3 n; vec3 alb; int mat;
    bool h = intersect(ro, rd, t, n, alb, mat);
    if (b == 0) {
      vec3 oc = ro - LAMP_POS;
      float bb = dot(oc, rd);
      float cc = dot(oc, oc) - BULB_R * BULB_R;
      float disc = bb * bb - cc;
      if (disc > 0.0) {
        float tb = -bb - sqrt(disc);
        if (tb > 0.0 && (!h || tb < t)) return uBulb;
      }
    }
    if (!h) {
      L += thr * uSkyGain * skyRadiance(rd);
      break;
    }
    vec3 p = ro + rd * t;
    thr *= alb * albedoPattern(mat, p);
    vec3 o = p + n * 3e-3;
    float cs = dot(n, SUN_DIR);
    if (cs > 0.0 && !occluded(o, SUN_DIR, 1e20)) L += thr * uSunGain * (cs * 0.3183099);
    vec3 lv = LAMP_POS - o;
    float l2 = dot(lv, lv);
    float l = sqrt(l2);
    float cl = dot(n, lv) / l;
    if (cl > 0.0 && !occluded(o, lv / l, l)) L += thr * uLampGain * (cl * 0.3183099 / l2);
    if (b == 4) break;
    rd = cosDir(n);
    ro = o;
  }
  return L;
}

void main() {
  uvec2 px = uvec2(gl_FragCoord.xy);
  rngS = pcg(px.x + pcg(px.y + pcg(uint(uFrame) * 9781u + 1u)));
  vec2 jit = vec2(rnd(), rnd());
  vec2 ndc = ((gl_FragCoord.xy - 0.5 + jit) / uRes) * 2.0 - 1.0;
  vec3 rd = normalize(uCamF + uCamR * (ndc.x * uTanHalf * uAspect) + uCamU * (ndc.y * uTanHalf));
  vec3 c = min(trace(uCamPos, rd), vec3(24.0));
  if (any(isnan(c))) c = vec3(0.0);
  if (uFrame <= 1.0) {
    fragColor = vec4(c, 1.0);
  } else {
    vec3 prev = texture(uPrev, gl_FragCoord.xy / uRes).rgb;
    fragColor = vec4(mix(prev, c, 1.0 / uFrame), 1.0);
  }
}
`;

export const COMPOSITE_FS =
  COMMON +
  `
uniform sampler2D uTex;
uniform vec2 uRes;
uniform float uSplitPx, uExposure;
out vec4 fragColor;
void main() {
  if (gl_FragCoord.x < uSplitPx) discard;
  vec3 c = texture(uTex, gl_FragCoord.xy / uRes).rgb;
  fragColor = vec4(tonemapACES(c * uExposure), 1.0);
}
`;
