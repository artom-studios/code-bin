// Shared scene description used by the CPU baker, the GPU rasteriser and the GPU reference path tracer.
// Everything is analytic (AABBs + spheres) so the same data can be turned into GLSL constants.

export type V3 = [number, number, number];

/** Face index f: axis = f >> 1, negative direction when (f & 1) === 1.  0:+X 1:-X 2:+Y 3:-Y 4:+Z 5:-Z */
export const FM = { PX: 1, NX: 2, PY: 4, NY: 8, PZ: 16, NZ: 32, ALL: 63, ALL_BUT_BOTTOM: 63 & ~8 } as const;

export interface BoxDef {
  name: string;
  min: V3;
  max: V3;
  albedo: V3;
  mat: number; // procedural pattern id (0 plain, 1 planks, 2 checker)
  faces: number; // bitmask of faces that are rendered / baked
}
export interface SphereDef {
  name: string;
  center: V3;
  radius: number;
  albedo: V3;
  mat: number;
}

const WHITE: V3 = [0.78, 0.77, 0.74];
const RED: V3 = [0.7, 0.1, 0.08];
const GREEN: V3 = [0.1, 0.5, 0.14];
const WOOD: V3 = [0.6, 0.46, 0.33];
const DARKWOOD: V3 = [0.42, 0.28, 0.18];
const FABRIC: V3 = [0.22, 0.33, 0.55];

const B = (name: string, min: V3, max: V3, albedo: V3, mat: number, faces: number): BoxDef => ({
  name,
  min,
  max,
  albedo,
  mat,
  faces,
});

export const ROOM = { min: [-4, 0, -4] as V3, max: [4, 3.5, 4] as V3 };

/** Boxes that take part in light transport (occluders + receivers). */
export const BOXES: BoxDef[] = [
  B("floor", [-4.4, -0.4, -4.4], [4.4, 0, 4.4], WOOD, 1, FM.PY),
  B("ceiling", [-4.4, 3.5, -4.4], [4.4, 3.9, 4.4], WHITE, 0, FM.NY),
  B("back wall", [-4.4, 0, -4.4], [4.4, 3.5, -4], WHITE, 0, FM.PZ),
  B("left wall", [-4.4, 0, -4], [-4, 3.5, 4], RED, 0, FM.PX),
  B("right wall", [4, 0, -4], [4.4, 3.5, 4], GREEN, 0, FM.NX),
  // Window wall: these boxes only take part in light transport. Their visible faces are rendered by the
  // watertight WINDOW_WALL polygons below (shared vertices -> no T-junction cracks along the seams).
  B("front low", [-4.4, 0, 4], [4.4, 1.0, 4.4], WHITE, 0, 0),
  B("front high", [-4.4, 2.8, 4], [4.4, 3.5, 4.4], WHITE, 0, 0),
  B("front left", [-4.4, 1.0, 4], [-1.5, 2.8, 4.4], WHITE, 0, 0),
  B("front right", [1.5, 1.0, 4], [4.4, 2.8, 4.4], WHITE, 0, 0),
  // table
  B("table top", [-1.2, 0.72, -2.3], [1.2, 0.8, -0.9], DARKWOOD, 1, FM.ALL),
  B("leg a", [-1.18, 0, -2.28], [-1.1, 0.72, -2.2], DARKWOOD, 0, FM.ALL_BUT_BOTTOM),
  B("leg b", [1.1, 0, -2.28], [1.18, 0.72, -2.2], DARKWOOD, 0, FM.ALL_BUT_BOTTOM),
  B("leg c", [-1.18, 0, -1.0], [-1.1, 0.72, -0.92], DARKWOOD, 0, FM.ALL_BUT_BOTTOM),
  B("leg d", [1.1, 0, -1.0], [1.18, 0.72, -0.92], DARKWOOD, 0, FM.ALL_BUT_BOTTOM),
  // sofa
  B("sofa base", [-3.9, 0, -1.2], [-2.8, 0.42, 1.6], FABRIC, 0, FM.ALL_BUT_BOTTOM),
  B("sofa back", [-3.9, 0.42, -1.2], [-3.5, 0.95, 1.6], FABRIC, 0, FM.ALL_BUT_BOTTOM),
  B("sofa arm a", [-3.5, 0.42, -1.2], [-2.8, 0.62, -0.9], FABRIC, 0, FM.ALL_BUT_BOTTOM),
  B("sofa arm b", [-3.5, 0.42, 1.3], [-2.8, 0.62, 1.6], FABRIC, 0, FM.ALL_BUT_BOTTOM),
  // bookcase + checker cube
  B("bookcase", [2.7, 0, -3.9], [3.9, 2.2, -3.3], [0.85, 0.84, 0.78], 0, FM.ALL_BUT_BOTTOM),
  B("cube", [1.9, 0, 0.3], [2.7, 0.8, 1.1], [0.78, 0.78, 0.8], 2, FM.ALL_BUT_BOTTOM),
];

/** Watertight render polygons for the window wall (inner plane z = 4, sill, lintel and the two reveals). */
const WALL_Z = 4;
const WINDOW_WALL: { pts: V3[]; n: V3 }[] = [
  // inner plane, split so that every seam vertex is shared (extra vertices sit on the strip edges)
  { n: [0, 0, -1], pts: [[-4.4, 0, WALL_Z], [-1.5, 0, WALL_Z], [-1.5, 1.0, WALL_Z], [-1.5, 2.8, WALL_Z], [-1.5, 3.5, WALL_Z], [-4.4, 3.5, WALL_Z]] },
  { n: [0, 0, -1], pts: [[1.5, 0, WALL_Z], [4.4, 0, WALL_Z], [4.4, 3.5, WALL_Z], [1.5, 3.5, WALL_Z], [1.5, 2.8, WALL_Z], [1.5, 1.0, WALL_Z]] },
  { n: [0, 0, -1], pts: [[-1.5, 0, WALL_Z], [1.5, 0, WALL_Z], [1.5, 1.0, WALL_Z], [-1.5, 1.0, WALL_Z]] },
  { n: [0, 0, -1], pts: [[-1.5, 2.8, WALL_Z], [1.5, 2.8, WALL_Z], [1.5, 3.5, WALL_Z], [-1.5, 3.5, WALL_Z]] },
  // sill, lintel, reveals
  { n: [0, 1, 0], pts: [[-1.5, 1.0, WALL_Z], [1.5, 1.0, WALL_Z], [1.5, 1.0, 4.4], [-1.5, 1.0, 4.4]] },
  { n: [0, -1, 0], pts: [[-1.5, 2.8, WALL_Z], [1.5, 2.8, WALL_Z], [1.5, 2.8, 4.4], [-1.5, 2.8, 4.4]] },
  { n: [1, 0, 0], pts: [[-1.5, 1.0, WALL_Z], [-1.5, 2.8, WALL_Z], [-1.5, 2.8, 4.4], [-1.5, 1.0, 4.4]] },
  { n: [-1, 0, 0], pts: [[1.5, 1.0, WALL_Z], [1.5, 2.8, WALL_Z], [1.5, 2.8, 4.4], [1.5, 1.0, 4.4]] },
];

export const SPHERES: SphereDef[] = [
  { name: "orange ball", center: [-0.45, 0.5, 1.6], radius: 0.5, albedo: [0.88, 0.42, 0.1], mat: 0 },
  { name: "table ball", center: [0.3, 0.98, -1.6], radius: 0.18, albedo: [0.9, 0.9, 0.92], mat: 0 },
  { name: "teal ball", center: [3.2, 0.4, 0.2], radius: 0.4, albedo: [0.1, 0.55, 0.55], mat: 0 },
];

/** Visual-only geometry (not part of light transport, never looked up in the LUT). */
export const CORD: BoxDef = B("cord", [-0.012, 2.55, -1.612], [0.012, 3.5, -1.588], [0.02, 0.02, 0.02], -2, FM.ALL);

const norm = (v: V3): V3 => {
  const l = Math.hypot(v[0], v[1], v[2]);
  return [v[0] / l, v[1] / l, v[2] / l];
};

/** Direction *towards* the sun. */
export const SUN_DIR: V3 = norm([0.3, 0.6, 0.74]);
export const LAMP_POS: V3 = [0.0, 2.45, -1.6];
export const BULB_RADIUS = 0.1;

export const SKY = {
  horizon: [0.8, 0.88, 1.0] as V3,
  zenith: [0.28, 0.52, 1.0] as V3,
  ground: [0.3, 0.31, 0.27] as V3,
};

const clamp01 = (x: number) => (x < 0 ? 0 : x > 1 ? 1 : x);

/** Unit-gain sky radiance. Must match skyRadiance() in GLSL below. */
export function skyInto(dx: number, dy: number, dz: number, out: Float64Array | number[], o = 0) {
  void dx;
  void dz;
  const k = Math.pow(clamp01(dy), 0.55);
  let g = clamp01((dy + 0.02) / 0.04);
  g = g * g * (3 - 2 * g);
  const gs = 0.8 + 0.2 * clamp01(dy + 1);
  for (let c = 0; c < 3; c++) {
    const sky = SKY.horizon[c] + (SKY.zenith[c] - SKY.horizon[c]) * k;
    const ground = SKY.ground[c] * gs;
    out[o + c] = ground + (sky - ground) * g;
  }
}

export interface LightState {
  on: boolean;
  intensity: number;
  color: V3;
}
export interface LightsState {
  sun: LightState;
  sky: LightState;
  lamp: LightState;
}
export const DEFAULT_LIGHTS: LightsState = {
  sun: { on: true, intensity: 5.5, color: [1.0, 0.93, 0.78] },
  sky: { on: true, intensity: 1.2, color: [1.0, 1.0, 1.0] },
  lamp: { on: true, intensity: 7, color: [1.0, 0.78, 0.52] },
};

// ---------------------------------------------------------------------------------------------
// Mesh generation (rasteriser input).  Positions are in world space, scene is static.
// ---------------------------------------------------------------------------------------------
export interface Mesh {
  pos: Float32Array;
  nrm: Float32Array;
  alb: Float32Array;
  mat: Float32Array;
  idx: Uint32Array;
}

export function buildMesh(): Mesh {
  const pos: number[] = [];
  const nrm: number[] = [];
  const alb: number[] = [];
  const mat: number[] = [];
  const idx: number[] = [];

  const pushV = (p: V3, n: V3, a: V3, m: number) => {
    pos.push(p[0], p[1], p[2]);
    nrm.push(n[0], n[1], n[2]);
    alb.push(a[0], a[1], a[2]);
    mat.push(m);
    return pos.length / 3 - 1;
  };

  const addBox = (b: BoxDef) => {
    for (let f = 0; f < 6; f++) {
      if (!(b.faces & (1 << f))) continue;
      const a = f >> 1;
      const s = f & 1 ? -1 : 1;
      const u = (a + 1) % 3;
      const v = (a + 2) % 3;
      const n: V3 = [0, 0, 0];
      n[a] = s;
      const ca = s > 0 ? b.max[a] : b.min[a];
      const ids: number[] = [];
      for (const [cu, cv] of [
        [0, 0],
        [1, 0],
        [1, 1],
        [0, 1],
      ]) {
        const p: V3 = [0, 0, 0];
        p[a] = ca;
        p[u] = cu ? b.max[u] : b.min[u];
        p[v] = cv ? b.max[v] : b.min[v];
        ids.push(pushV(p, n, b.albedo, b.mat));
      }
      if (s > 0) idx.push(ids[0], ids[1], ids[2], ids[0], ids[2], ids[3]);
      else idx.push(ids[0], ids[2], ids[1], ids[0], ids[3], ids[2]);
    }
  };

  const addSphere = (c: V3, r: number, a: V3, m: number, lat = 40, lon = 80) => {
    const base = pos.length / 3;
    for (let i = 0; i <= lat; i++) {
      const th = (Math.PI * i) / lat;
      for (let j = 0; j <= lon; j++) {
        const ph = (2 * Math.PI * j) / lon;
        const n: V3 = [Math.sin(th) * Math.cos(ph), Math.cos(th), Math.sin(th) * Math.sin(ph)];
        pushV([c[0] + r * n[0], c[1] + r * n[1], c[2] + r * n[2]], n, a, m);
      }
    }
    for (let i = 0; i < lat; i++) {
      for (let j = 0; j < lon; j++) {
        const a0 = base + i * (lon + 1) + j;
        const b0 = a0 + lon + 1;
        idx.push(a0, a0 + 1, b0, a0 + 1, b0 + 1, b0);
      }
    }
  };

  const addPoly = (pts: V3[], n: V3, a: V3, m: number) => {
    // make sure the winding is counter-clockwise when seen from the side the normal points to
    const e1: V3 = [pts[1][0] - pts[0][0], pts[1][1] - pts[0][1], pts[1][2] - pts[0][2]];
    const e2: V3 = [pts[2][0] - pts[0][0], pts[2][1] - pts[0][1], pts[2][2] - pts[0][2]];
    const gx = e1[1] * e2[2] - e1[2] * e2[1];
    const gy = e1[2] * e2[0] - e1[0] * e2[2];
    const gz = e1[0] * e2[1] - e1[1] * e2[0];
    const ordered = gx * n[0] + gy * n[1] + gz * n[2] >= 0 ? pts : [...pts].reverse();
    const ids = ordered.map((p) => pushV(p, n, a, m));
    for (let i = 1; i < ids.length - 1; i++) idx.push(ids[0], ids[i], ids[i + 1]);
  };

  BOXES.forEach(addBox);
  WINDOW_WALL.forEach((w) => addPoly(w.pts, w.n, WHITE, 0));
  SPHERES.forEach((s) => addSphere(s.center, s.radius, s.albedo, s.mat));
  addBox(CORD);
  addSphere(LAMP_POS, BULB_RADIUS, [1, 1, 1], -1, 16, 32); // emissive bulb

  return {
    pos: new Float32Array(pos),
    nrm: new Float32Array(nrm),
    alb: new Float32Array(alb),
    mat: new Float32Array(mat),
    idx: new Uint32Array(idx),
  };
}

/** Sum of triangle areas of all surfaces that receive baked light (mat >= 0). */
export function bakedSurfaceArea(mesh: Mesh): number {
  let area = 0;
  const { pos, mat, idx } = mesh;
  for (let t = 0; t < idx.length; t += 3) {
    const i0 = idx[t];
    if (mat[i0] < 0) continue;
    const i1 = idx[t + 1];
    const i2 = idx[t + 2];
    const ax = pos[i1 * 3] - pos[i0 * 3];
    const ay = pos[i1 * 3 + 1] - pos[i0 * 3 + 1];
    const az = pos[i1 * 3 + 2] - pos[i0 * 3 + 2];
    const bx = pos[i2 * 3] - pos[i0 * 3];
    const by = pos[i2 * 3 + 1] - pos[i0 * 3 + 1];
    const bz = pos[i2 * 3 + 2] - pos[i0 * 3 + 2];
    const cx = ay * bz - az * by;
    const cy = az * bx - ax * bz;
    const cz = ax * by - ay * bx;
    area += 0.5 * Math.hypot(cx, cy, cz);
  }
  return area;
}

// ---------------------------------------------------------------------------------------------
// GLSL generation
// ---------------------------------------------------------------------------------------------
const f5 = (n: number) => (Math.abs(n) < 1e-9 ? "0.0" : n.toFixed(5));
const gv3 = (v: V3) => `vec3(${f5(v[0])},${f5(v[1])},${f5(v[2])})`;

export function sceneGLSL(): string {
  const nb = BOXES.length;
  const ns = SPHERES.length;
  return `
const int NB = ${nb};
const int NS = ${ns};
const vec3 B_MIN[${nb}] = vec3[${nb}](${BOXES.map((b) => gv3(b.min)).join(",")});
const vec3 B_MAX[${nb}] = vec3[${nb}](${BOXES.map((b) => gv3(b.max)).join(",")});
const vec3 B_ALB[${nb}] = vec3[${nb}](${BOXES.map((b) => gv3(b.albedo)).join(",")});
const int B_MAT[${nb}] = int[${nb}](${BOXES.map((b) => b.mat).join(",")});
const vec4 S_C[${ns}] = vec4[${ns}](${SPHERES.map((s) => `vec4(${f5(s.center[0])},${f5(s.center[1])},${f5(s.center[2])},${f5(s.radius)})`).join(",")});
const vec3 S_ALB[${ns}] = vec3[${ns}](${SPHERES.map((s) => gv3(s.albedo)).join(",")});
const int S_MAT[${ns}] = int[${ns}](${SPHERES.map((s) => s.mat).join(",")});
const vec3 SUN_DIR = ${gv3(SUN_DIR)};
const vec3 LAMP_POS = ${gv3(LAMP_POS)};
const float BULB_R = ${f5(BULB_RADIUS)};
const vec3 SKY_H = ${gv3(SKY.horizon)};
const vec3 SKY_Z = ${gv3(SKY.zenith)};
const vec3 SKY_G = ${gv3(SKY.ground)};

vec3 skyRadiance(vec3 d) {
  float k = pow(clamp(d.y, 0.0, 1.0), 0.55);
  float g = smoothstep(-0.02, 0.02, d.y);
  float gs = 0.8 + 0.2 * clamp(d.y + 1.0, 0.0, 1.0);
  vec3 sky = mix(SKY_H, SKY_Z, k);
  vec3 ground = SKY_G * gs;
  return mix(ground, sky, g);
}

float hash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

// Procedural albedo detail (average ~1). Proves that albedo stays full-res while light comes from the LUT.
vec3 albedoPattern(int mat, vec3 p) {
  if (mat == 1) {
    float rz = p.z / 0.22;
    float row = floor(rz);
    float h = hash12(vec2(row, floor(p.x * 0.33 + row * 0.37)));
    float tone = 0.8 + 0.4 * h;
    float fz = fract(rz);
    float seam = smoothstep(0.0, 0.03, fz) * smoothstep(0.0, 0.03, 1.0 - fz);
    float grain = 1.0 + 0.05 * sin(p.x * 38.0 + row * 3.1 + p.y * 0.0);
    return vec3(tone * (0.7 + 0.3 * seam) * grain * 1.02);
  }
  if (mat == 2) {
    vec3 q = floor((p + vec3(0.0137, 0.0291, 0.0173)) / 0.2);
    float c = mod(q.x + q.y + q.z, 2.0);
    return vec3(mix(0.5, 1.5, c));
  }
  return vec3(1.0);
}

vec3 tonemapACES(vec3 c) {
  c = max(c, vec3(0.0));
  c = (c * (2.51 * c + 0.03)) / (c * (2.43 * c + 0.59) + 0.14);
  return pow(clamp(c, 0.0, 1.0), vec3(1.0 / 2.2));
}
`;
}
