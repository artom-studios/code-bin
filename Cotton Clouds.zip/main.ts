import * as THREE from 'three';
import { makeNoiseTexture } from '../engine/noise';
import { skyFragment, skyVertex } from '../engine/shaders';

const CLOUD_COUNT = 46;
const PUFFS_PER_LOBE = 28;
const FIELD_RADIUS = 440;
const LIGHT_SMOOTH_RADIUS = 16;
const SUN_ELEVATION = 38;
const SUN_AZIMUTH = 130;
const PROXY_SCALE = 0.9;
const DEFAULT_WINDOW = 0.25;

// Proxy targets are rendered at 1/N of the drawing-buffer size. The slider goes
// up to MAX_PROXY_DIVISOR so you can push it until the fade visibly breaks.
const DEFAULT_PROXY_DIVISOR = 2;
const MAX_PROXY_DIVISOR = 32;

// Was 0.62 (per puff) * 0.62 (uniform) = 0.3844; collapsed into one value, same look.
const CLOUD_OPACITY = 0.62 * 0.62;
const DEFAULT_SILVER_LINING = 0.5;
const DEFAULT_RELIEF = 1; // per-pixel mode: how strongly each puff is shaded as a sphere

// Baked puff sprites: SPRITE_VARIANTS noise patches of SPRITE_SIZE^2, mip-mapped.
const SPRITE_SIZE = 256;
const SPRITE_VARIANTS = 32;

// Static per-puff data lives in an RGBA32F texture, 3 texels per puff.
const PUFFS_PER_ROW = 256;
const DATA_TEX_WIDTH = PUFFS_PER_ROW * 3;

// Depth sort cadence: re-sort when the camera moves/turns, or at least this often (drift).
const SORT_INTERVAL = 0.15;
const SORT_MIN_MOVE_SQ = 0.2 * 0.2;
const SORT_MIN_TURN_DOT = 0.99995;
const SORT_ID_MUL = 1 << 20; // supports up to ~1M puffs per packed sort key

const glslNumber = (value: number) => (Number.isInteger(value) ? value.toFixed(1) : String(value));

// ---------------------------------------------------------------------------
// Shaders
// ---------------------------------------------------------------------------

// Shared by the two proxy passes and the billboard pass. Puff data is fetched
// from a texture by instance order id; drift/bob run here; lighting and fog are
// evaluated once per puff (all of it is constant across a puff's quad).
const billboardVertexSource = `
precision highp sampler2D;

const int TEX_W = ${DATA_TEX_WIDTH};
const float FIELD_RADIUS_F = ${glslNumber(FIELD_RADIUS)};
const float FIELD_EXTENT_F = ${glslNumber(FIELD_RADIUS * 2)};
const float VARIANTS_F = ${glslNumber(SPRITE_VARIANTS)};

attribute float aOrder;
uniform sampler2D uData;
uniform vec3 uRight;
uniform vec3 uUp;
uniform vec3 uFwd;
uniform vec3 uCam;
uniform vec3 uSun;
uniform vec3 uSunColor;
uniform vec3 uAmbTop;
uniform vec3 uAmbBottom;
uniform vec3 uFogColor;
uniform float uTime;
uniform float uDrift;
uniform float uFog;
uniform float uOpacity;
uniform float uSilver;

varying vec2 vUv;
varying vec2 vUvRot;
#ifdef PER_PIXEL
flat varying vec3 vShade; // light, height, edge
varying vec3 vWorld;
#else
flat varying vec3 vColor;
#endif
flat varying float vAlpha;
flat varying float vLayer;
flat varying float vSize;
flat varying float vId;
flat varying float vCentreDepth;

void main() {
  int id = int(aOrder + 0.5);
  int base = id * 3;
  int row = base / TEX_W;
  int col = base - row * TEX_W;
  vec4 t0 = texelFetch(uData, ivec2(col, row), 0);     // cloud x0, y, z, speed
  vec4 t1 = texelFetch(uData, ivec2(col + 1, row), 0); // local x, y, z, size
  vec4 t2 = texelFetch(uData, ivec2(col + 2, row), 0); // seed, light, edge, height

  float size = t1.w;
  float seed = t2.x;
  float light = t2.y;
  float edge = t2.z;
  float height = t2.w;

  float cloudX = mod(t0.x + uDrift * t0.w + FIELD_RADIUS_F, FIELD_EXTENT_F) - FIELD_RADIUS_F;
  vec3 centre = vec3(
    cloudX + t1.x + cos(uTime * 0.19 + seed * 23.0) * 0.55,
    t0.y + t1.y + sin(uTime * 0.27 + seed * 41.0) * 0.6,
    t0.z + t1.z
  );

  vec3 world = centre + (uRight * position.x + uUp * position.y) * size;
  vec3 rel = centre - uCam;
  float dist = length(rel);
  vec3 view = rel / max(dist, 1e-3);
  float nearFade = smoothstep(size * 0.35, size * 1.7, dist);

  float ang = seed * 6.2831853 + uTime * 0.025 * (fract(seed * 7.31) - 0.5) * 2.0;
  vec2 rot = vec2(cos(ang), sin(ang));
  vUv = position.xy;
  // Rotation is linear in position, so interpolating it per-vertex is exact.
  vUvRot = vec2(rot.x * position.x - rot.y * position.y, rot.y * position.x + rot.x * position.y);

  vAlpha = uOpacity * nearFade;
  vLayer = min(floor(seed * VARIANTS_F), VARIANTS_F - 1.0);
  vSize = size;
  vId = float(id);
  vCentreDepth = dot(rel, uFwd);

#ifdef PER_PIXEL
  // Per-pixel mode: pass the baked inputs through; the fragment shader shades.
  vShade = vec3(light, height, edge);
  vWorld = world;
#else
  // Per-puff mode: lighting + fog evaluated once per puff from the puff centre.
  vec3 amb = mix(uAmbBottom, uAmbTop, pow(clamp(height, 0.0, 1.0), 0.8)) * 0.74;
  vec3 col3 = amb + uSunColor * light * 0.44;
  float fwdScatter = pow(clamp(dot(view, uSun), 0.0, 1.0), 5.0);
  col3 += uSunColor * fwdScatter * edge * uSilver * (0.25 + 0.75 * light) * 0.55;
  float fogF = min(1.0 - exp(-dist * uFog), 0.82);
  vColor = mix(col3, uFogColor, fogF);
#endif

  gl_Position = projectionMatrix * viewMatrix * vec4(world, 1.0);
}
`;

// Analytic stand-in for the per-pixel ray/sphere solve. Puff quads are parallel
// to the image plane, so the proxy sphere's front surface at a pixel is the
// centre depth minus R * sqrt(1 - (r/R)^2), measured along the view axis.
// h doubles as the surface-facing term; it is 0 when we fall back to the back
// surface (camera inside the sphere).
const sphereSnippet = `
uniform float uProxyScale;
uniform float uNear;

float sphereDepth(float rr, float centreDepth, float size, out float h) {
  h = sqrt(max(1.0 - rr, 0.0));
  float reach = size * uProxyScale * h;
  float d = centreDepth - reach;
  if (d < uNear) {
    d = centreDepth + reach;
    h = 0.0;
  }
  return d;
}
`;

const billboardFragmentSource = `
precision highp sampler2DArray;

uniform sampler2DArray uSprites;
uniform sampler2D tNear;
uniform sampler2D tSecond;
uniform vec2 uResolution;
uniform float uWindow;
uniform float uDebugView;
uniform float uFadeFloor;
#ifdef PER_PIXEL
uniform vec3 uCam;
uniform vec3 uSun;
uniform vec3 uSunColor;
uniform vec3 uAmbTop;
uniform vec3 uAmbBottom;
uniform vec3 uFogColor;
uniform float uFog;
uniform float uSilver;
uniform vec3 uRight;
uniform vec3 uUp;
uniform vec3 uFwd;
uniform float uNormalShade;
#endif
${sphereSnippet}
varying vec2 vUv;
varying vec2 vUvRot;
#ifdef PER_PIXEL
flat varying vec3 vShade;
varying vec3 vWorld;
#else
flat varying vec3 vColor;
#endif
flat varying float vAlpha;
flat varying float vLayer;
flat varying float vSize;
flat varying float vId;
flat varying float vCentreDepth;

void main() {
  float r2 = dot(vUv, vUv);
  if (r2 >= 1.0) discard;

  // Baked density sprite (noise + radial falloff), sampled with the rotated uv.
  float dens = texture(uSprites, vec3(vUvRot * 0.5 + 0.5, vLayer)).r;
  float alpha = dens * vAlpha;
  // The fade factor can only lower alpha, so bail out before the proxy fetches.
  if (uDebugView < 0.5 && alpha < 0.004) discard;

  vec2 screenUv = gl_FragCoord.xy / uResolution;
  vec4 nearSample = texture(tNear, screenUv);
  vec4 secondSample = texture(tSecond, screenUv);
  float nearDepth = nearSample.r > 0.5 ? nearSample.g : 1e9;
  float secondDepth = secondSample.r > 0.5 ? secondSample.g : 1e9;
  float nearId = nearSample.r - 1.0;

  float h;
  float rr = r2 / (uProxyScale * uProxyScale);
  float selfDepth = rr < 1.0 ? sphereDepth(rr, vCentreDepth, vSize, h) : vCentreDepth;
  bool selfIsNear = abs(nearId - vId) < 0.5;
  float otherDepth = selfIsNear ? secondDepth : nearDepth;
  float otherCoverage = selfIsNear ? secondSample.b : nearSample.b;
  float gap = abs(selfDepth - otherDepth);
  float fadeFactor = 1.0 - otherCoverage * (1.0 - mix(uFadeFloor, 1.0, smoothstep(0.0, uWindow, gap)));

  if (uDebugView > 0.5 && dens > 0.004) {
    if (uDebugView < 1.5) {
      gl_FragColor = vec4(vec3(fadeFactor), 1.0);
    } else {
      gl_FragColor = vec4(fract(nearId * 0.618), fract(nearId * 0.337), fract(nearId * 0.771), 1.0);
    }
    return;
  }

  alpha *= fadeFactor;
  if (alpha < 0.004) discard;

#ifdef PER_PIXEL
  // Same lighting model as the vertex path, but shaded per pixel: view direction and
  // fog distance come from this pixel's position on the billboard, and the puff is lit
  // as a sphere (normal from the proxy-sphere profile) so each puff reads as a rounded clump.
  vec3 toFrag = vWorld - uCam;
  float fragDist = length(toFrag);
  vec3 viewDir = toFrag / max(fragDist, 1e-3);
  vec2 nxy = vUv / uProxyScale;
  float nz = sqrt(max(1.0 - dot(nxy, nxy), 0.0));
  vec3 n = normalize(uRight * nxy.x + uUp * nxy.y - uFwd * nz);
  float wrapL = clamp(dot(n, uSun) * 0.5 + 0.5, 0.0, 1.0);
  float relief = mix(1.0, 0.25 + 1.5 * wrapL * wrapL, uNormalShade);
  float upMix = clamp(mix(pow(clamp(vShade.y, 0.0, 1.0), 0.8), n.y * 0.5 + 0.5, 0.45 * uNormalShade), 0.0, 1.0);
  vec3 amb = mix(uAmbBottom, uAmbTop, upMix) * 0.74;
  vec3 col = amb + uSunColor * vShade.x * 0.44 * relief;
  float fwdScatter = pow(clamp(dot(viewDir, uSun), 0.0, 1.0), 5.0);
  col += uSunColor * fwdScatter * vShade.z * uSilver * (0.25 + 0.75 * vShade.x) * 0.55;
  float fogF = min(1.0 - exp(-fragDist * uFog), 0.82);
  vec3 shaded = mix(col, uFogColor, fogF);
#else
  vec3 shaded = vColor;
#endif
  float ign = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
  gl_FragColor = vec4(shaded + (ign - 0.5) / 255.0, alpha);
}
`;

const proxyFragmentNearSource = `
${sphereSnippet}
uniform float uProjA;
uniform float uProjB;
varying vec2 vUv;
flat varying float vSize;
flat varying float vId;
flat varying float vCentreDepth;
layout(location = 0) out vec4 outValue;

void main() {
  float rr = dot(vUv, vUv) / (uProxyScale * uProxyScale);
  if (rr >= 1.0) discard;
  float h;
  float depth = sphereDepth(rr, vCentreDepth, vSize, h);
  if (depth < uNear) discard;
  gl_FragDepth = 0.5 * (uProjB / depth - uProjA) + 0.5;
  outValue = vec4(vId + 1.0, depth, clamp(2.0 * h, 0.0, 1.0), 1.0);
}
`;

const proxyFragmentSecondSource = `
${sphereSnippet}
uniform float uProjA;
uniform float uProjB;
uniform sampler2D tNear;
uniform vec2 uProxyResolution;
varying vec2 vUv;
flat varying float vSize;
flat varying float vId;
flat varying float vCentreDepth;
layout(location = 0) out vec4 outValue;

void main() {
  float rr = dot(vUv, vUv) / (uProxyScale * uProxyScale);
  if (rr >= 1.0) discard;
  float h;
  float depth = sphereDepth(rr, vCentreDepth, vSize, h);
  if (depth < uNear) discard;
  vec4 nearValue = texture(tNear, gl_FragCoord.xy / uProxyResolution);
  if (nearValue.r > 0.5 && depth <= nearValue.g + 1e-4) discard;
  gl_FragDepth = 0.5 * (uProjB / depth - uProjA) + 0.5;
  outValue = vec4(vId + 1.0, depth, clamp(2.0 * h, 0.0, 1.0), 1.0);
}
`;

// One-off bake of the puff density (the old per-pixel noise code) into a tile.
const spriteBakeVertexSource = `
varying vec2 vUv;
void main() {
  vUv = position.xy;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`;

const spriteBakeFragmentSource = `
uniform sampler2D uNoise;
uniform float uSeed;
varying vec2 vUv;

void main() {
  float r2 = dot(vUv, vUv);
  float dens = 0.0;
  if (r2 < 1.0) {
    float r = sqrt(r2);
    vec2 off = vec2(uSeed, fract(uSeed * 13.7));
    float n1 = texture2D(uNoise, vUv * 0.42 + off).r;
    float n2 = texture2D(uNoise, vUv * 1.05 + off.yx + 0.31).r;
    float nn = n1 * 0.6 + n2 * 0.4;
    dens = (1.0 - r) * 1.55 + (nn - 0.5) * 0.95;
    dens = smoothstep(0.0, 1.0, dens);
    dens *= 1.0 - smoothstep(0.72, 1.0, r);
  }
  gl_FragColor = vec4(dens, 0.0, 0.0, 1.0);
}
`;

// ---------------------------------------------------------------------------
// Layout + baked lighting
// ---------------------------------------------------------------------------

interface Puff {
  lx: number;
  ly: number;
  lz: number;
  size: number;
  seed: number;
  height: number;
  light: number;
  edge: number;
}

interface CloudInfo {
  x0: number;
  z: number;
  y: number;
  speed: number;
  start: number;
  count: number;
}

function mulberry32(seedValue: number) {
  let state = seedValue;
  return () => {
    state |= 0;
    state = (state + 0x6d2b79f5) | 0;
    let mixed = Math.imul(state ^ (state >>> 15), 1 | state);
    mixed = (mixed + Math.imul(mixed ^ (mixed >>> 7), 61 | mixed)) ^ mixed;
    return ((mixed ^ (mixed >>> 14)) >>> 0) / 4294967296;
  };
}

function randomInSphere(random: () => number): [number, number, number] {
  let x = 0;
  let y = 0;
  let z = 0;
  let len = 0;
  do {
    x = random() * 2 - 1;
    y = random() * 2 - 1;
    z = random() * 2 - 1;
    len = Math.hypot(x, y, z);
  } while (len > 1 || len < 0.001);
  return [x, y, z];
}

function randomDirection(random: () => number): [number, number, number] {
  const [x, y, z] = randomInSphere(random);
  const len = Math.hypot(x, y, z);
  return [x / len, y / len, z / len];
}

function buildLayout() {
  const random = mulberry32(20240607);
  const clouds: CloudInfo[] = [];
  const puffs: Puff[] = [];
  for (let c = 0; c < CLOUD_COUNT; c++) {
    const angle = random() * Math.PI * 2;
    const radius = Math.sqrt(random()) * FIELD_RADIUS * 0.96;
    const scale = 0.7 + random() * 0.95;
    const cloud: CloudInfo = {
      x0: Math.cos(angle) * radius,
      z: Math.sin(angle) * radius,
      y: -5 + random() * 15,
      speed: 0.75 + random() * 0.5,
      start: puffs.length,
      count: 0,
    };
    random();
    const lobes = 3 + Math.floor(random() * 4);
    const spreadX = 30 * scale;
    const spreadZ = 15 * scale;
    // Puffs sit on a flat base: a puff's centre is never lower than 0.8 * its size.
    const addPuff = (x: number, y: number, z: number, size: number) => {
      puffs.push({ lx: x, ly: Math.max(y, size * 0.8), lz: z, size, seed: random(), height: 0, light: 1, edge: 0 });
    };
    for (let lobe = 0; lobe < lobes; lobe++) {
      const cx = (random() - 0.5) * 2 * spreadX;
      const cz = (random() - 0.5) * 2 * spreadZ;
      const edgeT = cx / spreadX;
      const core = 1 - edgeT * edgeT;
      const lobeRadius = (9 + random() * 9) * scale * (1.15 - 0.5 * edgeT * edgeT);
      // Lobes toward the middle of the cloud rise into taller towers.
      const lobeCentreY = lobeRadius * 0.55 + core * random() * 0.3 * lobeRadius;
      const detail = Math.min(Math.max(lobeRadius / 13, 0.7), 1.4);

      // 1. Body: a few large overlapping puffs that define the lobe's mass.
      const bodyCount = 3 + Math.floor(random() * 3);
      for (let k = 0; k < bodyCount; k++) {
        const d = randomInSphere(random);
        const up = d[1] < 0 ? d[1] * 0.3 : d[1];
        addPuff(
          cx + d[0] * lobeRadius * 0.45,
          lobeCentreY + up * lobeRadius * 0.4,
          cz + d[2] * lobeRadius * 0.4,
          lobeRadius * (0.55 + random() * 0.25),
        );
      }
      // 2. Shoulders: medium puffs on the dome surface, giving the silhouette its lumps.
      const midCount = Math.round((9 + random() * 5) * detail);
      for (let k = 0; k < midCount; k++) {
        const d = randomDirection(random);
        const up = d[1] < 0 ? d[1] * 0.25 : d[1];
        const reach = lobeRadius * (0.65 + random() * 0.3);
        addPuff(cx + d[0] * reach, lobeCentreY + up * reach, cz + d[2] * reach * 0.9, lobeRadius * (0.3 + random() * 0.14));
      }
      // 3. Detail: small puffs on the outer surface for the cauliflower edge.
      const detailCount = Math.round((14 + random() * 8) * detail);
      for (let k = 0; k < detailCount; k++) {
        const d = randomDirection(random);
        const up = d[1] < 0 ? d[1] * 0.25 : d[1];
        const reach = lobeRadius * (0.85 + random() * 0.25);
        addPuff(cx + d[0] * reach, lobeCentreY + up * reach, cz + d[2] * reach * 0.9, lobeRadius * (0.14 + random() * 0.1));
      }
    }
    cloud.count = puffs.length - cloud.start;
    let maxY = 1;
    for (let i = cloud.start; i < puffs.length; i++) maxY = Math.max(maxY, puffs[i].ly + puffs[i].size);
    for (let i = cloud.start; i < puffs.length; i++) puffs[i].height = Math.min(puffs[i].ly / maxY, 1);
    clouds.push(cloud);
  }
  return { clouds, puffs };
}

// Bakes per-puff sun light and a silver-lining "edge" term. Edge is high where
// the cloud is thin along the sun axis (little material toward or behind the
// puff), which is where light shines through when you look toward the sun.
function bakeLight(clouds: CloudInfo[], puffs: Puff[], sun: THREE.Vector3) {
  const reach = LIGHT_SMOOTH_RADIUS * LIGHT_SMOOTH_RADIUS;
  const raw = new Float64Array(puffs.length);
  const rawEdge = new Float64Array(puffs.length);
  for (const cloud of clouds) {
    const end = cloud.start + cloud.count;
    for (let i = cloud.start; i < end; i++) {
      const target = puffs[i];
      let occlusion = 0;
      let behind = 0;
      for (let j = cloud.start; j < end; j++) {
        if (j === i) continue;
        const other = puffs[j];
        const dx = other.lx - target.lx;
        const dy = other.ly - target.ly;
        const dz = other.lz - target.lz;
        const along = dx * sun.x + dy * sun.y + dz * sun.z;
        const perp2 = dx * dx + dy * dy + dz * dz - along * along;
        const otherRadius = other.size * 0.95;
        const radius2 = otherRadius * otherRadius;
        if (perp2 < radius2) {
          const chord = Math.sqrt(radius2 - perp2);
          if (along > 0) occlusion += chord;
          else behind += chord;
        }
      }
      raw[i] = Math.exp(-occlusion * 0.085) * 0.76 + Math.exp(-occlusion * 0.02) * 0.24;
      rawEdge[i] = Math.exp(-(occlusion + behind) * 0.06);
    }
    for (let i = cloud.start; i < end; i++) {
      const target = puffs[i];
      let sum = 0;
      let sumEdge = 0;
      let weightSum = 0;
      for (let j = cloud.start; j < end; j++) {
        const other = puffs[j];
        const dx = other.lx - target.lx;
        const dy = other.ly - target.ly;
        const dz = other.lz - target.lz;
        const d2 = dx * dx + dy * dy + dz * dz;
        if (d2 >= reach) continue;
        const k = 1 - d2 / reach;
        const w = k * k;
        sum += w * raw[j];
        sumEdge += w * rawEdge[j];
        weightSum += w;
      }
      target.light = sum / weightSum;
      target.edge = sumEdge / weightSum;
    }
  }
}

const { clouds, puffs } = buildLayout();
const sunDirection = new THREE.Vector3(
  Math.cos(THREE.MathUtils.degToRad(SUN_ELEVATION)) * Math.sin(THREE.MathUtils.degToRad(SUN_AZIMUTH)),
  Math.sin(THREE.MathUtils.degToRad(SUN_ELEVATION)),
  Math.cos(THREE.MathUtils.degToRad(SUN_ELEVATION)) * Math.cos(THREE.MathUtils.degToRad(SUN_AZIMUTH)),
).normalize();
bakeLight(clouds, puffs, sunDirection);

const total = puffs.length;
const extent = FIELD_RADIUS * 2;

// Static puff data -> RGBA32F texture (3 texels per puff, 256 puffs per row).
const dataRows = Math.ceil(total / PUFFS_PER_ROW);
const staticData = new Float32Array(DATA_TEX_WIDTH * dataRows * 4);
const localXYZ = new Float32Array(total * 3); // for the CPU depth sort
for (const cloud of clouds) {
  const end = cloud.start + cloud.count;
  for (let i = cloud.start; i < end; i++) {
    const puff = puffs[i];
    const o = (Math.floor(i / PUFFS_PER_ROW) * DATA_TEX_WIDTH + (i % PUFFS_PER_ROW) * 3) * 4;
    staticData[o] = cloud.x0;
    staticData[o + 1] = cloud.y;
    staticData[o + 2] = cloud.z;
    staticData[o + 3] = cloud.speed;
    staticData[o + 4] = puff.lx;
    staticData[o + 5] = puff.ly;
    staticData[o + 6] = puff.lz;
    staticData[o + 7] = puff.size;
    staticData[o + 8] = puff.seed;
    staticData[o + 9] = puff.light;
    staticData[o + 10] = puff.edge;
    staticData[o + 11] = puff.height;
    localXYZ[i * 3] = puff.lx;
    localXYZ[i * 3 + 1] = puff.ly;
    localXYZ[i * 3 + 2] = puff.lz;
  }
}
const dataTexture = new THREE.DataTexture(staticData, DATA_TEX_WIDTH, dataRows, THREE.RGBAFormat, THREE.FloatType);
dataTexture.minFilter = THREE.NearestFilter;
dataTexture.magFilter = THREE.NearestFilter;
dataTexture.generateMipmaps = false;
dataTexture.needsUpdate = true;

// Per-frame instance data is just the draw order (far -> near).
const orderArray = new Float32Array(total);
for (let i = 0; i < total; i++) orderArray[i] = i;
const orderAttribute = new THREE.InstancedBufferAttribute(orderArray, 1);
orderAttribute.setUsage(THREE.DynamicDrawUsage);

const geometry = new THREE.InstancedBufferGeometry();
geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-1, -1, 0, 1, -1, 0, 1, 1, 0, -1, 1, 0]), 3));
geometry.setIndex([0, 1, 2, 0, 2, 3]);
geometry.setAttribute('aOrder', orderAttribute);
geometry.instanceCount = total;

// ---------------------------------------------------------------------------
// Renderer, targets, sprite bake
// ---------------------------------------------------------------------------

const canvas = document.getElementById('view') as HTMLCanvasElement;
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
renderer.setSize(window.innerWidth, window.innerHeight, false);
renderer.autoClear = true;
if (!renderer.extensions.has('EXT_color_buffer_float')) {
  console.warn('EXT_color_buffer_float is unavailable; the float proxy targets will not render.');
}

const camera = new THREE.PerspectiveCamera(58, window.innerWidth / window.innerHeight, 1, 1200);
const resolution = new THREE.Vector2();
const proxyResolution = new THREE.Vector2();
renderer.getDrawingBufferSize(resolution);

function bakeSprites(noise: THREE.Texture) {
  const size = SPRITE_SIZE;
  const bakeTarget = new THREE.WebGLRenderTarget(size, size, {
    type: THREE.UnsignedByteType,
    format: THREE.RGBAFormat,
    minFilter: THREE.NearestFilter,
    magFilter: THREE.NearestFilter,
    depthBuffer: false,
  });
  const bakeMaterial = new THREE.ShaderMaterial({
    vertexShader: spriteBakeVertexSource,
    fragmentShader: spriteBakeFragmentSource,
    side: THREE.DoubleSide,
    depthTest: false,
    depthWrite: false,
    uniforms: { uNoise: { value: noise }, uSeed: { value: 0 } },
  });
  const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), bakeMaterial);
  quad.frustumCulled = false;
  const bakeScene = new THREE.Scene();
  bakeScene.add(quad);
  const bakeCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

  const pixels = new Uint8Array(size * size * 4);
  const data = new Uint8Array(size * size * SPRITE_VARIANTS);
  renderer.setClearColor(0x000000, 0);
  renderer.setRenderTarget(bakeTarget);
  for (let v = 0; v < SPRITE_VARIANTS; v++) {
    bakeMaterial.uniforms.uSeed.value = (v + 0.5) / SPRITE_VARIANTS;
    renderer.render(bakeScene, bakeCamera);
    renderer.readRenderTargetPixels(bakeTarget, 0, 0, size, size, pixels);
    const layerOffset = v * size * size;
    for (let p = 0; p < size * size; p++) data[layerOffset + p] = pixels[p * 4];
  }
  renderer.setRenderTarget(null);
  bakeTarget.dispose();
  bakeMaterial.dispose();
  quad.geometry.dispose();

  const sprites = new THREE.DataArrayTexture(data, size, size, SPRITE_VARIANTS);
  sprites.format = THREE.RedFormat;
  sprites.type = THREE.UnsignedByteType;
  sprites.minFilter = THREE.LinearMipmapLinearFilter;
  sprites.magFilter = THREE.LinearFilter;
  sprites.wrapS = THREE.ClampToEdgeWrapping;
  sprites.wrapT = THREE.ClampToEdgeWrapping;
  sprites.generateMipmaps = true;
  sprites.unpackAlignment = 1;
  sprites.needsUpdate = true;
  return sprites;
}

const noiseTexture = makeNoiseTexture(256);
const spriteTexture = bakeSprites(noiseTexture);
noiseTexture.dispose();

const makeProxyTarget = () =>
  new THREE.WebGLRenderTarget(1, 1, {
    type: THREE.FloatType,
    format: THREE.RGBAFormat,
    minFilter: THREE.NearestFilter,
    magFilter: THREE.NearestFilter,
    depthBuffer: true,
  });
const nearTarget = makeProxyTarget();
const secondTarget = makeProxyTarget();

const zenith = new THREE.Vector3(0.17, 0.4, 0.8);
const horizon = new THREE.Vector3(0.72, 0.85, 0.97);
const below = zenith.clone().multiplyScalar(0.62).lerp(horizon, 0.18);
const sunColor = new THREE.Vector3(1.0, 0.96, 0.88);
const ambientTop = new THREE.Vector3(0.82, 0.9, 1.0);
const ambientBottom = new THREE.Vector3(0.5, 0.58, 0.72);
const horizonColor = new THREE.Color(horizon.x, horizon.y, horizon.z);

const sky = new THREE.Mesh(
  new THREE.SphereGeometry(1, 48, 24),
  new THREE.ShaderMaterial({
    vertexShader: skyVertex,
    fragmentShader: skyFragment,
    side: THREE.BackSide,
    depthWrite: false,
    depthTest: false,
    uniforms: {
      uZenith: { value: zenith },
      uHorizon: { value: horizon },
      uBelow: { value: below },
      uSun: { value: sunDirection },
      uSunColor: { value: sunColor },
    },
  }),
);
sky.scale.setScalar(2000);
sky.frustumCulled = false;
sky.renderOrder = -10;

const shared = {
  uRight: { value: new THREE.Vector3() },
  uUp: { value: new THREE.Vector3() },
  uFwd: { value: new THREE.Vector3() },
  uCam: { value: new THREE.Vector3() },
  uTime: { value: 0 },
  uDrift: { value: 0 },
  uNear: { value: camera.near },
  uProjA: { value: camera.projectionMatrix.elements[10] },
  uProjB: { value: camera.projectionMatrix.elements[14] },
  uProxyScale: { value: PROXY_SCALE },
  uWindow: { value: DEFAULT_WINDOW },
  uResolution: { value: resolution },
  uProxyResolution: { value: proxyResolution },
  tNear: { value: nearTarget.texture },
  tSecond: { value: secondTarget.texture },
  uData: { value: dataTexture },
  uSprites: { value: spriteTexture },
  uSun: { value: sunDirection },
  uSunColor: { value: sunColor },
  uAmbTop: { value: ambientTop },
  uAmbBottom: { value: ambientBottom },
  uFogColor: { value: horizon },
  uOpacity: { value: CLOUD_OPACITY },
  uFog: { value: 0.0016 },
  uDebugView: { value: 0 },
  uFadeFloor: { value: 0.6 },
  uSilver: { value: DEFAULT_SILVER_LINING },
  uNormalShade: { value: DEFAULT_RELIEF },
};

const proxyMaterialNear = new THREE.ShaderMaterial({
  glslVersion: THREE.GLSL3,
  vertexShader: billboardVertexSource,
  fragmentShader: proxyFragmentNearSource,
  uniforms: { ...shared },
});
const proxyMaterialSecond = new THREE.ShaderMaterial({
  glslVersion: THREE.GLSL3,
  vertexShader: billboardVertexSource,
  fragmentShader: proxyFragmentSecondSource,
  uniforms: { ...shared },
});
const billboardMaterial = new THREE.ShaderMaterial({
  vertexShader: billboardVertexSource,
  fragmentShader: billboardFragmentSource,
  transparent: true,
  depthWrite: false,
  depthTest: false,
  uniforms: { ...shared },
});

const billboardMaterialPixel = new THREE.ShaderMaterial({
  defines: { PER_PIXEL: 1 },
  vertexShader: billboardVertexSource,
  fragmentShader: billboardFragmentSource,
  transparent: true,
  depthWrite: false,
  depthTest: false,
  uniforms: { ...shared },
});

const proxySceneNear = new THREE.Scene();
const proxySceneSecond = new THREE.Scene();
const mainScene = new THREE.Scene();
const proxyMeshNear = new THREE.Mesh(geometry, proxyMaterialNear);
const proxyMeshSecond = new THREE.Mesh(geometry, proxyMaterialSecond);
const billboardMesh = new THREE.Mesh(geometry, billboardMaterial);
for (const mesh of [proxyMeshNear, proxyMeshSecond, billboardMesh]) mesh.frustumCulled = false;
proxySceneNear.add(proxyMeshNear);
proxySceneSecond.add(proxyMeshSecond);
mainScene.add(sky, billboardMesh);

renderer.setClearColor(horizonColor, 1);

// ---------------------------------------------------------------------------
// Camera controls
// ---------------------------------------------------------------------------

const target = new THREE.Vector3(0, 12, 0);
let yaw = 0.6;
let pitch = 0.06;
let distance = 70;
let targetYaw = yaw;
let targetPitch = pitch;
let targetDistance = distance;
let dragging = false;
let lastX = 0;
let lastY = 0;

const clamp = (value: number, low: number, high: number) => Math.min(Math.max(value, low), high);

canvas.addEventListener('pointerdown', (event) => {
  dragging = true;
  lastX = event.clientX;
  lastY = event.clientY;
  canvas.setPointerCapture(event.pointerId);
});
canvas.addEventListener('pointermove', (event) => {
  if (!dragging) return;
  targetYaw -= (event.clientX - lastX) * 0.0055;
  targetPitch = clamp(targetPitch + (event.clientY - lastY) * 0.0055, -1.45, 1.45);
  lastX = event.clientX;
  lastY = event.clientY;
});
canvas.addEventListener('pointerup', () => {
  dragging = false;
});
canvas.addEventListener('pointercancel', () => {
  dragging = false;
});
canvas.addEventListener('wheel', (event) => {
  event.preventDefault();
  targetDistance = clamp(targetDistance * Math.exp(event.deltaY * 0.0012), 18, 320);
}, { passive: false });

// ---------------------------------------------------------------------------
// UI
// ---------------------------------------------------------------------------

const windowSlider = document.getElementById('window') as HTMLInputElement;
const windowValue = document.getElementById('window-value') as HTMLSpanElement;
windowSlider.value = String(DEFAULT_WINDOW);
windowValue.textContent = DEFAULT_WINDOW.toFixed(2);
windowSlider.addEventListener('input', () => {
  const value = parseFloat(windowSlider.value);
  shared.uWindow.value = Math.max(value, 0.0001);
  windowValue.textContent = value.toFixed(2);
});

const floorSlider = document.getElementById('floor') as HTMLInputElement;
const floorValue = document.getElementById('floor-value') as HTMLSpanElement;
floorSlider.value = '0.6';
floorValue.textContent = '0.60';
floorSlider.addEventListener('input', () => {
  const value = parseFloat(floorSlider.value);
  shared.uFadeFloor.value = value;
  floorValue.textContent = value.toFixed(2);
});

const silverSlider = document.getElementById('silver') as HTMLInputElement;
const silverValue = document.getElementById('silver-value') as HTMLSpanElement;
silverSlider.value = String(DEFAULT_SILVER_LINING);
silverValue.textContent = DEFAULT_SILVER_LINING.toFixed(2);
silverSlider.addEventListener('input', () => {
  const value = parseFloat(silverSlider.value);
  shared.uSilver.value = value;
  silverValue.textContent = value.toFixed(2);
});

const reliefSlider = document.getElementById('relief') as HTMLInputElement;
const reliefValue = document.getElementById('relief-value') as HTMLSpanElement;
reliefSlider.value = String(DEFAULT_RELIEF);
reliefValue.textContent = DEFAULT_RELIEF.toFixed(2);
reliefSlider.addEventListener('input', () => {
  const value = parseFloat(reliefSlider.value);
  shared.uNormalShade.value = value;
  reliefValue.textContent = value.toFixed(2);
});

let proxyDivisor = DEFAULT_PROXY_DIVISOR;
const proxySlider = document.getElementById('proxy') as HTMLInputElement;
const proxyValue = document.getElementById('proxy-value') as HTMLSpanElement;
const proxySize = document.getElementById('proxy-size') as HTMLSpanElement;
proxySlider.max = String(MAX_PROXY_DIVISOR);
proxySlider.value = String(proxyDivisor);

function applyProxyScale() {
  renderer.getDrawingBufferSize(resolution);
  const width = Math.max(1, Math.round(resolution.x / proxyDivisor));
  const height = Math.max(1, Math.round(resolution.y / proxyDivisor));
  proxyResolution.set(width, height);
  nearTarget.setSize(width, height);
  secondTarget.setSize(width, height);
  proxyValue.textContent = String(proxyDivisor);
  proxySize.textContent = width + '×' + height;
}
proxySlider.addEventListener('input', () => {
  proxyDivisor = clamp(parseInt(proxySlider.value, 10) || 1, 1, MAX_PROXY_DIVISOR);
  applyProxyScale();
});
applyProxyScale();

window.addEventListener('resize', () => {
  renderer.setSize(window.innerWidth, window.innerHeight, false);
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  applyProxyScale();
});

const viewButtons: [string, number][] = [['view-normal', 0], ['view-fade', 1], ['view-id', 2]];
for (const [buttonId, mode] of viewButtons) {
  const button = document.getElementById(buttonId) as HTMLButtonElement;
  button.addEventListener('click', () => {
    shared.uDebugView.value = mode;
  });
}

// ---------------------------------------------------------------------------
// Frame loop
// ---------------------------------------------------------------------------

let perPixelShading = true;
billboardMesh.material = billboardMaterialPixel;
const shadeButtons: [string, boolean][] = [['shade-puff', false], ['shade-pixel', true]];
for (const [buttonId, perPixel] of shadeButtons) {
  const button = document.getElementById(buttonId) as HTMLButtonElement;
  button.addEventListener('click', () => {
    perPixelShading = perPixel;
    billboardMesh.material = perPixel ? billboardMaterialPixel : billboardMaterial;
  });
}

const statsLine = document.getElementById('stats') as HTMLDivElement;
let time = 0;
let drift = 0;
let lastNow = performance.now();
let fpsTime = 0;
let fpsFrames = 0;
let sortMs = 0;
let sortCount = 0;

const sortKeys = new Float64Array(total);
const lastSortPosition = new THREE.Vector3();
const lastSortForward = new THREE.Vector3();
let lastSortTime = -Infinity;

function wrapX(value: number) {
  return ((((value + FIELD_RADIUS) % extent) + extent) % extent) - FIELD_RADIUS;
}

function shouldResort() {
  if (time - lastSortTime > SORT_INTERVAL) return true;
  if (camera.position.distanceToSquared(lastSortPosition) > SORT_MIN_MOVE_SQ) return true;
  return shared.uFwd.value.dot(lastSortForward) < SORT_MIN_TURN_DOT;
}

// Back-to-front order for the alpha-blended billboards. Positions advance in
// the vertex shader every frame; this only refreshes the order, and ignores the
// sub-unit bob (it cannot meaningfully change the order).
function resort(cameraPosition: THREE.Vector3, forward: THREE.Vector3) {
  const start = performance.now();
  for (const cloud of clouds) {
    const cloudX = wrapX(cloud.x0 + drift * cloud.speed) - cameraPosition.x;
    const cloudY = cloud.y - cameraPosition.y;
    const cloudZ = cloud.z - cameraPosition.z;
    const end = cloud.start + cloud.count;
    for (let i = cloud.start; i < end; i++) {
      const depth =
        (cloudX + localXYZ[i * 3]) * forward.x +
        (cloudY + localXYZ[i * 3 + 1]) * forward.y +
        (cloudZ + localXYZ[i * 3 + 2]) * forward.z;
      sortKeys[i] = Math.max(0, Math.floor((2600 - depth) * 8)) * SORT_ID_MUL + i;
    }
  }
  sortKeys.sort();
  for (let j = 0; j < total; j++) orderArray[j] = sortKeys[j] % SORT_ID_MUL;
  orderAttribute.needsUpdate = true;
  lastSortPosition.copy(cameraPosition);
  lastSortForward.copy(forward);
  lastSortTime = time;
  sortMs += performance.now() - start;
  sortCount += 1;
}

function frame(now: number) {
  requestAnimationFrame(frame);
  const dt = Math.min((now - lastNow) / 1000, 0.05);
  lastNow = now;
  time += dt;
  drift += dt * 2.0;

  const ease = 1 - Math.exp(-dt * 9);
  yaw += (targetYaw - yaw) * ease;
  pitch += (targetPitch - pitch) * ease;
  distance += (targetDistance - distance) * ease;
  const cosPitch = Math.cos(pitch);
  camera.position.set(
    target.x + distance * cosPitch * Math.sin(yaw),
    target.y + distance * Math.sin(pitch),
    target.z + distance * cosPitch * Math.cos(yaw),
  );
  camera.lookAt(target);
  camera.updateMatrixWorld();

  const m = camera.matrixWorld.elements;
  shared.uRight.value.set(m[0], m[1], m[2]);
  shared.uUp.value.set(m[4], m[5], m[6]);
  shared.uFwd.value.set(-m[8], -m[9], -m[10]);
  shared.uCam.value.copy(camera.position);
  shared.uTime.value = time;
  shared.uDrift.value = drift;
  sky.position.copy(camera.position);

  if (shouldResort()) resort(camera.position, shared.uFwd.value);

  renderer.setClearColor(0x000000, 0);
  renderer.setRenderTarget(nearTarget);
  renderer.render(proxySceneNear, camera);
  renderer.setRenderTarget(secondTarget);
  renderer.render(proxySceneSecond, camera);
  renderer.setRenderTarget(null);
  renderer.setClearColor(horizonColor, 1);
  renderer.render(mainScene, camera);

  fpsTime += dt;
  fpsFrames += 1;
  if (fpsTime >= 0.5) {
    const fps = Math.round(fpsFrames / fpsTime);
    const sortAverage = sortCount > 0 ? sortMs / sortCount : 0;
    statsLine.textContent =
      'fps ' + fps +
      ' · puffs ' + total +
      ' · shade ' + (perPixelShading ? 'pixel' : 'puff') +
      ' · proxy ' + proxyResolution.x + '×' + proxyResolution.y +
      ' · sort ' + sortAverage.toFixed(2) + ' ms × ' + Math.round(sortCount / fpsTime) + '/s';
    fpsTime = 0;
    fpsFrames = 0;
    sortMs = 0;
    sortCount = 0;
  }
}

requestAnimationFrame(frame);
