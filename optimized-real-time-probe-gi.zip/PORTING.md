# Surfel-Relit Probe GI — porting guide

Dynamic diffuse GI (sun, sky, point lights, emissives, infinite bounces) for **static geometry +
dynamic lighting + dynamic objects**, with no runtime ray tracing.

## Idea

Probe *visibility* never changes when geometry is static, so it is traced once. Each probe keeps a
tiny G-buffer of what its N fixed rays hit ("surfels"). At runtime the surfels are only *relit*.

## Baked data (`src/engine/bake.ts` → `BakeResult`, plain typed arrays)

| Buffer     | Format                    | Content                                                        |
|------------|---------------------------|----------------------------------------------------------------|
| `surfPos`  | RGBA32F atlas             | xyz hit position, `w=1` · xyz ray dir, `w=0` (sky) · `w=-1` dead |
| `surfAlb`  | RGBA8 atlas               | albedo (gamma 2.0), a = emissive                               |
| `surfNrm`  | RGBA8 atlas               | normal                                                         |
| `rayDirs`  | RGBA32F, N×1              | shared spherical-Fibonacci directions                          |
| `lampSH`   | RGBA16F volume            | visibility-tested L1 transfer of all static local lights       |
| vertex AO  | 1 byte / vertex           | small-scale occlusion the probe grid cannot resolve            |

Atlas layout: probe `(x,y,z)` owns the `RS×RS` tile at `(x*RS, (y + z*GY)*RS)`; one volume slice is a
contiguous row band, which is what makes amortised updates a single scissor rect.

Probes buried in geometry (>18 % back-face hits) copy the surfels of their nearest valid neighbour
**at bake time**. That is why the runtime can use plain hardware trilinear filtering with no
per-pixel visibility/Chebyshev test.

## Runtime (`src/engine/renderer.ts`, `updateGI`) — two tiny passes

1. **Relight** (`RELIGHT_FS`, 1 fragment per surfel, R11G11B10F target)  
   `radiance = albedo * (sun·N·L·shadowTap + pointLights + irradianceVolume(prev frame) * bounce) + emissive`  
   Sampling last frame's volume gives one extra bounce per frame → converges to infinite bounces.
2. **Project** (`PROJECT_FS`, 1 fragment per probe, 3 MRT into RGBA16F 3D-texture slices)  
   Sums the tile into pre-convolved L1 SH so that `E/π = dot(sh, vec4(n, 1))`, adds `lampSH`.
   Temporal hysteresis = fixed-function blend with `CONSTANT_ALPHA` (free).

`budget` refreshes only a fraction of the slices per frame (round-robin).

**Per-pixel cost:** `fetchSH` = 3 trilinear 3D taps; `evalSH` = 3 dot products. The same taps are
reused for rough specular along the reflection vector.

## Mapping to an engine

- *Unity / Unreal / Godot*: the two passes are fullscreen blits/compute dispatches (a compute
  shader over `probes` with a loop over `RS²` is equivalent). Bind the three SH volumes globally
  and replace the engine's ambient/SH term with `evalSH(fetchSH(P + N*bias), N) * ao`.
- Replace `shadow1()` with your cascaded shadow lookup; replace `skyColor()` with your sky.
- Bake offline with your engine's ray caster (or port `bake.worker.ts`: SAH BVH + Möller–Trumbore)
  and ship the atlases as assets. For streaming worlds, bake one volume per cell.
- Tighter storage if needed: positions as RGBA16F relative to the probe, octahedral RG8 normals.

## Tuning

| Knob            | Where                 | Notes                                                    |
|-----------------|-----------------------|----------------------------------------------------------|
| probe spacing   | `GRID` in `scene.ts`  | keep walls ≥ ~0.8 × spacing, or add a second finer volume |
| rays per probe  | `RAY_SIDE`            | 64–144; small bright emitters should be analytic (`lampSH`) |
| normal bias     | `uBias` (0.3 × spacing) | trades leaking vs. contact detail                       |
| hysteresis      | `settings.hysteresis` | 0.7 default; raise with small budgets                    |

## Limits (by design)

Static occluders only (moving objects receive GI but do not block or bounce it); diffuse/rough
specular only; resolution is the probe spacing — fine detail comes from baked vertex AO.
