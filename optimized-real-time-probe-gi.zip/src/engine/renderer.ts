// WebGL2 renderer. Frame = [shadow map if sun moved] -> GI relight -> GI project -> forward -> resolve.
import type { BakeResult } from "./bake";
import { clamp, lookAt, mat4, mix, mul, ortho, perspective, smooth, type V3 } from "./math";
import { MeshBuilder, type MeshData } from "./mesh";
import { GRID, RAY_SIDE } from "./scene";
import { SHADERS as S } from "./shaders";

export interface Settings {
  timeOfDay: number; autoTime: boolean; sunIntensity: number; bounce: number; emissive: number; gi: boolean;
  exposure: number; mode: number; showProbes: boolean; orbs: boolean; budget: number; hysteresis: number; autoCam: boolean;
}
export const defaultSettings = (): Settings => ({
  timeOfDay: 9.6, autoTime: true, sunIntensity: 1, bounce: 1, emissive: 1, gi: true, exposure: 1, mode: 0,
  showProbes: false, orbs: true, budget: 1, hysteresis: 0.7, autoCam: true,
});
export interface Stats { fps: number; cpuMs: number; giMs: number; surfels: number; probes: number; drawCalls: number }

type Prog = { p: WebGLProgram; u: Record<string, WebGLUniformLocation> };
const SHADOW_RES = 4096, [GX, GY, GZ] = GRID.dims;

export class Renderer {
  settings = defaultSettings();
  stats: Stats = { fps: 0, cpuMs: 0, giMs: -1, surfels: 0, probes: 0, drawCalls: 0 };
  cam = { pos: [14, 3.2, 7] as V3, yaw: -2.1, pitch: -0.05 };
  private gl: WebGL2RenderingContext;
  private prog: Record<string, Prog> = {};
  private scene!: { vao: WebGLVertexArrayObject; count: number };
  private ball!: { vao: WebGLVertexArrayObject; count: number };
  private ballLo!: { vao: WebGLVertexArrayObject; count: number };
  private tex: Record<string, WebGLTexture> = {};
  private fbRadiance!: WebGLFramebuffer; private fbShadow!: WebGLFramebuffer; private fbSH: WebGLFramebuffer[] = [];
  private fbMsaa: WebGLFramebuffer | null = null; private fbResolve: WebGLFramebuffer | null = null;
  private rb: WebGLRenderbuffer[] = [];
  private w = 0; private h = 0;
  private view = mat4(); private proj = mat4(); private vp = mat4(); private lightVP = mat4(); private shadowMat = mat4();
  private sunDir: V3 = [0, 1, 0]; private lastSun: V3 = [0, 0, 0]; private env = { sun: [0, 0, 0], zen: [0, 0, 0], hor: [0, 0, 0], gnd: [0, 0, 0] };
  private lightPos = new Float32Array(9); private lightCol = new Float32Array(9);
  private time = 0; private cursor = 0; private warm = 0; private keys = new Set<string>();
  private timerExt: unknown; private query: WebGLQuery | null = null; private queryBusy = false;
  private cleanup: (() => void)[] = [];
  private fpsAcc = 0; private fpsN = 0; private autoExposure = 1;

  constructor(private canvas: HTMLCanvasElement, private bake: BakeResult) {
    const gl = canvas.getContext("webgl2", { antialias: false, alpha: false, powerPreference: "high-performance" });
    if (!gl) throw new Error("WebGL2 is not available on this device.");
    if (!gl.getExtension("EXT_color_buffer_float")) throw new Error("EXT_color_buffer_float is required (float render targets).");
    this.gl = gl;
    this.timerExt = gl.getExtension("EXT_disjoint_timer_query_webgl2");
    const mk = (name: string, vs: string, fs: string) => (this.prog[name] = this.compile(vs, fs));
    mk("relight", S.FS_TRI, S.RELIGHT_FS); mk("project", S.FS_TRI, S.PROJECT_FS); mk("main", S.MAIN_VS, S.MAIN_FS);
    mk("shadow", S.SHADOW_VS, S.SHADOW_FS); mk("sky", S.FS_TRI, S.SKY_FS); mk("orb", S.ORB_VS, S.ORB_FS); mk("post", S.FS_TRI, S.POST_FS);
    this.scene = this.upload(bake.mesh);
    const sphere = (nu: number, nv: number) => {
      const b = new MeshBuilder().material(1, 1, 1, 0.5, 0, 5);
      b.surface(nu, nv, (u, v, o) => { const a = u * 6.2831853, p = v * Math.PI; o[0] = Math.sin(p) * Math.cos(a); o[1] = Math.cos(p); o[2] = Math.sin(p) * Math.sin(a); });
      return this.upload(b.build());
    };
    this.ball = sphere(48, 28); this.ballLo = sphere(10, 6);
    this.initTextures();
    this.initInput();
  }

  // ------------------------------------------------------------ setup
  private compile(vs: string, fs: string): Prog {
    const gl = this.gl, p = gl.createProgram()!;
    for (const [type, src] of [[gl.VERTEX_SHADER, vs], [gl.FRAGMENT_SHADER, fs]] as const) {
      const s = gl.createShader(type)!; gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error("Shader compile failed: " + gl.getShaderInfoLog(s));
      gl.attachShader(p, s);
    }
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error("Program link failed: " + gl.getProgramInfoLog(p));
    const u: Prog["u"] = {};
    for (let i = 0, n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS); i < n; i++) {
      const name = gl.getActiveUniform(p, i)!.name.replace("[0]", "");
      u[name] = gl.getUniformLocation(p, name)!;
    }
    return { p, u };
  }

  /** Interleave to 24-byte vertices: pos f32x3 | normal i8x4 | colour+AO u8x4 | material u8x4. */
  private upload(m: MeshData) {
    const gl = this.gl, n = m.positions.length / 3, buf = new ArrayBuffer(n * 24);
    const f = new Float32Array(buf), i8 = new Int8Array(buf), u8 = new Uint8Array(buf);
    for (let i = 0; i < n; i++) {
      f[i * 6] = m.positions[i * 3]; f[i * 6 + 1] = m.positions[i * 3 + 1]; f[i * 6 + 2] = m.positions[i * 3 + 2];
      for (let k = 0; k < 3; k++) i8[i * 24 + 12 + k] = Math.round(clamp(m.normals[i * 3 + k], -1, 1) * 127);
      for (let k = 0; k < 4; k++) { u8[i * 24 + 16 + k] = m.colors[i * 4 + k]; u8[i * 24 + 20 + k] = m.mats[i * 4 + k]; }
    }
    const vao = gl.createVertexArray()!; gl.bindVertexArray(vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer()); gl.bufferData(gl.ARRAY_BUFFER, buf, gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 24, 0);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 3, gl.BYTE, true, 24, 12);
    gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 4, gl.UNSIGNED_BYTE, true, 24, 16);
    gl.enableVertexAttribArray(3); gl.vertexAttribPointer(3, 4, gl.UNSIGNED_BYTE, true, 24, 20);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, gl.createBuffer()); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, m.indices, gl.STATIC_DRAW);
    gl.bindVertexArray(null);
    return { vao, count: m.indices.length };
  }

  private tex2D(name: string, ifmt: number, w: number, h: number, fmt: number, type: number, data: ArrayBufferView | null, filter: number, wrap: number) {
    const gl = this.gl, t = (this.tex[name] = gl.createTexture()!);
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, ifmt, w, h, 0, fmt, type, data);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter === gl.NEAREST ? gl.NEAREST : gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrap); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrap);
    return t;
  }

  private initTextures() {
    const gl = this.gl, b = this.bake, CE = gl.CLAMP_TO_EDGE, NE = gl.NEAREST;
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    // static surfel G-buffer (baked)
    this.tex2D("surfPos", gl.RGBA32F, b.atlasW, b.atlasH, gl.RGBA, gl.FLOAT, b.surfPos, NE, CE);
    this.tex2D("surfAlb", gl.RGBA8, b.atlasW, b.atlasH, gl.RGBA, gl.UNSIGNED_BYTE, b.surfAlb, NE, CE);
    this.tex2D("surfNrm", gl.RGBA8, b.atlasW, b.atlasH, gl.RGBA, gl.UNSIGNED_BYTE, b.surfNrm, NE, CE);
    this.tex2D("rayDirs", gl.RGBA32F, RAY_SIDE * RAY_SIDE, 1, gl.RGBA, gl.FLOAT, b.rayDirs, NE, CE);
    // dynamic: surfel radiance (4 bytes / surfel)
    const rad = this.tex2D("radiance", gl.R11F_G11F_B10F, b.atlasW, b.atlasH, gl.RGB, gl.HALF_FLOAT, null, NE, CE);
    this.fbRadiance = gl.createFramebuffer()!; gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbRadiance);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, rad, 0);
    // dynamic: L1 SH irradiance volume, one RGBA16F 3D texture per colour channel
    for (const n of ["shR", "shG", "shB"]) {
      const t = (this.tex[n] = gl.createTexture()!); gl.bindTexture(gl.TEXTURE_3D, t);
      gl.texStorage3D(gl.TEXTURE_3D, 1, gl.RGBA16F, GX, GY, GZ);
      for (const p of [gl.TEXTURE_MIN_FILTER, gl.TEXTURE_MAG_FILTER]) gl.texParameteri(gl.TEXTURE_3D, p, gl.LINEAR);
      for (const p of [gl.TEXTURE_WRAP_S, gl.TEXTURE_WRAP_T, gl.TEXTURE_WRAP_R]) gl.texParameteri(gl.TEXTURE_3D, p, CE);
    }
    this.tex.lampSH = gl.createTexture()!; gl.bindTexture(gl.TEXTURE_3D, this.tex.lampSH);
    gl.texImage3D(gl.TEXTURE_3D, 0, gl.RGBA16F, GX, GY, GZ, 0, gl.RGBA, gl.FLOAT, b.lampSH);
    for (const p of [gl.TEXTURE_MIN_FILTER, gl.TEXTURE_MAG_FILTER]) gl.texParameteri(gl.TEXTURE_3D, p, NE);
    for (let z = 0; z < GZ; z++) {
      const fb = gl.createFramebuffer()!; gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
      ["shR", "shG", "shB"].forEach((n, i) => gl.framebufferTextureLayer(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0 + i, this.tex[n], 0, z));
      gl.drawBuffers([gl.COLOR_ATTACHMENT0, gl.COLOR_ATTACHMENT1, gl.COLOR_ATTACHMENT2]);
      gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
      this.fbSH.push(fb);
    }
    // sun shadow map (re-rendered only when the sun moves — the scene is static)
    const sm = this.tex2D("shadow", gl.DEPTH_COMPONENT24, SHADOW_RES, SHADOW_RES, gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, null, gl.LINEAR, CE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE);
    this.fbShadow = gl.createFramebuffer()!; gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbShadow);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, sm, 0); gl.drawBuffers([gl.NONE]);
    // tiling detail noise: rg = gradient, b = fbm, a = grain
    const N = 256, hgt = new Float32Array(N * N), grain = new Float32Array(N * N), px = new Uint8Array(N * N * 4);
    const hash = (x: number, y: number, s: number) => { const v = Math.sin(x * 127.1 + y * 311.7 + s * 74.7) * 43758.5453; return v - Math.floor(v); };
    const vnoise = (x: number, y: number, per: number, s: number) => {
      const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy);
      const h = (a: number, c: number) => hash(((a % per) + per) % per, ((c % per) + per) % per, s);
      return mix(mix(h(xi, yi), h(xi + 1, yi), ux), mix(h(xi, yi + 1), h(xi + 1, yi + 1), ux), uy);
    };
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
      let a = 0, g = 0;
      for (let o = 0; o < 5; o++) { const per = 4 << o; a += vnoise((x / N) * per, (y / N) * per, per, o) / (1 << (o + 1)); }
      for (let o = 0; o < 3; o++) { const per = 32 << o; g += vnoise((x / N) * per, (y / N) * per, per, o + 9) / (1 << (o + 1)); }
      hgt[x + y * N] = a / 0.97; grain[x + y * N] = g / 0.875;
    }
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
      const i = x + y * N, at = (dx: number, dy: number) => { const j = ((x + dx + N) % N) + ((y + dy + N) % N) * N; return hgt[j] * 0.7 + grain[j] * 0.3; };
      px[i * 4] = clamp(128 + (at(1, 0) - at(-1, 0)) * 900, 0, 255); px[i * 4 + 1] = clamp(128 + (at(0, 1) - at(0, -1)) * 900, 0, 255);
      px[i * 4 + 2] = clamp(hgt[i] * 255, 0, 255); px[i * 4 + 3] = clamp(grain[i] * 255, 0, 255);
    }
    this.tex2D("noise", gl.RGBA8, N, N, gl.RGBA, gl.UNSIGNED_BYTE, px, gl.LINEAR_MIPMAP_LINEAR, gl.REPEAT);
    gl.generateMipmap(gl.TEXTURE_2D);
    const aniso = gl.getExtension("EXT_texture_filter_anisotropic");
    if (aniso) gl.texParameterf(gl.TEXTURE_2D, aniso.TEXTURE_MAX_ANISOTROPY_EXT, 8);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  private resize() {
    const gl = this.gl, dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    const w = Math.max(2, Math.floor(this.canvas.clientWidth * dpr)), h = Math.max(2, Math.floor(this.canvas.clientHeight * dpr));
    if (w === this.w && h === this.h) return;
    this.w = this.canvas.width = w; this.h = this.canvas.height = h;
    this.rb.forEach((r) => gl.deleteRenderbuffer(r)); if (this.tex.hdr) gl.deleteTexture(this.tex.hdr);
    if (this.fbMsaa) gl.deleteFramebuffer(this.fbMsaa); if (this.fbResolve) gl.deleteFramebuffer(this.fbResolve);
    const sup = gl.getInternalformatParameter(gl.RENDERBUFFER, gl.RGBA16F, gl.SAMPLES) as Int32Array | null;
    const samples = Math.min(4, sup && sup.length ? sup[0] : 0); // 0 => graceful non-MSAA fallback
    this.rb = [gl.createRenderbuffer()!, gl.createRenderbuffer()!];
    this.fbMsaa = gl.createFramebuffer()!; gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbMsaa);
    gl.bindRenderbuffer(gl.RENDERBUFFER, this.rb[0]); gl.renderbufferStorageMultisample(gl.RENDERBUFFER, samples, gl.RGBA16F, w, h);
    gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.RENDERBUFFER, this.rb[0]);
    gl.bindRenderbuffer(gl.RENDERBUFFER, this.rb[1]); gl.renderbufferStorageMultisample(gl.RENDERBUFFER, samples, gl.DEPTH_COMPONENT24, w, h);
    gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, this.rb[1]);
    const hdr = this.tex2D("hdr", gl.RGBA16F, w, h, gl.RGBA, gl.HALF_FLOAT, null, gl.LINEAR, gl.CLAMP_TO_EDGE);
    this.fbResolve = gl.createFramebuffer()!; gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbResolve);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, hdr, 0);
  }

  private initInput() {
    const c = this.canvas, on = <K extends keyof WindowEventMap>(t: EventTarget, e: K, f: (ev: WindowEventMap[K]) => void) => {
      t.addEventListener(e, f as EventListener); this.cleanup.push(() => t.removeEventListener(e, f as EventListener));
    };
    let drag = false;
    on(c, "pointerdown", (e) => { drag = true; c.setPointerCapture(e.pointerId); this.syncCam(); this.settings.autoCam = false; });
    on(c, "pointerup", () => (drag = false));
    on(c, "pointermove", (e) => { if (!drag) return; this.cam.yaw -= e.movementX * 0.0035; this.cam.pitch = clamp(this.cam.pitch - e.movementY * 0.0035, -1.5, 1.5); });
    on(window, "keydown", (e) => { const k = e.key.toLowerCase(); this.keys.add(k); if ("wasdqe".includes(k)) { this.syncCam(); this.settings.autoCam = false; } });
    on(window, "keyup", (e) => this.keys.delete(e.key.toLowerCase()));
    on(window, "blur", () => this.keys.clear());
  }
  private autoPose: { pos: V3; yaw: number; pitch: number } | null = null;
  private syncCam() { if (this.settings.autoCam && this.autoPose) { this.cam.pos = [...this.autoPose.pos]; this.cam.yaw = this.autoPose.yaw; this.cam.pitch = this.autoPose.pitch; } }

  // ------------------------------------------------------------ per-frame state
  private updateEnvironment() {
    const s = this.settings, a = (s.timeOfDay / 24) * Math.PI * 2 - Math.PI / 2, sa = Math.sin(a), ca = Math.cos(a);
    const night = sa < 0, k = night ? -1 : 1, l = 1 / Math.hypot(ca, sa * 0.9, 0.45);
    this.sunDir = [k * ca * l, k * sa * 0.9 * l, 0.45 * l];
    const day = smooth(0.0, 0.14, sa), moon = smooth(0.02, 0.2, -sa), warm = smooth(0, 0.45, sa), dk = smooth(-0.12, 0.3, sa), dusk = Math.exp(-((sa / 0.2) ** 2)) * 0.55;
    const I = 3.4 * s.sunIntensity * day, e = this.env;
    e.sun = night ? [0.035 * moon, 0.05 * moon, 0.09 * moon] : [I, I * mix(0.42, 0.95, warm), I * mix(0.14, 0.86, warm)];
    e.zen = [mix(0.004, 0.11, dk), mix(0.007, 0.27, dk), mix(0.02, 0.7, dk)];
    e.hor = [mix(0.012, 0.5, dk) + dusk * 0.9, mix(0.016, 0.66, dk) + dusk * 0.32, mix(0.035, 0.88, dk) + dusk * 0.06];
    e.gnd = [e.hor[0] * 0.25, e.hor[1] * 0.25, e.hor[2] * 0.22];
    this.autoExposure = mix(3.2, 1, smooth(-0.1, 0.25, sa)); // cheap analytic eye adaptation
    // moving emissive orbs = dynamic point lights injected into the GI through the surfels
    const t = this.time, P = this.lightPos, C = this.lightCol, on = s.orbs ? 1 : 0;
    const rect = (u: number, hx: number, hz: number, o: number) => { // rounded-rectangle loop
      const per = 4 * (hx + hz), d = (((u % 1) + 1) % 1) * per;
      if (d < 2 * hx) return [-hx + d, -hz, o]; if (d < 2 * hx + 2 * hz) return [hx, -hz + d - 2 * hx, o];
      if (d < 4 * hx + 2 * hz) return [hx - (d - 2 * hx - 2 * hz), hz, o]; return [-hx, hz - (d - 4 * hx - 2 * hz), o];
    };
    const p0 = rect(t * 0.012, 20.4, 12.4, 0), p2 = rect(0.5 - t * 0.01, 20.4, 12.4, 0);
    P.set([p0[0], 2.3 + Math.sin(t * 0.9) * 0.4, p0[1], Math.cos(t * 0.21) * 7, 1.7 + Math.sin(t * 0.6) * 0.5, Math.sin(t * 0.21) * 7, p2[0], 8.6, p2[1]]);
    C.set([34 * on, 9 * on, 2.5 * on, 4 * on, 12 * on, 34 * on, 6 * on, 30 * on, 9 * on]);
  }

  private updateCamera(dt: number) {
    const c = this.cam, s = this.settings, t = this.time * 0.045;
    if (s.autoCam) {
      const pos: V3 = [Math.cos(t) * 13.5, 3.4 + Math.sin(t * 1.7) * 1.6, Math.sin(t) * 6.8 + Math.sin(t * 0.37) * 1.2];
      const tx = Math.cos(t + 2.2) * 9, ty = 3.2, tz = Math.sin(t + 2.2) * 9, dx = tx - pos[0], dy = ty - pos[1], dz = tz - pos[2];
      this.autoPose = { pos, yaw: Math.atan2(-dx, -dz), pitch: Math.atan2(dy, Math.hypot(dx, dz)) };
    } else {
      const sp = (this.keys.has("shift") ? 14 : 5) * dt, sy = Math.sin(c.yaw), cy = Math.cos(c.yaw), k = this.keys;
      const f = (k.has("w") ? 1 : 0) - (k.has("s") ? 1 : 0), r = (k.has("d") ? 1 : 0) - (k.has("a") ? 1 : 0), u = (k.has("e") ? 1 : 0) - (k.has("q") ? 1 : 0);
      c.pos[0] += (-sy * f + cy * r) * sp; c.pos[2] += (-cy * f - sy * r) * sp; c.pos[1] += u * sp;
    }
    const pose = s.autoCam && this.autoPose ? this.autoPose : c, cp = Math.cos(pose.pitch);
    const fwd: V3 = [-Math.sin(pose.yaw) * cp, Math.sin(pose.pitch), -Math.cos(pose.yaw) * cp];
    lookAt(this.view, pose.pos, [pose.pos[0] + fwd[0], pose.pos[1] + fwd[1], pose.pos[2] + fwd[2]], [0, 1, 0]);
    perspective(this.proj, 1.05, this.w / this.h, 0.1, 600); mul(this.vp, this.proj, this.view);
    return { pos: pose.pos, fwd };
  }

  private bindCommon(pr: Prog) {
    const gl = this.gl, u = pr.u, e = this.env;
    const bind = (unit: number, target: number, t: WebGLTexture, loc?: WebGLUniformLocation) => { if (!loc) return; gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(target, t); gl.uniform1i(loc, unit); };
    bind(0, gl.TEXTURE_2D, this.tex.shadow, u.uShadow); bind(1, gl.TEXTURE_3D, this.tex.shR, u.uSHR); bind(2, gl.TEXTURE_3D, this.tex.shG, u.uSHG); bind(3, gl.TEXTURE_3D, this.tex.shB, u.uSHB);
    gl.uniform3fv(u.uSunDir, this.sunDir); gl.uniform3fv(u.uSunColor, e.sun); gl.uniform3fv(u.uSkyZenith, e.zen); gl.uniform3fv(u.uSkyHorizon, e.hor); gl.uniform3fv(u.uGroundCol, e.gnd);
    gl.uniformMatrix4fv(u.uShadowMat, false, this.shadowMat);
    gl.uniform3fv(u.uGridMin, GRID.min as unknown as number[]);
    const sp = GRID.spacing; gl.uniform3f(u.uGridInvSize, 1 / (GX * sp), 1 / (GY * sp), 1 / (GZ * sp));
    if (u.uLightPos) { gl.uniform3fv(u.uLightPos, this.lightPos); gl.uniform3fv(u.uLightCol, this.lightCol); }
    if (u.uBias) gl.uniform1f(u.uBias, sp * 0.3);
    if (u.uEmissive) gl.uniform1f(u.uEmissive, this.settings.emissive * 14);
  }
  private tex2(unit: number, t: WebGLTexture, loc: WebGLUniformLocation) { const gl = this.gl; gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, t); gl.uniform1i(loc, unit); }

  private renderShadow() {
    const gl = this.gl, d = this.sunDir, l = this.lastSun;
    if (Math.abs(d[0] - l[0]) + Math.abs(d[1] - l[1]) + Math.abs(d[2] - l[2]) < 1e-5) return;
    this.lastSun = [...d];
    lookAt(this.view, [d[0] * 70, 5 + d[1] * 70, d[2] * 70], [0, 5, 0], [0, 1, 0]);
    ortho(this.proj, -32, 32, -32, 32, 10, 130); mul(this.lightVP, this.proj, this.view);
    const bias = mat4(); bias[0] = bias[5] = bias[10] = bias[12] = bias[13] = bias[14] = 0.5; mul(this.shadowMat, bias, this.lightVP);
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbShadow); gl.viewport(0, 0, SHADOW_RES, SHADOW_RES);
    gl.enable(gl.DEPTH_TEST); gl.depthMask(true); gl.clear(gl.DEPTH_BUFFER_BIT); gl.disable(gl.CULL_FACE);
    gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(1.5, 3);
    gl.useProgram(this.prog.shadow.p); gl.uniformMatrix4fv(this.prog.shadow.u.uViewProj, false, this.lightVP);
    gl.bindVertexArray(this.scene.vao); gl.drawElements(gl.TRIANGLES, this.scene.count, gl.UNSIGNED_INT, 0);
    gl.disable(gl.POLYGON_OFFSET_FILL); this.stats.drawCalls++;
  }

  /** The whole dynamic GI update. Amortisable: `budget` = fraction of volume slices refreshed per frame. */
  private updateGI() {
    const gl = this.gl, s = this.settings, b = this.bake, RS = RAY_SIDE;
    const n = this.warm < 2 ? GZ : clamp(Math.round(GZ * s.budget), 1, GZ);
    const ext = this.timerExt as { TIME_ELAPSED_EXT: number; GPU_DISJOINT_EXT: number } | null;
    let timing = false;
    if (ext && !this.queryBusy) { this.query = gl.createQuery(); gl.beginQuery(ext.TIME_ELAPSED_EXT, this.query!); timing = true; }
    gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE); gl.depthMask(false); gl.bindVertexArray(null);
    // pass 1 — relight surfels
    let pr = this.prog.relight; gl.useProgram(pr.p); this.bindCommon(pr);
    this.tex2(4, this.tex.surfPos, pr.u.uSurfPos); this.tex2(5, this.tex.surfAlb, pr.u.uSurfAlb); this.tex2(6, this.tex.surfNrm, pr.u.uSurfNrm);
    gl.uniform1f(pr.u.uBounce, s.bounce);
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbRadiance); gl.viewport(0, 0, b.atlasW, b.atlasH); gl.enable(gl.SCISSOR_TEST);
    const sliceH = GY * RS;
    for (let i = 0; i < n;) { // merge contiguous slices into one scissored draw
      const z = (this.cursor + i) % GZ, run = Math.min(n - i, GZ - z);
      gl.scissor(0, z * sliceH, b.atlasW, run * sliceH); gl.drawArrays(gl.TRIANGLES, 0, 3); i += run; this.stats.drawCalls++;
    }
    gl.disable(gl.SCISSOR_TEST);
    // pass 2 — project to SH, blended into the volume (hysteresis via blend constant)
    pr = this.prog.project; gl.useProgram(pr.p);
    this.tex2(4, this.tex.radiance, pr.u.uRadiance); this.tex2(5, this.tex.rayDirs, pr.u.uRayDirs);
    gl.activeTexture(gl.TEXTURE6); gl.bindTexture(gl.TEXTURE_3D, this.tex.lampSH); gl.uniform1i(pr.u.uLampSH, 6);
    const lk = s.emissive * 7; gl.uniform3f(pr.u.uLampCol, lk, lk * 0.6, lk * 0.24);
    gl.viewport(0, 0, GX, GY);
    const alpha = this.warm < 2 ? 1 : 1 - s.hysteresis;
    gl.enable(gl.BLEND); gl.blendColor(0, 0, 0, alpha); gl.blendFunc(gl.CONSTANT_ALPHA, gl.ONE_MINUS_CONSTANT_ALPHA);
    for (let i = 0; i < n; i++) {
      const z = (this.cursor + i) % GZ;
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbSH[z]); gl.uniform1i(pr.u.uLayer, z); gl.drawArrays(gl.TRIANGLES, 0, 3); this.stats.drawCalls++;
    }
    gl.disable(gl.BLEND);
    this.cursor = (this.cursor + n) % GZ; this.warm++;
    this.stats.probes = n * GX * GY; this.stats.surfels = this.stats.probes * RS * RS;
    if (ext) {
      if (timing) { gl.endQuery(ext.TIME_ELAPSED_EXT); this.queryBusy = true; }
      else if (this.query && gl.getQueryParameter(this.query, gl.QUERY_RESULT_AVAILABLE)) {
        if (!gl.getParameter(ext.GPU_DISJOINT_EXT)) this.stats.giMs = mix(this.stats.giMs < 0 ? gl.getQueryParameter(this.query, gl.QUERY_RESULT) / 1e6 : this.stats.giMs, gl.getQueryParameter(this.query, gl.QUERY_RESULT) / 1e6, 0.2);
        gl.deleteQuery(this.query); this.query = null; this.queryBusy = false;
      }
    }
  }

  frame(dt: number) {
    const gl = this.gl, s = this.settings, t0 = performance.now();
    this.resize(); this.time += dt; this.stats.drawCalls = 0;
    if (s.autoTime) s.timeOfDay = (s.timeOfDay + dt * 0.12) % 24;
    this.updateEnvironment();
    this.renderShadow();
    this.updateGI();
    const cam = this.updateCamera(dt);

    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbMsaa); gl.viewport(0, 0, this.w, this.h);
    gl.enable(gl.DEPTH_TEST); gl.depthMask(true); gl.depthFunc(gl.LEQUAL); gl.enable(gl.CULL_FACE); gl.clear(gl.DEPTH_BUFFER_BIT | gl.COLOR_BUFFER_BIT);
    let pr = this.prog.main; gl.useProgram(pr.p); this.bindCommon(pr); this.tex2(4, this.tex.noise, pr.u.uNoise);
    gl.uniformMatrix4fv(pr.u.uViewProj, false, this.vp); gl.uniform3fv(pr.u.uCamPos, cam.pos);
    gl.uniform1f(pr.u.uTime, this.time); gl.uniform1i(pr.u.uMode, s.mode); gl.uniform1f(pr.u.uGiScale, s.gi ? 1 : 0); gl.uniform1f(pr.u.uShadowTexel, 1 / SHADOW_RES);
    gl.uniform4f(pr.u.uModel, 0, 0, 0, 1); gl.uniform4f(pr.u.uOverride, 0, 0, 0, 0);
    gl.bindVertexArray(this.scene.vao); gl.drawElements(gl.TRIANGLES, this.scene.count, gl.UNSIGNED_INT, 0);
    // dynamic objects: lit purely by sun + probes (they never touch the bake)
    gl.bindVertexArray(this.ball.vao);
    const T = this.time, dyn = [[1, 1, 1, 0.12, 1], [0.9, 0.9, 0.88, 0.75, 0], [1, 0.72, 0.3, 0.3, 1]];
    dyn.forEach((m, i) => {
      const ph = T * 0.25 + i * 2.1;
      gl.uniform4f(pr.u.uModel, -6 + i * 6 + Math.sin(ph * 0.7) * 1.5, 1.5 + Math.sin(ph * 2) * 0.35, 8.6 + Math.sin(ph) * 4.2, 0.6);
      gl.uniform4f(pr.u.uOverride, m[0], m[1], m[2], m[3]); gl.uniform1f(pr.u.uOverrideMetal, m[4]);
      gl.drawElements(gl.TRIANGLES, this.ball.count, gl.UNSIGNED_INT, 0);
    });
    // emissive orbs + optional probe visualisation
    pr = this.prog.orb; gl.useProgram(pr.p); this.bindCommon(pr);
    gl.uniformMatrix4fv(pr.u.uViewProj, false, this.vp); gl.uniform1f(pr.u.uSpacing, GRID.spacing);
    if (s.orbs) for (let i = 0; i < 3; i++) {
      gl.uniform4f(pr.u.uOrb, this.lightPos[i * 3], this.lightPos[i * 3 + 1], this.lightPos[i * 3 + 2], 0.16);
      gl.uniform3f(pr.u.uColor, this.lightCol[i * 3] * 1.5, this.lightCol[i * 3 + 1] * 1.5, this.lightCol[i * 3 + 2] * 1.5);
      gl.drawElements(gl.TRIANGLES, this.ball.count, gl.UNSIGNED_INT, 0);
    }
    if (s.showProbes) {
      gl.bindVertexArray(this.ballLo.vao); gl.uniform4f(pr.u.uOrb, 0, 0, 0, 0);
      gl.drawElementsInstanced(gl.TRIANGLES, this.ballLo.count, gl.UNSIGNED_INT, 0, GX * GY * GZ);
    }
    // sky
    pr = this.prog.sky; gl.useProgram(pr.p); this.bindCommon(pr); gl.bindVertexArray(null); gl.disable(gl.CULL_FACE);
    const f = cam.fwd, rl = 1 / Math.hypot(f[2], f[0]), rx = -f[2] * rl, rz = f[0] * rl, th = Math.tan(1.05 / 2);
    gl.uniform3f(pr.u.uCamF, f[0], f[1], f[2]); gl.uniform3f(pr.u.uCamR, rx, 0, rz);
    gl.uniform3f(pr.u.uCamU, -rz * f[1], rz * f[0] - rx * f[2], rx * f[1]); gl.uniform2f(pr.u.uTan, th * (this.w / this.h), th);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    // resolve MSAA -> tonemap to backbuffer
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER, this.fbMsaa); gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, this.fbResolve);
    gl.blitFramebuffer(0, 0, this.w, this.h, 0, 0, this.w, this.h, gl.COLOR_BUFFER_BIT, gl.NEAREST);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.disable(gl.DEPTH_TEST);
    pr = this.prog.post; gl.useProgram(pr.p); this.tex2(0, this.tex.hdr, pr.u.uHdr); gl.uniform1f(pr.u.uExposure, s.exposure * this.autoExposure);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    this.stats.drawCalls += 6 + (s.orbs ? 3 : 0) + (s.showProbes ? 1 : 0);

    this.stats.cpuMs = mix(this.stats.cpuMs, performance.now() - t0, 0.1);
    this.fpsAcc += dt; this.fpsN++;
    if (this.fpsAcc > 0.5) { this.stats.fps = this.fpsN / this.fpsAcc; this.fpsAcc = 0; this.fpsN = 0; }
  }

  dispose() { this.cleanup.forEach((f) => f()); this.gl.getExtension("WEBGL_lose_context")?.loseContext(); }
}
