// Procedural demo scene: a two-storey cloister courtyard (~48 x 32 m).
// Pure data generation — runs inside the bake worker, no GL dependencies.
import { MAT, MeshBuilder, type MeshData } from "./mesh";

/** Irradiance volume layout. Probes sit at min + (i + 0.5) * spacing. */
export const GRID = { min: [-23.8, -0.35, -16.1] as const, spacing: 1.4, dims: [34, 10, 23] as const };

/** Rays per probe = RAY_SIDE^2 (baked once, relit every frame). */
export const RAY_SIDE = 10;
/** World positions (xyz triples) of static lanterns; filled by buildScene(). */
export const LAMPS: number[] = [];

const rng = (seed: number) => () => {
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const COLUMN = [0.46, 0.12, 0.5, 0.17, 0.5, 0.22, 0.46, 0.27, 0.4, 0.3, 0.38, 0.36, 0.36, 0.42, 0.36, 1.2, 0.35, 2.0, 0.33, 2.8,
  0.305, 3.66, 0.3, 3.7, 0.335, 3.74, 0.335, 3.78, 0.3, 3.82, 0.32, 3.86, 0.4, 3.94, 0.46, 4.0, 0.47, 4.04, 0, 4.04];
const COLUMN_UP = [0.3, 0.08, 0.33, 0.12, 0.33, 0.16, 0.27, 0.2, 0.24, 0.26, 0.24, 0.9, 0.225, 1.6, 0.2, 2.24, 0.2, 2.28, 0.23, 2.31,
  0.2, 2.34, 0.22, 2.38, 0.29, 2.46, 0.3, 2.5, 0, 2.5];
const BALUSTER = [0.075, 0, 0.075, 0.05, 0.05, 0.09, 0.085, 0.2, 0.1, 0.3, 0.075, 0.44, 0.045, 0.58, 0.06, 0.66, 0.075, 0.72, 0.075, 0.8];
const URN = [0.22, 0, 0.26, 0.04, 0.2, 0.1, 0.3, 0.3, 0.42, 0.55, 0.44, 0.7, 0.36, 0.85, 0.33, 0.92, 0.4, 1.0, 0.36, 1.0, 0.3, 0.9, 0, 0.9];
const BANNER_COLORS = [[0.62, 0.05, 0.04], [0.75, 0.48, 0.05], [0.07, 0.36, 0.1], [0.06, 0.14, 0.55]];

const stone = (b: MeshBuilder, k = 1) => b.material(0.66 * k, 0.6 * k, 0.5 * k, 0.78, 0, MAT.STONE);
const plaster = (b: MeshBuilder, k = 1) => b.material(0.74 * k, 0.66 * k, 0.52 * k, 0.9, 0, MAT.PLASTER);

/** One side of the cloister, built in local space (colonnade at z = D, outward = +z) and rotated. */
function arcadeSide(b: MeshBuilder, L: number, D: number, rot: number, ends: boolean, rnd: () => number) {
  const cs = Math.cos(rot), sn = Math.sin(rot);
  const at = (x: number, y: number, z: number, s = 1) => b.xf(x * cs + z * sn, y, -x * sn + z * cs, rot, s);
  const local = () => b.xf(0, 0, 0, rot);
  const zf = D - 0.4, zb = D + 0.4, R = 1.6, Y0 = 4.2, Y1 = 6.6;

  for (let x = -L, ci = 0; x <= L + 0.01; x += 4, ci++) {
    const isEnd = Math.abs(Math.abs(x) - L) < 0.01;
    if (!isEnd || ends) {
      // lower fluted column + plinth + abacus
      stone(at(x, 0, D), 0.97 + rnd() * 0.06); b.lathe(COLUMN, 96, 16, 0.06, 6 / 19, 10 / 19);
      local(); b.rbox(x, 0.06, D, 0.54, 0.06, 0.54, 0.025, 2); b.rbox(x, 4.12, D, 0.52, 0.08, 0.52, 0.03, 2);
      // upper column
      stone(at(x, 7, D)); b.lathe(COLUMN_UP, 28);
      local(); b.rbox(x, 7.04, D, 0.36, 0.04, 0.36, 0.02, 2); b.rbox(x, 9.55, D, 0.34, 0.05, 0.34, 0.02, 2);
    }
    local();
    // pilasters on the outer wall + ceiling beam
    plaster(b, 0.92); b.rbox(x, 3.3, D + 4.74, 0.32, 3.3, 0.12, 0.03, 2); b.rbox(x, 8.6, D + 4.74, 0.26, 1.6, 0.1, 0.03, 2);
    b.material(0.2, 0.11, 0.055, 0.7, 0, MAT.WOOD); b.rbox(x, 6.44, D + 2.4, 0.16, 0.16, 2.45, 0.03, 2);
    if (x > L - 0.01) break;

    // ---- bay between x and x + 4 ----
    const cx = x + 2, N = 28;
    plaster(b);
    const xs: number[] = [x], ys: number[] = [Y0];
    for (let k = 0; k <= N; k++) { const a = Math.PI * (1 - k / N); xs.push(cx + R * Math.cos(a)); ys.push(Y0 + R * Math.sin(a)); }
    xs.push(x + 4); ys.push(Y0);
    for (let k = 0; k < xs.length - 1; k++) {
      b.quad([xs[k + 1], ys[k + 1], zf], [xs[k], ys[k], zf], [xs[k], Y1, zf], [xs[k + 1], Y1, zf]);
      b.quad([xs[k], ys[k], zb], [xs[k + 1], ys[k + 1], zb], [xs[k + 1], Y1, zb], [xs[k], Y1, zb]);
    }
    b.quad([x, Y0, zb], [x, Y0, zf], [cx - R, Y0, zf], [cx - R, Y0, zb]);
    b.quad([cx + R, Y0, zb], [cx + R, Y0, zf], [x + 4, Y0, zf], [x + 4, Y0, zb]);
    stone(b, 0.95); // arch intrados + archivolt moulding
    b.surface(N, 2, (u, v, o) => { const a = Math.PI * (1 - u); o[0] = cx + R * Math.cos(a); o[1] = Y0 + R * Math.sin(a); o[2] = zf + (zb - zf) * v; });
    for (const z of [zf, zb]) b.tube((t, o) => { const a = Math.PI * (1 - t); o[0] = cx + (R + 0.1) * Math.cos(a); o[1] = Y0 + (R + 0.1) * Math.sin(a); o[2] = z; }, () => 0.085, N, 8);

    // balustrade
    stone(b); b.rbox(cx, 7.96, D, 1.76, 0.06, 0.13, 0.03, 2); b.rbox(cx, 7.06, D, 1.76, 0.06, 0.13, 0.02, 2);
    for (let k = 0; k < 10; k++) { at(x + 0.38 + k * 0.36, 7.11, D); b.lathe(BALUSTER, 10); }

    // hanging lantern (emissive -> feeds GI through the surfels for free)
    if (ci % 2 === 0) {
      at(cx, 0, D + 2.4);
      LAMPS.push(cx * cs + (D + 2.4) * sn, 5.5, -cx * sn + (D + 2.4) * cs);
      b.material(0.06, 0.05, 0.04, 0.5, 1, MAT.METAL); b.tube((t, o) => { o[0] = 0; o[1] = 6.6 - t * 0.85; o[2] = 0; }, () => 0.015, 1, 6);
      b.lathe([0.02, 5.2, 0.13, 5.24, 0.15, 5.3, 0.03, 5.36, 0, 5.36], 12); b.lathe([0.03, 5.68, 0.16, 5.72, 0.05, 5.8, 0, 5.8], 12);
      b.material(1, 0.62, 0.25, 0.6, 0, MAT.LAMP, 1); b.lathe([0.03, 5.36, 0.12, 5.42, 0.14, 5.52, 0.12, 5.62, 0.03, 5.68], 14);
    }
    // potted shrub (courtyard side)
    if (ci % 2 === 1) {
      at(cx + 2, 0, D - 1.05, 0.9);
      b.material(0.5, 0.2, 0.1, 0.75, 0, MAT.STONE); b.lathe(URN, 28);
      const s1 = rnd() * 6, s2 = rnd() * 6;
      b.material(0.1, 0.24, 0.05, 0.7, 0, MAT.LEAF);
      b.surface(18, 12, (u, v, o) => {
        const a = u * Math.PI * 2, p = v * Math.PI, r = 0.55 * (1 + 0.16 * Math.sin(3 * a + s1) * Math.sin(4 * p) + 0.1 * Math.cos(5 * a + s2) * Math.sin(p * 3));
        o[0] = r * Math.sin(p) * Math.cos(a); o[1] = 1.3 + r * 0.9 * Math.cos(p); o[2] = r * Math.sin(p) * Math.sin(a);
      });
    }
    // heraldic banner hung from the gallery on every other pier
    if (ci % 2 === 1 && x + 4 < L) {
      local();
      const c = BANNER_COLORS[(((ci + Math.round(rot * 2)) % 4) + 4) % 4], px = x + 4, ph = rnd() * 6;
      b.material(c[0], c[1], c[2], 0.85, 0, MAT.FABRIC);
      b.surface(8, 20, (u, v, o) => {
        o[0] = px + (u - 0.5) * 1.0; o[1] = 6.5 - v * (2.0 + 0.25 * Math.abs(u - 0.5) * -2 + 0.25);
        o[2] = D - 0.52 - 0.05 * v * Math.sin(u * 9 + ph) - 0.03 * Math.sin(v * 7 + ph);
      }, false, true);
    }
  }
  local();
  // architrave + cornices
  plaster(b, 0.95); b.box(-L - 0.35, 9.6, D - 0.35, L + 0.35, 10.2, D + 0.35);
  stone(b, 0.9); b.rbox(0, 6.82, D - 0.47, L + 0.6, 0.2, 0.1, 0.05, 2); b.rbox(0, 10.1, D - 0.4, L + 0.5, 0.09, 0.09, 0.04, 2);
  // roof: top, underside, fascia
  const z0 = D - 0.9, z1 = D + 5.4, s = 0.3, RL = L + 5.4, y0 = 10.22, y1 = y0 + (z1 - z0) * s;
  b.material(0.5, 0.17, 0.08, 0.8, 0, MAT.ROOF); b.quad([-RL, y0, z0], [-RL, y1, z1], [RL, y1, z1], [RL, y0, z0]);
  b.material(0.2, 0.11, 0.055, 0.8, 0, MAT.WOOD);
  b.quad([RL, y0 - 0.22, z0], [RL, y1 - 0.22, z1], [-RL, y1 - 0.22, z1], [-RL, y0 - 0.22, z0]);
  b.quad([-RL, y0 - 0.22, z0], [-RL, y0, z0], [RL, y0, z0], [RL, y0 - 0.22, z0]);
}

function tree(b: MeshBuilder, rnd: () => number, x: number, z: number) {
  stone(b.xf(x, 0, z), 0.9); b.lathe([1.35, 0, 1.4, 0.05, 1.4, 0.4, 1.34, 0.5, 1.2, 0.5, 1.14, 0.42], 48);
  b.material(0.09, 0.06, 0.04, 0.95, 0, MAT.GRASS); b.lathe([1.16, 0.43, 0, 0.47], 24);
  b.xf();
  const grow = (px: number, py: number, pz: number, dx: number, dy: number, dz: number, len: number, r: number, depth: number) => {
    const ex = px + dx * len, ey = py + dy * len, ez = pz + dz * len, k = len * 0.3;
    const mx = (px + ex) / 2 + (rnd() - 0.5) * k, my = (py + ey) / 2, mz = (pz + ez) / 2 + (rnd() - 0.5) * k;
    b.material(0.16, 0.1, 0.06, 0.9, 0, MAT.WOOD);
    b.tube((t, o) => {
      const a = (1 - t) * (1 - t), c = 2 * t * (1 - t), d = t * t;
      o[0] = a * px + c * mx + d * ex; o[1] = a * py + c * my + d * ey; o[2] = a * pz + c * mz + d * ez;
    }, (t) => r * (1 - 0.38 * t) * (depth === 0 ? 1 + 0.5 * Math.pow(1 - t, 6) : 1), depth === 0 ? 10 : 6, Math.max(6, 14 - depth * 3));
    if (depth >= 3) {
      for (let i = 0; i < 2; i++) {
        const R = 0.75 + rnd() * 0.55, s1 = rnd() * 6, s2 = rnd() * 6, g = 0.75 + rnd() * 0.5;
        const ox = ex + (rnd() - 0.5) * 0.9, oy = ey + (rnd() - 0.3) * 0.6, oz = ez + (rnd() - 0.5) * 0.9;
        b.material(0.07 * g, 0.2 * g, 0.035 * g, 0.65, 0, MAT.LEAF);
        b.surface(14, 9, (u, v, o) => {
          const a = u * Math.PI * 2, p = v * Math.PI;
          const rr = R * (1 + 0.2 * Math.sin(3 * a + s1) * Math.sin(4 * p) + 0.13 * Math.cos(5 * a + s2) * Math.sin(3 * p));
          o[0] = ox + rr * Math.sin(p) * Math.cos(a); o[1] = oy + rr * 0.72 * Math.cos(p); o[2] = oz + rr * Math.sin(p) * Math.sin(a);
        });
      }
      return;
    }
    const n = depth === 0 ? 4 : 2 + (rnd() < 0.6 ? 1 : 0), a0 = rnd() * 6.28;
    for (let i = 0; i < n; i++) {
      const a = a0 + (i / n) * 6.28 + (rnd() - 0.5) * 0.7, sp = 0.75 + rnd() * 0.35;
      let nx = dx * 0.55 + Math.cos(a) * sp, ny = dy * 0.55 + 0.35 + rnd() * 0.3, nz = dz * 0.55 + Math.sin(a) * sp;
      const l = 1 / Math.hypot(nx, ny, nz); nx *= l; ny *= l; nz *= l;
      grow(ex, ey, ez, nx, ny, nz, len * (0.62 + rnd() * 0.14), r * 0.6, depth + 1);
    }
  };
  grow(x, 0.42, z, (rnd() - 0.5) * 0.15, 1, (rnd() - 0.5) * 0.15, 2.7, 0.24, 0);
}

export function buildScene(): MeshData {
  const b = new MeshBuilder(), rnd = rng(1337);
  LAMPS.length = 0;

  // ground: tessellated courtyard floor (gives baked AO some resolution) + far terrain
  b.material(0.52, 0.47, 0.4, 0.7, 0, MAT.TILE);
  b.surface(92, 60, (u, v, o) => { o[0] = -22.9 + 45.8 * u; o[1] = 0; o[2] = -14.9 + 29.8 * v; }, true);
  b.material(0.16, 0.24, 0.07, 0.95, 0, MAT.GRASS);
  b.quad([-300, -0.05, 300], [300, -0.05, 300], [300, -0.05, -300], [-300, -0.05, -300]);

  // outer walls (thick: probe spacing is 1.4 m, walls are 1.2 m — bake marks in-wall probes invalid)
  plaster(b, 0.97);
  b.box(-24, -0.5, 14.8, 24, 12.6, 16); b.box(-24, -0.5, -16, 24, 12.6, -14.8);
  b.box(22.8, -0.5, -14.8, 24, 12.6, 14.8); b.box(-24, -0.5, -14.8, -22.8, 12.6, 14.8);
  // gallery floor slabs
  stone(b, 0.9);
  b.box(-22.8, 6.6, 9.5, 22.8, 7, 14.8); b.box(-22.8, 6.6, -14.8, 22.8, 7, -9.5);
  b.box(17.5, 6.6, -9.5, 22.8, 7, 9.5); b.box(-22.8, 6.6, -9.5, -17.5, 7, 9.5);

  arcadeSide(b, 18, 10, 0, true, rnd); arcadeSide(b, 18, 10, Math.PI, true, rnd);
  arcadeSide(b, 10, 18, Math.PI / 2, false, rnd); arcadeSide(b, 10, 18, -Math.PI / 2, false, rnd);

  // fountain
  stone(b.xf(), 0.92);
  b.lathe([5.2, 0, 5.2, 0.14, 4.6, 0.15, 4.6, 0.29, 3.3, 0.3], 96);
  stone(b, 1.02);
  b.lathe([3.1, 0.3, 3.25, 0.36, 3.25, 0.48, 3.12, 0.56, 3.12, 0.92, 3.3, 1.0, 3.3, 1.1, 3.0, 1.12, 2.86, 1.0, 2.86, 0.4], 96);
  b.lathe([0.7, 0.4, 0.75, 0.9, 0.5, 1.1, 0.32, 1.5, 0.28, 2.1, 0.4, 2.3, 1.0, 2.5, 1.5, 2.72, 1.56, 2.84, 1.44, 2.84, 0.9, 2.62, 0.3, 2.56,
    0.2, 2.9, 0.26, 3.3, 0.5, 3.45, 0.56, 3.55, 0.3, 3.56, 0.12, 3.75, 0.16, 3.9, 0, 4.02], 64);
  b.material(0.02, 0.09, 0.1, 0.06, 0, MAT.WATER); b.lathe([2.87, 0.88, 0, 0.88], 64); b.lathe([1.45, 2.78, 0, 2.78], 48);

  // bronze torus-knot sculptures on pedestals + benches
  for (const sx of [-1, 1]) {
    stone(b.xf(sx * 8.5, 0, 0), 0.85);
    b.rbox(0, 0.1, 0, 0.75, 0.1, 0.75, 0.03, 2); b.rbox(0, 0.7, 0, 0.55, 0.5, 0.55, 0.04, 2); b.rbox(0, 1.26, 0, 0.66, 0.06, 0.66, 0.03, 2);
    b.material(0.72, 0.43, 0.18, 0.32, 1, MAT.METAL);
    b.xf(sx * 8.5, 2.35, 0, sx * 0.6, 0.42);
    b.tube((t, o) => {
      const a = t * Math.PI * 2, r = 2 + Math.cos(3 * a);
      o[0] = r * Math.cos(2 * a); o[1] = r * Math.sin(2 * a) * 0.95 + 0.2; o[2] = -Math.sin(3 * a) * 1.1;
    }, () => 0.42, 260, 18);
    for (const sz of [-1, 1]) {
      stone(b.xf(sx * 8.5, 0, sz * 6.6), 1.0);
      b.rbox(0, 0.5, 0, 1.3, 0.07, 0.34, 0.035, 3); b.rbox(-0.95, 0.22, 0, 0.12, 0.22, 0.28, 0.03, 2); b.rbox(0.95, 0.22, 0, 0.12, 0.22, 0.28, 0.03, 2);
      tree(b, rnd, sx * 13.4, sz * 5.4);
    }
  }

  // long fabric canopies sagging across the courtyard (strong coloured bounce)
  b.xf();
  [-11, -5.2, 5.2, 11].forEach((x0, i) => {
    const c = BANNER_COLORS[i], ph = i * 1.7;
    b.material(c[0], c[1], c[2], 0.85, 0, MAT.FABRIC);
    b.surface(10, 72, (u, v, o) => {
      const q = 2 * v - 1, sag = 1 - q * q;
      o[0] = x0 + (u - 0.5) * (2.6 - 0.5 * sag) + 0.12 * Math.sin(v * 9 + ph);
      o[1] = 9.5 - 1.9 * sag + 0.07 * Math.sin(u * 7 + v * 31 + ph) * sag + 0.1 * (u - 0.5) * (u - 0.5) * 4;
      o[2] = q * 9.45;
    }, false, true);
  });
  return b.build();
}
