// GLSL ES 3.00 sources. Kept engine-neutral: every pass is a plain function of textures + uniforms.
import { GRID, RAY_SIDE } from "./scene";

const HEAD = `#version 300 es
precision highp float; precision highp int; precision highp sampler2D; precision highp sampler3D; precision highp sampler2DShadow;
#define GX ${GRID.dims[0]}
#define GY ${GRID.dims[1]}
#define GZ ${GRID.dims[2]}
#define RS ${RAY_SIDE}
`;

/** Shared lighting environment: sky model, sun shadow, irradiance volume lookup. */
const COMMON = `
uniform vec3 uSunDir, uSunColor, uSkyZenith, uSkyHorizon, uGroundCol;
uniform sampler2DShadow uShadow; uniform mat4 uShadowMat;
uniform sampler3D uSHR, uSHG, uSHB;
uniform vec3 uGridMin, uGridInvSize;

vec3 skyColor(vec3 d) {
  vec3 c = mix(uSkyHorizon, uSkyZenith, sqrt(max(d.y, 0.0)));
  c = mix(c, uGroundCol, smoothstep(0.0, -0.2, d.y));
  float s = max(dot(d, uSunDir), 0.0);
  return c + uSunColor * (0.06 * pow(s, 6.0) + 0.25 * pow(s, 64.0));
}
float shadow1(vec3 p) { vec4 s = uShadowMat * vec4(p, 1.0); return texture(uShadow, s.xyz); }

// The ENTIRE per-pixel GI cost: 3 hardware-trilinear taps + dot products.
// Coefficients are stored pre-convolved so  E/pi = dot(sh, vec4(n, 1)).
struct SH { vec4 r, g, b; };
SH fetchSH(vec3 p) {
  vec3 uvw = (p - uGridMin) * uGridInvSize;
  return SH(texture(uSHR, uvw), texture(uSHG, uvw), texture(uSHB, uvw));
}
vec3 evalSH(SH s, vec3 n) { vec4 b = vec4(n, 1.0); return max(vec3(dot(s.r, b), dot(s.g, b), dot(s.b, b)), 0.0); }
`;

const FS_TRI = HEAD + `
out vec2 vUv;
void main() { vUv = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2); gl_Position = vec4(vUv * 2.0 - 1.0, 1.0, 1.0); }`;

// ---------------------------------------------------------------- GI pass 1: relight surfels
// One fragment per baked surfel. No ray tracing: direct sun (1 shadow tap) + point lights + emissive
// + last frame's irradiance volume (=> infinite bounces converge over a few frames for free).
const RELIGHT_FS = HEAD + COMMON + `
uniform sampler2D uSurfPos, uSurfAlb, uSurfNrm;
uniform vec3 uLightPos[3], uLightCol[3];
uniform float uEmissive, uBounce, uBias;
out vec4 o;
void main() {
  ivec2 c = ivec2(gl_FragCoord.xy);
  vec4 P = texelFetch(uSurfPos, c, 0);
  if (P.w < -0.5) { o = vec4(0.0); return; }
  if (P.w < 0.5) { o = vec4(skyColor(P.xyz), 1.0); return; }
  vec4 A = texelFetch(uSurfAlb, c, 0); vec3 alb = A.rgb * A.rgb;
  vec3 N = texelFetch(uSurfNrm, c, 0).xyz * 2.0 - 1.0;
  float nl = dot(N, uSunDir);
  vec3 E = nl > 0.0 ? uSunColor * nl * shadow1(P.xyz + N * 0.06) : vec3(0.0);
  for (int i = 0; i < 3; i++) {
    vec3 L = uLightPos[i] - P.xyz; float d2 = dot(L, L);
    E += uLightCol[i] * max(dot(N, L) * inversesqrt(d2), 0.0) / (d2 + 1.0);
  }
  E += evalSH(fetchSH(P.xyz + N * uBias), N) * uBounce;
  o = vec4(min(alb * E + alb * A.a * uEmissive, vec3(60.0)), 1.0);
}`;

// ---------------------------------------------------------------- GI pass 2: project to L1 SH
// One fragment per probe, written straight into slices of three RGBA16F 3D textures.
// Temporal hysteresis is done by fixed-function blending (CONSTANT_ALPHA) — zero extra cost.
const PROJECT_FS = HEAD + `
uniform sampler2D uRadiance, uRayDirs; uniform sampler3D uLampSH; uniform vec3 uLampCol; uniform int uLayer;
layout(location = 0) out vec4 oR; layout(location = 1) out vec4 oG; layout(location = 2) out vec4 oB;
void main() {
  ivec2 p = ivec2(gl_FragCoord.xy), base = ivec2(p.x, p.y + uLayer * GY) * RS;
  vec3 s0 = vec3(0.0), sx = vec3(0.0), sy = vec3(0.0), sz = vec3(0.0);
  for (int j = 0; j < RS; j++) for (int i = 0; i < RS; i++) {
    vec3 L = texelFetch(uRadiance, base + ivec2(i, j), 0).rgb;
    vec3 d = texelFetch(uRayDirs, ivec2(i + j * RS, 0), 0).xyz;
    s0 += L; sx += L * d.x; sy += L * d.y; sz += L * d.z;
  }
  float k = 1.0 / float(RS * RS), k1 = 2.0 * k * 0.9; // 0.9: slight L1 de-ringing
  vec4 lamp = texelFetch(uLampSH, ivec3(p, uLayer), 0); // baked lantern transfer (all static lights at once)
  oR = vec4(k1 * vec3(sx.r, sy.r, sz.r), k * s0.r) + lamp * uLampCol.r;
  oG = vec4(k1 * vec3(sx.g, sy.g, sz.g), k * s0.g) + lamp * uLampCol.g;
  oB = vec4(k1 * vec3(sx.b, sy.b, sz.b), k * s0.b) + lamp * uLampCol.b;
}`;

// ---------------------------------------------------------------- forward PBR
const MAIN_VS = HEAD + `
layout(location = 0) in vec3 aPos; layout(location = 1) in vec3 aNrm; layout(location = 2) in vec4 aCol; layout(location = 3) in vec4 aMat;
uniform mat4 uViewProj; uniform vec4 uModel; // xyz = translation, w = uniform scale
out vec3 vPos, vNrm; out vec4 vCol; out vec3 vMat; flat out int vId;
void main() {
  vPos = aPos * uModel.w + uModel.xyz; vNrm = aNrm; vCol = aCol; vMat = aMat.xyz; vId = int(aMat.w * 255.0 + 0.5);
  gl_Position = uViewProj * vec4(vPos, 1.0);
}`;

const MAIN_FS = HEAD + COMMON + `
in vec3 vPos, vNrm; in vec4 vCol; in vec3 vMat; flat in int vId;
uniform sampler2D uNoise;
uniform vec3 uCamPos, uLightPos[3], uLightCol[3];
uniform vec4 uOverride; // dynamic objects: rgb albedo, a > 0 enables (a = roughness), metal via uOverrideMetal
uniform float uOverrideMetal, uTime, uBias, uEmissive, uGiScale, uShadowTexel;
uniform int uMode;
out vec4 o;
const float PI = 3.14159265;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float shadowPCF(vec3 p) {
  vec4 s = uShadowMat * vec4(p, 1.0); float t = uShadowTexel * 1.25, r = hash(gl_FragCoord.xy) * 6.283;
  vec2 a = vec2(cos(r), sin(r)) * t, b = vec2(-a.y, a.x);
  return 0.25 * (texture(uShadow, vec3(s.xy + a, s.z)) + texture(uShadow, vec3(s.xy - a, s.z))
               + texture(uShadow, vec3(s.xy + b, s.z)) + texture(uShadow, vec3(s.xy - b, s.z)));
}
vec3 specBRDF(vec3 N, vec3 V, vec3 L, vec3 F0, float a) { // GGX, Schlick, Smith-joint approx (already * NdotL)
  vec3 H = normalize(V + L); float nh = max(dot(N, H), 0.0), nv = max(dot(N, V), 1e-3), nl = max(dot(N, L), 0.0), vh = max(dot(V, H), 0.0);
  float a2 = a * a, d = nh * nh * (a2 - 1.0) + 1.0, D = a2 / (PI * d * d);
  float Vis = 0.5 / mix(2.0 * nl * nv, nl + nv, a);
  return (F0 + (1.0 - F0) * pow(1.0 - vh, 5.0)) * (D * Vis * nl);
}
void main() {
  vec3 Ng = normalize(vNrm), N = Ng, V = normalize(uCamPos - vPos);
  vec3 alb = vCol.rgb * vCol.rgb; float ao = vCol.a, rough = vMat.x, metal = vMat.y, emis = vMat.z, trans = 0.0;
  int id = vId;
  if (uOverride.a > 0.0) { alb = uOverride.rgb; rough = uOverride.a; metal = uOverrideMetal; id = 5; ao = 1.0; }

  // --- procedural surface detail: one tiling noise texture, triplanar (rg = gradient, b = fbm, a = grain)
  vec3 w = Ng * Ng; float sc = id == 4 ? 1.7 : (id == 8 ? 0.9 : 0.45);
  vec3 q = vPos * sc; if (id == 8) q.y *= 0.12;
  vec4 nx = texture(uNoise, q.zy), ny = texture(uNoise, q.xz), nz = texture(uNoise, q.xy);
  vec4 n4 = nx * w.x + ny * w.y + nz * w.z;
  vec3 bump = (vec3(0.0, nx.g, nx.r) * w.x + vec3(ny.r, 0.0, ny.g) * w.y + vec3(nz.r, nz.g, 0.0) * w.z) - 0.5 * vec3(w.y + w.z, w.x + w.z, w.x + w.y);
  float macro = texture(uNoise, vPos.xz * 0.021 + vPos.y * 0.033).b;
  float bumpK = 0.35, tint = 0.72 + 0.56 * n4.b;

  if (id == 1) {            // paving: staggered flagstones with grout
    vec2 uv = vPos.xz / vec2(1.2, 0.8); uv.x += 0.5 * floor(uv.y);
    vec2 f = fract(uv), e = min(f, 1.0 - f) * vec2(1.2, 0.8); float g = smoothstep(0.0, 0.025 + fwidth(uv.x) * 1.5, min(e.x, e.y));
    float h = hash(floor(uv)); alb *= mix(0.45, 0.82 + 0.3 * h, g) * mix(vec3(1.0), vec3(1.05, 0.97, 0.9), h);
    rough = mix(0.95, rough - 0.25 * n4.a * h, g); bumpK = 0.25;
  } else if (id == 7) {     // terracotta barrel tiles
    float c = (abs(Ng.x) > abs(Ng.z) ? vPos.z : vPos.x) / 0.28, r = vPos.y / 0.1;
    float fc = fract(c), fr = fract(r), h = hash(vec2(floor(c), floor(r)));
    N = normalize(N + (abs(Ng.x) > abs(Ng.z) ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0)) * (fc - 0.5) * 1.6);
    alb *= (0.6 + 0.5 * h) * mix(0.35, 1.0, smoothstep(0.0, 0.12, fr)) * mix(0.5, 1.0, smoothstep(0.0, 0.15, min(fc, 1.0 - fc)));
  } else if (id == 3) {     // fabric: thread weave + translucency
    alb *= 0.8 + 0.4 * n4.a; trans = 0.45; bumpK = 0.15;
  } else if (id == 4) {     // foliage
    alb *= 0.45 + 1.3 * n4.b * n4.a * 1.6; trans = 0.35; bumpK = 1.6; ao *= 0.6 + 0.4 * n4.b;
  } else if (id == 6) {     // water
    vec2 uv = vPos.xz * 0.35; vec4 r1 = texture(uNoise, uv + uTime * vec2(0.02, 0.013)), r2 = texture(uNoise, uv * 1.7 - uTime * vec2(0.017, 0.022));
    N = normalize(vec3((r1.r + r2.r - 1.0) * 0.35, 1.0, (r1.g + r2.g - 1.0) * 0.35)); bumpK = 0.0;
  } else if (id == 5 || id == 10) { bumpK = 0.04; rough += 0.15 * (n4.b - 0.5);
  } else if (id == 8) { alb *= 0.6 + 0.8 * n4.b; bumpK = 0.5;
  } else if (id == 9) { alb *= 0.5 + n4.b * 1.1; bumpK = 0.8;
  } else {                  // stone / plaster: grain + large weathering stains
    alb *= tint * (0.78 + 0.44 * macro) * mix(vec3(1.0), vec3(0.93, 0.98, 1.04), macro); rough = clamp(rough + 0.2 * (n4.a - 0.5), 0.3, 1.0);
    if (id == 2) alb *= mix(0.62, 1.0, smoothstep(0.0, 0.9, vPos.y + macro * 1.2)); // rising damp near the ground
  }
  N = normalize(N - bump * bumpK * 2.0);

  vec3 F0 = mix(vec3(0.04), alb, metal), dAlb = alb * (1.0 - metal);
  float a = max(rough * rough, 0.02), nv = max(dot(N, V), 1e-3);

  // --- direct sun
  float nl = dot(N, uSunDir), sh = (nl > 0.0 || trans > 0.0) ? shadowPCF(vPos + Ng * (nl > 0.0 ? 0.035 : -0.035)) : 0.0;
  vec3 direct = uSunColor * sh * (dAlb * max(nl, 0.0) + PI * specBRDF(N, V, uSunDir, F0, a) + dAlb * trans * max(-nl, 0.0));
  for (int i = 0; i < 3; i++) {
    vec3 L = uLightPos[i] - vPos; float d2 = dot(L, L); L *= inversesqrt(d2);
    direct += uLightCol[i] / (d2 + 1.0) * (dAlb * max(dot(N, L), 0.0) + PI * specBRDF(N, V, L, F0, a));
  }

  // --- probe GI: diffuse from N, rough specular from the reflection vector (same 3 taps)
  SH s = fetchSH(vPos + Ng * uBias);
  vec3 E = evalSH(s, N) * ao * uGiScale;
  vec3 R = reflect(-V, N);
  vec3 env = id == 6 ? skyColor(R) : mix(evalSH(s, R), evalSH(s, N), rough) * uGiScale;
  vec4 r4 = rough * vec4(-1.0, -0.0275, -0.572, 0.022) + vec4(1.0, 0.0425, 1.04, -0.04);   // Karis env-BRDF
  vec2 AB = vec2(-1.04, 1.04) * (min(r4.x * r4.x, exp2(-9.28 * nv)) * r4.x + r4.y) + r4.zw;
  vec3 indirect = dAlb * E + env * (F0 * AB.x + AB.y) * min(ao + 0.3, 1.0);

  vec3 c = direct + indirect + alb * emis * uEmissive * 1.5;
  if (uMode == 1) c = direct;
  else if (uMode == 2) c = indirect;
  else if (uMode == 3) c = evalSH(s, Ng) * uGiScale;
  else if (uMode == 4) c = vec3(ao);
  else if (uMode == 5) c = alb;
  if (uMode < 3) { float d = length(uCamPos - vPos); c = mix(c, uSkyHorizon * 0.8, 1.0 - exp(-max(d - 30.0, 0.0) * 0.004)); }
  o = vec4(c, 1.0);
}`;

const SHADOW_VS = HEAD + `
layout(location = 0) in vec3 aPos; uniform mat4 uViewProj;
void main() { gl_Position = uViewProj * vec4(aPos, 1.0); }`;
const SHADOW_FS = HEAD + `void main() {}`;

// ---------------------------------------------------------------- sky dome (fullscreen at far plane)
const SKY_FS = HEAD + COMMON + `
in vec2 vUv; uniform vec3 uCamR, uCamU, uCamF; uniform vec2 uTan; out vec4 o;
void main() {
  vec2 n = vUv * 2.0 - 1.0; vec3 d = normalize(uCamF + uCamR * n.x * uTan.x + uCamU * n.y * uTan.y);
  float s = dot(d, uSunDir);
  o = vec4(skyColor(d) + uSunColor * 40.0 * smoothstep(0.9994, 0.9998, s), 1.0);
}`;

// ---------------------------------------------------------------- probe visualisation / emissive orbs
const ORB_VS = HEAD + `
layout(location = 0) in vec3 aPos;
uniform mat4 uViewProj; uniform vec4 uOrb; uniform vec3 uGridMin; uniform float uSpacing;
out vec3 vN, vC;
void main() {
  vec3 c = uOrb.xyz; float r = uOrb.w;
  if (r <= 0.0) { int i = gl_InstanceID; c = uGridMin + (vec3(i % GX, (i / GX) % GY, i / (GX * GY)) + 0.5) * uSpacing; r = 0.11; }
  vN = aPos; vC = c; gl_Position = uViewProj * vec4(c + aPos * r, 1.0);
}`;
const ORB_FS = HEAD + COMMON + `
in vec3 vN, vC; uniform vec4 uOrb; uniform vec3 uColor; out vec4 o;
void main() { o = vec4(uOrb.w > 0.0 ? uColor : evalSH(fetchSH(vC), normalize(vN)), 1.0); }`;

// ---------------------------------------------------------------- post: bloom-less filmic resolve
const POST_FS = HEAD + `
in vec2 vUv; uniform sampler2D uHdr; uniform float uExposure; out vec4 o;
vec3 aces(vec3 x) { // Narkowicz fit
  return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}
void main() {
  vec3 c = texture(uHdr, vUv).rgb * uExposure;
  vec2 v = vUv - 0.5; c *= 1.0 - dot(v, v) * 0.55;
  c = pow(aces(c), vec3(1.0 / 2.2));
  c += (fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453) - 0.5) / 255.0;
  o = vec4(c, 1.0);
}`;

export const SHADERS = { FS_TRI, RELIGHT_FS, PROJECT_FS, MAIN_VS, MAIN_FS, SHADOW_VS, SHADOW_FS, SKY_FS, ORB_VS, ORB_FS, POST_FS };
