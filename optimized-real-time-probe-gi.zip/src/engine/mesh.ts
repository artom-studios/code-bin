// Procedural mesh builder. Everything is merged into ONE static indexed mesh
// (single draw call, 24-byte vertices) — engine-agnostic output buffers.

export const MAT = { STONE: 0, TILE: 1, PLASTER: 2, FABRIC: 3, LEAF: 4, METAL: 5, WATER: 6, ROOF: 7, WOOD: 8, GRASS: 9, LAMP: 10 } as const;

export interface MeshData {
  positions: Float32Array; // xyz
  normals: Float32Array;   // xyz
  colors: Uint8Array;      // rgb = albedo (gamma 2.0), a = baked AO
  mats: Uint8Array;        // roughness, metallic, emissive, material id
  indices: Uint32Array;
}

type SurfFn = (u: number, v: number, o: Float32Array) => void;
const A = new Float32Array(3), B = new Float32Array(3), C = new Float32Array(3);

export class MeshBuilder {
  pos: number[] = []; nrm: number[] = []; col: number[] = []; mat: number[] = []; idx: number[] = [];
  private cr = 255; private cg = 255; private cb = 255;
  private rough = 200; private metal = 0; private emis = 0; private id = 0;
  private tx = 0; private ty = 0; private tz = 0; private cs = 1; private sn = 0; private sc = 1;

  get vertexCount() { return this.pos.length / 3; }

  /** Set current material. Color is linear albedo. */
  material(r: number, g: number, b: number, rough = 0.8, metal = 0, id = 0, emis = 0) {
    this.cr = Math.round(Math.sqrt(r) * 255); this.cg = Math.round(Math.sqrt(g) * 255); this.cb = Math.round(Math.sqrt(b) * 255);
    this.rough = Math.round(rough * 255); this.metal = Math.round(metal * 255); this.emis = Math.round(emis * 255); this.id = id;
    return this;
  }
  /** Set current transform: uniform scale -> Y rotation -> translation. */
  xf(x = 0, y = 0, z = 0, rotY = 0, scale = 1) {
    this.tx = x; this.ty = y; this.tz = z; this.cs = Math.cos(rotY); this.sn = Math.sin(rotY); this.sc = scale;
    return this;
  }

  v(x: number, y: number, z: number, nx: number, ny: number, nz: number): number {
    const { cs, sn, sc } = this;
    this.pos.push((x * cs + z * sn) * sc + this.tx, y * sc + this.ty, (-x * sn + z * cs) * sc + this.tz);
    this.nrm.push(nx * cs + nz * sn, ny, -nx * sn + nz * cs);
    this.col.push(this.cr, this.cg, this.cb, 255);
    this.mat.push(this.rough, this.metal, this.emis, this.id);
    return this.pos.length / 3 - 1;
  }

  /** Parametric surface with finite-difference normals. u,v in [0,1]. */
  surface(nu: number, nv: number, f: SurfFn, flip = false, twoSided = false) {
    const base = this.vertexCount, e = 1e-3, s = flip ? -1 : 1;
    for (let j = 0; j <= nv; j++) {
      for (let i = 0; i <= nu; i++) {
        const u = i / nu, v = j / nv;
        f(u, v, A);
        const vc = Math.min(1 - 2 * e, Math.max(2 * e, v)); // avoid degenerate poles
        f(u + e, vc, B); f(u - e, vc, C);
        const dux = B[0] - C[0], duy = B[1] - C[1], duz = B[2] - C[2];
        f(u, vc + e, B); f(u, vc - e, C);
        const dvx = B[0] - C[0], dvy = B[1] - C[1], dvz = B[2] - C[2];
        let nx = duy * dvz - duz * dvy, ny = duz * dvx - dux * dvz, nz = dux * dvy - duy * dvx;
        const l = s / (Math.hypot(nx, ny, nz) || 1);
        nx *= l; ny *= l; nz *= l;
        this.v(A[0], A[1], A[2], nx, ny, nz);
      }
    }
    const w = nu + 1;
    for (let j = 0; j < nv; j++) for (let i = 0; i < nu; i++) {
      const a = base + j * w + i, b = a + 1, c = a + w, d = c + 1;
      if (flip) this.idx.push(a, c, b, b, c, d); else this.idx.push(a, b, c, b, d, c);
    }
    if (twoSided) this.surface(nu, nv, f, !flip, false);
  }

  /** Surface of revolution. profile = [r0,y0, r1,y1, ...] bottom to top. Optional fluting. */
  lathe(profile: number[], segs: number, flutes = 0, depth = 0, v0 = 0, v1 = 1) {
    const n = profile.length / 2 - 1;
    this.surface(segs, n, (u, v, o) => {
      const t = Math.min(n, Math.max(0, v * n)), i = Math.min(n - 1, Math.floor(t)), k = t - i;
      let r = profile[i * 2] + (profile[i * 2 + 2] - profile[i * 2]) * k;
      const y = profile[i * 2 + 1] + (profile[i * 2 + 3] - profile[i * 2 + 1]) * k;
      if (flutes && v > v0 && v < v1) {
        const fade = Math.min(1, (v - v0) * 30, (v1 - v) * 30);
        const c = 0.5 + 0.5 * Math.cos(u * Math.PI * 2 * flutes);
        r *= 1 - depth * fade * (1 - c * c * c);
      }
      const a = u * Math.PI * 2;
      o[0] = r * Math.cos(a); o[1] = y; o[2] = r * Math.sin(a);
    }, true);
  }

  /** Swept tube along path(t) with radius(t). */
  tube(path: (t: number, o: Float32Array) => void, radius: (t: number) => number, nt: number, segs: number) {
    const P = new Float32Array(3), Q = new Float32Array(3);
    this.surface(segs, nt, (u, v, o) => {
      path(v, P); path(v + 1e-3, Q);
      let tx = Q[0] - P[0], ty = Q[1] - P[1], tz = Q[2] - P[2];
      let l = 1 / (Math.hypot(tx, ty, tz) || 1); tx *= l; ty *= l; tz *= l;
      // reference axis least aligned with tangent
      let rx = 0, ry = 1, rz = 0;
      if (Math.abs(ty) > 0.9) { rx = 1; ry = 0; }
      let bx = ty * rz - tz * ry, by = tz * rx - tx * rz, bz = tx * ry - ty * rx;
      l = 1 / Math.hypot(bx, by, bz); bx *= l; by *= l; bz *= l;
      const nx = by * tz - bz * ty, ny = bz * tx - bx * tz, nz = bx * ty - by * tx;
      const a = u * Math.PI * 2, c = Math.cos(a) * radius(v), s = Math.sin(a) * radius(v);
      o[0] = P[0] + bx * c + nx * s; o[1] = P[1] + by * c + ny * s; o[2] = P[2] + bz * c + nz * s;
    }, true);
  }

  /** Flat quad, CCW as seen from the front. */
  quad(a: number[], b: number[], c: number[], d: number[]) {
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = d[0] - a[0], vy = d[1] - a[1], vz = d[2] - a[2];
    let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    const l = 1 / (Math.hypot(nx, ny, nz) || 1); nx *= l; ny *= l; nz *= l;
    const i = this.v(a[0], a[1], a[2], nx, ny, nz);
    this.v(b[0], b[1], b[2], nx, ny, nz); this.v(c[0], c[1], c[2], nx, ny, nz); this.v(d[0], d[1], d[2], nx, ny, nz);
    this.idx.push(i, i + 1, i + 2, i, i + 2, i + 3);
  }

  /** Axis-aligned flat box (min/max corners). */
  box(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number) {
    this.quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]);
    this.quad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0]);
    this.quad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1]);
    this.quad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]);
    this.quad([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]);
    this.quad([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]);
  }

  /** Rounded (bevelled) box: center, half extents, bevel radius, bevel segments. */
  rbox(cx: number, cy: number, cz: number, hx: number, hy: number, hz: number, r: number, S = 3) {
    const h = [hx, hy, hz], n = 2 * S + 1;
    // uniform angular spacing across each bevel, mirrored about the centre
    const coord = (k: number, hh: number): number => {
      const m = k <= S ? k : n - k;
      const x = -hh + r * (1 - Math.tan((1 - m / S) * Math.PI * 0.25));
      return k <= S ? x : -x;
    };
    for (let ax = 0; ax < 3; ax++) for (let sg = -1; sg <= 1; sg += 2) {
      const a1 = (ax + 1) % 3, a2 = (ax + 2) % 3, base = this.vertexCount, p = [0, 0, 0], q = [0, 0, 0], d = [0, 0, 0];
      for (let j = 0; j <= n; j++) for (let i = 0; i <= n; i++) {
        p[ax] = sg * h[ax]; p[a1] = coord(i, h[a1]); p[a2] = coord(j, h[a2]);
        for (let k = 0; k < 3; k++) { q[k] = Math.min(h[k] - r, Math.max(-(h[k] - r), p[k])); d[k] = p[k] - q[k]; }
        const l = 1 / (Math.hypot(d[0], d[1], d[2]) || 1);
        this.v(cx + q[0] + d[0] * l * r, cy + q[1] + d[1] * l * r, cz + q[2] + d[2] * l * r, d[0] * l, d[1] * l, d[2] * l);
      }
      const w = n + 1;
      for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
        const a = base + j * w + i, b = a + 1, c = a + w, e = c + 1;
        if (sg > 0) this.idx.push(a, b, c, b, e, c); else this.idx.push(a, c, b, b, c, e);
      }
    }
  }

  build(): MeshData {
    return {
      positions: new Float32Array(this.pos), normals: new Float32Array(this.nrm),
      colors: new Uint8Array(this.col), mats: new Uint8Array(this.mat), indices: new Uint32Array(this.idx),
    };
  }
}
