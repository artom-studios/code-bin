// Bake orchestrator (main thread): fans the bake out over all CPU cores, merges the slices and
// resolves invalid probes. Output is plain typed arrays — serialise them to ship a pre-baked level.
import BakeWorker from "./bake.worker.ts?worker&inline";
import type { MeshData } from "./mesh";
import { GRID, RAY_SIDE } from "./scene";

export interface BakeResult {
  mesh: MeshData;
  surfPos: Float32Array;   // RGBA32F atlas: xyz = hit position (w=1) | ray dir (w=0, sky) | w=-1 dead
  surfAlb: Uint8Array;     // RGBA8 atlas: albedo (gamma 2.0), a = emissive
  surfNrm: Uint8Array;     // RGBA8 atlas: normal * 0.5 + 0.5
  rayDirs: Float32Array;   // RGBA32F x rays: shared ray directions
  lampSH: Float32Array;    // RGBA per probe: precomputed, visibility-tested L1 transfer from static lanterns
  atlasW: number; atlasH: number;
  stats: { tris: number; verts: number; probes: number; invalid: number; surfels: number; bakeMs: number; workers: number };
}
export interface BakePart {
  part: number; parts: number; z0: number; z1: number; ao: Uint8Array; mesh: MeshData | null;
  surfPos: Float32Array; surfAlb: Uint8Array; surfNrm: Uint8Array; rayDirs: Float32Array; valid: Uint8Array; lampSH: Float32Array;
}

export function runBake(onProgress: (stage: string, p: number) => void): Promise<BakeResult> {
  const t0 = performance.now(), [GX, GY, GZ] = GRID.dims, RS = RAY_SIDE;
  const parts = Math.max(1, Math.min(8, (navigator.hardwareConcurrency || 4) - 1, GZ));
  const prog = new Float32Array(parts), results: BakePart[] = [];
  return new Promise((resolve, reject) => {
    const workers = Array.from({ length: parts }, (_, part) => {
      const w = new BakeWorker();
      w.onerror = (e) => reject(new Error(e.message || "Bake worker failed"));
      w.onmessage = (e: MessageEvent) => {
        const m = e.data;
        if (m.type === "progress") {
          prog[m.part] = m.p;
          onProgress(m.stage, prog.reduce((a, b) => a + b, 0) / parts);
          return;
        }
        results.push(m.result as BakePart); prog[part] = 1; w.terminate();
        if (results.length === parts) {
          try { resolve(merge(results, t0, parts)); } catch (err) { reject(err as Error); }
        }
      };
      w.postMessage({ part, parts });
      return w;
    });
    void workers;
  });

  function merge(rs: BakePart[], start: number, n: number): BakeResult {
    const mesh = rs.find((r) => r.mesh)!.mesh!, nv = mesh.positions.length / 3;
    const W = GX * RS, H = GY * GZ * RS, NP = GX * GY * GZ, sliceTex = W * GY * RS * 4, sliceP = GX * GY;
    const surfPos = new Float32Array(W * H * 4), surfAlb = new Uint8Array(W * H * 4), surfNrm = new Uint8Array(W * H * 4);
    const valid = new Uint8Array(NP), lampSH = new Float32Array(NP * 4);
    for (const r of rs) {
      for (let i = r.part, k = 0; i < nv; i += r.parts, k++) mesh.colors[i * 4 + 3] = r.ao[k];
      surfPos.set(r.surfPos, r.z0 * sliceTex); surfAlb.set(r.surfAlb, r.z0 * sliceTex); surfNrm.set(r.surfNrm, r.z0 * sliceTex);
      valid.set(r.valid, r.z0 * sliceP); lampSH.set(r.lampSH, r.z0 * sliceP * 4);
    }
    // Probes buried in geometry adopt the surfel set of their nearest valid neighbour. After this the
    // runtime can use plain hardware trilinear filtering — no per-pixel visibility / Chebyshev test.
    let invalid = 0;
    for (let pz = 0; pz < GZ; pz++) for (let py = 0; py < GY; py++) for (let px = 0; px < GX; px++) {
      const pi = px + py * GX + pz * GX * GY;
      if (valid[pi]) continue;
      invalid++;
      let bd = 1e9, bx = -1, by = 0, bz = 0;
      for (let z = Math.max(0, pz - 2); z <= Math.min(GZ - 1, pz + 2); z++) for (let y = Math.max(0, py - 2); y <= Math.min(GY - 1, py + 2); y++)
        for (let x = Math.max(0, px - 2); x <= Math.min(GX - 1, px + 2); x++) {
          if (valid[x + y * GX + z * GX * GY] !== 1) continue;
          const d = (x - px) ** 2 + (y - py) ** 2 * 1.5 + (z - pz) ** 2;
          if (d < bd) { bd = d; bx = x; by = y; bz = z; }
        }
      if (bx < 0) continue;
      for (let j = 0; j < RS; j++) {
        const s = (bx * RS + ((by + bz * GY) * RS + j) * W) * 4, d = (px * RS + ((py + pz * GY) * RS + j) * W) * 4;
        surfPos.copyWithin(d, s, s + RS * 4); surfAlb.copyWithin(d, s, s + RS * 4); surfNrm.copyWithin(d, s, s + RS * 4);
      }
      const si = (bx + by * GX + bz * GX * GY) * 4; lampSH.copyWithin(pi * 4, si, si + 4);
    }
    return {
      mesh, surfPos, surfAlb, surfNrm, rayDirs: rs[0].rayDirs, lampSH, atlasW: W, atlasH: H,
      stats: { tris: mesh.indices.length / 3, verts: nv, probes: NP, invalid, surfels: W * H, bakeMs: performance.now() - start, workers: n },
    };
  }
}
