// Offline-style bake, executed once at load in a worker:
//   1. build scene + BVH
//   2. per-vertex ambient occlusion
//   3. probe "surfel G-buffer": every probe shoots a fixed set of rays ONCE and stores what it sees
//      (position / normal / albedo / emissive). Geometry is static, so visibility never has to be
//      traced again — the runtime only *relights* these surfels. This is the whole trick.
import { MAT, type MeshData } from "./mesh";
import type { BakePart } from "./bake";
import { GRID, LAMPS, RAY_SIDE, buildScene } from "./scene";

// ------------------------------------------------------------------ BVH
let bb: Float32Array, meta: Int32Array, axisOf: Uint8Array, T: Float32Array, triId: Uint32Array;
const stack = new Int32Array(128);
let hitTri = -1, hitFront = true;

function buildBVH(P: Float32Array, I: Uint32Array) {
  const n = I.length / 3, cen = new Float32Array(n * 3), tmin = new Float32Array(n * 3), tmax = new Float32Array(n * 3);
  const order = new Uint32Array(n);
  for (let t = 0; t < n; t++) {
    order[t] = t;
    for (let k = 0; k < 3; k++) {
      const a = P[I[t * 3] * 3 + k], b = P[I[t * 3 + 1] * 3 + k], c = P[I[t * 3 + 2] * 3 + k];
      tmin[t * 3 + k] = Math.min(a, b, c); tmax[t * 3 + k] = Math.max(a, b, c); cen[t * 3 + k] = (a + b + c) / 3;
    }
  }
  bb = new Float32Array(n * 2 * 6); meta = new Int32Array(n * 2 * 2); axisOf = new Uint8Array(n * 2);
  let count = 1;
  const NB = 16, binN = new Int32Array(NB), binB = new Float64Array(NB * 6), rCost = new Float64Array(NB + 1);
  const work: number[] = [0, 0, n];
  while (work.length) {
    const e = work.pop()!, s = work.pop()!, node = work.pop()!;
    let x0 = Infinity, y0 = Infinity, z0 = Infinity, x1 = -Infinity, y1 = -Infinity, z1 = -Infinity;
    const c0 = [Infinity, Infinity, Infinity], c1 = [-Infinity, -Infinity, -Infinity];
    for (let i = s; i < e; i++) {
      const t = order[i] * 3;
      if (tmin[t] < x0) x0 = tmin[t]; if (tmin[t + 1] < y0) y0 = tmin[t + 1]; if (tmin[t + 2] < z0) z0 = tmin[t + 2];
      if (tmax[t] > x1) x1 = tmax[t]; if (tmax[t + 1] > y1) y1 = tmax[t + 1]; if (tmax[t + 2] > z1) z1 = tmax[t + 2];
      for (let k = 0; k < 3; k++) { const c = cen[t + k]; if (c < c0[k]) c0[k] = c; if (c > c1[k]) c1[k] = c; }
    }
    bb.set([x0, y0, z0, x1, y1, z1], node * 6);
    if (e - s <= 4) { meta[node * 2] = s; meta[node * 2 + 1] = e - s; continue; }
    let ax = 0; if (c1[1] - c0[1] > c1[ax] - c0[ax]) ax = 1; if (c1[2] - c0[2] > c1[ax] - c0[ax]) ax = 2;
    // binned SAH along the widest centroid axis
    const lo = c0[ax], scale = NB / Math.max(c1[ax] - lo, 1e-9);
    binN.fill(0); for (let k = 0; k < NB * 6; k += 6) { binB[k] = binB[k + 1] = binB[k + 2] = Infinity; binB[k + 3] = binB[k + 4] = binB[k + 5] = -Infinity; }
    for (let i = s; i < e; i++) {
      const t = order[i] * 3, k = Math.min(NB - 1, ((cen[t + ax] - lo) * scale) | 0), o = k * 6; binN[k]++;
      if (tmin[t] < binB[o]) binB[o] = tmin[t]; if (tmin[t + 1] < binB[o + 1]) binB[o + 1] = tmin[t + 1]; if (tmin[t + 2] < binB[o + 2]) binB[o + 2] = tmin[t + 2];
      if (tmax[t] > binB[o + 3]) binB[o + 3] = tmax[t]; if (tmax[t + 1] > binB[o + 4]) binB[o + 4] = tmax[t + 1]; if (tmax[t + 2] > binB[o + 5]) binB[o + 5] = tmax[t + 2];
    }
    let ax0 = Infinity, ay0 = Infinity, az0 = Infinity, ax1 = -Infinity, ay1 = -Infinity, az1 = -Infinity, cnt = 0;
    for (let k = NB - 1; k > 0; k--) { // suffix sweep: cost of the right side for split k
      const o = k * 6; cnt += binN[k];
      ax0 = Math.min(ax0, binB[o]); ay0 = Math.min(ay0, binB[o + 1]); az0 = Math.min(az0, binB[o + 2]);
      ax1 = Math.max(ax1, binB[o + 3]); ay1 = Math.max(ay1, binB[o + 4]); az1 = Math.max(az1, binB[o + 5]);
      const dx = ax1 - ax0, dy = ay1 - ay0, dz = az1 - az0; rCost[k] = cnt ? cnt * (dx * dy + dy * dz + dz * dx) : 0;
    }
    ax0 = ay0 = az0 = Infinity; ax1 = ay1 = az1 = -Infinity; cnt = 0;
    let bestK = -1, bestC = Infinity;
    for (let k = 0; k < NB - 1; k++) {
      const o = k * 6; cnt += binN[k];
      ax0 = Math.min(ax0, binB[o]); ay0 = Math.min(ay0, binB[o + 1]); az0 = Math.min(az0, binB[o + 2]);
      ax1 = Math.max(ax1, binB[o + 3]); ay1 = Math.max(ay1, binB[o + 4]); az1 = Math.max(az1, binB[o + 5]);
      if (!cnt || cnt === e - s) continue;
      const dx = ax1 - ax0, dy = ay1 - ay0, dz = az1 - az0, c = cnt * (dx * dy + dy * dz + dz * dx) + rCost[k + 1];
      if (c < bestC) { bestC = c; bestK = k; }
    }
    let i = s, j = e - 1;
    if (bestK >= 0) while (i <= j) {
      if ((Math.min(NB - 1, ((cen[order[i] * 3 + ax] - lo) * scale) | 0)) <= bestK) i++; else { const t = order[i]; order[i] = order[j]; order[j] = t; j--; }
    }
    if (i === s || i === e) i = (s + e) >> 1;
    const l = count; count += 2;
    meta[node * 2] = l; meta[node * 2 + 1] = 0; axisOf[node] = ax;
    work.push(l, s, i, l + 1, i, e);
  }
  // triangles re-ordered into leaf order as (v0, e1, e2) for cache-friendly Möller–Trumbore
  T = new Float32Array(n * 9); triId = order;
  for (let i = 0; i < n; i++) {
    const t = order[i] * 3, a = I[t] * 3, b = I[t + 1] * 3, c = I[t + 2] * 3;
    for (let k = 0; k < 3; k++) { T[i * 9 + k] = P[a + k]; T[i * 9 + 3 + k] = P[b + k] - P[a + k]; T[i * 9 + 6 + k] = P[c + k] - P[a + k]; }
  }
}

/** Closest hit (or any hit). Returns t or Infinity; sets hitTri (ordered index) / hitFront. */
function trace(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, tMax: number, any: boolean): number {
  const B = bb, M = meta, AX = axisOf, TR = T, st = stack; // locals: lets the JIT keep them in registers
  const ix = 1 / dx, iy = 1 / dy, iz = 1 / dz;
  let best = tMax, sp = 0, hit = -1, front = true; st[sp++] = 0;
  while (sp > 0) {
    const node = st[--sp], o = node * 6;
    let t0 = (B[o] - ox) * ix, t1 = (B[o + 3] - ox) * ix, lo = t0 < t1 ? t0 : t1, hi = t0 < t1 ? t1 : t0, a = 0, b = 0;
    t0 = (B[o + 1] - oy) * iy; t1 = (B[o + 4] - oy) * iy; a = t0 < t1 ? t0 : t1; b = t0 < t1 ? t1 : t0; if (a > lo) lo = a; if (b < hi) hi = b;
    t0 = (B[o + 2] - oz) * iz; t1 = (B[o + 5] - oz) * iz; a = t0 < t1 ? t0 : t1; b = t0 < t1 ? t1 : t0; if (a > lo) lo = a; if (b < hi) hi = b;
    if (hi < lo || hi < 0 || lo > best) continue;
    const cnt = M[node * 2 + 1], first = M[node * 2];
    if (cnt === 0) {
      const ax = AX[node], d = ax === 0 ? dx : ax === 1 ? dy : dz;
      if (d > 0) { st[sp++] = first + 1; st[sp++] = first; } else { st[sp++] = first; st[sp++] = first + 1; }
      continue;
    }
    for (let i = first, end = first + cnt; i < end; i++) {
      const q = i * 9, e1x = TR[q + 3], e1y = TR[q + 4], e1z = TR[q + 5], e2x = TR[q + 6], e2y = TR[q + 7], e2z = TR[q + 8];
      const px = dy * e2z - dz * e2y, py = dz * e2x - dx * e2z, pz = dx * e2y - dy * e2x;
      const det = e1x * px + e1y * py + e1z * pz;
      if (det > -1e-10 && det < 1e-10) continue;
      const inv = 1 / det, sx = ox - TR[q], sy = oy - TR[q + 1], sz = oz - TR[q + 2];
      const u = (sx * px + sy * py + sz * pz) * inv; if (u < 0 || u > 1) continue;
      const qx = sy * e1z - sz * e1y, qy = sz * e1x - sx * e1z, qz = sx * e1y - sy * e1x;
      const v = (dx * qx + dy * qy + dz * qz) * inv; if (v < 0 || u + v > 1) continue;
      const t = (e2x * qx + e2y * qy + e2z * qz) * inv;
      if (t > 1e-4 && t < best) { best = t; hit = i; front = det > 0; if (any) { hitTri = hit; hitFront = front; return t; } }
    }
  }
  hitTri = hit; hitFront = front;
  return hit < 0 ? Infinity : best;
}

// ------------------------------------------------------------------ bake (this worker handles one slice of the work)
const ctx = self as unknown as { postMessage(m: unknown, t?: Transferable[]): void; onmessage: ((e: { data: { part: number; parts: number } }) => void) | null };
let partId = 0;
const progress = (stage: string, p: number) => ctx.postMessage({ type: "progress", part: partId, stage, p });

/** Per-vertex AO for vertices i where i % parts == part. Returns a compact array. */
function bakeAO(m: MeshData, part: number, parts: number): Uint8Array {
  const P = m.positions, N = m.normals, I = m.indices, nv = P.length / 3, RAYS = 8, DIST = 1.1;
  const out = new Uint8Array(Math.ceil((nv - part) / parts)).fill(255);
  // Only "detail" vertices get AO: huge wall/slab polygons would smear a corner value across metres.
  const skip = new Uint8Array(nv);
  for (let t = 0; t < I.length; t += 3) for (let k = 0; k < 3; k++) {
    const a = I[t + k] * 3, b = I[t + (k + 1) % 3] * 3;
    if (Math.hypot(P[a] - P[b], P[a + 1] - P[b + 1], P[a + 2] - P[b + 2]) > 1.6) { skip[I[t]] = skip[I[t + 1]] = skip[I[t + 2]] = 1; break; }
  }
  for (let i = part, n = 0; i < nv; i += parts, n++) {
    if (n % 4096 === 0) progress("Baking ambient occlusion", (i / nv) * 0.5);
    if (skip[i]) continue;
    const nx = N[i * 3], ny = N[i * 3 + 1], nz = N[i * 3 + 2];
    const s = nz >= 0 ? 1 : -1, a = -1 / (s + nz), b = nx * ny * a; // branchless orthonormal basis
    const tx = 1 + s * nx * nx * a, ty = s * b, tz = -s * nx, bx = b, by = s + ny * ny * a, bz = -ny;
    const ox = P[i * 3] + nx * 0.03, oy = P[i * 3 + 1] + ny * 0.03, oz = P[i * 3 + 2] + nz * 0.03;
    let occ = 0; const rot = (i * 0.61803398875) % 1;
    for (let r = 0; r < RAYS; r++) {
      const u = (r + 0.5) / RAYS, ph = (r * 0.61803398875 + rot) * 6.2831853, sr = Math.sqrt(u), cz = Math.sqrt(1 - u);
      const lx = sr * Math.cos(ph), ly = sr * Math.sin(ph);
      const dx = tx * lx + bx * ly + nx * cz, dy = ty * lx + by * ly + ny * cz, dz = tz * lx + bz * ly + nz * cz;
      const t = trace(ox, oy, oz, dx || 1e-9, dy || 1e-9, dz || 1e-9, DIST, true);
      if (t < DIST) occ += 1 - t / DIST;
    }
    const ao = 1 - occ / RAYS;
    out[n] = Math.round(255 * (m.mats[i * 4 + 3] === MAT.LEAF ? 0.5 + 0.5 * ao : 0.15 + 0.85 * ao));
  }
  return out;
}

/** Probe surfel G-buffer + lantern transfer for z-slices [z0, z1). */
function bakeProbes(m: MeshData, z0: number, z1: number) {
  const [GX, GY] = GRID.dims, RS = RAY_SIDE, R = RS * RS, W = GX * RS, H = GY * (z1 - z0) * RS, NP = GX * GY * (z1 - z0);
  const surfPos = new Float32Array(W * H * 4), surfAlb = new Uint8Array(W * H * 4), surfNrm = new Uint8Array(W * H * 4);
  const rayDirs = new Float32Array(R * 4), valid = new Uint8Array(NP), lampSH = new Float32Array(NP * 4);
  for (let r = 0; r < R; r++) { // spherical Fibonacci — uniform, deterministic
    const y = 1 - (2 * r + 1) / R, s = Math.sqrt(1 - y * y), ph = r * 2.39996323;
    rayDirs.set([s * Math.cos(ph) || 1e-9, y || 1e-9, s * Math.sin(ph) || 1e-9, 0], r * 4);
  }
  const I = m.indices;
  for (let pz = z0; pz < z1; pz++) for (let py = 0; py < GY; py++) {
    progress("Baking probe surfels", 0.5 + (0.5 * ((pz - z0) * GY + py)) / ((z1 - z0) * GY));
    for (let px = 0; px < GX; px++) {
      const ox = GRID.min[0] + (px + 0.5) * GRID.spacing, oy = GRID.min[1] + (py + 0.5) * GRID.spacing, oz = GRID.min[2] + (pz + 0.5) * GRID.spacing;
      const pi = px + py * GX + (pz - z0) * GX * GY;
      let back = 0;
      for (let r = 0; r < R; r++) {
        const dx = rayDirs[r * 4], dy = rayDirs[r * 4 + 1], dz = rayDirs[r * 4 + 2];
        const o = ((px * RS + (r % RS)) + ((py + (pz - z0) * GY) * RS + ((r / RS) | 0)) * W) * 4;
        const t = trace(ox, oy, oz, dx, dy, dz, 1e9, false);
        if (hitTri < 0) { surfPos[o] = dx; surfPos[o + 1] = dy; surfPos[o + 2] = dz; surfPos[o + 3] = 0; continue; }
        const v0 = I[triId[hitTri] * 3], twoSided = m.mats[v0 * 4 + 3] === MAT.FABRIC;
        if (!hitFront && !twoSided) { back++; surfPos[o + 3] = -1; continue; }
        const q = hitTri * 9;
        let nx = T[q + 4] * T[q + 8] - T[q + 5] * T[q + 7], ny = T[q + 5] * T[q + 6] - T[q + 3] * T[q + 8], nz = T[q + 3] * T[q + 7] - T[q + 4] * T[q + 6];
        const l = (hitFront ? 1 : -1) / (Math.hypot(nx, ny, nz) || 1); nx *= l; ny *= l; nz *= l;
        surfPos[o] = ox + dx * t + nx * 0.02; surfPos[o + 1] = oy + dy * t + ny * 0.02; surfPos[o + 2] = oz + dz * t + nz * 0.02; surfPos[o + 3] = 1;
        surfAlb[o] = m.colors[v0 * 4]; surfAlb[o + 1] = m.colors[v0 * 4 + 1]; surfAlb[o + 2] = m.colors[v0 * 4 + 2];
        surfAlb[o + 3] = m.mats[v0 * 4 + 3] === MAT.LAMP ? 0 : m.mats[v0 * 4 + 2];
        surfNrm[o] = nx * 127.5 + 127.5; surfNrm[o + 1] = ny * 127.5 + 127.5; surfNrm[o + 2] = nz * 127.5 + 127.5; surfNrm[o + 3] = 255;
      }
      if (back > R * 0.18) continue;
      valid[pi] = 1;
      // Static lantern transfer: one shadow ray per (probe, lamp), folded into L1 coefficients
      // (clamped cosine ~ 1/4 + 1/2 cos). Runtime cost for ALL lanterns: one texel fetch per probe.
      for (let k = 0; k < LAMPS.length; k += 3) {
        let dx = LAMPS[k] - ox, dy = LAMPS[k + 1] - oy, dz = LAMPS[k + 2] - oz; const d2 = dx * dx + dy * dy + dz * dz;
        if (d2 > 196) continue;
        const d = Math.sqrt(d2) || 1e-6; dx /= d; dy /= d; dz /= d;
        if (d > 0.4 && trace(ox, oy, oz, dx || 1e-9, dy || 1e-9, dz || 1e-9, d - 0.3, true) < d - 0.3) continue;
        const A = 1 / (d2 + 1);
        lampSH[pi * 4] += 0.5 * A * dx; lampSH[pi * 4 + 1] += 0.5 * A * dy; lampSH[pi * 4 + 2] += 0.5 * A * dz; lampSH[pi * 4 + 3] += 0.25 * A;
      }
    }
  }
  return { surfPos, surfAlb, surfNrm, rayDirs, valid, lampSH };
}

ctx.onmessage = (e) => {
  const { part, parts } = e.data, GZ = GRID.dims[2];
  partId = part;
  progress("Generating procedural geometry", 0);
  const mesh = buildScene();
  progress("Building BVH", 0);
  buildBVH(mesh.positions, mesh.indices);
  const ao = bakeAO(mesh, part, parts);
  const z0 = Math.floor((part * GZ) / parts), z1 = Math.floor(((part + 1) * GZ) / parts);
  const p = bakeProbes(mesh, z0, z1);
  const out: BakePart = { part, parts, z0, z1, ao, mesh: part === 0 ? mesh : null, ...p };
  const transfer: Transferable[] = [ao.buffer, p.surfPos.buffer, p.surfAlb.buffer, p.surfNrm.buffer, p.rayDirs.buffer, p.valid.buffer, p.lampSH.buffer];
  if (part === 0) transfer.push(mesh.positions.buffer, mesh.normals.buffer, mesh.colors.buffer, mesh.mats.buffer, mesh.indices.buffer);
  ctx.postMessage({ type: "done", result: out }, transfer);
};
