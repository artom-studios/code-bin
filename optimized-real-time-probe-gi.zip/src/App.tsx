import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { runBake, type BakeResult } from "./engine/bake";
import { Renderer, defaultSettings, type Settings, type Stats } from "./engine/renderer";
import { GRID, RAY_SIDE } from "./engine/scene";

const MODES = ["Final", "Direct only", "Indirect only", "Irradiance", "Baked AO", "Albedo"];
const BUDGETS: [string, number][] = [["100%", 1], ["50%", 0.5], ["25%", 0.25], ["1 slice", 0.01]];
const fmtTime = (t: number) => `${String(Math.floor(t)).padStart(2, "0")}:${String(Math.floor((t % 1) * 60)).padStart(2, "0")}`;
const fmtK = (n: number) => (n >= 1e6 ? (n / 1e6).toFixed(2) + "M" : n >= 1e3 ? (n / 1e3).toFixed(1) + "k" : String(Math.round(n)));

function Slider(p: { label: string; value: number; min: number; max: number; step: number; text?: string; onChange: (v: number) => void }) {
  return (
    <label className="block">
      <div className="mb-1 flex justify-between text-[11px] text-zinc-400">
        <span>{p.label}</span>
        <span className="font-mono text-zinc-200">{p.text ?? p.value.toFixed(2)}</span>
      </div>
      <input type="range" min={p.min} max={p.max} step={p.step} value={p.value} onChange={(e) => p.onChange(+e.target.value)}
        className="h-1 w-full cursor-pointer appearance-none rounded-full bg-white/15 accent-amber-400" />
    </label>
  );
}
function Toggle(p: { label: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => p.onChange(!p.on)}
      className={`rounded-md border px-2.5 py-1.5 text-left text-[11px] transition ${p.on ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 bg-white/5 text-zinc-400 hover:bg-white/10"}`}>
      <span className={`mr-1.5 inline-block h-1.5 w-1.5 rounded-full ${p.on ? "bg-amber-400" : "bg-zinc-600"}`} />
      {p.label}
    </button>
  );
}
const Section = ({ title, children }: { title: string; children: ReactNode }) => (
  <div className="space-y-2.5 border-t border-white/10 pt-3 first:border-0 first:pt-0">
    <div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-500">{title}</div>
    {children}
  </div>
);
const Stat = ({ k, v, hi }: { k: string; v: string; hi?: boolean }) => (
  <div className="flex justify-between gap-6"><span className="text-zinc-500">{k}</span><span className={hi ? "text-amber-300" : "text-zinc-200"}>{v}</span></div>
);

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<Renderer | null>(null);
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [stats, setStats] = useState<Stats | null>(null);
  const [bake, setBake] = useState<BakeResult["stats"] | null>(null);
  const [progress, setProgress] = useState({ stage: "Starting bake workers", p: 0 });
  const [error, setError] = useState<string | null>(null);
  const [panel, setPanel] = useState(true);

  useEffect(() => {
    let dead = false, raf = 0, last = 0, timer = 0;
    runBake((stage, p) => !dead && setProgress({ stage, p }))
      .then((result) => {
        if (dead || !canvasRef.current) return;
        const r = new Renderer(canvasRef.current, result);
        rendererRef.current = r;
        setBake(result.stats);
        const loop = (t: number) => {
          const dt = Math.min(0.1, (t - last) / 1000 || 0.016); last = t;
          try { r.frame(dt); } catch (e) { setError(String((e as Error).message ?? e)); return; }
          raf = requestAnimationFrame(loop);
        };
        raf = requestAnimationFrame(loop);
        timer = window.setInterval(() => { setStats({ ...r.stats }); setSettings({ ...r.settings }); }, 250);
      })
      .catch((e) => !dead && setError(String(e?.message ?? e)));
    return () => { dead = true; cancelAnimationFrame(raf); clearInterval(timer); rendererRef.current?.dispose(); rendererRef.current = null; };
  }, []);

  const set = useCallback((patch: Partial<Settings>) => {
    if (rendererRef.current) Object.assign(rendererRef.current.settings, patch);
    setSettings((s) => ({ ...s, ...patch }));
  }, []);

  const rays = RAY_SIDE * RAY_SIDE, shKb = (GRID.dims[0] * GRID.dims[1] * GRID.dims[2] * 3 * 8) / 1024;
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-black font-sans text-zinc-100 select-none">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full cursor-grab touch-none active:cursor-grabbing" />

      {/* header + stats */}
      <div className="pointer-events-none absolute left-4 top-4 w-72 space-y-3">
        <div className="rounded-xl border border-white/10 bg-black/55 p-4 backdrop-blur-md">
          <div className="text-[10px] font-semibold uppercase tracking-[0.22em] text-amber-400">Real-time global illumination</div>
          <h1 className="mt-1 text-lg font-semibold leading-tight">Surfel-Relit Probe GI</h1>
          <p className="mt-1.5 text-[11px] leading-relaxed text-zinc-400">
            Probe visibility is baked once. Each frame only <em className="text-zinc-200 not-italic">relights</em> the cached surfels and
            projects them to L1 SH — no runtime ray tracing. Shading cost: <span className="text-zinc-200">3 trilinear taps</span> per pixel.
          </p>
        </div>
        {stats && bake && (
          <div className="space-y-1 rounded-xl border border-white/10 bg-black/55 p-4 font-mono text-[11px] backdrop-blur-md">
            <Stat k="frame rate" v={`${stats.fps.toFixed(0)} fps`} hi />
            <Stat k="GI update (GPU)" v={stats.giMs >= 0 ? `${stats.giMs.toFixed(2)} ms` : "timer n/a"} hi />
            <Stat k="CPU submit" v={`${stats.cpuMs.toFixed(2)} ms`} />
            <Stat k="draw calls" v={String(stats.drawCalls)} />
            <div className="my-1.5 border-t border-white/10" />
            <Stat k="probes" v={`${GRID.dims.join("×")} = ${fmtK(bake.probes)}`} />
            <Stat k="rays / probe (baked)" v={String(rays)} />
            <Stat k="surfels relit / frame" v={fmtK(stats.surfels)} />
            <Stat k="SH volume" v={`${shKb.toFixed(0)} KB`} />
            <div className="my-1.5 border-t border-white/10" />
            <Stat k="scene" v={`${fmtK(bake.tris)} tris · 1 draw`} />
            <Stat k="bake" v={`${(bake.bakeMs / 1000).toFixed(1)} s · ${bake.workers} workers`} />
            <Stat k="buried probes fixed" v={fmtK(bake.invalid)} />
          </div>
        )}
      </div>

      {/* controls */}
      {bake && (
        <div className="absolute right-4 top-4 w-72">
          <button onClick={() => setPanel(!panel)} className="mb-2 ml-auto block rounded-md border border-white/10 bg-black/55 px-3 py-1.5 text-[11px] text-zinc-300 backdrop-blur-md hover:bg-black/70">
            {panel ? "Hide controls" : "Show controls"}
          </button>
          {panel && (
            <div className="max-h-[calc(100vh-5rem)] space-y-3 overflow-y-auto rounded-xl border border-white/10 bg-black/55 p-4 backdrop-blur-md">
              <Section title="Lighting">
                <Slider label="Time of day" value={settings.timeOfDay} min={0} max={24} step={0.01} text={fmtTime(settings.timeOfDay)} onChange={(v) => set({ timeOfDay: v, autoTime: false })} />
                <Slider label="Sun intensity" value={settings.sunIntensity} min={0} max={3} step={0.01} onChange={(v) => set({ sunIntensity: v })} />
                <Slider label="Lantern intensity" value={settings.emissive} min={0} max={4} step={0.01} onChange={(v) => set({ emissive: v })} />
                <Slider label="Exposure" value={settings.exposure} min={0.2} max={4} step={0.01} onChange={(v) => set({ exposure: v })} />
                <div className="grid grid-cols-2 gap-2">
                  <Toggle label="Animate sun" on={settings.autoTime} onChange={(v) => set({ autoTime: v })} />
                  <Toggle label="Light orbs" on={settings.orbs} onChange={(v) => set({ orbs: v })} />
                </div>
              </Section>
              <Section title="Global illumination">
                <div className="grid grid-cols-2 gap-2">
                  <Toggle label="Probe GI" on={settings.gi} onChange={(v) => set({ gi: v })} />
                  <Toggle label="Show probes" on={settings.showProbes} onChange={(v) => set({ showProbes: v })} />
                </div>
                <Slider label="Bounce energy (multi-bounce feedback)" value={settings.bounce} min={0} max={1.5} step={0.01} onChange={(v) => set({ bounce: v })} />
                <Slider label="Temporal hysteresis" value={settings.hysteresis} min={0} max={0.97} step={0.01} onChange={(v) => set({ hysteresis: v })} />
                <div>
                  <div className="mb-1 text-[11px] text-zinc-400">Update budget (volume refreshed per frame)</div>
                  <div className="grid grid-cols-4 gap-1">
                    {BUDGETS.map(([l, v]) => (
                      <button key={l} onClick={() => set({ budget: v })}
                        className={`rounded border px-1 py-1 text-[10px] ${settings.budget === v ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 bg-white/5 text-zinc-400 hover:bg-white/10"}`}>{l}</button>
                    ))}
                  </div>
                </div>
              </Section>
              <Section title="Debug view">
                <div className="grid grid-cols-3 gap-1">
                  {MODES.map((m, i) => (
                    <button key={m} onClick={() => set({ mode: i })}
                      className={`rounded border px-1 py-1.5 text-[10px] ${settings.mode === i ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 bg-white/5 text-zinc-400 hover:bg-white/10"}`}>{m}</button>
                  ))}
                </div>
              </Section>
              <Section title="Camera">
                <Toggle label="Cinematic auto-tour" on={settings.autoCam} onChange={(v) => set({ autoCam: v })} />
                <p className="text-[10px] leading-relaxed text-zinc-500">Drag to look · WASD move · Q/E down/up · Shift to sprint</p>
              </Section>
            </div>
          )}
        </div>
      )}

      {/* loading / error */}
      {!bake && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-zinc-950">
          <div className="w-80">
            <div className="text-[10px] font-semibold uppercase tracking-[0.22em] text-amber-400">One-time precompute</div>
            <div className="mt-1 text-xl font-semibold">Baking light transport</div>
            <div className="mt-4 h-1 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full bg-amber-400 transition-[width] duration-200" style={{ width: `${Math.max(3, progress.p * 100)}%` }} />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[11px] text-zinc-400"><span>{progress.stage}…</span><span>{Math.round(progress.p * 100)}%</span></div>
            <p className="mt-4 text-[11px] leading-relaxed text-zinc-500">
              Generating geometry, building a SAH BVH, tracing vertex AO and the per-probe surfel cache on all CPU cores.
              In a shipped game this is an offline asset — runtime never traces a ray.
            </p>
          </div>
        </div>
      )}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-zinc-950/95 p-6">
          <div className="max-w-md rounded-xl border border-red-500/30 bg-red-500/10 p-5">
            <div className="text-sm font-semibold text-red-300">Renderer could not start</div>
            <p className="mt-2 break-words font-mono text-xs text-red-200/80">{error}</p>
            <p className="mt-3 text-xs text-zinc-400">This demo needs WebGL2 with float render targets (any recent desktop browser).</p>
          </div>
        </div>
      )}
    </div>
  );
}
