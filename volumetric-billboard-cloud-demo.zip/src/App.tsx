import { useEffect, useRef, useState } from 'react';
import { CloudEngine, type Quality, type Stats, type ViewPreset } from './engine/CloudEngine';

function Slider({
  label,
  value,
  min,
  max,
  step,
  unit,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit?: string;
  onChange: (v: number) => void;
}) {
  return (
    <label className="block">
      <div className="mb-1.5 flex items-baseline justify-between text-[11px] uppercase tracking-[0.12em] text-white/60">
        <span>{label}</span>
        <span className="font-mono normal-case tracking-normal text-white/90">
          {Math.round(value * 100) / 100}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="cloud-range w-full"
      />
    </label>
  );
}

function Segmented<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { id: T; label: string }[];
  value: T | null;
  onChange: (v: T) => void;
}) {
  return (
    <div className="grid auto-cols-fr grid-flow-col gap-1 rounded-lg bg-black/25 p-1">
      {options.map((o) => (
        <button
          key={o.id}
          onClick={() => onChange(o.id)}
          className={`rounded-md px-2 py-1.5 text-xs font-medium transition ${
            value === o.id ? 'bg-white/90 text-slate-900 shadow' : 'text-white/75 hover:bg-white/10'
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<CloudEngine | null>(null);

  const [stats, setStats] = useState<Stats | null>(null);
  const [quality, setQuality] = useState<Quality>('medium');
  const [elev, setElev] = useState(38);
  const [az, setAz] = useState(130);
  const [coverage, setCoverage] = useState(0.62);
  const [wind, setWind] = useState(2);
  const [view, setView] = useState<ViewPreset | null>('horizon');
  const [open, setOpen] = useState(true);

  useEffect(() => {
    const engine = new CloudEngine(canvasRef.current!, setStats);
    engineRef.current = engine;
    engine.setView('horizon');
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => engineRef.current?.setQuality(quality), [quality]);
  useEffect(() => engineRef.current?.setSun(elev, az), [elev, az]);
  useEffect(() => engineRef.current?.setCoverage(coverage), [coverage]);
  useEffect(() => engineRef.current?.setWind(wind), [wind]);

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-slate-900 select-none">
      <div className="absolute inset-0">
        <canvas ref={canvasRef} className="block h-full w-full" onPointerDown={() => setView(null)} />
      </div>

      {/* Title */}
      <div className="pointer-events-none absolute left-6 top-5 text-white drop-shadow-[0_1px_8px_rgba(0,0,0,0.35)]">
        <h1 className="text-lg font-semibold tracking-tight">Cumulus</h1>
        <p className="text-xs text-white/75">Billboard-volume clouds · one instanced draw call</p>
      </div>

      {/* Controls */}
      <div className="absolute right-4 top-4 w-72 max-w-[calc(100vw-2rem)] text-white">
        <div className="rounded-2xl border border-white/15 bg-slate-900/45 p-4 shadow-2xl backdrop-blur-md">
          <button
            onClick={() => setOpen((o) => !o)}
            className="flex w-full items-center justify-between text-[11px] font-semibold uppercase tracking-[0.16em] text-white/80"
          >
            Controls
            <span className="text-base leading-none">{open ? '–' : '+'}</span>
          </button>

          {open && (
            <div className="mt-4 space-y-4">
              <div>
                <div className="mb-1.5 text-[11px] uppercase tracking-[0.12em] text-white/60">View</div>
                <Segmented
                  value={view}
                  onChange={(v) => {
                    setView(v);
                    engineRef.current?.setView(v);
                  }}
                  options={[
                    { id: 'above', label: 'Above' },
                    { id: 'horizon', label: 'Horizon' },
                    { id: 'below', label: 'Below' },
                  ]}
                />
              </div>

              <Slider label="Sun elevation" value={elev} min={3} max={80} step={1} unit="°" onChange={setElev} />
              <Slider label="Sun azimuth" value={az} min={0} max={360} step={1} unit="°" onChange={setAz} />
              <Slider label="Coverage" value={coverage} min={0.05} max={1} step={0.01} onChange={setCoverage} />
              <Slider label="Wind" value={wind} min={0} max={12} step={0.1} onChange={setWind} />

              <div>
                <div className="mb-1.5 text-[11px] uppercase tracking-[0.12em] text-white/60">Quality</div>
                <Segmented
                  value={quality}
                  onChange={setQuality}
                  options={[
                    { id: 'low', label: 'Low' },
                    { id: 'medium', label: 'Medium' },
                    { id: 'high', label: 'High' },
                  ]}
                />
              </div>

              {stats && (
                <div className="grid grid-cols-3 gap-2 border-t border-white/10 pt-3 text-center font-mono text-[11px] text-white/70">
                  <div>
                    <div className="text-sm text-white">{stats.fps}</div>fps
                  </div>
                  <div>
                    <div className="text-sm text-white">{stats.drawn.toLocaleString()}</div>puffs drawn
                  </div>
                  <div>
                    <div className="text-sm text-white">{stats.clouds}</div>clouds
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="pointer-events-none absolute bottom-5 left-1/2 -translate-x-1/2 rounded-full bg-slate-900/40 px-4 py-1.5 text-xs text-white/80 backdrop-blur">
        Drag to orbit · scroll / pinch to zoom
      </div>
    </div>
  );
}
