export const cloudVertex = /* glsl */ `
attribute vec3 aPos;     // world-space puff centre (sorted back-to-front on CPU)
attribute vec4 aA;       // size, rotation, baked sun light, alpha
attribute vec4 aB;       // height in cloud, edge-ness, seed, unused

uniform vec3 uRight;
uniform vec3 uUp;
uniform float uTime;

varying vec2 vUv;
varying float vAlpha;
varying float vLight;
varying float vH;
varying float vEdge;
varying float vSeed;
varying float vDist;
varying vec2 vRot;
varying vec3 vView;

void main() {
  float size = aA.x;

  // Camera-aligned billboard: every quad is parallel to the image plane, so
  // sorting by view depth gives an exact painter's order (no intersections,
  // hence no z-fighting; depth test/write are off entirely).
  vec3 world = aPos + (uRight * position.x + uUp * position.y) * size;

  vec3 rel = aPos - cameraPosition;
  float dist = length(rel);
  vDist = dist;
  vView = rel / max(dist, 1e-3);

  // Dissolve puffs that get too close to the lens instead of popping.
  float nearFade = smoothstep(size * 0.35, size * 1.7, dist);

  vAlpha = aA.w * nearFade;
  vLight = aA.z;
  vH = aB.x;
  vEdge = aB.y;
  vSeed = aB.z;

  // Slow per-puff texture rotation => the cloud surface subtly boils.
  float ang = aA.y + uTime * 0.025 * (fract(aB.z * 7.31) - 0.5) * 2.0;
  vRot = vec2(cos(ang), sin(ang));

  vUv = position.xy;
  gl_Position = projectionMatrix * viewMatrix * vec4(world, 1.0);
}
`;

export const cloudFragment = /* glsl */ `
uniform sampler2D uNoise;
uniform vec3 uSun;
uniform vec3 uSunColor;
uniform vec3 uAmbTop;
uniform vec3 uAmbBottom;
uniform vec3 uFogColor;
uniform vec3 uRight;
uniform vec3 uUp;
uniform vec3 uFwd;
uniform float uOpacity;
uniform float uFog;

varying vec2 vUv;
varying float vAlpha;
varying float vLight;
varying float vH;
varying float vEdge;
varying float vSeed;
varying float vDist;
varying vec2 vRot;
varying vec3 vView;

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
  float r2 = dot(vUv, vUv);
  if (r2 >= 1.0) discard;
  float r = sqrt(r2);

  // --- Shape: radial envelope eroded by tiled noise -----------------------
  vec2 q = vec2(vRot.x * vUv.x - vRot.y * vUv.y, vRot.y * vUv.x + vRot.x * vUv.y);
  vec2 off = vec2(vSeed, fract(vSeed * 13.7));
  float n1 = texture2D(uNoise, q * 0.42 + off).r;
  float n2 = texture2D(uNoise, q * 1.05 + off.yx + 0.31).r;
  float nn = n1 * 0.6 + n2 * 0.4;

  float dens = (1.0 - r) * 1.55 + (nn - 0.5) * 0.95;
  dens = smoothstep(0.0, 1.0, dens);
  dens *= smoothstep(1.0, 0.72, r);          // guarantees no visible quad / disc rim
  float alpha = dens * uOpacity * vAlpha;
  if (alpha < 0.004) discard;

  // --- Cheap lighting -------------------------------------------------------
  // Baked: transmittance towards the sun through the *whole cloud* (vLight).
  // Per-pixel: fake sphere normal for soft directional shading, kept low
  // contrast so neighbouring puffs melt into one body.
  float z = sqrt(max(1.0 - r2, 0.0));
  vec3 n = normalize(uRight * vUv.x + uUp * vUv.y - uFwd * z);
  float shape = dot(n, uSun) * 0.5 + 0.5;

  float direct = vLight * (0.68 + 0.32 * shape);
  direct += (nn - 0.5) * 0.30 * vLight;       // surface billow detail
  direct = clamp(direct, 0.0, 1.2);

  vec3 amb = mix(uAmbBottom, uAmbTop, pow(clamp(vH, 0.0, 1.0), 0.8)) * 0.74;
  vec3 col = amb + uSunColor * direct * 0.52;

  // Forward scattering: silver lining when looking toward the sun.
  float fwd = pow(clamp(dot(vView, uSun), 0.0, 1.0), 5.0);
  col += uSunColor * fwd * vEdge * (0.25 + 0.75 * vLight) * 0.55;

  // Aerial perspective.
  float fogF = min(1.0 - exp(-vDist * uFog), 0.82);
  col = mix(col, uFogColor, fogF);

  // Dither against banding in the soft gradients.
  col += (hash(gl_FragCoord.xy) - 0.5) / 255.0;

  gl_FragColor = vec4(col, alpha);
}
`;

export const skyVertex = /* glsl */ `
varying vec3 vDir;
void main() {
  vDir = position;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

export const skyFragment = /* glsl */ `
uniform vec3 uZenith;
uniform vec3 uHorizon;
uniform vec3 uBelow;
uniform vec3 uSun;
uniform vec3 uSunColor;
varying vec3 vDir;

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
  vec3 d = normalize(vDir);
  float h = d.y;

  vec3 col = mix(uHorizon, uZenith, pow(clamp(h, 0.0, 1.0), 0.55));
  col = mix(col, uBelow, smoothstep(0.0, -0.55, h));

  float s = max(dot(d, uSun), 0.0);
  float glow = pow(s, 6.0) * 0.18 + pow(s, 48.0) * 0.35;
  float disc = smoothstep(0.99955, 0.99985, s);
  col += uSunColor * (glow + disc * 2.0);

  col += (hash(gl_FragCoord.xy) - 0.5) / 255.0;
  gl_FragColor = vec4(col, 1.0);
}
`;
