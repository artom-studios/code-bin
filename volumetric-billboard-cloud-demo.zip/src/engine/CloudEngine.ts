import * as THREE from 'three';
import { makeNoiseTexture } from './noise';
import { cloudFragment, cloudVertex, skyFragment, skyVertex } from './shaders';

export type Quality = 'low' | 'medium' | 'high';
export type ViewPreset = 'above' | 'horizon' | 'below';

export interface Stats {
  fps: number;
  drawn: number;
  total: number;
  clouds: number;
}

const QUALITY: Record<Quality, { clouds: number; perLobe: number; dpr: number }> = {
  low: { clouds: 30, perLobe: 20, dpr: 1 },
  medium: { clouds: 46, perLobe: 28, dpr: 1.5 },
  high: { clouds: 64, perLobe: 36, dpr: 2 },
};

const FIELD_RADIUS = 440; // clouds live in a disc of this radius and wrap around it
const MAX_PUFFS = 16000; // limited by the 14-bit index packed into the sort key
const INDEX_BITS = 16384;

const smoothstep = (a: number, b: number, x: number) => {
  const t = Math.min(Math.max((x - a) / (b - a), 0), 1);
  return t * t * (3 - 2 * t);
};
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const mix3 = (a: number[], b: number[], t: number) => new THREE.Vector3(lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t));

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface Cloud {
  x0: number;
  y: number;
  z: number;
  speed: number;
  rank: number;
  start: number;
  count: number;
}

export class CloudEngine {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(58, 1, 0.5, 4000);
  private noise = makeNoiseTexture(256);

  private sky: THREE.Mesh;
  private skyMat: THREE.ShaderMaterial;
  private cloudMat: THREE.ShaderMaterial;
  private cloudMesh: THREE.Mesh | null = null;
  private geo: THREE.InstancedBufferGeometry | null = null;

  // static per-puff data (struct of arrays)
  private lx = new Float32Array(0);
  private ly = new Float32Array(0);
  private lz = new Float32Array(0);
  private size = new Float32Array(0);
  private seed = new Float32Array(0);
  private light = new Float32Array(0);
  private hnorm = new Float32Array(0);
  private edge = new Float32Array(0);
  private clouds: Cloud[] = [];
  private total = 0;

  // dynamic (re-sorted every frame)
  private stagePos = new Float32Array(0); // world pos per puff id (pre-sort)
  private stageAlpha = new Float32Array(0);
  private sortKeys = new Float64Array(0);
  private order = new Uint32Array(0);

  // state
  private quality: Quality = 'medium';
  private coverage = 0.62;
  private wind = 2.0;
  private drift = 0;
  private sunElev = 38;
  private sunAz = 130;
  private sunDir = new THREE.Vector3();

  // orbit camera
  private yaw = 0.6;
  private pitch = 0.1;
  private dist = 85;
  private yawT = 0.6;
  private pitchT = 0.1;
  private distT = 85;
  private target = new THREE.Vector3(0, 12, 0);
  private pointers = new Map<number, { x: number; y: number }>();
  private pinchDist = 0;

  private raf = 0;
  private last = performance.now();
  private time = 0;
  private fpsAcc = 0;
  private fpsFrames = 0;
  private drawn = 0;
  private ro: ResizeObserver;
  private disposed = false;

  private tmpRight = new THREE.Vector3();
  private tmpUp = new THREE.Vector3();
  private tmpFwd = new THREE.Vector3();

  constructor(private canvas: HTMLCanvasElement, private onStats?: (s: Stats) => void) {
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false, // soft alpha content: MSAA buys nothing, costs bandwidth
      alpha: false,
      powerPreference: 'high-performance',
      stencil: false,
      depth: false, // no depth buffer at all: sorted painter's algorithm
    });
    this.renderer.autoClear = true;

    // Sky dome
    this.skyMat = new THREE.ShaderMaterial({
      vertexShader: skyVertex,
      fragmentShader: skyFragment,
      side: THREE.BackSide,
      depthWrite: false,
      depthTest: false,
      uniforms: {
        uZenith: { value: new THREE.Vector3() },
        uHorizon: { value: new THREE.Vector3() },
        uBelow: { value: new THREE.Vector3() },
        uSun: { value: new THREE.Vector3() },
        uSunColor: { value: new THREE.Vector3() },
      },
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(1, 48, 24), this.skyMat);
    this.sky.scale.setScalar(2000);
    this.sky.frustumCulled = false;
    this.sky.renderOrder = -10;
    this.scene.add(this.sky);

    // Cloud material (shared by the single instanced draw call)
    this.cloudMat = new THREE.ShaderMaterial({
      vertexShader: cloudVertex,
      fragmentShader: cloudFragment,
      transparent: true,
      depthWrite: false,
      depthTest: false,
      uniforms: {
        uNoise: { value: this.noise },
        uSun: { value: new THREE.Vector3() },
        uSunColor: { value: new THREE.Vector3() },
        uAmbTop: { value: new THREE.Vector3() },
        uAmbBottom: { value: new THREE.Vector3() },
        uFogColor: { value: new THREE.Vector3() },
        uRight: { value: new THREE.Vector3() },
        uUp: { value: new THREE.Vector3() },
        uFwd: { value: new THREE.Vector3() },
        uTime: { value: 0 },
        uOpacity: { value: 0.62 },
        uFog: { value: 0.0016 },
      },
    });

    this.applySun();
    this.build();
    this.bindEvents();

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(canvas.parentElement ?? canvas);
    this.resize();

    this.raf = requestAnimationFrame(this.loop);
  }

  /* ------------------------------------------------------------------ */
  /* Public API                                                         */
  /* ------------------------------------------------------------------ */

  setQuality(q: Quality) {
    if (q === this.quality) return;
    this.quality = q;
    this.build();
    this.resize();
  }

  setSun(elevationDeg: number, azimuthDeg: number) {
    this.sunElev = elevationDeg;
    this.sunAz = azimuthDeg;
    this.applySun();
    this.bake();
  }

  setCoverage(v: number) {
    this.coverage = v;
  }

  setWind(v: number) {
    this.wind = v;
  }

  setView(p: ViewPreset) {
    if (p === 'above') this.pitchT = 0.95;
    if (p === 'horizon') this.pitchT = 0.06;
    if (p === 'below') this.pitchT = -0.75;
    this.distT = p === 'horizon' ? 70 : 90;
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    this.unbindEvents();
    this.geo?.dispose();
    this.cloudMat.dispose();
    this.skyMat.dispose();
    this.sky.geometry.dispose();
    this.noise.dispose();
    this.renderer.dispose();
  }

  /* ------------------------------------------------------------------ */
  /* Scene construction                                                 */
  /* ------------------------------------------------------------------ */

  private build() {
    const q = QUALITY[this.quality];
    const rng = mulberry32(20240607);

    const lx: number[] = [];
    const ly: number[] = [];
    const lz: number[] = [];
    const size: number[] = [];
    const seed: number[] = [];
    const hnorm: number[] = [];
    const edge: number[] = [];
    this.clouds = [];

    for (let c = 0; c < q.clouds; c++) {
      const ang = rng() * Math.PI * 2;
      const rad = Math.sqrt(rng()) * FIELD_RADIUS * 0.96;
      const scale = 0.7 + rng() * 0.95;
      const cloud: Cloud = {
        x0: Math.cos(ang) * rad,
        z: Math.sin(ang) * rad,
        y: -5 + rng() * 15,
        speed: 0.75 + rng() * 0.5,
        rank: rng(),
        start: lx.length,
        count: 0,
      };

      const lobes = 3 + Math.floor(rng() * 4);
      const spreadX = 30 * scale;
      const spreadZ = 15 * scale;
      const startIdx = lx.length;

      for (let l = 0; l < lobes; l++) {
        const cx = (rng() - 0.5) * 2 * spreadX;
        const cz = (rng() - 0.5) * 2 * spreadZ;
        const t = cx / spreadX;
        const R = (9 + rng() * 9) * scale * (1.15 - 0.5 * t * t);
        const cy = R * 0.55;
        const n = Math.round(q.perLobe * Math.min(Math.max(R / 13, 0.6), 1.5));

        for (let i = 0; i < n; i++) {
          let px: number, py: number, pz: number, len: number;
          do {
            px = rng() * 2 - 1;
            py = rng() * 2 - 1;
            pz = rng() * 2 - 1;
            len = Math.hypot(px, py, pz);
          } while (len > 1 || len < 0.001);
          if (py < 0) py *= 0.3; // flat-ish cumulus base
          const s = R * (0.6 - 0.27 * len) * (0.75 + rng() * 0.5);
          lx.push(cx + px * R);
          ly.push(Math.max(cy + py * R * 0.95, s * 0.35));
          lz.push(cz + pz * R * 0.9);
          size.push(s);
          seed.push(rng());
          edge.push(Math.pow(len, 1.3));
          hnorm.push(0);
        }
      }

      cloud.count = lx.length - startIdx;
      let maxY = 1;
      for (let i = startIdx; i < lx.length; i++) maxY = Math.max(maxY, ly[i] + size[i]);
      for (let i = startIdx; i < lx.length; i++) hnorm[i] = Math.min(ly[i] / maxY, 1);
      this.clouds.push(cloud);
    }

    this.total = Math.min(lx.length, MAX_PUFFS);
    this.lx = new Float32Array(lx);
    this.ly = new Float32Array(ly);
    this.lz = new Float32Array(lz);
    this.size = new Float32Array(size);
    this.seed = new Float32Array(seed);
    this.hnorm = new Float32Array(hnorm);
    this.edge = new Float32Array(edge);
    this.light = new Float32Array(this.total);
    this.bake();

    // GPU buffers
    this.geo?.dispose();
    if (this.cloudMesh) this.scene.remove(this.cloudMesh);

    const geo = new THREE.InstancedBufferGeometry();
    geo.setAttribute(
      'position',
      new THREE.BufferAttribute(new Float32Array([-1, -1, 0, 1, -1, 0, 1, 1, 0, -1, 1, 0]), 3),
    );
    geo.setIndex([0, 1, 2, 0, 2, 3]);

    this.stagePos = new Float32Array(this.total * 3);
    this.stageAlpha = new Float32Array(this.total);
    this.sortKeys = new Float64Array(this.total);
    this.order = new Uint32Array(this.total);

    const mk = (arr: Float32Array, n: number) => {
      const a = new THREE.InstancedBufferAttribute(arr, n);
      a.setUsage(THREE.DynamicDrawUsage);
      return a;
    };
    geo.setAttribute('aPos', mk(new Float32Array(this.total * 3), 3));
    geo.setAttribute('aA', mk(new Float32Array(this.total * 4), 4));
    geo.setAttribute('aB', mk(new Float32Array(this.total * 4), 4));
    geo.instanceCount = 0;

    this.geo = geo;
    this.cloudMesh = new THREE.Mesh(geo, this.cloudMat);
    this.cloudMesh.frustumCulled = false;
    this.cloudMesh.renderOrder = 0;
    this.scene.add(this.cloudMesh);
  }

  /**
   * Cheap "baked" light: for each puff, accumulate the chord length through
   * all other puffs of the same cloud that sit between it and the sun
   * (ray vs. sphere), then turn the optical depth into a two-lobe
   * transmittance (direct + multiple-scattering). The result is one smooth
   * brightness per puff that varies across the *cloud*, not per sprite.
   * Clouds are rigid while drifting, so this is only redone when the sun moves.
   */
  private bake() {
    const L = this.sunDir;
    const { lx, ly, lz, size, light } = this;
    for (const cloud of this.clouds) {
      const s = cloud.start;
      const e = Math.min(s + cloud.count, this.total);
      for (let i = s; i < e; i++) {
        let occ = 0;
        for (let j = s; j < e; j++) {
          if (j === i) continue;
          const dx = lx[j] - lx[i];
          const dy = ly[j] - ly[i];
          const dz = lz[j] - lz[i];
          const t = dx * L.x + dy * L.y + dz * L.z;
          if (t <= 0) continue;
          const perp2 = dx * dx + dy * dy + dz * dz - t * t;
          const rj = size[j] * 0.95;
          const r2 = rj * rj;
          if (perp2 < r2) occ += Math.sqrt(r2 - perp2);
        }
        light[i] = Math.exp(-occ * 0.085) * 0.76 + Math.exp(-occ * 0.02) * 0.24;
      }
    }
  }

  private applySun() {
    const e = THREE.MathUtils.degToRad(this.sunElev);
    const a = THREE.MathUtils.degToRad(this.sunAz);
    this.sunDir.set(Math.cos(e) * Math.sin(a), Math.sin(e), Math.cos(e) * Math.cos(a)).normalize();

    // 0 = golden hour, 1 = midday
    const t = smoothstep(3, 38, this.sunElev);
    const dim = 0.55 + 0.45 * smoothstep(0, 14, this.sunElev);

    const zenith = mix3([0.14, 0.2, 0.44], [0.17, 0.4, 0.8], t).multiplyScalar(dim);
    const horizon = mix3([1.0, 0.56, 0.34], [0.72, 0.85, 0.97], t).multiplyScalar(0.55 + 0.45 * dim);
    const below = zenith.clone().multiplyScalar(0.62).lerp(horizon, 0.18);
    const sunColor = mix3([1.0, 0.6, 0.32], [1.0, 0.96, 0.88], t);
    const ambTop = mix3([0.66, 0.56, 0.62], [0.82, 0.9, 1.0], t).multiplyScalar(dim);
    const ambBottom = mix3([0.3, 0.26, 0.36], [0.5, 0.58, 0.72], t).multiplyScalar(dim);

    const s = this.skyMat.uniforms;
    s.uZenith.value.copy(zenith);
    s.uHorizon.value.copy(horizon);
    s.uBelow.value.copy(below);
    s.uSun.value.copy(this.sunDir);
    s.uSunColor.value.copy(sunColor);

    const c = this.cloudMat.uniforms;
    c.uSun.value.copy(this.sunDir);
    c.uSunColor.value.copy(sunColor);
    c.uAmbTop.value.copy(ambTop);
    c.uAmbBottom.value.copy(ambBottom);
    c.uFogColor.value.copy(horizon);

    this.renderer.setClearColor(new THREE.Color(horizon.x, horizon.y, horizon.z), 1);
  }

  /* ------------------------------------------------------------------ */
  /* Per-frame update                                                   */
  /* ------------------------------------------------------------------ */

  private update(dt: number) {
    this.time += dt;
    this.drift += dt * this.wind;

    // smoothed orbit
    const k = 1 - Math.exp(-dt * 9);
    this.yaw += (this.yawT - this.yaw) * k;
    this.pitch += (this.pitchT - this.pitch) * k;
    this.dist += (this.distT - this.dist) * k;
    const cp = Math.cos(this.pitch);
    this.camera.position.set(
      this.target.x + this.dist * cp * Math.sin(this.yaw),
      this.target.y + this.dist * Math.sin(this.pitch),
      this.target.z + this.dist * cp * Math.cos(this.yaw),
    );
    this.camera.lookAt(this.target);
    this.camera.updateMatrixWorld(true);

    const m = this.camera.matrixWorld.elements;
    const right = this.tmpRight.set(m[0], m[1], m[2]);
    const up = this.tmpUp.set(m[4], m[5], m[6]);
    const fwd = this.tmpFwd.set(-m[8], -m[9], -m[10]);
    const cu = this.cloudMat.uniforms;
    cu.uRight.value.copy(right);
    cu.uUp.value.copy(up);
    cu.uFwd.value.copy(fwd);
    cu.uTime.value = this.time;
    this.sky.position.copy(this.camera.position);

    const cam = this.camera.position;
    const tanV = Math.tan(THREE.MathUtils.degToRad(this.camera.fov) * 0.5);
    const tanH = tanV * this.camera.aspect;
    const far = this.camera.far * 0.6;
    const t = this.time;
    const ext = FIELD_RADIUS * 2;
    const R = FIELD_RADIUS;

    const { lx, ly, lz, size, seed, light, hnorm, edge, sortKeys, stagePos, stageAlpha, order } = this;
    let n = 0;

    for (const cloud of this.clouds) {
      // wind drift + wrap-around
      const wx = ((((cloud.x0 + this.drift * cloud.speed + R) % ext) + ext) % ext) - R;
      const rr = Math.hypot(wx, cloud.z);
      const edgeFade = 1 - smoothstep(R * 0.58, R * 0.97, rr);
      const vis = Math.min(Math.max((this.coverage * 1.2 - cloud.rank) / 0.2, 0), 1);
      const ca = edgeFade * vis * vis * (3 - 2 * vis);
      if (ca < 0.01) continue;

      const end = Math.min(cloud.start + cloud.count, this.total);
      for (let i = cloud.start; i < end; i++) {
        const sd = seed[i];
        const bobX = Math.cos(t * 0.19 + sd * 23.0) * 0.55;
        const bobY = Math.sin(t * 0.27 + sd * 41.0) * 0.6;
        const px = wx + lx[i] + bobX;
        const py = cloud.y + ly[i] + bobY;
        const pz = cloud.z + lz[i];

        const rx = px - cam.x;
        const ry = py - cam.y;
        const rz = pz - cam.z;
        const depth = rx * fwd.x + ry * fwd.y + rz * fwd.z;
        const s = size[i];
        if (depth < -s || depth > far) continue; // behind camera / beyond fog
        const xc = rx * right.x + ry * right.y + rz * right.z;
        const yc = rx * up.x + ry * up.y + rz * up.z;
        const lim = s * 1.2;
        if (Math.abs(xc) > depth * tanH + lim || Math.abs(yc) > depth * tanV + lim) continue; // frustum cull

        // store temp world pos directly in the output buffers (indexed by puff id)
        const o = i * 3;
        stagePos[o] = px;
        stagePos[o + 1] = py;
        stagePos[o + 2] = pz;
        stageAlpha[i] = ca;
        // key: far -> near, plus puff id in the low bits (native numeric sort, no comparator)
        const key = Math.max(0, Math.floor((2600 - depth) * 8));
        sortKeys[n++] = key * INDEX_BITS + i;
      }
    }

    // Native Float64 sort. Ascending key == far first == correct "over" order.
    const sorted = sortKeys.subarray(0, n).sort();

    // Gather into compact, ordered instance buffers.
    const geo = this.geo!;
    const posAttr = geo.getAttribute('aPos') as THREE.InstancedBufferAttribute;
    const aAttr = geo.getAttribute('aA') as THREE.InstancedBufferAttribute;
    const bAttr = geo.getAttribute('aB') as THREE.InstancedBufferAttribute;
    const outPos = posAttr.array as Float32Array;
    const outA = aAttr.array as Float32Array;
    const outB = bAttr.array as Float32Array;

    for (let j = 0; j < n; j++) {
      const id = sorted[j] % INDEX_BITS;
      order[j] = id;
      const o = j * 4;
      const sp = id * 3;
      outPos[j * 3] = stagePos[sp];
      outPos[j * 3 + 1] = stagePos[sp + 1];
      outPos[j * 3 + 2] = stagePos[sp + 2];
      outA[o] = size[id];
      outA[o + 1] = seed[id] * 6.2831853;
      outA[o + 2] = light[id];
      outA[o + 3] = stageAlpha[id];
      outB[o] = hnorm[id];
      outB[o + 1] = edge[id];
      outB[o + 2] = seed[id];
      outB[o + 3] = 0;
    }

    geo.instanceCount = n;
    posAttr.needsUpdate = true;
    aAttr.needsUpdate = true;
    bAttr.needsUpdate = true;
    this.drawn = n;
  }

  private loop = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min((now - this.last) / 1000, 0.05);
    this.last = now;

    this.update(dt);
    this.renderer.render(this.scene, this.camera);

    this.fpsAcc += dt;
    this.fpsFrames++;
    if (this.fpsAcc >= 0.5) {
      this.onStats?.({
        fps: Math.round(this.fpsFrames / this.fpsAcc),
        drawn: this.drawn,
        total: this.total,
        clouds: this.clouds.length,
      });
      this.fpsAcc = 0;
      this.fpsFrames = 0;
    }
  };

  /* ------------------------------------------------------------------ */
  /* Input / sizing                                                     */
  /* ------------------------------------------------------------------ */

  private resize() {
    const host = this.canvas.parentElement ?? this.canvas;
    const w = Math.max(host.clientWidth, 1);
    const h = Math.max(host.clientHeight, 1);
    const dpr = Math.min(window.devicePixelRatio || 1, QUALITY[this.quality].dpr);
    this.renderer.setPixelRatio(dpr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  private onDown = (e: PointerEvent) => {
    this.canvas.setPointerCapture(e.pointerId);
    this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (this.pointers.size === 2) this.pinchDist = this.getPinch();
    this.canvas.style.cursor = 'grabbing';
  };

  private onMove = (e: PointerEvent) => {
    const p = this.pointers.get(e.pointerId);
    if (!p) return;
    const dx = e.clientX - p.x;
    const dy = e.clientY - p.y;
    p.x = e.clientX;
    p.y = e.clientY;

    if (this.pointers.size === 1) {
      this.yawT -= dx * 0.0055;
      this.pitchT = Math.min(Math.max(this.pitchT + dy * 0.0055, -1.45), 1.45);
    } else if (this.pointers.size === 2) {
      const d = this.getPinch();
      if (this.pinchDist > 0) this.zoomBy(this.pinchDist / d);
      this.pinchDist = d;
    }
  };

  private onUp = (e: PointerEvent) => {
    this.pointers.delete(e.pointerId);
    if (this.pointers.size < 2) this.pinchDist = 0;
    if (this.pointers.size === 0) this.canvas.style.cursor = 'grab';
  };

  private onWheel = (e: WheelEvent) => {
    e.preventDefault();
    this.zoomBy(Math.exp(e.deltaY * 0.0012));
  };

  private zoomBy(f: number) {
    this.distT = Math.min(Math.max(this.distT * f, 18), 320);
  }

  private getPinch() {
    const [a, b] = Array.from(this.pointers.values());
    return Math.hypot(a.x - b.x, a.y - b.y);
  }

  private bindEvents() {
    const c = this.canvas;
    c.style.cursor = 'grab';
    c.style.touchAction = 'none';
    c.addEventListener('pointerdown', this.onDown);
    c.addEventListener('pointermove', this.onMove);
    c.addEventListener('pointerup', this.onUp);
    c.addEventListener('pointercancel', this.onUp);
    c.addEventListener('wheel', this.onWheel, { passive: false });
  }

  private unbindEvents() {
    const c = this.canvas;
    c.removeEventListener('pointerdown', this.onDown);
    c.removeEventListener('pointermove', this.onMove);
    c.removeEventListener('pointerup', this.onUp);
    c.removeEventListener('pointercancel', this.onUp);
    c.removeEventListener('wheel', this.onWheel);
  }
}
