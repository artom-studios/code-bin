import * as THREE from 'three';

/**
 * Tileable fBm value-noise, baked once into a single-channel texture.
 * Every puff samples this (rotated / offset per instance) to get billowy,
 * unique silhouettes without any per-pixel noise math in the shader.
 */
export function makeNoiseTexture(size = 256): THREE.DataTexture {
  const data = new Uint8Array(size * size);
  const acc = new Float32Array(size * size);

  let s = 1337;
  const rnd = () => {
    s |= 0;
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };

  const octaves: Array<[number, number]> = [
    [4, 0.5],
    [8, 0.28],
    [16, 0.14],
    [32, 0.08],
  ];

  for (const [g, amp] of octaves) {
    const grid = new Float32Array(g * g);
    for (let i = 0; i < grid.length; i++) grid[i] = rnd();
    for (let y = 0; y < size; y++) {
      const fy = (y / size) * g;
      const iy = Math.floor(fy);
      let ty = fy - iy;
      ty = ty * ty * (3 - 2 * ty);
      const y0 = iy % g;
      const y1 = (iy + 1) % g;
      for (let x = 0; x < size; x++) {
        const fx = (x / size) * g;
        const ix = Math.floor(fx);
        let tx = fx - ix;
        tx = tx * tx * (3 - 2 * tx);
        const x0 = ix % g;
        const x1 = (ix + 1) % g;
        const a = grid[y0 * g + x0];
        const b = grid[y0 * g + x1];
        const c = grid[y1 * g + x0];
        const d = grid[y1 * g + x1];
        const v = a + (b - a) * tx + (c - a + (a - b - c + d) * tx) * ty;
        acc[y * size + x] += v * amp;
      }
    }
  }

  let min = Infinity;
  let max = -Infinity;
  for (let i = 0; i < acc.length; i++) {
    if (acc[i] < min) min = acc[i];
    if (acc[i] > max) max = acc[i];
  }
  for (let i = 0; i < acc.length; i++) {
    data[i] = Math.round(((acc[i] - min) / (max - min)) * 255);
  }

  const tex = new THREE.DataTexture(data, size, size, THREE.RedFormat, THREE.UnsignedByteType);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.generateMipmaps = true;
  tex.needsUpdate = true;
  return tex;
}
