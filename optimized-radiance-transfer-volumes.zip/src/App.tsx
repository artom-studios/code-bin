import { useCallback, useEffect, useRef, useState } from 'react';
import { Engine } from '@/engine/engine';
import { defaultSettings, type Settings, type FrameStats } from '@/engine/renderer';
import { Button, Kbd, Section, Segmented, Slider, Toggle } from '@/ui/Controls';

const VIEWS = [
  { label: 'Final', value: 0 }, { label: 'GI only', value: 1 }, { label: 'Direct', value: 5 },
  { label: 'AO', value: 4 }, { label: 'Albedo', value: 2 }, { label: 'Normals', value: 3 }, { label: 'Shadow', value: 6 },
];
const BUDGETS = [{ label: 'All', value: 0 }, { label: '12', value: 12 }, { label: '6', value: 6 }, { label: '3', value: 3 }, { label: '1', value: 1 }];
const SCALES = [{ label: '50%', value: 0.5 }, { label: '75%', value: 0.75 }, { label: '100%', value: 1 }];

const fmtTime = (t: number) => {
  const h = Math.floor(t) % 24, m = Math.floor((t - Math.floor(t)) * 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
};

interface Hud { fps: number; ms: number; stats: FrameStats; time: number; mode: string; lights: number }

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [progress, setProgress] = useState({ f: 0, msg: 'Starting…' });
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [s, setS] = useState<Settings>({ ...defaultSettings });
  const [time, setTime] = useState(15);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(0.35);
  const [hud, setHud] = useState<Hud | null>(null);
  const [panel, setPanel] = useState(true);
  const [uiHidden, setUiHidden] = useState(false);
  const [mode, setMode] = useState<'tour' | 'free'>('tour');
  const [exportMsg, setExportMsg] = useState('');

  useEffect(() => {
    const canvas = canvasRef.current!;
    let cancelled = false;
    let engine: Engine | null = null;
    Engine.create(canvas, (f, msg) => !cancelled && setProgress({ f, msg }))
      .then((e) => {
        if (cancelled) { e.stop(); return; }
        engine = e;
        engineRef.current = e;
        (window as unknown as { __engine: Engine }).__engine = e;
        e.start();
        setReady(true);
      })
      .catch((err) => { console.error(err); setError(String(err?.message ?? err)); });
    return () => { cancelled = true; engine?.stop(); };
  }, []);

  // HUD polling
  useEffect(() => {
    if (!ready) return;
    const id = setInterval(() => {
      const e = engineRef.current;
      if (!e) return;
      setHud({ fps: e.fps, ms: e.frameMs, stats: { ...e.stats, gpu: { ...e.stats.gpu } }, time: e.env.timeOfDay, mode: e.camera.mode, lights: e.env.userLightCount });
      setMode(e.camera.mode);
      if (e.timePlaying) setTime(e.env.timeOfDay);
    }, 250);
    return () => clearInterval(id);
  }, [ready]);

  // H toggles UI
  useEffect(() => {
    const k = (ev: KeyboardEvent) => { if (ev.key.toLowerCase() === 'h') setUiHidden((v) => !v); };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, []);

  const upd = useCallback((patch: Partial<Settings>) => {
    setS((prev) => {
      const n = { ...prev, ...patch };
      if (engineRef.current) Object.assign(engineRef.current.settings, n);
      return n;
    });
  }, []);

  const eng = engineRef.current;
  const info = eng?.info;
  const gpu = hud?.stats.gpu ?? {};
  const gpuOrder = ['Shadow map', 'GI relight', 'GI SH project', 'G-buffer', 'SSAO', 'GI apply', 'Lighting', 'Post'];
  const gpuTotal = gpuOrder.reduce((a, k) => a + (gpu[k] ?? 0), 0);

  return (
    <div className="fixed inset-0 select-none overflow-hidden bg-black text-zinc-100">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" style={{ cursor: mode === 'free' ? 'grab' : 'default' }} />

      {/* ------------------------------------------------ loading / error */}
      {!ready && !error && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#07090c]">
          <div className="w-[min(520px,86vw)]">
            <div className="mb-1 text-[11px] font-semibold uppercase tracking-[0.3em] text-amber-500">Deferred Radiance Transfer Volumes</div>
            <h1 className="mb-6 text-3xl font-light tracking-tight text-white">Baking global illumination…</h1>
            <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full bg-gradient-to-r from-amber-600 to-amber-300 transition-all duration-200" style={{ width: `${Math.round(progress.f * 100)}%` }} />
            </div>
            <div className="mt-3 flex justify-between font-mono text-[11px] text-zinc-400">
              <span>{progress.msg}</span>
              <span>{Math.round(progress.f * 100)}%</span>
            </div>
            <p className="mt-8 text-[12px] leading-relaxed text-zinc-500">
              Ray-tracing the surface cache of every probe on a worker pool. At runtime this data is relit every frame on the GPU,
              so the sun, sky and dynamic lights all produce multi-bounce indirect light with no further baking.
            </p>
          </div>
        </div>
      )}
      {error && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-[#07090c] p-8">
          <div className="max-w-lg rounded-lg border border-red-500/30 bg-red-950/30 p-6">
            <div className="mb-2 text-sm font-semibold text-red-300">Could not start the renderer</div>
            <div className="font-mono text-xs text-red-200/80">{error}</div>
            <div className="mt-3 text-xs text-zinc-400">This demo needs WebGL2 with float render targets (EXT_color_buffer_float).</div>
          </div>
        </div>
      )}

      {ready && !uiHidden && (
        <>
          {/* ------------------------------------------------ title */}
          <div className="pointer-events-none absolute left-5 top-5">
            <div className="text-[10px] font-semibold uppercase tracking-[0.3em] text-amber-400">Far Cry 3 · GDC 2012</div>
            <h1 className="text-xl font-light tracking-tight text-white drop-shadow">Deferred Radiance Transfer Volumes</h1>
            <div className="mt-0.5 text-[11px] text-zinc-300/80 drop-shadow">WebGL2 reference implementation · {info?.probes.toLocaleString()} probes · {info?.triangles.toLocaleString()} tris</div>
          </div>

          {/* ------------------------------------------------ perf HUD */}
          <div className="absolute bottom-5 left-5 w-[250px] rounded-lg border border-white/10 bg-black/55 p-3 font-mono text-[10.5px] leading-[1.55] text-zinc-300 backdrop-blur-md">
            <div className="mb-1 flex items-baseline justify-between">
              <span className="text-lg font-semibold text-white">{(hud?.fps ?? 0).toFixed(0)}<span className="ml-1 text-[10px] font-normal text-zinc-500">FPS</span></span>
              <span className="text-zinc-400">{(hud?.ms ?? 0).toFixed(1)} ms</span>
            </div>
            <div className="text-zinc-500">{hud?.stats.width}×{hud?.stats.height} · {hud?.stats.drawCalls} draws · {Math.round((hud?.stats.triangles ?? 0) / 1000)}k tris</div>
            <div className="text-zinc-500">chunks {hud?.stats.chunksVisible}/{hud?.stats.chunksTotal} · CPU {hud?.stats.cpuMs.toFixed(2)} ms</div>
            <div className="mt-1.5 border-t border-white/10 pt-1.5">
              <div className="text-amber-400/90">DRTV update: {hud?.stats.layersUpdated} layers · {(hud?.stats.probesUpdated ?? 0).toLocaleString()} probes</div>
              {hud?.stats.gpuTimers ? (
                <div className="mt-1 space-y-[1px]">
                  {gpuOrder.map((k) => (
                    <div key={k} className="flex items-center gap-2">
                      <span className="w-[86px] text-zinc-500">{k}</span>
                      <span className="h-1 flex-1 overflow-hidden rounded bg-white/10">
                        <span className="block h-full bg-amber-500/80" style={{ width: `${Math.min(100, ((gpu[k] ?? 0) / Math.max(gpuTotal, 0.01)) * 100)}%` }} />
                      </span>
                      <span className="w-9 text-right">{(gpu[k] ?? 0).toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between border-t border-white/10 pt-0.5 text-zinc-400"><span>GPU total</span><span>{gpuTotal.toFixed(2)} ms</span></div>
                </div>
              ) : (
                <div className="mt-1 text-zinc-600">GPU timers unavailable in this browser</div>
              )}
            </div>
            <div className="mt-1.5 border-t border-white/10 pt-1.5 text-zinc-500">
              GI memory {info?.giMB.toFixed(1)} MB · bake {info?.bake.seconds.toFixed(1)}s ({info?.bake.workers || 1} thr)
            </div>
          </div>

          {/* ------------------------------------------------ bottom time-of-day */}
          <div className="absolute bottom-5 left-1/2 flex w-[min(560px,40vw)] min-w-[360px] -translate-x-1/2 items-center gap-3 rounded-full border border-white/10 bg-black/55 px-4 py-2 backdrop-blur-md">
            <button
              onClick={() => { const v = !playing; setPlaying(v); if (eng) eng.timePlaying = v; }}
              className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-amber-500 text-black hover:bg-amber-400"
              title="Animate time of day"
            >
              {playing ? (
                <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor"><rect x="1" y="1" width="3" height="8" /><rect x="6" y="1" width="3" height="8" /></svg>
              ) : (
                <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor"><path d="M2 1l7 4-7 4z" /></svg>
              )}
            </button>
            <span className="w-11 font-mono text-sm text-white">{fmtTime(playing ? (hud?.time ?? time) : time)}</span>
            <input
              type="range" min={0} max={24} step={0.02} value={playing ? (hud?.time ?? time) : time}
              onChange={(e) => { const v = parseFloat(e.target.value); setTime(v); eng?.setTime(v); }}
              className="drtv-range flex-1"
              style={{ background: 'linear-gradient(to right,#0b1030,#27407a 22%,#ffb169 28%,#9fd0ff 40%,#bfe2ff 52%,#ffb169 74%,#27407a 80%,#0b1030)' }}
            />
          </div>

          {/* ------------------------------------------------ controls hint */}
          <div className="pointer-events-none absolute bottom-5 right-[22rem] hidden items-center gap-2 text-[10px] text-zinc-300/80 2xl:flex">
            <Kbd>WASD</Kbd><Kbd>Q</Kbd><Kbd>E</Kbd> move <Kbd>Shift</Kbd> sprint <Kbd>drag</Kbd> look <Kbd>F</Kbd> light <Kbd>G</Kbd> clear <Kbd>T</Kbd> tour <Kbd>H</Kbd> hide UI
          </div>

          {/* ------------------------------------------------ panel */}
          <button onClick={() => setPanel(!panel)} className="absolute right-5 top-5 z-10 rounded-md border border-white/10 bg-black/60 px-3 py-1.5 text-[11px] text-zinc-200 backdrop-blur-md hover:bg-black/80">
            {panel ? 'Hide panel' : 'Settings'}
          </button>
          {panel && (
            <div className="absolute bottom-5 right-5 top-14 w-[330px] overflow-y-auto rounded-xl border border-white/10 bg-[#0b0d11]/80 backdrop-blur-xl [scrollbar-width:thin]">
              <Section title="Global Illumination" badge={<span className={`rounded px-1.5 py-px text-[9px] ${s.giEnabled ? 'bg-amber-500/20 text-amber-300' : 'bg-white/10 text-zinc-400'}`}>{s.giEnabled ? 'DRTV' : 'AMBIENT'}</span>}>
                <Toggle label="Radiance transfer volumes" value={s.giEnabled} onChange={(v) => upd({ giEnabled: v })} hint="A/B" />
                <Slider label="Indirect intensity" value={s.giIntensity} min={0} max={2.5} step={0.01} onChange={(v) => upd({ giIntensity: v })} />
                <Slider label="Bounce feedback" value={s.bounce} min={0} max={1} step={0.01} onChange={(v) => upd({ bounce: v })} format={(v) => `${(v * 100).toFixed(0)}%`} />
                <Slider label="Temporal blend / update" value={s.blend} min={0.05} max={1} step={0.01} onChange={(v) => upd({ blend: v })} />
                <div>
                  <div className="mb-1 text-[11px] text-zinc-400">Probe layers relit per frame</div>
                  <Segmented options={BUDGETS} value={s.budget} onChange={(v) => upd({ budget: v })} />
                </div>
                <Toggle label="Half-resolution apply" value={s.giHalfRes} onChange={(v) => upd({ giHalfRes: v })} hint="bilateral upsample" />
                <Slider label="Contact AO strength" value={s.aoStrength} min={0} max={1} step={0.01} onChange={(v) => upd({ aoStrength: v })} />
                <Slider label="AO radius (m)" value={s.aoRadius} min={0.3} max={3} step={0.05} onChange={(v) => upd({ aoRadius: v })} />
                <Button onClick={() => eng?.resetGI()} className="w-full">Reset GI history</Button>
              </Section>

              <Section title="Debug views">
                <Segmented options={VIEWS} value={s.view} onChange={(v) => upd({ view: v })} />
                <Toggle label="Show probes (SH irradiance)" value={s.showProbes} onChange={(v) => upd({ showProbes: v })} />
                {s.showProbes && <Slider label="Probe draw range (m)" value={s.probeRange} min={8} max={90} step={1} onChange={(v) => upd({ probeRange: v })} format={(v) => `${v.toFixed(0)} m`} />}
                {s.showProbes && <div className="text-[10px] text-zinc-500">Magenta spheres = probes that could not be relocated out of solid geometry.</div>}
              </Section>

              <Section title="Camera & lights">
                <div className="flex gap-2">
                  <Button variant={mode === 'tour' ? 'primary' : 'default'} onClick={() => { eng?.camera.startTour(); setMode('tour'); }} className="flex-1">Cinematic tour</Button>
                  <Button variant={mode === 'free' ? 'primary' : 'default'} onClick={() => { if (eng) eng.camera.mode = 'free'; setMode('free'); }} className="flex-1">Free fly</Button>
                </div>
                <div className="flex gap-2">
                  <Button onClick={() => eng?.addLightAtCamera()} className="flex-1">Drop light <span className="ml-1 opacity-60">F</span></Button>
                  <Button onClick={() => eng?.clearLights()} className="flex-1">Clear <span className="ml-1 opacity-60">G</span></Button>
                </div>
                <div className="text-[10px] text-zinc-500">{hud?.lights ?? 0} user lights. Dynamic lights are injected into the probe relight pass, so they bounce.</div>
              </Section>

              <Section title="Time of day" defaultOpen={false}>
                <Slider label="Animation speed (h / s)" value={speed} min={0.05} max={3} step={0.05} onChange={(v) => { setSpeed(v); if (eng) eng.timeSpeed = v; }} />
              </Section>

              <Section title="Post & quality" defaultOpen={false}>
                <Slider label="Exposure" value={s.exposure} min={0.3} max={3} step={0.01} onChange={(v) => upd({ exposure: v })} />
                <Slider label="Bloom" value={s.bloom} min={0} max={0.3} step={0.005} onChange={(v) => upd({ bloom: v })} />
                <Slider label="Aerial fog" value={s.fog} min={0} max={0.006} step={0.0001} onChange={(v) => upd({ fog: v })} format={(v) => v.toFixed(4)} />
                <Toggle label="FXAA" value={s.fxaa} onChange={(v) => upd({ fxaa: v })} />
                <div>
                  <div className="mb-1 text-[11px] text-zinc-400">Render scale</div>
                  <Segmented options={SCALES} value={s.renderScale} onChange={(v) => upd({ renderScale: v })} />
                </div>
              </Section>

              <Section title="Volumes & export" defaultOpen={false}>
                <div className="space-y-1 font-mono text-[10.5px] text-zinc-400">
                  {info?.volumes.map((v) => (
                    <div key={v.name} className="flex justify-between">
                      <span className="text-zinc-300">{v.name}</span>
                      <span>{v.dims.join('×')} · {v.probes.toLocaleString()}{v.invalid ? ` (${v.invalid} inv)` : ''}</span>
                    </div>
                  ))}
                  <div className="pt-1 text-zinc-500">{info?.bake.rays.toLocaleString()} rays traced · {info?.renderer}</div>
                </div>
                <Button variant="primary" className="w-full" onClick={() => { const b = eng?.exportBake(); if (b) setExportMsg(`Saved compound.drtv (${(b / 1048576).toFixed(1)} MB)`); }}>
                  Export baked probe data (.drtv)
                </Button>
                {exportMsg && <div className="text-[10px] text-emerald-400">{exportMsg}</div>}
              </Section>
            </div>
          )}
        </>
      )}
    </div>
  );
}
