/**
 * Procedural demo scene: "Ruined jungle compound".
 *
 *  - 200m x 200m terrain with hills, a paved plaza and two terraces
 *  - Hollow stepped temple with an oculus light-well (indoor GI showcase)
 *  - Village street with 10 hollow houses (color bleeding between rooms)
 *  - Long gallery with window slits, pavilion, and saturated color panels
 *  - ~300 trees, rocks, pillars, braziers
 *
 * Output is a chunked, indexed static mesh with a 20-byte vertex:
 *   float3 position | snorm8x4 normal | unorm8x4 (albedo.rgb, material id)
 * Chunks carry AABBs for frustum culling (camera + shadow).
 */
import { mix, smoothstep, type Vec3 } from './math';

export const MAT = { TERRAIN: 0, STONE: 1, PLASTER: 2, FOLIAGE: 3, WOOD: 4, EMISSIVE: 5 } as const;
export const VERTEX_STRIDE = 20;

export interface VolumeDef {
  name: string;
  origin: Vec3;
  spacing: number;
  dims: [number, number, number];
  maxRay: number;
  /** Edge fade width in metres (0 for the global volume). */
  blend: number;
}

export interface PointLightDef {
  name: string;
  pos: Vec3;
  color: Vec3;
  radius: number;
  /** Optional AABB that confines the light (cheap interior occlusion). */
  box?: [Vec3, Vec3];
  flicker: number;
}

export interface Chunk { first: number; count: number; bounds: Float32Array }

export interface SceneData {
  interleaved: ArrayBuffer;
  positions: Float32Array;
  normals: Int8Array;
  colors: Uint8Array;
  indices: Uint32Array;
  vertexCount: number;
  triangleCount: number;
  chunks: Chunk[];
  volumes: VolumeDef[];
  lights: PointLightDef[];
  tour: { pos: Vec3; target: Vec3 }[];
  bounds: { min: Vec3; max: Vec3 };
  treeCount: number;
}

/* ------------------------------------------------------------------ noise / rng */
function hash2(ix: number, iz: number, seed = 0): number {
  let h = (Math.imul(ix, 374761393) + Math.imul(iz, 668265263) + Math.imul(seed, 1442695041)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}
function vnoise(x: number, z: number, seed = 0): number {
  const ix = Math.floor(x), iz = Math.floor(z);
  const fx = x - ix, fz = z - iz;
  const ux = fx * fx * (3 - 2 * fx), uz = fz * fz * (3 - 2 * fz);
  const a = hash2(ix, iz, seed), b = hash2(ix + 1, iz, seed), c = hash2(ix, iz + 1, seed), d = hash2(ix + 1, iz + 1, seed);
  return mix(mix(a, b, ux), mix(c, d, ux), uz);
}
function fbm(x: number, z: number, oct = 4, seed = 0): number {
  let a = 0.5, s = 0, n = 0;
  for (let i = 0; i < oct; i++) { s += a * vnoise(x, z, seed + i * 17); n += a; x *= 2.03; z *= 2.03; a *= 0.5; }
  return s / n;
}
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ------------------------------------------------------------------ terrain definition */
const HALF = 100;
const PLAZA = { r0: 34, r1: 52, y: 3 };
const VILL = { x0: 42, x1: 84, z0: -44, z1: 44, y: 2, pad: 12 };
const GAL = { x0: -86, x1: -46, z0: -30, z1: 30, y: 1, pad: 12 };

function rectF(x: number, z: number, r: { x0: number; x1: number; z0: number; z1: number }, pad: number) {
  const dx = Math.max(r.x0 - x, 0, x - r.x1), dz = Math.max(r.z0 - z, 0, z - r.z1);
  return 1 - smoothstep(0, pad, Math.hypot(dx, dz));
}
function plazaF(x: number, z: number) { return 1 - smoothstep(PLAZA.r0, PLAZA.r1, Math.hypot(x, z)); }
function flatF(x: number, z: number) {
  return Math.max(plazaF(x, z), rectF(x, z, VILL, VILL.pad), rectF(x, z, GAL, GAL.pad));
}

export function terrainHeight(x: number, z: number): number {
  let h = 3.5 + (fbm(x * 0.012 + 11.3, z * 0.012 - 4.1, 4) - 0.5) * 16;
  const d = Math.max(Math.abs(x), Math.abs(z));
  h += smoothstep(66, 98, d) * (12 + fbm(x * 0.03, z * 0.03, 3, 5) * 10);
  h = mix(h, PLAZA.y, plazaF(x, z));
  h = mix(h, VILL.y, rectF(x, z, VILL, VILL.pad));
  h = mix(h, GAL.y, rectF(x, z, GAL, GAL.pad));
  return h;
}

/* ------------------------------------------------------------------ mesh builder */
class ChunkMesh {
  pos: number[] = [];
  nrm: number[] = [];
  col: number[] = [];
  idx: number[] = [];
  cache = new Map<number, number>();

  vert(x: number, y: number, z: number, nx: number, ny: number, nz: number, c: Vec3, mat: number): number {
    const i = this.pos.length / 3;
    this.pos.push(x, y, z);
    const l = Math.hypot(nx, ny, nz) || 1;
    this.nrm.push(nx / l, ny / l, nz / l);
    this.col.push(c[0], c[1], c[2], mat);
    return i;
  }

  /** Adds a triangle; winding is auto-corrected against the vertex normals so the
   *  geometric normal is always outward (required by the baker's back-face test). */
  tri(a: number, b: number, c: number) {
    const p = this.pos, n = this.nrm;
    const ax = p[a * 3], ay = p[a * 3 + 1], az = p[a * 3 + 2];
    const ux = p[b * 3] - ax, uy = p[b * 3 + 1] - ay, uz = p[b * 3 + 2] - az;
    const vx = p[c * 3] - ax, vy = p[c * 3 + 1] - ay, vz = p[c * 3 + 2] - az;
    const gx = uy * vz - uz * vy, gy = uz * vx - ux * vz, gz = ux * vy - uy * vx;
    if (gx * gx + gy * gy + gz * gz < 1e-14) return; // degenerate
    const nx = n[a * 3] + n[b * 3] + n[c * 3], ny = n[a * 3 + 1] + n[b * 3 + 1] + n[c * 3 + 1], nz = n[a * 3 + 2] + n[b * 3 + 2] + n[c * 3 + 2];
    if (gx * nx + gy * ny + gz * nz >= 0) this.idx.push(a, b, c);
    else this.idx.push(a, c, b);
  }
}

type ColorArg = Vec3 | ((face: number) => Vec3);

const ICO = (() => {
  const t = (1 + Math.sqrt(5)) / 2;
  let v: Vec3[] = [
    [-1, t, 0], [1, t, 0], [-1, -t, 0], [1, -t, 0], [0, -1, t], [0, 1, t],
    [0, -1, -t], [0, 1, -t], [t, 0, -1], [t, 0, 1], [-t, 0, -1], [-t, 0, 1],
  ].map((p) => { const l = Math.hypot(p[0], p[1], p[2]); return [p[0] / l, p[1] / l, p[2] / l] as Vec3; });
  let f: number[][] = [
    [0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11], [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8],
    [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9], [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1],
  ];
  const cache = new Map<number, number>();
  const mid = (a: number, b: number) => {
    const k = a < b ? a * 1000 + b : b * 1000 + a;
    let i = cache.get(k);
    if (i === undefined) {
      const p = v[a], q = v[b];
      const m: Vec3 = [p[0] + q[0], p[1] + q[1], p[2] + q[2]];
      const l = Math.hypot(m[0], m[1], m[2]);
      v = v.concat([[m[0] / l, m[1] / l, m[2] / l]]);
      i = v.length - 1;
      cache.set(k, i);
    }
    return i;
  };
  const nf: number[][] = [];
  for (const [a, b, c] of f) {
    const ab = mid(a, b), bc = mid(b, c), ca = mid(c, a);
    nf.push([a, ab, ca], [b, bc, ab], [c, ca, bc], [ab, bc, ca]);
  }
  f = nf;
  return { v, f };
})();

class SceneBuilder {
  chunks = new Map<number, ChunkMesh>();
  readonly n: number;
  rng = mulberry32(1337);
  constructor(readonly chunkSize = 25) { this.n = Math.ceil((HALF * 2) / chunkSize); }

  chunk(x: number, z: number): ChunkMesh {
    const cx = Math.min(this.n - 1, Math.max(0, Math.floor((x + HALF) / this.chunkSize)));
    const cz = Math.min(this.n - 1, Math.max(0, Math.floor((z + HALF) / this.chunkSize)));
    const k = cz * this.n + cx;
    let c = this.chunks.get(k);
    if (!c) { c = new ChunkMesh(); this.chunks.set(k, c); }
    return c;
  }

  box(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, color: ColorArg, mat: number = MAT.PLASTER, noBottom = false) {
    if (x1 - x0 < 1e-4 || y1 - y0 < 1e-4 || z1 - z0 < 1e-4) return;
    const tint = 0.96 + this.rng() * 0.08;
    const faces: { n: Vec3; c: Vec3[] }[] = [
      { n: [1, 0, 0], c: [[x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1]] },
      { n: [-1, 0, 0], c: [[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]] },
      { n: [0, 1, 0], c: [[x0, y1, z0], [x0, y1, z1], [x1, y1, z1], [x1, y1, z0]] },
      { n: [0, -1, 0], c: [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]] },
      { n: [0, 0, 1], c: [[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]] },
      { n: [0, 0, -1], c: [[x0, y0, z0], [x0, y1, z0], [x1, y1, z0], [x1, y0, z0]] },
    ];
    for (let f = 0; f < 6; f++) {
      if (noBottom && f === 3) continue;
      const { n, c } = faces[f];
      const base = typeof color === 'function' ? color(f) : color;
      const col: Vec3 = [Math.min(1, base[0] * tint), Math.min(1, base[1] * tint), Math.min(1, base[2] * tint)];
      const cx = (c[0][0] + c[2][0]) / 2, cz = (c[0][2] + c[2][2]) / 2;
      const m = this.chunk(cx, cz);
      const ids = c.map((p) => m.vert(p[0], p[1], p[2], n[0], n[1], n[2], col, mat));
      m.tri(ids[0], ids[1], ids[2]);
      m.tri(ids[0], ids[2], ids[3]);
    }
  }

  /** Wall along X or Z with rectangular openings. u = distance along the wall from its start. */
  wall(ax: number, az: number, bx: number, bz: number, y0: number, h: number, thick: number, color: ColorArg, mat: number,
    openings: { u0: number; u1: number; v0: number; v1: number }[] = []) {
    const alongX = Math.abs(bx - ax) >= Math.abs(bz - az);
    const L = alongX ? Math.abs(bx - ax) : Math.abs(bz - az);
    const sx = alongX ? Math.min(ax, bx) : ax, sz = alongX ? az : Math.min(az, bz);
    const seg = (u0: number, u1: number, v0: number, v1: number) => {
      if (u1 - u0 < 1e-3 || v1 - v0 < 1e-3) return;
      if (alongX) this.box(sx + u0, y0 + v0, sz - thick / 2, sx + u1, y0 + v1, sz + thick / 2, color, mat, true);
      else this.box(sx - thick / 2, y0 + v0, sz + u0, sx + thick / 2, y0 + v1, sz + u1, color, mat, true);
    };
    const ops = [...openings].sort((a, b) => a.u0 - b.u0);
    let cur = 0;
    for (const o of ops) {
      seg(cur, o.u0, 0, h);
      seg(o.u0, o.u1, 0, o.v0);
      seg(o.u0, o.u1, o.v1, h);
      cur = o.u1;
    }
    seg(cur, L, 0, h);
  }

  cylinder(cx: number, cy: number, cz: number, r0: number, r1: number, h: number, sides: number, segs: number, color: Vec3, mat: number, bx = 0, bz = 0, cap = false) {
    const m = this.chunk(cx, cz);
    const rings: number[][] = [];
    for (let k = 0; k <= segs; k++) {
      const t = k / segs;
      const r = mix(r0, r1, t);
      const ox = bx * t * t, oz = bz * t * t;
      const ring: number[] = [];
      for (let s = 0; s < sides; s++) {
        const a = (s / sides) * Math.PI * 2;
        const ca = Math.cos(a), sa = Math.sin(a);
        const shade = 0.9 + 0.2 * hash2(s, k, 3);
        ring.push(m.vert(cx + ox + ca * r, cy + h * t, cz + oz + sa * r, ca, 0.1, sa, [color[0] * shade, color[1] * shade, color[2] * shade], mat));
      }
      rings.push(ring);
    }
    for (let k = 0; k < segs; k++) {
      for (let s = 0; s < sides; s++) {
        const s2 = (s + 1) % sides;
        const a = rings[k][s], b = rings[k][s2], c = rings[k + 1][s2], d = rings[k + 1][s];
        m.tri(a, b, c); m.tri(a, c, d);
      }
    }
    if (cap) {
      const top = rings[segs];
      const ox = bx, oz = bz;
      const ctr = m.vert(cx + ox, cy + h, cz + oz, 0, 1, 0, color, mat);
      const tv = top.map((_, s) => {
        const a = (s / sides) * Math.PI * 2;
        return m.vert(cx + ox + Math.cos(a) * r1, cy + h, cz + oz + Math.sin(a) * r1, 0, 1, 0, color, mat);
      });
      for (let s = 0; s < sides; s++) m.tri(ctr, tv[s], tv[(s + 1) % sides]);
    }
  }

  blob(cx: number, cy: number, cz: number, rx: number, ry: number, rz: number, color: Vec3, mat: number, lump: number, seed: number) {
    const m = this.chunk(cx, cz);
    const ids = ICO.v.map((u, i) => {
      const d = 1 + (hash2(i, seed, 9) - 0.5) * 2 * lump;
      const shade = 0.88 + 0.24 * hash2(i, seed, 4);
      return m.vert(cx + u[0] * rx * d, cy + u[1] * ry * d, cz + u[2] * rz * d,
        u[0] / rx, u[1] / ry, u[2] / rz, [color[0] * shade, color[1] * shade, color[2] * shade], mat);
    });
    for (const f of ICO.f) m.tri(ids[f[0]], ids[f[1]], ids[f[2]]);
  }

  tree(x: number, z: number, y: number, kind: number, r: () => number) {
    const trunkCol: Vec3 = [0.30 + r() * 0.06, 0.22 + r() * 0.04, 0.15];
    const leaf = (): Vec3 => [0.24 + r() * 0.10, 0.36 + r() * 0.12, 0.14 + r() * 0.06];
    const bendX = (r() - 0.5) * 1.6, bendZ = (r() - 0.5) * 1.6;
    if (kind === 0) {
      const h = 5 + r() * 4;
      this.cylinder(x, y - 0.3, z, 0.38, 0.2, h, 6, 3, trunkCol, MAT.WOOD, bendX, bendZ);
      const top = y + h - 0.3;
      const R = 2.6 + r() * 1.8;
      const lc = leaf();
      this.blob(x + bendX, top + R * 0.35, z + bendZ, R, R * 0.8, R, lc, MAT.FOLIAGE, 0.18, Math.floor(r() * 1000));
      this.blob(x + bendX + (r() - 0.5) * R, top - 0.2, z + bendZ + (r() - 0.5) * R, R * 0.75, R * 0.6, R * 0.75, leaf(), MAT.FOLIAGE, 0.2, Math.floor(r() * 1000));
      this.blob(x + bendX + (r() - 0.5) * R, top + R * 0.9, z + bendZ + (r() - 0.5) * R, R * 0.6, R * 0.55, R * 0.6, leaf(), MAT.FOLIAGE, 0.2, Math.floor(r() * 1000));
    } else {
      const h = 9 + r() * 6;
      this.cylinder(x, y - 0.3, z, 0.45, 0.22, h, 6, 4, trunkCol, MAT.WOOD, bendX * 1.4, bendZ * 1.4);
      const top = y + h - 0.3;
      const R = 2.2 + r() * 1.2;
      this.blob(x + bendX * 1.4, top + R * 0.8, z + bendZ * 1.4, R, R * 1.7, R, leaf(), MAT.FOLIAGE, 0.16, Math.floor(r() * 1000));
      this.blob(x + bendX * 1.4, top - R * 0.6, z + bendZ * 1.4, R * 1.25, R * 1.1, R * 1.25, leaf(), MAT.FOLIAGE, 0.2, Math.floor(r() * 1000));
    }
  }

  terrain(res: number, colorFn: (x: number, z: number, ny: number) => Vec3 & { 3?: number }) {
    const N = Math.round((HALF * 2) / res);
    const hAt = (i: number, j: number) => terrainHeight(-HALF + i * res, -HALF + j * res);
    const vertex = (m: ChunkMesh, i: number, j: number) => {
      const key = j * (N + 1) + i;
      let v = m.cache.get(key);
      if (v === undefined) {
        const x = -HALF + i * res, z = -HALF + j * res;
        const h = terrainHeight(x, z);
        const e = 1.0;
        const nx = terrainHeight(x - e, z) - terrainHeight(x + e, z);
        const nz = terrainHeight(x, z - e) - terrainHeight(x, z + e);
        const ny = 2 * e;
        const nl = Math.hypot(nx, ny, nz);
        const c = colorFn(x, z, ny / nl) as number[];
        v = m.vert(x, h, z, nx, ny, nz, [c[0], c[1], c[2]], c[3] ?? 0);
        m.cache.set(key, v);
      }
      return v;
    };
    void hAt;
    for (let j = 0; j < N; j++) {
      for (let i = 0; i < N; i++) {
        const cx = -HALF + (i + 0.5) * res, cz = -HALF + (j + 0.5) * res;
        const m = this.chunk(cx, cz);
        const a = vertex(m, i, j), b = vertex(m, i + 1, j), c = vertex(m, i + 1, j + 1), d = vertex(m, i, j + 1);
        // alternate diagonal for less directional artifacts
        if ((i + j) & 1) { m.tri(a, b, c); m.tri(a, c, d); } else { m.tri(a, b, d); m.tri(b, c, d); }
      }
    }
  }
}

/* ------------------------------------------------------------------ scene assembly */
const rgb = (r: number, g: number, b: number): Vec3 => [r, g, b];

export function generateScene(): SceneData {
  const B = new SceneBuilder(25);
  const rnd = mulberry32(20120);
  const lights: PointLightDef[] = [];

  /* ---------------- terrain ---------------- */
  B.terrain(2, (x, z, ny) => {
    const pf = plazaF(x, z);
    const vf = rectF(x, z, VILL, VILL.pad * 0.6);
    const gf = rectF(x, z, GAL, GAL.pad * 0.6);
    const n = fbm(x * 0.05, z * 0.05, 3, 2);
    let c: number[] = [mix(0.15, 0.30, n), mix(0.30, 0.42, n), mix(0.08, 0.12, n)];
    const dry = smoothstep(0.58, 0.75, fbm(x * 0.02 + 50, z * 0.02 - 30, 3, 8));
    c = [mix(c[0], 0.42, dry * 0.7), mix(c[1], 0.40, dry * 0.7), mix(c[2], 0.17, dry * 0.7)];
    // dirt paths
    const pathX = Math.max(smoothstep(4.5, 1.5, Math.abs(z)) * smoothstep(30, 38, Math.abs(x)), 0);
    const pathZ = smoothstep(4.5, 1.5, Math.abs(x)) * smoothstep(30, 38, z) * smoothstep(100, 80, z);
    const path = Math.max(pathX, pathZ);
    c = [mix(c[0], 0.46, path), mix(c[1], 0.37, path), mix(c[2], 0.25, path)];
    c = [mix(c[0], 0.52, vf), mix(c[1], 0.43, vf), mix(c[2], 0.31, vf)];
    c = [mix(c[0], 0.64, gf), mix(c[1], 0.57, gf), mix(c[2], 0.40, gf)];
    const rock = smoothstep(0.86, 0.68, ny);
    c = [mix(c[0], 0.40, rock), mix(c[1], 0.36, rock), mix(c[2], 0.32, rock)];
    c = [mix(c[0], 0.66, pf), mix(c[1], 0.62, pf), mix(c[2], 0.55, pf)];
    c.push(pf > 0.5 ? MAT.STONE : MAT.TERRAIN);
    return c as unknown as Vec3;
  });

  /* ---------------- temple ---------------- */
  const y0 = PLAZA.y;
  const sand = rgb(0.80, 0.70, 0.52), terracotta = rgb(0.74, 0.30, 0.20), gold = rgb(0.88, 0.70, 0.30);
  const teal = rgb(0.12, 0.50, 0.55), floorStone = rgb(0.72, 0.66, 0.55);
  const faceCol = (outer: Vec3, inner: Vec3, innerFace: number, top: Vec3 = outer) => (f: number): Vec3 =>
    f === innerFace ? inner : f === 2 ? top : outer;
  // base chamber (walls 4m thick, 7m high)
  const H1 = 7;
  B.box(-15, y0 - 0.5, -15, 15, y0, 15, sand, MAT.STONE, true); // foundation skirt
  B.box(-15, y0, -15, 15, y0 + H1, -11, faceCol(sand, terracotta, 4), MAT.STONE, true); // north wall (inner face +z)
  B.box(-15, y0, -11, -11, y0 + H1, 11, faceCol(sand, terracotta, 0), MAT.STONE, true); // west wall (inner face +x)
  B.box(11, y0, -11, 15, y0 + H1, 11, faceCol(sand, terracotta, 1), MAT.STONE, true); // east wall (inner face -x)
  B.box(-15, y0, 11, -3, y0 + H1, 15, faceCol(sand, terracotta, 5), MAT.STONE, true); // south wall, left of door
  B.box(3, y0, 11, 15, y0 + H1, 15, faceCol(sand, terracotta, 5), MAT.STONE, true); // south wall, right of door
  B.box(-3, y0 + 5.5, 11, 3, y0 + H1, 15, faceCol(sand, terracotta, 5), MAT.STONE, true); // lintel
  // interior floor + carpet
  B.box(-11, y0 - 0.4, -11, 11, y0 + 0.12, 11, floorStone, MAT.STONE, true);
  B.box(-2, y0 + 0.1, -11, 2, y0 + 0.16, 12, teal, MAT.PLASTER, true);
  // roof slab with oculus (6x6)
  const roofCol = faceCol(sand, rgb(0.62, 0.34, 0.24), 3);
  B.box(-15, y0 + H1, -15, 15, y0 + H1 + 1.2, -3, roofCol, MAT.STONE);
  B.box(-15, y0 + H1, 3, 15, y0 + H1 + 1.2, 15, roofCol, MAT.STONE);
  B.box(-15, y0 + H1, -3, -3, y0 + H1 + 1.2, 3, roofCol, MAT.STONE);
  B.box(3, y0 + H1, -3, 15, y0 + H1 + 1.2, 3, roofCol, MAT.STONE);
  // tier 2 ring (well)
  const yr = y0 + H1 + 1.2;
  const ring = (xo: number, xi: number, ya: number, yb: number, inner: Vec3, outer: Vec3) => {
    B.box(-xo, ya, -xo, xo, yb, -xi, faceCol(outer, inner, 4), MAT.STONE, true);
    B.box(-xo, ya, xi, xo, yb, xo, faceCol(outer, inner, 5), MAT.STONE, true);
    B.box(-xo, ya, -xi, -xi, yb, xi, faceCol(outer, inner, 0), MAT.STONE, true);
    B.box(xi, ya, -xi, xo, yb, xi, faceCol(outer, inner, 1), MAT.STONE, true);
  };
  ring(10, 4, yr, yr + 5.8, gold, sand);
  ring(7, 4, yr + 5.8, yr + 8.6, terracotta, sand);
  // east staircase up to the roof walk
  const steps = 16, roofTop = H1 + 1.2;
  for (let i = 0; i < steps; i++) {
    B.box(15, y0, -3, 15 + (steps - i) * 0.6, y0 + ((i + 1) * roofTop) / steps, 3, sand, MAT.STONE, true);
  }
  // temple porch pillars at the door
  for (const sx of [-5.5, 5.5]) {
    B.cylinder(sx, y0, 17.5, 0.7, 0.62, 6.2, 10, 2, sand, MAT.STONE, 0, 0, true);
    B.box(sx - 1, y0 + 6.2, 16.5, sx + 1, y0 + 6.8, 18.5, sand, MAT.STONE, true);
  }
  B.box(-6.6, y0 + 6.8, 16.5, 6.6, y0 + 7.4, 18.5, gold, MAT.STONE, true);
  // plaza colonnade
  for (let i = 0; i < 28; i++) {
    const a = (i / 28) * Math.PI * 2;
    if (Math.abs(a - Math.PI / 2) < 0.2 || Math.abs(a - Math.PI * 2) < 0.12 || Math.abs(a - Math.PI) < 0.12 || a < 0.01) continue; // leave path gaps
    const px = Math.cos(a) * 32, pz = Math.sin(a) * 32;
    const broken = rnd() < 0.3;
    const ph = broken ? 2.5 + rnd() * 3 : 7;
    B.cylinder(px, y0, pz, 0.8, 0.7, ph, 8, 2, sand, MAT.STONE, 0, 0, true);
    if (!broken) B.box(px - 1.1, y0 + ph, pz - 1.1, px + 1.1, y0 + ph + 0.6, pz + 1.1, sand, MAT.STONE, true);
  }

  /* ---------------- braziers ---------------- */
  const brazier = (x: number, y: number, z: number, name: string, box?: [Vec3, Vec3], radius = 12, intensity = 1) => {
    B.box(x - 0.35, y, z - 0.35, x + 0.35, y + 1.1, z + 0.35, rgb(0.3, 0.28, 0.26), MAT.STONE, true);
    B.box(x - 0.28, y + 1.1, z - 0.28, x + 0.28, y + 1.5, z + 0.28, rgb(1.0, 0.55, 0.16), MAT.EMISSIVE, true);
    lights.push({ name, pos: [x, y + 1.9, z], color: [1.0 * intensity, 0.52 * intensity, 0.20 * intensity], radius, box, flicker: 0.25 });
  };
  const inTemple: [Vec3, Vec3] = [[-11, y0, -11], [11, y0 + 7, 11]];
  brazier(-9, y0 + 0.12, -9, 'temple-nw', inTemple, 12, 1.4);
  brazier(9, y0 + 0.12, -9, 'temple-ne', inTemple, 12, 1.4);
  brazier(-4.2, y0, 20, 'porch-w', undefined, 13, 1.2);
  brazier(4.2, y0, 20, 'porch-e', undefined, 13, 1.2);

  /* ---------------- village ---------------- */
  const vy = VILL.y;
  const houseDefs: { x: number; z: number; w: number; d: number; h: number; c: Vec3; door: 'E' | 'W'; roof: boolean }[] = [];
  const palette: Vec3[] = [
    rgb(0.88, 0.84, 0.72), rgb(0.18, 0.55, 0.62), rgb(0.90, 0.68, 0.20), rgb(0.74, 0.27, 0.22),
    rgb(0.86, 0.50, 0.30), rgb(0.40, 0.60, 0.40), rgb(0.35, 0.40, 0.70), rgb(0.88, 0.84, 0.72),
    rgb(0.78, 0.36, 0.50), rgb(0.20, 0.55, 0.62),
  ];
  const zs = [-34, -18, -2, 14, 30];
  zs.forEach((z, i) => {
    houseDefs.push({ x: 52, z, w: 10, d: 9 + (i % 2) * 2, h: 3.4, c: palette[i], door: 'E', roof: i !== 1 });
    houseDefs.push({ x: 74, z: z + 1, w: 10, d: 9 + ((i + 1) % 2) * 2, h: 3.4, c: palette[i + 5], door: 'W', roof: i !== 3 });
  });
  const floorWood = rgb(0.46, 0.31, 0.19), roofDark = rgb(0.36, 0.31, 0.29);
  for (const hd of houseDefs) {
    const t = 0.5;
    const x0 = hd.x - hd.w / 2, x1 = hd.x + hd.w / 2, z0 = hd.z - hd.d / 2, z1 = hd.z + hd.d / 2;
    const win = (len: number) => [0.28, 0.72].map((f) => ({ u0: len * f - 0.7, u1: len * f + 0.7, v0: 0.9, v1: 2.2 }));
    const doorOp = (len: number) => ({ u0: len / 2 - 0.8, u1: len / 2 + 0.8, v0: 0, v1: 2.5 });
    // north & south walls (along x), extended by thickness to close corners
    B.wall(x0 - t / 2, z0, x1 + t / 2, z0, vy, hd.h, t, hd.c, MAT.PLASTER, win(hd.w));
    B.wall(x0 - t / 2, z1, x1 + t / 2, z1, vy, hd.h, t, hd.c, MAT.PLASTER, [{ u0: hd.w * 0.5 - 0.7, u1: hd.w * 0.5 + 0.7, v0: 0.9, v1: 2.2 }]);
    // east/west walls (along z)
    const eOps = hd.door === 'E' ? [doorOp(hd.d)] : [{ u0: hd.d * 0.5 - 0.7, u1: hd.d * 0.5 + 0.7, v0: 0.9, v1: 2.2 }];
    const wOps = hd.door === 'W' ? [doorOp(hd.d)] : [{ u0: hd.d * 0.5 - 0.7, u1: hd.d * 0.5 + 0.7, v0: 0.9, v1: 2.2 }];
    B.wall(x1, z0 + t / 2, x1, z1 - t / 2, vy, hd.h, t, hd.c, MAT.PLASTER, eOps);
    B.wall(x0, z0 + t / 2, x0, z1 - t / 2, vy, hd.h, t, hd.c, MAT.PLASTER, wOps);
    B.box(x0, vy - 0.4, z0, x1, vy + 0.1, z1, floorWood, MAT.WOOD, true);
    if (hd.roof) B.box(x0 - 0.6, vy + hd.h, z0 - 0.6, x1 + 0.6, vy + hd.h + 0.45, z1 + 0.6, (f) => (f === 3 ? hd.c : roofDark), MAT.PLASTER);
    else B.box(x0 + 1, vy + 0.1, z0 + 1.2, x0 + 2.6, vy + 0.9, z0 + 2.2, rgb(0.5, 0.35, 0.2), MAT.WOOD, true); // crate in ruined house
  }
  brazier(63, vy, -9, 'village-n', undefined, 14, 1.2);
  brazier(63, vy, 9, 'village-s', undefined, 14, 1.2);
  // market well
  B.cylinder(63, vy, 0, 1.4, 1.3, 1.0, 12, 1, rgb(0.55, 0.52, 0.48), MAT.STONE, 0, 0, true);

  /* ---------------- gallery & colour panels ---------------- */
  const gy = GAL.y;
  const turq = rgb(0.16, 0.56, 0.60), yellowTile = rgb(0.80, 0.66, 0.28);
  {
    const x0 = -82, x1 = -52, hh = 5.2, t = 0.8, zS = 3, zN = -3;
    const slits = [0, 1, 2, 3, 4, 5].map((k) => ({ u0: 3 + k * 4.6, u1: 4.1 + k * 4.6, v0: 1.1, v1: 4.4 }));
    B.wall(x0, zS, x1, zS, gy, hh, t, turq, MAT.PLASTER, slits);
    const arches = [6, 15, 24].map((u) => ({ u0: u, u1: u + 2.4, v0: 0, v1: 3.6 }));
    B.wall(x0, zN, x1, zN, gy, hh, t, turq, MAT.PLASTER, arches);
    B.wall(x0, zN + t / 2, x0, zS - t / 2, gy, hh, t, turq, MAT.PLASTER, [{ u0: 2.0, u1: 4.2, v0: 0, v1: 3.4 }]); // west end door
    B.wall(x1, zN + t / 2, x1, zS - t / 2, gy, hh, t, turq, MAT.PLASTER, [{ u0: 1.8, u1: 4.2, v0: 0, v1: 3.6 }]); // east end door
    B.box(x0, gy - 0.4, zN, x1, gy + 0.1, zS, yellowTile, MAT.STONE, true);
    const roofG = (f: number): Vec3 => (f === 3 ? rgb(0.88, 0.80, 0.62) : turq);
    const rt = gy + hh, ry = rt + 0.6;
    const hole = (cx: number) => [cx - 1.6, cx + 1.6];
    const h1 = hole(-72), h2 = hole(-60);
    // roof with two skylights (slabs between holes)
    B.box(x0 - 0.5, rt, zN - 0.5, h1[0], ry, zS + 0.5, roofG, MAT.PLASTER);
    B.box(h1[1], rt, zN - 0.5, h2[0], ry, zS + 0.5, roofG, MAT.PLASTER);
    B.box(h2[1], rt, zN - 0.5, x1 + 0.5, ry, zS + 0.5, roofG, MAT.PLASTER);
    for (const h of [h1, h2]) {
      B.box(h[0], rt, zN - 0.5, h[1], ry, -1.6, roofG, MAT.PLASTER);
      B.box(h[0], rt, 1.6, h[1], ry, zS + 0.5, roofG, MAT.PLASTER);
    }
    brazier(-76, gy + 0.1, 0, 'gallery-w', [[-82, gy, -3], [-52, gy + 5.2, 3]], 11, 1.3);
    brazier(-62, gy + 0.1, 0, 'gallery-e', [[-82, gy, -3], [-52, gy + 5.2, 3]], 11, 1.3);
  }
  // pavilion
  {
    const cx = -64, cz = 20, py = gy;
    const stone = rgb(0.74, 0.66, 0.54);
    for (let i = 0; i < 4; i++) for (let j = 0; j < 3; j++) {
      B.cylinder(cx - 8 + 1 + i * 4.67, py, cz - 6 + 1 + j * 5, 0.5, 0.45, 5.5, 8, 1, stone, MAT.STONE, 0, 0, true);
    }
    B.box(cx - 8.6, py + 5.5, cz - 6.6, cx + 8.6, py + 6.1, cz + 6.6, (f) => (f === 3 ? rgb(0.90, 0.55, 0.25) : stone), MAT.PLASTER);
  }
  // saturated colour panels (colour bleeding showcase)
  const panelCols: Vec3[] = [rgb(0.85, 0.12, 0.10), rgb(0.12, 0.65, 0.20), rgb(0.12, 0.25, 0.85), rgb(0.95, 0.80, 0.10), rgb(0.88, 0.88, 0.86)];
  panelCols.forEach((c, i) => {
    const px = -80 + i * 7;
    B.box(px, gy, -19.6, px + 5, gy + 3.4, -19.1, c, MAT.PLASTER, true);
  });
  // a few ruined walls in the open
  for (let i = 0; i < 6; i++) {
    const rx = -48 + (i % 3) * 4, rz = 9 + Math.floor(i / 3) * 6;
    B.box(rx, gy, rz, rx + 0.6, gy + 1.5 + rnd() * 2, rz + 3 + rnd() * 2, rgb(0.78, 0.72, 0.60), MAT.STONE, true);
  }

  /* ---------------- camera tour ---------------- */
  type W = { p: Vec3; t: Vec3; rel?: boolean };
  const spec: W[] = [
    { p: [-62, 16, 72], t: [0, 6, 0], rel: true },
    { p: [-28, 9, 50], t: [0, 8, 4] , rel: true },
    { p: [8, 4, 34], t: [0, 7, 12], rel: true },
    { p: [0, 5.4, 24], t: [0, 5.4, 0] },
    { p: [0, 5.6, 9], t: [-2, 4.0, -9] },
    { p: [-5, 5.2, -5], t: [6, 3.8, 5] },
    { p: [0, 5.4, 6], t: [0, 5, 22] },
    { p: [0, 5.4, 22], t: [14, 9, 8] },
    { p: [24, 15, 16], t: [4, 14, -4] },
    { p: [34, 15, -4], t: [0, 14, 0] },
    { p: [46, 9, -2], t: [66, 3.5, 0] },
    { p: [60, 4.3, -3], t: [74, 3.5, -4] },
    { p: [64, 4.0, -2], t: [74, 3.6, -2] },
    { p: [69, 3.9, -2], t: [78, 3.6, -2] },
    { p: [80, 8, -4], t: [60, 3, -6] },
    { p: [70, 12, 8], t: [-40, 6, 0] },
    { p: [-34, 8, 4], t: [-70, 3, 0] },
    { p: [-46, 3.6, 0.5], t: [-64, 3.2, 0] },
    { p: [-60, 3.5, -0.4], t: [-80, 3.0, 0.5] },
    { p: [-72, 3.4, 0.4], t: [-86, 3.2, 0] },
    { p: [-84, 4.0, 0.2], t: [-60, 3, -19] },
    { p: [-70, 9, -8], t: [-70, 2, -19.5] },
    { p: [-60, 12, 10], t: [-64, 3, 20] },
    { p: [-50, 14, 40], t: [-10, 6, 0], rel: true },
  ];
  const tour = spec.map((w) => {
    const p: Vec3 = [...w.p] as Vec3, t: Vec3 = [...w.t] as Vec3;
    if (w.rel) { p[1] += terrainHeight(p[0], p[2]); t[1] += terrainHeight(t[0], t[2]); }
    return { pos: p, target: t };
  });


  const nearTour = (x: number, z: number, r: number) => {
    for (let i = 0; i < tour.length; i++) {
      const a = tour[i].pos, b = tour[(i + 1) % tour.length].pos;
      const dx = b[0] - a[0], dz = b[2] - a[2];
      const l2 = dx * dx + dz * dz || 1;
      const t = Math.max(0, Math.min(1, ((x - a[0]) * dx + (z - a[2]) * dz) / l2));
      if (Math.hypot(x - (a[0] + dx * t), z - (a[2] + dz * t)) < r) return true;
    }
    return false;
  };
  /* ---------------- rocks + trees ---------------- */
  for (let i = 0, n = 0; n < 70 && i < 600; i++) {
    const x = (rnd() - 0.5) * 190, z = (rnd() - 0.5) * 190;
    if (flatF(x, z) > 0.02) continue;
    const r = 0.8 + rnd() * 2.2;
    const g = 0.36 + rnd() * 0.14;
    B.blob(x, terrainHeight(x, z) + r * 0.15, z, r * 1.2, r * 0.7, r, rgb(g, g * 0.95, g * 0.88), MAT.TERRAIN, 0.22, i);
    n++;
  }
  let treeCount = 0;
  for (let i = 0; treeCount < 300 && i < 4000; i++) {
    const x = (rnd() - 0.5) * 192, z = (rnd() - 0.5) * 192;
    if (flatF(x, z) > 0.015) continue;
    if (nearTour(x, z, 7)) continue;
    const y = terrainHeight(x, z);
    const slope = Math.hypot(terrainHeight(x + 1, z) - terrainHeight(x - 1, z), terrainHeight(x, z + 1) - terrainHeight(x, z - 1)) / 2;
    if (slope > 0.9) continue;
    B.tree(x, z, y, rnd() < 0.62 ? 0 : 1, rnd);
    treeCount++;
  }

  /* ---------------- finalize: merge chunks into one VB/IB ---------------- */
  const keys = [...B.chunks.keys()].sort((a, b) => a - b);
  let vc = 0, ic = 0;
  for (const k of keys) { const c = B.chunks.get(k)!; vc += c.pos.length / 3; ic += c.idx.length; }
  const interleaved = new ArrayBuffer(vc * VERTEX_STRIDE);
  const f32 = new Float32Array(interleaved);
  const i8 = new Int8Array(interleaved);
  const u8 = new Uint8Array(interleaved);
  const positions = new Float32Array(vc * 3);
  const normals = new Int8Array(vc * 4);
  const colors = new Uint8Array(vc * 4);
  const indices = new Uint32Array(ic);
  const chunks: Chunk[] = [];
  let vo = 0, io = 0;
  const bmin: Vec3 = [1e9, 1e9, 1e9], bmax: Vec3 = [-1e9, -1e9, -1e9];
  for (const k of keys) {
    const c = B.chunks.get(k)!;
    const nv = c.pos.length / 3;
    const bounds = new Float32Array([1e9, 1e9, 1e9, -1e9, -1e9, -1e9]);
    for (let v = 0; v < nv; v++) {
      const g = vo + v;
      const px = c.pos[v * 3], py = c.pos[v * 3 + 1], pz = c.pos[v * 3 + 2];
      f32[g * 5] = px; f32[g * 5 + 1] = py; f32[g * 5 + 2] = pz;
      positions[g * 3] = px; positions[g * 3 + 1] = py; positions[g * 3 + 2] = pz;
      for (let a = 0; a < 3; a++) {
        const nn = Math.round(Math.max(-1, Math.min(1, c.nrm[v * 3 + a])) * 127);
        i8[g * 20 + 12 + a] = nn; normals[g * 4 + a] = nn;
        const cc = Math.round(Math.max(0, Math.min(1, c.col[v * 4 + a])) * 255);
        u8[g * 20 + 16 + a] = cc; colors[g * 4 + a] = cc;
      }
      i8[g * 20 + 15] = 0;
      u8[g * 20 + 19] = colors[g * 4 + 3] = c.col[v * 4 + 3];
      bounds[0] = Math.min(bounds[0], px); bounds[1] = Math.min(bounds[1], py); bounds[2] = Math.min(bounds[2], pz);
      bounds[3] = Math.max(bounds[3], px); bounds[4] = Math.max(bounds[4], py); bounds[5] = Math.max(bounds[5], pz);
    }
    for (let i = 0; i < c.idx.length; i++) indices[io + i] = c.idx[i] + vo;
    chunks.push({ first: io, count: c.idx.length, bounds });
    for (let a = 0; a < 3; a++) { bmin[a] = Math.min(bmin[a], bounds[a]); bmax[a] = Math.max(bmax[a], bounds[3 + a]); }
    vo += nv; io += c.idx.length;
  }

  /* ---------------- probe volumes ---------------- */
  const volumes: VolumeDef[] = [
    { name: 'World (5m)', origin: [-100, -2, -100], spacing: 5, dims: [41, 8, 41], maxRay: 220, blend: 0 },
    { name: 'Temple (2m)', origin: [-24, 1, -24], spacing: 2, dims: [25, 11, 25], maxRay: 60, blend: 6 },
    { name: 'Village (2m)', origin: [40, 0, -48], spacing: 2, dims: [28, 6, 49], maxRay: 60, blend: 6 },
    { name: 'Gallery (2m)', origin: [-88, 0, -30], spacing: 2, dims: [23, 6, 31], maxRay: 60, blend: 6 },
  ];

  return {
    interleaved, positions, normals, colors, indices,
    vertexCount: vc, triangleCount: ic / 3, chunks, volumes, lights, tour,
    bounds: { min: bmin, max: bmax }, treeCount,
  };
}
