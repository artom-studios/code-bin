/**
 * Deferred Radiance Transfer Volumes - GPU runtime.
 *
 * Per frame (time-sliced over probe layers):
 *   1. RELIGHT  : relight the baked surface cache of the probes in the selected layers.
 *   2. PROJECT  : integrate to L1 SH and temporally blend into the volume's 3D textures.
 * Then, once per visible volume:
 *   3. APPLY    : deferred volume pass that evaluates SH irradiance from the G-buffer.
 */
import { TU, Program, bindTex, createTex2D, createTex3D, checkFbo } from './gl';
import { aabbInFrustum, mat4, type Mat4, type Vec3 } from './math';
import type { BakedVolume } from './bakeService';
import type { Environment } from './env';
import { TILE } from './bake';

import COMMON from './shaders/common.glsl?raw';
import FULLSCREEN_VS from './shaders/fullscreen_vs.glsl?raw';
import RELIGHT_FS from './shaders/relight_fs.glsl?raw';
import SH_FS from './shaders/sh_fs.glsl?raw';
import GIAPPLY_FS from './shaders/giapply_fs.glsl?raw';
import PROBE_VS from './shaders/probe_vs.glsl?raw';
import PROBE_FS from './shaders/probe_fs.glsl?raw';

export class RadianceVolume {
  readonly nx: number; readonly ny: number; readonly nz: number;
  readonly layout: BakedVolume['layout'];
  geoTex: WebGLTexture; albTex: WebGLTexture; offTex: WebGLTexture; radTex: WebGLTexture;
  radFbo: WebGLFramebuffer;
  sh: WebGLTexture[] = [];
  shFbos: WebGLFramebuffer[] = [];
  layerReady: boolean[];
  boxMin: Vec3; boxMax: Vec3;
  bytes = 0;

  constructor(readonly gl: WebGL2RenderingContext, readonly baked: BakedVolume) {
    const L = baked.layout;
    this.layout = L;
    this.nx = L.nx; this.ny = L.ny; this.nz = L.nz;
    const d = baked.def;
    this.layerReady = new Array(L.ny).fill(false);

    // Surface cache (static): distance/normal/flag as RGBA16F, albedo as RGBA8.
    this.geoTex = createTex2D(gl, L.texW, L.texH, { internal: gl.RGBA16F, format: gl.RGBA, type: gl.FLOAT, data: baked.geo });
    this.albTex = createTex2D(gl, L.texW, L.texH, { internal: gl.RGBA8, format: gl.RGBA, type: gl.UNSIGNED_BYTE, data: baked.alb });
    this.offTex = createTex2D(gl, L.offW, L.offH, { internal: gl.RGBA16F, format: gl.RGBA, type: gl.FLOAT, data: baked.off });

    // Relit radiance (dynamic). R11G11B10F when renderable, RGBA16F otherwise.
    let rad = createTex2D(gl, L.texW, L.texH, { internal: gl.R11F_G11F_B10F, format: gl.RGB, type: gl.HALF_FLOAT });
    let fbo = gl.createFramebuffer()!;
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, rad, 0);
    let bpp = 4;
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) {
      gl.deleteTexture(rad);
      rad = createTex2D(gl, L.texW, L.texH, { internal: gl.RGBA16F, format: gl.RGBA, type: gl.HALF_FLOAT });
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, rad, 0);
      bpp = 8;
    }
    gl.drawBuffers([gl.COLOR_ATTACHMENT0]);
    checkFbo(gl, 'radiance');
    this.radTex = rad; this.radFbo = fbo;

    // SH volumes: 3 x RGBA16F (one per colour channel), laid out (x, z, y).
    for (let c = 0; c < 3; c++) {
      const t = createTex3D(gl, L.nx, L.nz, L.ny, gl.RGBA16F, gl.RGBA, gl.HALF_FLOAT);
      this.sh.push(t);
    }
    for (let y = 0; y < L.ny; y++) {
      const f = gl.createFramebuffer()!;
      gl.bindFramebuffer(gl.FRAMEBUFFER, f);
      for (let c = 0; c < 3; c++) gl.framebufferTextureLayer(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0 + c, this.sh[c], 0, y);
      gl.drawBuffers([gl.COLOR_ATTACHMENT0, gl.COLOR_ATTACHMENT1, gl.COLOR_ATTACHMENT2]);
      checkFbo(gl, `sh-layer-${y}`);
      this.shFbos.push(f);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);

    this.bytes = L.texW * L.texH * (8 + 4 + bpp) + L.offW * L.offH * 8 + L.nx * L.ny * L.nz * 8 * 3;
    const s = d.spacing;
    this.boxMin = [d.origin[0] - s / 2, d.origin[1] - s / 2, d.origin[2] - s / 2];
    this.boxMax = [d.origin[0] + (d.dims[0] - 0.5) * s, d.origin[1] + (d.dims[1] - 0.5) * s, d.origin[2] + (d.dims[2] - 0.5) * s];
  }

  get bounds() { return [...this.boxMin, ...this.boxMax]; }
}

export interface GIParams {
  bounce: number;
  /** Temporal blend factor per update (1 = no history). */
  blend: number;
}

export class GISystem {
  readonly volumes: RadianceVolume[];
  private relight: Program;
  private sh: Program;
  private apply: Program;
  private probeProg: Program;
  private cursor = 0;
  private sphereVao: WebGLVertexArrayObject;
  private sphereCount = 0;
  private emptyVao: WebGLVertexArrayObject;
  readonly layerTotal: number;
  lastUpdatedLayers = 0;
  lastUpdatedProbes = 0;

  constructor(private gl: WebGL2RenderingContext, baked: BakedVolume[]) {
    this.volumes = baked.map((b) => new RadianceVolume(gl, b));
    this.layerTotal = this.volumes.reduce((a, v) => a + v.ny, 0);

    this.relight = new Program(gl, 'relight', FULLSCREEN_VS, COMMON + RELIGHT_FS).samplers({
      uGeo: TU.GEO, uAlb: TU.ALB, uOff: TU.OFF, uShadow: TU.SHADOW,
      uShR: TU.SH_R, uShG: TU.SH_G, uShB: TU.SH_B, uGlR: TU.GL_R, uGlG: TU.GL_G, uGlB: TU.GL_B,
    });
    this.sh = new Program(gl, 'sh', FULLSCREEN_VS, COMMON + SH_FS).samplers({ uRad: TU.RAD });
    this.apply = new Program(gl, 'giapply', FULLSCREEN_VS, COMMON + GIAPPLY_FS).samplers({
      uDepth: TU.DEPTH, uGBNrm: TU.GB_NRM, uShR: TU.SH_R, uShG: TU.SH_G, uShB: TU.SH_B,
    });
    this.probeProg = new Program(gl, 'probes', PROBE_VS, COMMON + PROBE_FS, { aPos: 0 }).samplers({
      uOff: TU.OFF, uShR: TU.SH_R, uShG: TU.SH_G, uShB: TU.SH_B,
    });
    this.emptyVao = gl.createVertexArray()!;

    // debug sphere
    const seg = 10, ring = 6, pos: number[] = [], idx: number[] = [];
    for (let r = 0; r <= ring; r++) {
      const th = (r / ring) * Math.PI;
      for (let s = 0; s <= seg; s++) {
        const ph = (s / seg) * Math.PI * 2;
        pos.push(Math.sin(th) * Math.cos(ph), Math.cos(th), Math.sin(th) * Math.sin(ph));
      }
    }
    for (let r = 0; r < ring; r++) for (let s = 0; s < seg; s++) {
      const a = r * (seg + 1) + s, b = a + seg + 1;
      idx.push(a, a + 1, b, a + 1, b + 1, b);
    }
    this.sphereCount = idx.length;
    this.sphereVao = gl.createVertexArray()!;
    gl.bindVertexArray(this.sphereVao);
    const vb = gl.createBuffer()!;
    gl.bindBuffer(gl.ARRAY_BUFFER, vb);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(pos), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 12, 0);
    const ib = gl.createBuffer()!;
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(idx), gl.STATIC_DRAW);
    gl.bindVertexArray(null);
  }

  get gpuBytes() { return this.volumes.reduce((a, v) => a + v.bytes, 0); }
  get probeCount() { return this.volumes.reduce((a, v) => a + v.baked.probeCount, 0); }

  /** Pick the next `budget` (volume, layer) pairs round-robin. */
  private schedule(budget: number): Map<number, number[]> {
    const out = new Map<number, number[]>();
    // Layers not yet initialised have absolute priority (fast start-up convergence).
    const flat: [number, number][] = [];
    this.volumes.forEach((v, vi) => { for (let y = 0; y < v.ny; y++) flat.push([vi, y]); });
    let picked = 0;
    for (const [vi, y] of flat) {
      if (!this.volumes[vi].layerReady[y]) { (out.get(vi) ?? out.set(vi, []).get(vi)!).push(y); picked++; }
    }
    const n = Math.min(budget, flat.length);
    for (let i = 0; i < n; i++) {
      const [vi, y] = flat[(this.cursor + i) % flat.length];
      const list = out.get(vi) ?? out.set(vi, []).get(vi)!;
      if (!list.includes(y)) { list.push(y); picked++; }
    }
    this.cursor = (this.cursor + n) % flat.length;
    void picked;
    return out;
  }

  update(env: Environment, params: GIParams, budget: number, shadowTex: WebGLTexture, timer?: { begin(l: string): void; end(): void }) {
    const gl = this.gl;
    const plan = this.schedule(budget);
    let layers = 0, probes = 0;

    gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE); gl.disable(gl.BLEND);
    gl.bindVertexArray(this.emptyVao);
    bindTex(gl, TU.SHADOW, gl.TEXTURE_2D, shadowTex);
    const glob = this.volumes[0];

    for (const [vi, ys] of plan) {
      const V = this.volumes[vi];
      const d = V.baked.def;
      const L = V.layout;

      // ---------------- relight ----------------
      timer?.begin('GI relight');
      const r = this.relight.use();
      env.apply(r);
      r.f3('uOrigin', d.origin[0], d.origin[1], d.origin[2]);
      r.f1('uSpacing', d.spacing);
      r.i3('uDims', L.nx, L.ny, L.nz);
      r.i1('uCols', L.cols);
      r.f3('uGOrigin', glob.baked.def.origin[0], glob.baked.def.origin[1], glob.baked.def.origin[2]);
      r.f1('uGSpacing', glob.baked.def.spacing);
      r.f3('uGDims', glob.nx, glob.ny, glob.nz);
      r.f1('uBounce', params.bounce);
      bindTex(gl, TU.GEO, gl.TEXTURE_2D, V.geoTex);
      bindTex(gl, TU.ALB, gl.TEXTURE_2D, V.albTex);
      bindTex(gl, TU.OFF, gl.TEXTURE_2D, V.offTex);
      for (let c = 0; c < 3; c++) {
        bindTex(gl, TU.SH_R + c, gl.TEXTURE_3D, V.sh[c]);
        bindTex(gl, TU.GL_R + c, gl.TEXTURE_3D, glob.sh[c]);
      }
      gl.bindFramebuffer(gl.FRAMEBUFFER, V.radFbo);
      gl.viewport(0, 0, L.texW, L.texH);
      gl.enable(gl.SCISSOR_TEST);
      for (const y of ys) {
        gl.scissor((y % L.cols) * L.layerW, Math.floor(y / L.cols) * L.layerH, L.layerW, L.layerH);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
      }
      gl.disable(gl.SCISSOR_TEST);
      timer?.end();

      // ---------------- SH projection + temporal blend ----------------
      timer?.begin('GI SH project');
      const s = this.sh.use();
      s.i3('uDims', L.nx, L.ny, L.nz);
      s.i1('uCols', L.cols);
      bindTex(gl, TU.RAD, gl.TEXTURE_2D, V.radTex);
      gl.viewport(0, 0, L.nx, L.nz);
      for (const y of ys) {
        gl.bindFramebuffer(gl.FRAMEBUFFER, V.shFbos[y]);
        if (!V.layerReady[y] || params.blend >= 0.999) gl.disable(gl.BLEND);
        else {
          gl.enable(gl.BLEND);
          gl.blendColor(params.blend, params.blend, params.blend, params.blend);
          gl.blendFunc(gl.CONSTANT_COLOR, gl.ONE_MINUS_CONSTANT_COLOR);
        }
        s.i1('uLayer', y);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
        V.layerReady[y] = true;
      }
      gl.disable(gl.BLEND);
      timer?.end();
      layers += ys.length;
      probes += ys.length * L.nx * L.nz;
    }
    this.lastUpdatedLayers = layers;
    this.lastUpdatedProbes = probes;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  /** Update everything `n` times - used at start-up for fast bounce convergence. */
  warmup(env: Environment, params: GIParams, shadowTex: WebGLTexture, iterations: number) {
    for (let i = 0; i < iterations; i++) this.update(env, { ...params, blend: 1 }, this.layerTotal, shadowTex);
  }

  /** Deferred volume application into the currently bound GI target. */
  applyVolumes(
    viewProj: Mat4, invViewProj: Mat4, planes: Float32Array, w: number, h: number, scale: number,
    timer?: { begin(l: string): void; end(): void },
  ) {
    const gl = this.gl;
    timer?.begin('GI apply');
    gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);
    gl.enable(gl.BLEND);
    gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE);
    gl.enable(gl.SCISSOR_TEST);
    gl.bindVertexArray(this.emptyVao);
    const p = this.apply.use();
    p.m4('uInvViewProj', invViewProj);
    p.i1('uScale', scale);
    const clip = [0, 0, 0, 0];
    for (const V of this.volumes) {
      if (!V.layerReady.every(Boolean) && !V.layerReady.some(Boolean)) continue;
      if (!aabbInFrustum(planes, V.bounds)) continue;
      // screen-space scissor
      let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9, behind = false;
      for (let i = 0; i < 8; i++) {
        const cx = i & 1 ? V.boxMax[0] : V.boxMin[0], cy = i & 2 ? V.boxMax[1] : V.boxMin[1], cz = i & 4 ? V.boxMax[2] : V.boxMin[2];
        mat4.transformPoint4(viewProj, cx, cy, cz, clip);
        if (clip[3] <= 0.05) { behind = true; break; }
        const nx = clip[0] / clip[3], ny = clip[1] / clip[3];
        x0 = Math.min(x0, nx); x1 = Math.max(x1, nx); y0 = Math.min(y0, ny); y1 = Math.max(y1, ny);
      }
      let sx = 0, sy = 0, sw = w, sh = h;
      if (!behind) {
        sx = Math.max(0, Math.floor((x0 * 0.5 + 0.5) * w) - 1);
        sy = Math.max(0, Math.floor((y0 * 0.5 + 0.5) * h) - 1);
        sw = Math.min(w, Math.ceil((x1 * 0.5 + 0.5) * w) + 1) - sx;
        sh = Math.min(h, Math.ceil((y1 * 0.5 + 0.5) * h) + 1) - sy;
        if (sw <= 0 || sh <= 0) continue;
      }
      gl.scissor(sx, sy, sw, sh);
      const d = V.baked.def;
      p.f3('uBoxMin', V.boxMin[0], V.boxMin[1], V.boxMin[2]);
      p.f3('uBoxMax', V.boxMax[0], V.boxMax[1], V.boxMax[2]);
      p.f3('uOrigin', d.origin[0], d.origin[1], d.origin[2]);
      p.f1('uSpacing', d.spacing);
      p.f3('uDims', V.nx, V.ny, V.nz);
      p.f1('uBlend', d.blend);
      p.f1('uNormalBias', Math.min(0.35 * d.spacing, 0.7));
      for (let c = 0; c < 3; c++) bindTex(gl, TU.SH_R + c, gl.TEXTURE_3D, V.sh[c]);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    }
    gl.disable(gl.SCISSOR_TEST);
    gl.disable(gl.BLEND);
    timer?.end();
  }

  /** Debug: draw instanced probe spheres into the currently bound G-buffer. */
  drawProbes(viewProj: Mat4, cam: Vec3, maxDist: number) {
    const gl = this.gl;
    gl.bindVertexArray(this.sphereVao);
    const p = this.probeProg.use();
    p.m4('uViewProj', viewProj);
    p.f3('uCam', cam[0], cam[1], cam[2]);
    p.f1('uMaxDist', maxDist);
    for (let vi = 0; vi < this.volumes.length; vi++) {
      const V = this.volumes[vi];
      const d = V.baked.def;
      const b = V.bounds;
      // skip volumes that are entirely out of range
      const dx = Math.max(b[0] - cam[0], 0, cam[0] - b[3]), dy = Math.max(b[1] - cam[1], 0, cam[1] - b[4]), dz = Math.max(b[2] - cam[2], 0, cam[2] - b[5]);
      if (Math.hypot(dx, dy, dz) > maxDist) continue;
      p.f3('uOrigin', d.origin[0], d.origin[1], d.origin[2]);
      p.f1('uSpacing', d.spacing);
      p.i3('uDims', V.nx, V.ny, V.nz);
      p.i1('uCols', V.layout.cols);
      p.f1('uRadius', Math.min(0.3, d.spacing * 0.09) * (vi === 0 ? 1.3 : 1.0));
      bindTex(gl, TU.OFF, gl.TEXTURE_2D, V.offTex);
      for (let c = 0; c < 3; c++) bindTex(gl, TU.SH_R + c, gl.TEXTURE_3D, V.sh[c]);
      gl.drawElementsInstanced(gl.TRIANGLES, this.sphereCount, gl.UNSIGNED_SHORT, 0, V.baked.probeCount);
    }
    void TILE;
  }
}
