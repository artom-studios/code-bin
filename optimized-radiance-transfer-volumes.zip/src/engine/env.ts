/**
 * Environment state shared by every pass: time of day -> sun/moon, sky, exposure,
 * shadow-map matrix and the packed dynamic light list. `apply()` uploads the common
 * uniform block (see common.glsl) to any program.
 */
import { mat4, smoothstep, vec3, type Vec3 } from './math';
import type { Program } from './gl';
import type { PointLightDef } from './scene';

export const MAX_LIGHTS = 16;

export interface RuntimeLight {
  name: string;
  pos: Vec3;
  color: Vec3;
  radius: number;
  box?: [Vec3, Vec3];
  flicker: number;
  phase: number;
  user: boolean;
}

export class Environment {
  timeOfDay = 15.0;
  sunDir: Vec3 = [0, 1, 0];
  lightDir: Vec3 = [0, 1, 0];
  lightColor: Vec3 = [1, 1, 1];
  dayFactor = 1;
  autoExposure = 1;
  shadowVP = mat4.create();
  shadowBias = 0.00016;
  shadowNBias = 0.07;
  /** World bounds used to fit the single orthographic shadow map. */
  center: Vec3 = [0, 8, 0];
  radius = 148;

  lights: RuntimeLight[] = [];
  lightScale = 30;
  private lightGain = 1;
  private clock = 0;
  private pl = new Float32Array(MAX_LIGHTS * 4);
  private plc = new Float32Array(MAX_LIGHTS * 3);
  private plMin = new Float32Array(MAX_LIGHTS * 3);
  private plMax = new Float32Array(MAX_LIGHTS * 3);
  private count = 0;
  private view = mat4.create();
  private proj = mat4.create();

  constructor(defs: PointLightDef[]) {
    this.lights = defs.map((d, i) => ({ ...d, phase: i * 1.7, user: false }));
    this.setTime(this.timeOfDay);
  }

  setTime(t: number) {
    this.timeOfDay = ((t % 24) + 24) % 24;
    const a = ((this.timeOfDay - 6) / 24) * Math.PI * 2;
    const sun = vec3.normalize([Math.cos(a), 0.85 * Math.sin(a), 0.35]);
    this.sunDir = sun;
    const se = sun[1];
    const sunI = smoothstep(-0.04, 0.12, se) * 3.4;
    const moonI = smoothstep(-0.1, -0.25, se);
    const k = smoothstep(0.0, 0.35, se);
    const sunCol: Vec3 = [1.0 + (1.0 - 1.0) * k, 0.5 + (0.94 - 0.5) * k, 0.22 + (0.84 - 0.22) * k];
    if (se > -0.12) {
      this.lightDir = sun;
      this.lightColor = [sunCol[0] * sunI, sunCol[1] * sunI, sunCol[2] * sunI];
    } else {
      this.lightDir = vec3.normalize([-sun[0], -sun[1], sun[2]]);
      this.lightColor = [0.30 * 0.17 * moonI, 0.40 * 0.17 * moonI, 0.70 * 0.17 * moonI];
    }
    this.dayFactor = smoothstep(-0.18, 0.15, se);
    this.autoExposure = 3.0 + (0.62 - 3.0) * this.dayFactor;
    this.lightGain = 0.12 + 0.88 * (1 - this.dayFactor);
    this.updateShadowMatrix();
  }

  private updateShadowMatrix() {
    const L = this.lightDir, R = this.radius, C = this.center;
    const eye: Vec3 = [C[0] + L[0] * (R + 1), C[1] + L[1] * (R + 1), C[2] + L[2] * (R + 1)];
    const up: Vec3 = Math.abs(L[1]) > 0.99 ? [0, 0, 1] : [0, 1, 0];
    mat4.lookAt(this.view, eye, C, up);
    mat4.ortho(this.proj, -R, R, -R, R, 0.5, 2 * R + 2);
    mat4.multiply(this.shadowVP, this.proj, this.view);
  }

  addUserLight(pos: Vec3, color: Vec3) {
    const users = this.lights.filter((l) => l.user);
    if (this.lights.length >= MAX_LIGHTS) {
      const first = this.lights.findIndex((l) => l.user);
      if (first >= 0) this.lights.splice(first, 1);
    }
    void users;
    this.lights.push({ name: 'user', pos, color, radius: 16, flicker: 0.0, phase: Math.random() * 10, user: true });
  }
  clearUserLights() { this.lights = this.lights.filter((l) => !l.user); }
  get userLightCount() { return this.lights.filter((l) => l.user).length; }

  /** Pack lights (with flicker) into uniform arrays. Call once per frame. */
  tick(dt: number) {
    this.clock += dt;
    let n = 0;
    for (const l of this.lights) {
      if (n >= MAX_LIGHTS) break;
      const f = 1 + l.flicker * (0.5 * Math.sin(this.clock * 9.1 + l.phase) * Math.sin(this.clock * 5.3 + l.phase * 2.0) + 0.25 * Math.sin(this.clock * 23.0 + l.phase * 3.0));
      const g = (l.user ? 1.0 : this.lightGain) * this.lightScale * f;
      this.pl[n * 4] = l.pos[0]; this.pl[n * 4 + 1] = l.pos[1]; this.pl[n * 4 + 2] = l.pos[2]; this.pl[n * 4 + 3] = l.radius;
      this.plc[n * 3] = l.color[0] * g; this.plc[n * 3 + 1] = l.color[1] * g; this.plc[n * 3 + 2] = l.color[2] * g;
      const pad = 0.3;
      for (let a = 0; a < 3; a++) {
        this.plMin[n * 3 + a] = l.box ? l.box[0][a] - pad : -1e5;
        this.plMax[n * 3 + a] = l.box ? l.box[1][a] + pad : 1e5;
      }
      n++;
    }
    this.count = n;
  }

  apply(p: Program) {
    p.f3('uSunDir', this.sunDir[0], this.sunDir[1], this.sunDir[2]);
    p.f3('uLightDir', this.lightDir[0], this.lightDir[1], this.lightDir[2]);
    p.f3('uLightColor', this.lightColor[0], this.lightColor[1], this.lightColor[2]);
    p.m4('uShadowVP', this.shadowVP);
    p.f1('uShadowBias', this.shadowBias);
    p.f1('uShadowNBias', this.shadowNBias);
    p.i1('uNumPL', this.count);
    p.f4v('uPL', this.pl);
    p.f3v('uPLC', this.plc);
    p.f3v('uPLMin', this.plMin);
    p.f3v('uPLMax', this.plMax);
  }
}
