/**
 * `.drtv` exporter - engine-agnostic binary dump of the baked probe surface caches.
 *
 * Layout (little endian):
 *   u32 magic 'DRTV' (0x56545244) | u32 version (1) | u32 headerBytes | header JSON (UTF-8, 4-byte padded)
 *   then, for every volume in header order, the blobs listed in `volumes[i].blobs`
 *   (byte offsets are relative to the start of the binary payload, i.e. after the header).
 *
 * Per volume (probes in linear order  index = ix + nx * (iz + nz * iy) ):
 *   offsets   : float32[probes*4]       relocation xyz (metres), validity (1 = valid)
 *   distance  : float32[probes*64]      hit distance along the sample direction
 *   normal    : int8[probes*64*2]       octahedral hit normal, snorm8
 *   albedo    : uint8[probes*64*4]      sRGB albedo.rgb, a = 255
 *   flags     : uint8[probes*64]        0 = surface, 1 = sky, 2 = back-face / invalid
 * Sample s -> octahedral texel (s % 8, s / 8); direction = octDecode((texel + .5) / 8 * 2 - 1).
 */
import type { BakedVolume } from './bakeService';
import { SAMPLES, TILE } from './bake';
import type { SceneData } from './scene';

export function exportDRTV(baked: BakedVolume[], scene: SceneData): Blob {
  const parts: ArrayBuffer[] = [];
  let cursor = 0;
  const volumesMeta = baked.map((v) => {
    const { nx, ny, nz, cols, texW, offW } = v.layout;
    const n = v.probeCount;
    const offsets = new Float32Array(n * 4);
    const dist = new Float32Array(n * SAMPLES);
    const nrm = new Int8Array(n * SAMPLES * 2);
    const alb = new Uint8Array(n * SAMPLES * 4);
    const flags = new Uint8Array(n * SAMPLES);
    for (let p = 0; p < n; p++) {
      const ix = p % nx, iz = Math.floor(p / nx) % nz, iy = Math.floor(p / (nx * nz));
      const tx = (iy % cols) * nx + ix, ty = Math.floor(iy / cols) * nz + iz;
      for (let k = 0; k < 4; k++) offsets[p * 4 + k] = v.off[(ty * offW + tx) * 4 + k];
      for (let s = 0; s < SAMPLES; s++) {
        const texel = (ty * TILE + Math.floor(s / TILE)) * texW + tx * TILE + (s % TILE);
        const o = p * SAMPLES + s;
        dist[o] = v.geo[texel * 4];
        nrm[o * 2] = Math.round(Math.max(-1, Math.min(1, v.geo[texel * 4 + 1])) * 127);
        nrm[o * 2 + 1] = Math.round(Math.max(-1, Math.min(1, v.geo[texel * 4 + 2])) * 127);
        flags[o] = v.geo[texel * 4 + 3];
        for (let k = 0; k < 4; k++) alb[o * 4 + k] = v.alb[texel * 4 + k];
      }
    }
    const blobs: Record<string, { offset: number; bytes: number; type: string }> = {};
    const add = (name: string, a: ArrayBufferView, type: string) => {
      const buf = a.buffer.slice(a.byteOffset, a.byteOffset + a.byteLength) as ArrayBuffer;
      const padded = new ArrayBuffer(Math.ceil(buf.byteLength / 4) * 4);
      new Uint8Array(padded).set(new Uint8Array(buf));
      blobs[name] = { offset: cursor, bytes: buf.byteLength, type };
      cursor += padded.byteLength;
      parts.push(padded);
    };
    add('offsets', offsets, 'float32x4');
    add('distance', dist, 'float32');
    add('normal', nrm, 'snorm8x2');
    add('albedo', alb, 'unorm8x4');
    add('flags', flags, 'uint8');
    return {
      name: v.def.name, origin: v.def.origin, spacing: v.def.spacing, dims: [nx, ny, nz], maxRay: v.def.maxRay,
      blendMeters: v.def.blend, probes: n, samplesPerProbe: SAMPLES, tile: TILE, invalidProbes: v.invalidProbes, blobs,
    };
  });
  const header = JSON.stringify({
    format: 'DRTV', version: 1,
    description: 'Deferred Radiance Transfer Volumes - baked probe surface caches',
    sceneBounds: scene.bounds,
    sh: { bands: 1, storage: 'E(n)/pi, per channel vec4(c0, cY, cZ, cX)' },
    volumes: volumesMeta,
  });
  const hb = new TextEncoder().encode(header);
  const hpad = new Uint8Array(Math.ceil(hb.length / 4) * 4);
  hpad.set(hb);
  const pre = new Uint32Array([0x56545244, 1, hpad.length]);
  return new Blob([pre, hpad, ...parts], { type: 'application/octet-stream' });
}
