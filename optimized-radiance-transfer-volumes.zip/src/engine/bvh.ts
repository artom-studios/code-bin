/**
 * Compact binned-SAH BVH over a triangle soup, optimised for incoherent closest-hit rays
 * (probe baking). Flat typed arrays only - no per-node objects.
 *
 * Node layout (depth-first):  interior: left = i+1, right = info[2i], count = 0
 *                             leaf:     first = info[2i], count = info[2i+1]
 */
export class BVH {
  private bounds: Float32Array;
  private info: Int32Array;
  private axis: Uint8Array;
  private tv: Float32Array; // v0,e1,e2 per (sorted) triangle
  private triId: Uint32Array;
  private nodeCount = 0;
  private stack = new Int32Array(96);

  // last hit
  hitT = 0;
  hitTri = 0;
  hitU = 0;
  hitV = 0;

  constructor(positions: Float32Array, indices: Uint32Array) {
    const n = indices.length / 3;
    const tb = new Float32Array(n * 6);
    const cen = new Float32Array(n * 3);
    for (let t = 0; t < n; t++) {
      const a = indices[t * 3] * 3, b = indices[t * 3 + 1] * 3, c = indices[t * 3 + 2] * 3;
      for (let k = 0; k < 3; k++) {
        const p0 = positions[a + k], p1 = positions[b + k], p2 = positions[c + k];
        tb[t * 6 + k] = Math.min(p0, p1, p2);
        tb[t * 6 + 3 + k] = Math.max(p0, p1, p2);
        cen[t * 3 + k] = (p0 + p1 + p2) / 3;
      }
    }
    const order = new Uint32Array(n);
    for (let i = 0; i < n; i++) order[i] = i;
    this.bounds = new Float32Array(6 * (2 * n + 1));
    this.info = new Int32Array(2 * (2 * n + 1));
    this.axis = new Uint8Array(2 * n + 1);

    const K = 12;
    const binCnt = new Int32Array(K);
    const binB = new Float32Array(K * 6);
    const lA = new Float32Array(K), lC = new Int32Array(K);
    const area = (x0: number, y0: number, z0: number, x1: number, y1: number, z1: number) => {
      const dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
      return dx < 0 ? 0 : 2 * (dx * dy + dy * dz + dz * dx);
    };

    const build = (start: number, end: number): number => {
      const node = this.nodeCount++;
      let x0 = 1e30, y0 = 1e30, z0 = 1e30, x1 = -1e30, y1 = -1e30, z1 = -1e30;
      let cx0 = 1e30, cy0 = 1e30, cz0 = 1e30, cx1 = -1e30, cy1 = -1e30, cz1 = -1e30;
      for (let i = start; i < end; i++) {
        const t = order[i];
        x0 = Math.min(x0, tb[t * 6]); y0 = Math.min(y0, tb[t * 6 + 1]); z0 = Math.min(z0, tb[t * 6 + 2]);
        x1 = Math.max(x1, tb[t * 6 + 3]); y1 = Math.max(y1, tb[t * 6 + 4]); z1 = Math.max(z1, tb[t * 6 + 5]);
        const cx = cen[t * 3], cy = cen[t * 3 + 1], cz = cen[t * 3 + 2];
        cx0 = Math.min(cx0, cx); cy0 = Math.min(cy0, cy); cz0 = Math.min(cz0, cz);
        cx1 = Math.max(cx1, cx); cy1 = Math.max(cy1, cy); cz1 = Math.max(cz1, cz);
      }
      const B = this.bounds;
      B[node * 6] = x0; B[node * 6 + 1] = y0; B[node * 6 + 2] = z0;
      B[node * 6 + 3] = x1; B[node * 6 + 4] = y1; B[node * 6 + 5] = z1;
      const count = end - start;
      const makeLeaf = () => { this.info[node * 2] = start; this.info[node * 2 + 1] = count; return node; };
      if (count <= 3) return makeLeaf();
      const ex = cx1 - cx0, ey = cy1 - cy0, ez = cz1 - cz0;
      const ax = ex >= ey && ex >= ez ? 0 : ey >= ez ? 1 : 2;
      const cmin = ax === 0 ? cx0 : ax === 1 ? cy0 : cz0;
      const ext = ax === 0 ? ex : ax === 1 ? ey : ez;
      if (ext < 1e-9) return makeLeaf();

      binCnt.fill(0);
      for (let k = 0; k < K; k++) { binB[k * 6] = binB[k * 6 + 1] = binB[k * 6 + 2] = 1e30; binB[k * 6 + 3] = binB[k * 6 + 4] = binB[k * 6 + 5] = -1e30; }
      const scale = K / ext;
      for (let i = start; i < end; i++) {
        const t = order[i];
        const b = Math.min(K - 1, Math.floor((cen[t * 3 + ax] - cmin) * scale));
        binCnt[b]++;
        for (let k = 0; k < 3; k++) {
          binB[b * 6 + k] = Math.min(binB[b * 6 + k], tb[t * 6 + k]);
          binB[b * 6 + 3 + k] = Math.max(binB[b * 6 + 3 + k], tb[t * 6 + 3 + k]);
        }
      }
      // left sweep
      let ax0 = 1e30, ay0 = 1e30, az0 = 1e30, ax1 = -1e30, ay1 = -1e30, az1 = -1e30, c = 0;
      for (let k = 0; k < K - 1; k++) {
        c += binCnt[k];
        if (binCnt[k]) {
          ax0 = Math.min(ax0, binB[k * 6]); ay0 = Math.min(ay0, binB[k * 6 + 1]); az0 = Math.min(az0, binB[k * 6 + 2]);
          ax1 = Math.max(ax1, binB[k * 6 + 3]); ay1 = Math.max(ay1, binB[k * 6 + 4]); az1 = Math.max(az1, binB[k * 6 + 5]);
        }
        lC[k] = c; lA[k] = area(ax0, ay0, az0, ax1, ay1, az1);
      }
      ax0 = 1e30; ay0 = 1e30; az0 = 1e30; ax1 = -1e30; ay1 = -1e30; az1 = -1e30; c = 0;
      let best = 1e30, bestK = -1;
      for (let k = K - 1; k >= 1; k--) {
        c += binCnt[k];
        if (binCnt[k]) {
          ax0 = Math.min(ax0, binB[k * 6]); ay0 = Math.min(ay0, binB[k * 6 + 1]); az0 = Math.min(az0, binB[k * 6 + 2]);
          ax1 = Math.max(ax1, binB[k * 6 + 3]); ay1 = Math.max(ay1, binB[k * 6 + 4]); az1 = Math.max(az1, binB[k * 6 + 5]);
        }
        const cost = lC[k - 1] * lA[k - 1] + c * area(ax0, ay0, az0, ax1, ay1, az1);
        if (lC[k - 1] > 0 && c > 0 && cost < best) { best = cost; bestK = k - 1; }
      }
      const pa = area(x0, y0, z0, x1, y1, z1);
      if (bestK < 0 || (count <= 8 && 1 + best / pa >= count)) {
        if (bestK < 0 && count > 8) { /* fall through to median split */ } else return makeLeaf();
      }
      let i = start, j = end - 1;
      if (bestK >= 0) {
        while (i <= j) {
          const t = order[i];
          const b = Math.min(K - 1, Math.floor((cen[t * 3 + ax] - cmin) * scale));
          if (b <= bestK) i++;
          else { order[i] = order[j]; order[j] = t; j--; }
        }
      }
      let mid = bestK >= 0 ? i : (start + end) >> 1;
      if (mid === start || mid === end) mid = (start + end) >> 1;
      this.axis[node] = ax;
      build(start, mid);
      const right = build(mid, end);
      this.info[node * 2] = right;
      this.info[node * 2 + 1] = 0;
      return node;
    };
    build(0, n);

    this.tv = new Float32Array(n * 9);
    this.triId = order;
    for (let s = 0; s < n; s++) {
      const t = order[s];
      const a = indices[t * 3] * 3, b = indices[t * 3 + 1] * 3, c = indices[t * 3 + 2] * 3;
      for (let k = 0; k < 3; k++) {
        const v0 = positions[a + k];
        this.tv[s * 9 + k] = v0;
        this.tv[s * 9 + 3 + k] = positions[b + k] - v0;
        this.tv[s * 9 + 6 + k] = positions[c + k] - v0;
      }
    }
  }

  /** Closest hit along (o, d); d need not be normalised but hitT is in units of d. */
  intersect(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, tMax: number): boolean {
    if (Math.abs(dx) < 1e-12) dx = 1e-12;
    if (Math.abs(dy) < 1e-12) dy = 1e-12;
    if (Math.abs(dz) < 1e-12) dz = 1e-12;
    const ix = 1 / dx, iy = 1 / dy, iz = 1 / dz;
    const B = this.bounds, info = this.info, tv = this.tv, stack = this.stack, axis = this.axis;
    const dir = [dx, dy, dz];
    let sp = 0;
    stack[sp++] = 0;
    let best = tMax, found = false;
    while (sp > 0) {
      const ni = stack[--sp];
      const bo = ni * 6;
      let t1 = (B[bo] - ox) * ix, t2 = (B[bo + 3] - ox) * ix;
      let tmin = t1 < t2 ? t1 : t2, tmax = t1 < t2 ? t2 : t1;
      t1 = (B[bo + 1] - oy) * iy; t2 = (B[bo + 4] - oy) * iy;
      tmin = Math.max(tmin, t1 < t2 ? t1 : t2); tmax = Math.min(tmax, t1 < t2 ? t2 : t1);
      t1 = (B[bo + 2] - oz) * iz; t2 = (B[bo + 5] - oz) * iz;
      tmin = Math.max(tmin, t1 < t2 ? t1 : t2); tmax = Math.min(tmax, t1 < t2 ? t2 : t1);
      if (tmax < 0 || tmin > tmax || tmin > best) continue;
      const cnt = info[ni * 2 + 1];
      if (cnt > 0) {
        const first = info[ni * 2];
        for (let s = first; s < first + cnt; s++) {
          const o = s * 9;
          const e1x = tv[o + 3], e1y = tv[o + 4], e1z = tv[o + 5], e2x = tv[o + 6], e2y = tv[o + 7], e2z = tv[o + 8];
          const px = dy * e2z - dz * e2y, py = dz * e2x - dx * e2z, pz = dx * e2y - dy * e2x;
          const det = e1x * px + e1y * py + e1z * pz;
          if (det > -1e-12 && det < 1e-12) continue;
          const inv = 1 / det;
          const tx = ox - tv[o], ty = oy - tv[o + 1], tz = oz - tv[o + 2];
          const u = (tx * px + ty * py + tz * pz) * inv;
          if (u < 0 || u > 1) continue;
          const qx = ty * e1z - tz * e1y, qy = tz * e1x - tx * e1z, qz = tx * e1y - ty * e1x;
          const v = (dx * qx + dy * qy + dz * qz) * inv;
          if (v < 0 || u + v > 1) continue;
          const t = (e2x * qx + e2y * qy + e2z * qz) * inv;
          if (t > 1e-4 && t < best) { best = t; found = true; this.hitTri = this.triId[s]; this.hitU = u; this.hitV = v; }
        }
      } else {
        const left = ni + 1, right = info[ni * 2];
        if (dir[axis[ni]] > 0) { stack[sp++] = right; stack[sp++] = left; }
        else { stack[sp++] = left; stack[sp++] = right; }
      }
    }
    this.hitT = best;
    return found;
  }
}
