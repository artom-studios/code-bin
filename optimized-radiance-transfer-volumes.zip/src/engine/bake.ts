/**
 * Offline stage of Deferred Radiance Transfer Volumes.
 *
 * For every probe we capture a low-resolution "surface cache" of its surroundings: an 8x8
 * octahedral map of ray hits. Each texel stores the HIT SURFACE (distance, normal, albedo,
 * sky/back-face flag) - NOT lighting. All lighting (sun, sky, local lights, multi-bounce) is
 * evaluated at runtime on the GPU by relighting those surface samples ("deferred" transfer).
 *
 * The same code runs on a Worker pool (production path) or the main thread (fallback).
 */
import { BVH } from './bvh';
import { octDecode, octEncode } from './math';

export const TILE = 8;
export const SAMPLES = TILE * TILE;
/** flags stored in geo.a */
export const FLAG_SURFACE = 0, FLAG_SKY = 1, FLAG_INVALID = 2;

export interface BakeGeometry {
  positions: Float32Array;
  indices: Uint32Array;
  normals: Int8Array; // 4 per vertex
  colors: Uint8Array; // 4 per vertex (albedo.rgb, material)
}

export interface BakeVolumeParams {
  origin: [number, number, number];
  spacing: number;
  dims: [number, number, number];
  maxRay: number;
}

export interface BakeChunk {
  geo: Float32Array; // 4 floats / sample : hitDistance, octNormal.x, octNormal.y, flag
  alb: Uint8Array; // 4 bytes / sample : albedo rgb (gamma), unused
  off: Float32Array; // 4 floats / probe : relocation offset xyz, validity
}

/** 2D atlas layout of a volume's probe tiles (shared by baker, uploader and shaders). */
export function volumeLayout(dims: [number, number, number], maxTex = 4096) {
  const [nx, ny, nz] = dims;
  const layerW = nx * TILE, layerH = nz * TILE;
  const cols = Math.max(1, Math.min(ny, Math.floor(maxTex / layerW)));
  const rows = Math.ceil(ny / cols);
  return { nx, ny, nz, cols, rows, layerW, layerH, texW: cols * layerW, texH: rows * layerH, offW: cols * nx, offH: rows * nz };
}

let DIRS: Float32Array | null = null;
export function sampleDirections(): Float32Array {
  if (DIRS) return DIRS;
  DIRS = new Float32Array(SAMPLES * 3);
  const d: [number, number, number] = [0, 0, 0];
  for (let s = 0; s < SAMPLES; s++) {
    const sx = s % TILE, sy = Math.floor(s / TILE);
    octDecode(((sx + 0.5) / TILE) * 2 - 1, ((sy + 0.5) / TILE) * 2 - 1, d);
    DIRS[s * 3] = d[0]; DIRS[s * 3 + 1] = d[1]; DIRS[s * 3 + 2] = d[2];
  }
  return DIRS;
}

const MIN_SURFACE_DIST = 0.18;

export function bakeProbes(bvh: BVH, g: BakeGeometry, v: BakeVolumeParams, start: number, end: number): BakeChunk {
  const dirs = sampleDirections();
  const [nx, , nz] = v.dims;
  const count = end - start;
  const geo = new Float32Array(count * SAMPLES * 4);
  const alb = new Uint8Array(count * SAMPLES * 4);
  const off = new Float32Array(count * 4);

  const dist = new Float32Array(SAMPLES);
  const kind = new Uint8Array(SAMPLES); // 0 front, 1 sky, 2 back
  const tri = new Int32Array(SAMPLES);
  const bu = new Float32Array(SAMPLES), bv = new Float32Array(SAMPLES);

  const traceAll = (px: number, py: number, pz: number) => {
    for (let s = 0; s < SAMPLES; s++) {
      const dx = dirs[s * 3], dy = dirs[s * 3 + 1], dz = dirs[s * 3 + 2];
      if (bvh.intersect(px, py, pz, dx, dy, dz, v.maxRay)) {
        const i0 = g.indices[bvh.hitTri * 3], i1 = g.indices[bvh.hitTri * 3 + 1], i2 = g.indices[bvh.hitTri * 3 + 2];
        const P = g.positions;
        const e1x = P[i1 * 3] - P[i0 * 3], e1y = P[i1 * 3 + 1] - P[i0 * 3 + 1], e1z = P[i1 * 3 + 2] - P[i0 * 3 + 2];
        const e2x = P[i2 * 3] - P[i0 * 3], e2y = P[i2 * 3 + 1] - P[i0 * 3 + 1], e2z = P[i2 * 3 + 2] - P[i0 * 3 + 2];
        const gx = e1y * e2z - e1z * e2y, gy = e1z * e2x - e1x * e2z, gz = e1x * e2y - e1y * e2x;
        kind[s] = gx * dx + gy * dy + gz * dz > 0 ? 2 : 0;
        dist[s] = bvh.hitT; tri[s] = bvh.hitTri; bu[s] = bvh.hitU; bv[s] = bvh.hitV;
      } else { kind[s] = 1; dist[s] = v.maxRay; tri[s] = -1; }
    }
  };

  for (let p = 0; p < count; p++) {
    const lin = start + p;
    const ix = lin % nx;
    const iz = Math.floor(lin / nx) % nz;
    const iy = Math.floor(lin / (nx * nz));
    const gx0 = v.origin[0] + ix * v.spacing, gy0 = v.origin[1] + iy * v.spacing, gz0 = v.origin[2] + iz * v.spacing;
    let px = gx0, py = gy0, pz = gz0;

    // --- probe relocation (move probes out of solid geometry / away from surfaces) ---
    const maxMove = v.spacing * 2;
    for (let iter = 0; iter < 5; iter++) {
      traceAll(px, py, pz);
      let backs = 0, bd = 1e30, bi = -1, fd = 1e30, fi = -1;
      for (let s = 0; s < SAMPLES; s++) {
        if (kind[s] === 2) { backs++; if (dist[s] < bd) { bd = dist[s]; bi = s; } }
        else if (kind[s] === 0 && dist[s] < fd) { fd = dist[s]; fi = s; }
      }
      let moved = false;
      if (backs >= SAMPLES / 8) {
        px += dirs[bi * 3] * (bd + 0.2); py += dirs[bi * 3 + 1] * (bd + 0.2); pz += dirs[bi * 3 + 2] * (bd + 0.2);
        moved = true;
      } else if (fi >= 0 && fd < MIN_SURFACE_DIST) {
        const push = MIN_SURFACE_DIST - fd;
        px -= dirs[fi * 3] * push; py -= dirs[fi * 3 + 1] * push; pz -= dirs[fi * 3 + 2] * push;
        moved = true;
      }
      const mx = px - gx0, my = py - gy0, mz = pz - gz0;
      if (Math.hypot(mx, my, mz) > maxMove) { px = gx0; py = gy0; pz = gz0; traceAll(px, py, pz); break; }
      if (!moved) break;
      if (iter === 4) traceAll(px, py, pz);
    }

    let backs = 0;
    for (let s = 0; s < SAMPLES; s++) if (kind[s] === 2) backs++;
    const invalid = backs > SAMPLES / 2;
    off[p * 4] = px - gx0; off[p * 4 + 1] = py - gy0; off[p * 4 + 2] = pz - gz0; off[p * 4 + 3] = invalid ? 0 : 1;

    for (let s = 0; s < SAMPLES; s++) {
      const o = (p * SAMPLES + s) * 4;
      const k = kind[s];
      if (k === 1) { geo[o] = v.maxRay; geo[o + 3] = FLAG_SKY; continue; }
      if (k === 2) { geo[o] = dist[s]; geo[o + 3] = FLAG_INVALID; continue; }
      const t = tri[s];
      const i0 = g.indices[t * 3], i1 = g.indices[t * 3 + 1], i2 = g.indices[t * 3 + 2];
      const w1 = bu[s], w2 = bv[s], w0 = 1 - w1 - w2;
      let nxx = 0, nyy = 0, nzz = 0, r = 0, gg = 0, b = 0;
      const ids = [i0, i1, i2], ws = [w0, w1, w2];
      for (let q = 0; q < 3; q++) {
        const id = ids[q], w = ws[q];
        nxx += (g.normals[id * 4] / 127) * w; nyy += (g.normals[id * 4 + 1] / 127) * w; nzz += (g.normals[id * 4 + 2] / 127) * w;
        r += g.colors[id * 4] * w; gg += g.colors[id * 4 + 1] * w; b += g.colors[id * 4 + 2] * w;
      }
      const l = Math.hypot(nxx, nyy, nzz) || 1;
      nxx /= l; nyy /= l; nzz /= l;
      if (nxx * dirs[s * 3] + nyy * dirs[s * 3 + 1] + nzz * dirs[s * 3 + 2] > 0) { nxx = -nxx; nyy = -nyy; nzz = -nzz; }
      const e = octEncode(nxx, nyy, nzz);
      geo[o] = dist[s]; geo[o + 1] = e[0]; geo[o + 2] = e[1]; geo[o + 3] = invalid ? FLAG_INVALID : FLAG_SURFACE;
      alb[o] = Math.round(r); alb[o + 1] = Math.round(gg); alb[o + 2] = Math.round(b); alb[o + 3] = 255;
    }
  }
  return { geo, alb, off };
}
