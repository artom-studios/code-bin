/**
 * Camera: free-fly (WASD / QE / drag-look) and an automatic cinematic tour driven by a
 * closed Catmull-Rom spline through the scene's waypoints.
 */
import { mat4, vec3, clamp, type Mat4, type Vec3 } from './math';

function catmull(p0: Vec3, p1: Vec3, p2: Vec3, p3: Vec3, t: number): Vec3 {
  const t2 = t * t, t3 = t2 * t;
  const f = (a: number, b: number, c: number, d: number) =>
    0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
  return [f(p0[0], p1[0], p2[0], p3[0]), f(p0[1], p1[1], p2[1], p3[1]), f(p0[2], p1[2], p2[2], p3[2])];
}

export class Camera {
  pos: Vec3 = [0, 10, 40];
  yaw = 0;
  pitch = 0;
  fov = (62 * Math.PI) / 180;
  near = 0.3;
  far = 400;
  aspect = 16 / 9;
  speed = 14;
  mode: 'tour' | 'free' = 'tour';
  tourSpeed = 7.5;

  view = mat4.create();
  proj = mat4.create();
  viewProj = mat4.create();
  invViewProj = mat4.create();

  private keys = new Set<string>();
  private tour: { pos: Vec3; target: Vec3 }[] = [];
  private u = 0;
  private dragging = false;
  private lastX = 0;
  private lastY = 0;
  private smoothPos: Vec3 = [0, 0, 0];
  private smoothTarget: Vec3 = [0, 0, 0];
  private tourInit = false;

  constructor(private el: HTMLElement) {
    window.addEventListener('keydown', this.onKey);
    window.addEventListener('keyup', this.onKeyUp);
    el.addEventListener('pointerdown', this.onDown);
    window.addEventListener('pointermove', this.onMove);
    window.addEventListener('pointerup', this.onUp);
    el.addEventListener('wheel', this.onWheel, { passive: true });
    window.addEventListener('blur', () => this.keys.clear());
  }

  setTour(t: { pos: Vec3; target: Vec3 }[]) {
    this.tour = t;
    this.u = 0;
    this.tourInit = false;
  }

  dispose() {
    window.removeEventListener('keydown', this.onKey);
    window.removeEventListener('keyup', this.onKeyUp);
    this.el.removeEventListener('pointerdown', this.onDown);
    window.removeEventListener('pointermove', this.onMove);
    window.removeEventListener('pointerup', this.onUp);
    this.el.removeEventListener('wheel', this.onWheel);
  }

  startTour() { this.mode = 'tour'; this.tourInit = false; }

  private takeControl() {
    if (this.mode === 'tour') {
      // keep current orientation when handing over
      const fx = this.smoothTarget[0] - this.smoothPos[0], fy = this.smoothTarget[1] - this.smoothPos[1], fz = this.smoothTarget[2] - this.smoothPos[2];
      this.yaw = Math.atan2(fx, -fz);
      this.pitch = Math.atan2(fy, Math.hypot(fx, fz));
      this.mode = 'free';
    }
  }

  private onKey = (e: KeyboardEvent) => {
    if ((e.target as HTMLElement)?.tagName === 'INPUT' && (e.target as HTMLInputElement).type === 'text') return;
    const k = e.key.toLowerCase();
    if (['w', 'a', 's', 'd', 'q', 'e', 'shift', ' ', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(k)) {
      if ((e.target as HTMLElement)?.tagName === 'INPUT' && k.startsWith('arrow')) return;
      this.keys.add(k);
      if (['w', 'a', 's', 'd', 'q', 'e', ' '].includes(k)) this.takeControl();
    }
  };
  private onKeyUp = (e: KeyboardEvent) => { this.keys.delete(e.key.toLowerCase()); };
  private onDown = (e: PointerEvent) => {
    this.dragging = true; this.lastX = e.clientX; this.lastY = e.clientY;
    try { this.el.setPointerCapture(e.pointerId); } catch { /* ignore */ }
  };
  private onMove = (e: PointerEvent) => {
    if (!this.dragging) return;
    const dx = e.clientX - this.lastX, dy = e.clientY - this.lastY;
    this.lastX = e.clientX; this.lastY = e.clientY;
    if (Math.abs(dx) + Math.abs(dy) > 0) this.takeControl();
    if (this.mode !== 'free') return;
    this.yaw += dx * 0.0032;
    this.pitch = clamp(this.pitch - dy * 0.0032, -1.5, 1.5);
  };
  private onUp = () => { this.dragging = false; };
  private onWheel = (e: WheelEvent) => {
    this.speed = clamp(this.speed * (e.deltaY < 0 ? 1.15 : 1 / 1.15), 2, 80);
  };

  update(dt: number, aspect: number) {
    this.aspect = aspect;
    if (this.mode === 'tour' && this.tour.length > 3) {
      const n = this.tour.length;
      const i = Math.floor(this.u) % n, f = this.u - Math.floor(this.u);
      const g = (k: number) => this.tour[((i + k) % n + n) % n];
      const P = catmull(g(-1).pos, g(0).pos, g(1).pos, g(2).pos, f);
      const T = catmull(g(-1).target, g(0).target, g(1).target, g(2).target, f);
      const segLen = Math.max(4, vec3.len(vec3.sub(g(1).pos, g(0).pos)));
      this.u += (this.tourSpeed * dt) / segLen;
      if (!this.tourInit) { this.smoothPos = P; this.smoothTarget = T; this.tourInit = true; }
      const k = 1 - Math.exp(-dt * 6);
      this.smoothPos = vec3.lerp(this.smoothPos, P, k);
      this.smoothTarget = vec3.lerp(this.smoothTarget, T, k);
      this.pos = this.smoothPos;
      mat4.lookAt(this.view, this.pos, this.smoothTarget, [0, 1, 0]);
    } else {
      const fwd: Vec3 = [Math.sin(this.yaw) * Math.cos(this.pitch), Math.sin(this.pitch), -Math.cos(this.yaw) * Math.cos(this.pitch)];
      const right: Vec3 = [Math.cos(this.yaw), 0, Math.sin(this.yaw)];
      const sp = this.speed * (this.keys.has('shift') ? 3 : 1) * dt;
      const mv: Vec3 = [0, 0, 0];
      const add = (v: Vec3, s: number) => { mv[0] += v[0] * s; mv[1] += v[1] * s; mv[2] += v[2] * s; };
      if (this.keys.has('w') || this.keys.has('arrowup')) add(fwd, 1);
      if (this.keys.has('s') || this.keys.has('arrowdown')) add(fwd, -1);
      if (this.keys.has('d') || this.keys.has('arrowright')) add(right, 1);
      if (this.keys.has('a') || this.keys.has('arrowleft')) add(right, -1);
      if (this.keys.has('e') || this.keys.has(' ')) mv[1] += 1;
      if (this.keys.has('q')) mv[1] -= 1;
      this.pos = [this.pos[0] + mv[0] * sp, this.pos[1] + mv[1] * sp, this.pos[2] + mv[2] * sp];
      this.smoothPos = this.pos;
      this.smoothTarget = vec3.add(this.pos, fwd);
      mat4.lookAt(this.view, this.pos, this.smoothTarget, [0, 1, 0]);
    }
    mat4.perspective(this.proj, this.fov, this.aspect, this.near, this.far);
    mat4.multiply(this.viewProj, this.proj, this.view);
    mat4.invert(this.invViewProj, this.viewProj);
  }

  get viewProjMatrix(): Mat4 { return this.viewProj; }
}
