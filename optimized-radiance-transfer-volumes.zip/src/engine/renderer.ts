/**
 * Frame graph:
 *   Shadow (world-covering ortho, only when the light moves)
 *   -> DRTV update  (relight + SH project, time-sliced)
 *   -> G-buffer     (albedo RGBA8, oct-normal RGB10_A2, depth24)
 *   -> SSAO (half)  -> DRTV volume apply (half)
 *   -> Deferred lighting (HDR RGBA16F)
 *   -> Bloom pyramid -> Tonemap -> FXAA -> canvas
 */
import { Program, TU, GpuTimer, bindTex, createFbo, createTex2D } from './gl';
import { aabbInFrustum, extractFrustumPlanes, mat4 } from './math';
import type { Camera } from './camera';
import type { Environment } from './env';
import { GISystem } from './gi';
import type { BakedVolume } from './bakeService';
import { VERTEX_STRIDE, type SceneData } from './scene';

import COMMON from './shaders/common.glsl?raw';
import FULLSCREEN_VS from './shaders/fullscreen_vs.glsl?raw';
import GBUFFER_VS from './shaders/gbuffer_vs.glsl?raw';
import GBUFFER_FS from './shaders/gbuffer_fs.glsl?raw';
import SHADOW_VS from './shaders/shadow_vs.glsl?raw';
import SHADOW_FS from './shaders/shadow_fs.glsl?raw';
import SSAO_FS from './shaders/ssao_fs.glsl?raw';
import LIGHT_FS from './shaders/light_fs.glsl?raw';
import BLOOM_FS from './shaders/bloom_fs.glsl?raw';
import TONEMAP_FS from './shaders/tonemap_fs.glsl?raw';
import FXAA_FS from './shaders/fxaa_fs.glsl?raw';

export interface Settings {
  giEnabled: boolean;
  giIntensity: number;
  bounce: number;
  blend: number;
  /** probe layers updated per frame (0 = all) */
  budget: number;
  giHalfRes: boolean;
  aoStrength: number;
  aoRadius: number;
  view: number;
  exposure: number;
  bloom: number;
  fog: number;
  fxaa: boolean;
  showProbes: boolean;
  probeRange: number;
  renderScale: number;
}

export const defaultSettings: Settings = {
  giEnabled: true, giIntensity: 1.0, bounce: 0.9, blend: 0.4, budget: 6, giHalfRes: true,
  aoStrength: 0.8, aoRadius: 1.4, view: 0, exposure: 1.0, bloom: 0.06, fog: 0.0012, fxaa: true,
  showProbes: false, probeRange: 28, renderScale: 1.0,
};

export interface FrameStats {
  cpuMs: number; drawCalls: number; triangles: number; chunksVisible: number; chunksTotal: number;
  layersUpdated: number; probesUpdated: number; gpu: Record<string, number>; gpuTimers: boolean;
  giMB: number; width: number; height: number;
}

interface Target { tex: WebGLTexture; fbo: WebGLFramebuffer; w: number; h: number }

export class Renderer {
  readonly gl: WebGL2RenderingContext;
  readonly gi: GISystem;
  readonly timer: GpuTimer;
  readonly stats: FrameStats;

  private shadowTex!: WebGLTexture;
  private shadowFbo!: WebGLFramebuffer;
  private readonly shadowSize = 4096;
  private lastLight: [number, number, number] = [9, 9, 9];

  private sceneVao: WebGLVertexArrayObject;
  private shadowVao: WebGLVertexArrayObject;
  private emptyVao: WebGLVertexArrayObject;

  private pShadow: Program; private pGBuf: Program; private pSSAO: Program; private pLight: Program;
  private pBloom: Program; private pTone: Program; private pFXAA: Program;

  private gAlb!: WebGLTexture; private gNrm!: WebGLTexture; private gDepth!: WebGLTexture; private gFbo!: WebGLFramebuffer;
  private giT!: Target; private aoT!: Target; private hdrT!: Target; private ldrT!: Target;
  private bloomT: Target[] = [];
  private targetsKey = '';
  private planes = new Float32Array(24);
  private lightPlanes = new Float32Array(24);

  constructor(private canvas: HTMLCanvasElement, private scene: SceneData, baked: BakedVolume[], private env: Environment) {
    const gl = canvas.getContext('webgl2', { antialias: false, alpha: false, depth: false, stencil: false, powerPreference: 'high-performance' });
    if (!gl) throw new Error('WebGL2 is required.');
    if (!gl.getExtension('EXT_color_buffer_float')) throw new Error('EXT_color_buffer_float is required (float render targets).');
    gl.getExtension('OES_texture_float_linear');
    this.gl = gl;
    this.timer = new GpuTimer(gl);

    // ---- static geometry
    const vb = gl.createBuffer()!;
    gl.bindBuffer(gl.ARRAY_BUFFER, vb);
    gl.bufferData(gl.ARRAY_BUFFER, scene.interleaved, gl.STATIC_DRAW);
    const ib = gl.createBuffer()!;
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, scene.indices, gl.STATIC_DRAW);

    this.sceneVao = gl.createVertexArray()!;
    gl.bindVertexArray(this.sceneVao);
    gl.bindBuffer(gl.ARRAY_BUFFER, vb);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, VERTEX_STRIDE, 0);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 4, gl.BYTE, true, VERTEX_STRIDE, 12);
    gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 4, gl.UNSIGNED_BYTE, true, VERTEX_STRIDE, 16);

    this.shadowVao = gl.createVertexArray()!;
    gl.bindVertexArray(this.shadowVao);
    gl.bindBuffer(gl.ARRAY_BUFFER, vb);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, VERTEX_STRIDE, 0);
    gl.bindVertexArray(null);
    this.emptyVao = gl.createVertexArray()!;

    // ---- programs
    this.pShadow = new Program(gl, 'shadow', SHADOW_VS, SHADOW_FS, { aPos: 0 });
    this.pGBuf = new Program(gl, 'gbuffer', GBUFFER_VS, COMMON + GBUFFER_FS, { aPos: 0, aNrm: 1, aCol: 2 });
    this.pSSAO = new Program(gl, 'ssao', FULLSCREEN_VS, COMMON + SSAO_FS).samplers({ uDepth: TU.DEPTH, uGBNrm: TU.GB_NRM });
    this.pLight = new Program(gl, 'light', FULLSCREEN_VS, COMMON + LIGHT_FS).samplers({
      uDepth: TU.DEPTH, uGBAlb: TU.GB_ALB, uGBNrm: TU.GB_NRM, uGI: TU.GI, uAO: TU.AO, uShadow: TU.SHADOW,
    });
    this.pBloom = new Program(gl, 'bloom', FULLSCREEN_VS, BLOOM_FS).samplers({ uSrc: 0 });
    this.pTone = new Program(gl, 'tonemap', FULLSCREEN_VS, TONEMAP_FS).samplers({ uHdr: 0, uB0: 1, uB1: 2, uB2: 3, uB3: 4, uB4: 5 });
    this.pFXAA = new Program(gl, 'fxaa', FULLSCREEN_VS, FXAA_FS).samplers({ uLdr: 0 });

    // ---- shadow map
    this.shadowTex = gl.createTexture()!;
    gl.bindTexture(gl.TEXTURE_2D, this.shadowTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.DEPTH_COMPONENT24, this.shadowSize, this.shadowSize, 0, gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_FUNC, gl.LEQUAL);
    this.shadowFbo = createFbo(gl, 'shadow', [], this.shadowTex);

    this.gi = new GISystem(gl, baked);
    this.stats = {
      cpuMs: 0, drawCalls: 0, triangles: 0, chunksVisible: 0, chunksTotal: scene.chunks.length, layersUpdated: 0, probesUpdated: 0,
      gpu: {}, gpuTimers: this.timer.supported, giMB: this.gi.gpuBytes / 1048576, width: 0, height: 0,
    };
  }

  /** Initial lighting convergence: several full updates so bounces settle before the first frame. */
  warmup(s: Settings, iterations = 6) {
    this.renderShadow(true);
    this.env.tick(0);
    this.gi.warmup(this.env, { bounce: s.bounce, blend: 1 }, this.shadowTex, iterations);
  }

  resetGI() { for (const v of this.gi.volumes) v.layerReady.fill(false); }

  private makeTarget(w: number, h: number, internal: number, format: number, type: number, filter: number): Target {
    const gl = this.gl;
    const tex = createTex2D(gl, w, h, { internal, format, type, filter });
    const fbo = createFbo(gl, 'target', [tex]);
    return { tex, fbo, w, h };
  }
  private freeTarget(t?: Target) { if (t) { this.gl.deleteTexture(t.tex); this.gl.deleteFramebuffer(t.fbo); } }

  private ensureTargets(w: number, h: number, scale: number) {
    const key = `${w}x${h}x${scale}`;
    if (key === this.targetsKey) return;
    this.targetsKey = key;
    const gl = this.gl;
    if (this.gAlb) { gl.deleteTexture(this.gAlb); gl.deleteTexture(this.gNrm); gl.deleteTexture(this.gDepth); gl.deleteFramebuffer(this.gFbo); }
    this.gAlb = createTex2D(gl, w, h, { internal: gl.RGBA8, format: gl.RGBA, type: gl.UNSIGNED_BYTE });
    this.gNrm = createTex2D(gl, w, h, { internal: gl.RGB10_A2, format: gl.RGBA, type: gl.UNSIGNED_INT_2_10_10_10_REV });
    this.gDepth = createTex2D(gl, w, h, { internal: gl.DEPTH_COMPONENT24, format: gl.DEPTH_COMPONENT, type: gl.UNSIGNED_INT });
    this.gFbo = createFbo(gl, 'gbuffer', [this.gAlb, this.gNrm], this.gDepth);

    const gw = Math.ceil(w / scale), gh = Math.ceil(h / scale);
    this.freeTarget(this.giT); this.freeTarget(this.aoT); this.freeTarget(this.hdrT); this.freeTarget(this.ldrT);
    this.bloomT.forEach((b) => this.freeTarget(b));
    this.giT = this.makeTarget(gw, gh, gl.RGBA16F, gl.RGBA, gl.HALF_FLOAT, gl.NEAREST);
    this.aoT = this.makeTarget(gw, gh, gl.R8, gl.RED, gl.UNSIGNED_BYTE, gl.NEAREST);
    this.hdrT = this.makeTarget(w, h, gl.RGBA16F, gl.RGBA, gl.HALF_FLOAT, gl.LINEAR);
    this.ldrT = this.makeTarget(w, h, gl.RGBA8, gl.RGBA, gl.UNSIGNED_BYTE, gl.LINEAR);
    this.bloomT = [];
    let bw = w, bh = h;
    for (let i = 0; i < 5; i++) {
      bw = Math.max(1, bw >> 1); bh = Math.max(1, bh >> 1);
      this.bloomT.push(this.makeTarget(bw, bh, gl.RGBA16F, gl.RGBA, gl.HALF_FLOAT, gl.LINEAR));
    }
    this.stats.width = w; this.stats.height = h;
  }

  private drawChunks(planes: Float32Array): number {
    const gl = this.gl;
    let vis = 0, tris = 0;
    for (const c of this.scene.chunks) {
      if (!aabbInFrustum(planes, c.bounds)) continue;
      gl.drawElements(gl.TRIANGLES, c.count, gl.UNSIGNED_INT, c.first * 4);
      vis++; tris += c.count / 3;
    }
    this.stats.drawCalls += vis;
    this.stats.triangles += tris;
    return vis;
  }

  private renderShadow(force: boolean) {
    const L = this.env.lightDir;
    const d = Math.abs(L[0] - this.lastLight[0]) + Math.abs(L[1] - this.lastLight[1]) + Math.abs(L[2] - this.lastLight[2]);
    if (!force && d < 1e-5) return;
    this.lastLight = [L[0], L[1], L[2]];
    const gl = this.gl;
    this.timer.begin('Shadow map');
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.shadowFbo);
    gl.viewport(0, 0, this.shadowSize, this.shadowSize);
    gl.disable(gl.BLEND); gl.disable(gl.CULL_FACE); gl.disable(gl.SCISSOR_TEST);
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LESS); gl.depthMask(true);
    gl.clearDepth(1.0);
    gl.clear(gl.DEPTH_BUFFER_BIT);
    this.pShadow.use().m4('uLightVP', this.env.shadowVP);
    gl.bindVertexArray(this.shadowVao);
    extractFrustumPlanes(this.env.shadowVP, this.lightPlanes);
    this.drawChunks(this.lightPlanes);
    this.timer.end();
  }

  render(cam: Camera, dt: number, s: Settings) {
    const t0 = performance.now();
    const gl = this.gl;
    const st = this.stats;
    st.drawCalls = 0; st.triangles = 0;
    this.timer.poll();

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(64, Math.floor(this.canvas.clientWidth * dpr * s.renderScale));
    const h = Math.max(64, Math.floor(this.canvas.clientHeight * dpr * s.renderScale));
    if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; }
    const scale = s.giHalfRes ? 2 : 1;
    this.ensureTargets(w, h, scale);

    cam.far = 400;
    cam.update(dt, w / h);
    extractFrustumPlanes(cam.viewProj, this.planes);
    const env = this.env;
    env.tick(dt);

    // 1. shadow map ---------------------------------------------------------
    this.renderShadow(false);

    // 2. DRTV volume update (time-sliced) -----------------------------------
    if (s.giEnabled) {
      const budget = s.budget <= 0 ? this.gi.layerTotal : s.budget;
      this.gi.update(env, { bounce: s.bounce, blend: s.blend }, budget, this.shadowTex, this.timer);
      st.layersUpdated = this.gi.lastUpdatedLayers;
      st.probesUpdated = this.gi.lastUpdatedProbes;
    } else { st.layersUpdated = 0; st.probesUpdated = 0; }

    // 3. G-buffer -----------------------------------------------------------
    this.timer.begin('G-buffer');
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.gFbo);
    gl.viewport(0, 0, w, h);
    gl.disable(gl.BLEND); gl.disable(gl.SCISSOR_TEST);
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LESS); gl.depthMask(true);
    gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);
    gl.clearColor(0, 0, 0, 0);
    gl.clearDepth(1.0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    this.pGBuf.use().m4('uViewProj', cam.viewProj);
    gl.bindVertexArray(this.sceneVao);
    st.chunksVisible = this.drawChunks(this.planes);
    if (s.showProbes) {
      gl.disable(gl.CULL_FACE);
      this.gi.drawProbes(cam.viewProj, cam.pos, s.probeRange);
      gl.enable(gl.CULL_FACE);
    }
    this.timer.end();
    gl.disable(gl.CULL_FACE); gl.disable(gl.DEPTH_TEST);

    bindTex(gl, TU.DEPTH, gl.TEXTURE_2D, this.gDepth);
    bindTex(gl, TU.GB_ALB, gl.TEXTURE_2D, this.gAlb);
    bindTex(gl, TU.GB_NRM, gl.TEXTURE_2D, this.gNrm);
    gl.bindVertexArray(this.emptyVao);

    // 4. SSAO + volume application -------------------------------------------
    if (s.giEnabled) {
      if (s.aoStrength > 0) {
        this.timer.begin('SSAO');
        gl.bindFramebuffer(gl.FRAMEBUFFER, this.aoT.fbo);
        gl.viewport(0, 0, this.aoT.w, this.aoT.h);
        const p = this.pSSAO.use();
        p.m4('uInvViewProj', cam.invViewProj);
        p.m4('uViewProj', cam.viewProj);
        p.f3('uCam', cam.pos[0], cam.pos[1], cam.pos[2]);
        p.f1('uRadius', s.aoRadius);
        p.i1('uScale', scale);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
        this.timer.end();
      }
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.giT.fbo);
      gl.viewport(0, 0, this.giT.w, this.giT.h);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      this.gi.applyVolumes(cam.viewProj, cam.invViewProj, this.planes, this.giT.w, this.giT.h, scale, this.timer);
      gl.bindVertexArray(this.emptyVao);
    }

    // 5. deferred lighting -----------------------------------------------------
    this.timer.begin('Lighting');
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.hdrT.fbo);
    gl.viewport(0, 0, w, h);
    const L = this.pLight.use();
    env.apply(L);
    bindTex(gl, TU.SHADOW, gl.TEXTURE_2D, this.shadowTex);
    bindTex(gl, TU.GI, gl.TEXTURE_2D, this.giT.tex);
    bindTex(gl, TU.AO, gl.TEXTURE_2D, this.aoT.tex);
    L.m4('uInvViewProj', cam.invViewProj);
    L.f3('uCam', cam.pos[0], cam.pos[1], cam.pos[2]);
    L.f1('uNear', cam.near); L.f1('uFar', cam.far);
    L.i1('uGIEnabled', s.giEnabled ? 1 : 0);
    L.i1('uGIScale', scale);
    L.f1('uGIIntensity', s.giIntensity);
    L.f1('uAOStrength', s.giEnabled && s.aoStrength > 0 ? 1 : 0);
    L.f1('uFog', s.fog);
    L.i1('uView', s.view);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    this.timer.end();

    // 6. bloom pyramid -----------------------------------------------------------
    this.timer.begin('Post');
    const B = this.pBloom.use();
    let src: Target = this.hdrT;
    for (const b of this.bloomT) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, b.fbo);
      gl.viewport(0, 0, b.w, b.h);
      bindTex(gl, 0, gl.TEXTURE_2D, src.tex);
      B.f2('uTexel', 1 / src.w, 1 / src.h);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      src = b;
    }

    // 7. tonemap (+FXAA) -------------------------------------------------------------
    gl.bindFramebuffer(gl.FRAMEBUFFER, s.fxaa ? this.ldrT.fbo : null);
    gl.viewport(0, 0, w, h);
    const T = this.pTone.use();
    bindTex(gl, 0, gl.TEXTURE_2D, this.hdrT.tex);
    this.bloomT.forEach((b, i) => bindTex(gl, 1 + i, gl.TEXTURE_2D, b.tex));
    T.f1('uExposure', env.autoExposure * s.exposure);
    T.f1('uBloom', s.bloom * (0.5 + 0.5 * env.dayFactor + 1.2 * (1 - env.dayFactor)));
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    if (s.fxaa) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.viewport(0, 0, w, h);
      const F = this.pFXAA.use();
      bindTex(gl, 0, gl.TEXTURE_2D, this.ldrT.tex);
      F.f2('uTexel', 1 / w, 1 / h);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    }
    this.timer.end();

    st.cpuMs = performance.now() - t0;
    st.giMB = this.gi.gpuBytes / 1048576;
    for (const [k, v] of this.timer.ms) st.gpu[k] = v;
    void mat4;
  }
}
