/**
 * Orchestrates the offline probe bake: worker pool with dynamic load balancing,
 * automatic main-thread fallback, and assembly into GPU-ready atlas layouts.
 */
import BakeWorker from './bake.worker?worker&inline';
import { BVH } from './bvh';
import { bakeProbes, volumeLayout, TILE, SAMPLES, type BakeChunk, type BakeGeometry } from './bake';
import type { SceneData, VolumeDef } from './scene';

export interface BakedVolume {
  def: VolumeDef;
  layout: ReturnType<typeof volumeLayout>;
  /** RGBA32F atlas: hitDistance, octNormal.xy, flag */
  geo: Float32Array;
  /** RGBA8 atlas: albedo (gamma) */
  alb: Uint8Array;
  /** RGBA32F, one texel per probe: relocation xyz, valid */
  off: Float32Array;
  probeCount: number;
  invalidProbes: number;
}

export interface BakeStats { seconds: number; rays: number; probes: number; workers: number }

const TASK = 96;

export async function bakeScene(
  scene: SceneData,
  maxTex: number,
  onProgress: (frac: number, msg: string) => void,
): Promise<{ volumes: BakedVolume[]; stats: BakeStats }> {
  const t0 = performance.now();
  const geom: BakeGeometry = { positions: scene.positions, indices: scene.indices, normals: scene.normals, colors: scene.colors };

  const volumes: BakedVolume[] = scene.volumes.map((def) => {
    const layout = volumeLayout(def.dims, maxTex);
    const probeCount = def.dims[0] * def.dims[1] * def.dims[2];
    return {
      def, layout, probeCount, invalidProbes: 0,
      geo: new Float32Array(layout.texW * layout.texH * 4),
      alb: new Uint8Array(layout.texW * layout.texH * 4),
      off: new Float32Array(layout.offW * layout.offH * 4),
    };
  });

  // task list
  const tasks: { volIndex: number; start: number; end: number }[] = [];
  volumes.forEach((v, vi) => {
    for (let s = 0; s < v.probeCount; s += TASK) tasks.push({ volIndex: vi, start: s, end: Math.min(v.probeCount, s + TASK) });
  });
  const totalProbes = volumes.reduce((a, v) => a + v.probeCount, 0);
  let done = 0;

  const place = (vi: number, start: number, end: number, r: BakeChunk) => {
    const V = volumes[vi];
    const { nx, nz, cols, texW, offW } = V.layout;
    for (let p = start; p < end; p++) {
      const lp = p - start;
      const ix = p % nx, iz = Math.floor(p / nx) % nz, iy = Math.floor(p / (nx * nz));
      const lc = iy % cols, lr = Math.floor(iy / cols);
      const tx = lc * nx + ix, ty = lr * nz + iz;
      // probe offset texel
      const oo = (ty * offW + tx) * 4;
      V.off[oo] = r.off[lp * 4]; V.off[oo + 1] = r.off[lp * 4 + 1]; V.off[oo + 2] = r.off[lp * 4 + 2]; V.off[oo + 3] = r.off[lp * 4 + 3];
      if (r.off[lp * 4 + 3] < 0.5) V.invalidProbes++;
      for (let sy = 0; sy < TILE; sy++) {
        const dstTexel = (ty * TILE + sy) * texW + tx * TILE;
        const srcSample = lp * SAMPLES + sy * TILE;
        V.geo.set(r.geo.subarray(srcSample * 4, (srcSample + TILE) * 4), dstTexel * 4);
        V.alb.set(r.alb.subarray(srcSample * 4, (srcSample + TILE) * 4), dstTexel * 4);
      }
    }
    done += end - start;
    onProgress(done / totalProbes, `Baking radiance transfer probes  ${done.toLocaleString()} / ${totalProbes.toLocaleString()}`);
  };

  let workerCount = 0;
  let usedWorkers = false;
  try {
    const n = Math.max(1, Math.min(6, (navigator.hardwareConcurrency || 4) - 1));
    await runWorkers(n, geom, volumes, tasks, place, onProgress);
    workerCount = n;
    usedWorkers = true;
  } catch (err) {
    console.warn('[DRTV] worker bake failed, falling back to main thread:', err);
    done = 0;
    for (const v of volumes) { v.invalidProbes = 0; }
    await runLocal(geom, volumes, tasks, place, onProgress);
  }

  const seconds = (performance.now() - t0) / 1000;
  return { volumes, stats: { seconds, rays: totalProbes * SAMPLES, probes: totalProbes, workers: usedWorkers ? workerCount : 0 } };
}

type Place = (vi: number, s: number, e: number, r: BakeChunk) => void;

function runWorkers(
  n: number, geom: BakeGeometry, volumes: BakedVolume[],
  tasks: { volIndex: number; start: number; end: number }[], place: Place,
  onProgress: (f: number, m: string) => void,
): Promise<void> {
  return new Promise((resolve, reject) => {
    const workers: Worker[] = [];
    let next = 0, finished = 0, ready = 0, failed = false;
    const fail = (e: unknown) => { if (failed) return; failed = true; workers.forEach((w) => w.terminate()); reject(e); };
    const feed = (w: Worker) => {
      if (next >= tasks.length) return;
      const t = tasks[next];
      w.postMessage({
        type: 'task', id: next, volIndex: t.volIndex, start: t.start, end: t.end,
        vol: { origin: volumes[t.volIndex].def.origin, spacing: volumes[t.volIndex].def.spacing, dims: volumes[t.volIndex].def.dims, maxRay: volumes[t.volIndex].def.maxRay },
      });
      next++;
    };
    onProgress(0, `Building BVH on ${n} worker${n > 1 ? 's' : ''}…`);
    for (let i = 0; i < n; i++) {
      const w = new BakeWorker();
      workers.push(w);
      w.onerror = (e) => fail(e);
      w.onmessage = (e: MessageEvent) => {
        const m = e.data;
        if (m.type === 'ready') { ready++; feed(w); }
        else if (m.type === 'result') {
          place(m.vol, m.start, m.end, { geo: m.geo, alb: m.alb, off: m.off });
          finished++;
          if (finished === tasks.length) { workers.forEach((x) => x.terminate()); resolve(); }
          else feed(w);
        }
      };
      w.postMessage({ type: 'init', geom: { positions: geom.positions.slice(), indices: geom.indices.slice(), normals: geom.normals.slice(), colors: geom.colors.slice() } });
    }
    setTimeout(() => { if (!ready) fail(new Error('worker start timeout')); }, 20000);
  });
}

async function runLocal(
  geom: BakeGeometry, volumes: BakedVolume[],
  tasks: { volIndex: number; start: number; end: number }[], place: Place,
  onProgress: (f: number, m: string) => void,
) {
  onProgress(0, 'Building BVH (main thread)…');
  await new Promise((r) => setTimeout(r, 30));
  const bvh = new BVH(geom.positions, geom.indices);
  let last = performance.now();
  for (const t of tasks) {
    const d = volumes[t.volIndex].def;
    place(t.volIndex, t.start, t.end, bakeProbes(bvh, geom, { origin: d.origin, spacing: d.spacing, dims: d.dims, maxRay: d.maxRay }, t.start, t.end));
    if (performance.now() - last > 40) { await new Promise((r) => setTimeout(r, 0)); last = performance.now(); }
  }
}
