// Bloom composite + exposure + ACES filmic tone-map + sRGB encode + dither.
in vec2 vUv;
out vec4 oColor;
uniform sampler2D uHdr;
uniform sampler2D uB0, uB1, uB2, uB3, uB4;
uniform float uExposure;
uniform float uBloom;

vec3 aces(vec3 x) {
  return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}
vec3 toSRGB(vec3 c) {
  return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));
}
float hash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}
void main() {
  vec3 c = texture(uHdr, vUv).rgb;
  vec3 b = texture(uB0, vUv).rgb * 0.5 + texture(uB1, vUv).rgb * 0.7 + texture(uB2, vUv).rgb
         + texture(uB3, vUv).rgb + texture(uB4, vUv).rgb * 0.8;
  c += b * (uBloom / 4.0);
  c *= uExposure;
  vec2 q = vUv - 0.5;
  c *= 1.0 - dot(q, q) * 0.55;
  c = toSRGB(aces(c));
  c += (hash12(gl_FragCoord.xy) - 0.5) / 255.0;
  oColor = vec4(c, 1.0);
}
