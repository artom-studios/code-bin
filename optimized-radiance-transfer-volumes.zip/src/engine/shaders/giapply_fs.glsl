// ===========================================================================
// DRTV pass 3 - VOLUME APPLICATION (deferred). Drawn once per visible volume with a
// scissor rect equal to the volume's screen-space bounds. Reconstructs the world position
// from depth, samples the volume's SH with hardware trilinear filtering and evaluates
// irradiance in the G-buffer normal direction. Output is blended "over" with an edge
// falloff so fine volumes smoothly override the coarse world volume.
// ===========================================================================
layout(location = 0) out vec4 oGI;

uniform sampler2D uDepth;
uniform sampler2D uGBNrm;
uniform sampler3D uShR, uShG, uShB;
uniform mat4 uInvViewProj;
uniform vec3 uBoxMin, uBoxMax;
uniform vec3 uOrigin;
uniform float uSpacing;
uniform vec3 uDims;
uniform float uBlend;
uniform int uScale;
uniform float uNormalBias;

void main() {
  ivec2 fs = textureSize(uDepth, 0);
  ivec2 fp = min(ivec2(gl_FragCoord.xy) * uScale, fs - 1);
  float depth = texelFetch(uDepth, fp, 0).r;
  if (depth >= 1.0) discard;
  vec4 nrm = texelFetch(uGBNrm, fp, 0);
  vec3 N = octDecode(nrm.xy * 2.0 - 1.0);
  vec3 P = reconstructPos((vec2(fp) + 0.5) / vec2(fs), depth, uInvViewProj);
  vec3 Pq = P + N * uNormalBias;
  if (any(lessThan(Pq, uBoxMin)) || any(greaterThan(Pq, uBoxMax))) discard;

  vec3 dm = Pq - uBoxMin, dM = uBoxMax - Pq;
  float e = min(min(min(dm.x, dm.y), dm.z), min(min(dM.x, dM.y), dM.z));
  float w = uBlend > 0.0 ? smoothstep(0.0, uBlend, e) : 1.0;

  vec3 uvw = volUVW(Pq, uOrigin, uSpacing, uDims);
  vec3 gi = shEval(texture(uShR, uvw), texture(uShG, uvw), texture(uShB, uvw), N);
  oGI = vec4(gi, w);
}
