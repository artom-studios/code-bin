// Deferred lighting: sun + shadow, DRTV indirect (bilateral-upsampled), local lights, sky, fog.
in vec2 vUv;
out vec4 oColor;

uniform sampler2D uDepth;
uniform sampler2D uGBAlb;
uniform sampler2D uGBNrm;
uniform sampler2D uGI;
uniform sampler2D uAO;

uniform mat4 uInvViewProj;
uniform vec3 uCam;
uniform float uNear, uFar;
uniform int uGIEnabled;
uniform int uGIScale;
uniform float uGIIntensity;
uniform float uAOStrength;
uniform float uFog;
uniform int uView;   // 0 final, 1 GI only, 2 albedo, 3 normals, 4 AO, 5 direct only, 6 shadow

float linearizeDepth(float d) {
  float z = d * 2.0 - 1.0;
  return 2.0 * uNear * uFar / (uFar + uNear - z * (uFar - uNear));
}

vec4 fetchGI(ivec2 q) {
  return vec4(texelFetch(uGI, q, 0).rgb, texelFetch(uAO, q, 0).r);
}

// Depth + normal aware upsample of the half-resolution GI/AO buffers.
vec4 upsampleGI(ivec2 p, float lin, vec3 N, ivec2 fs) {
  if (uGIScale == 1) return fetchGI(p);
  ivec2 hs = textureSize(uGI, 0);
  vec2 hp = (vec2(p) + 0.5) * 0.5 - 0.5;
  ivec2 b = ivec2(floor(hp));
  vec2 f = hp - vec2(b);
  vec4 acc = vec4(0.0);
  float ws = 0.0;
  for (int j = 0; j < 2; j++) {
    for (int i = 0; i < 2; i++) {
      ivec2 q = clamp(b + ivec2(i, j), ivec2(0), hs - 1);
      ivec2 fq = min(q * 2, fs - 1);
      float d = linearizeDepth(texelFetch(uDepth, fq, 0).r);
      vec3 n = octDecode(texelFetch(uGBNrm, fq, 0).xy * 2.0 - 1.0);
      float bw = (i == 0 ? 1.0 - f.x : f.x) * (j == 0 ? 1.0 - f.y : f.y);
      float w = bw * exp(-abs(d - lin) / (0.05 * lin + 0.08)) * pow(max(dot(n, N), 0.0), 6.0) + 1e-5;
      acc += w * fetchGI(q);
      ws += w;
    }
  }
  return acc / ws;
}

const vec2 POISSON[8] = vec2[8](
  vec2(-0.613392, 0.617481), vec2(0.170019, -0.040254), vec2(-0.299417, 0.791925), vec2(0.645680, 0.493210),
  vec2(-0.651784, 0.717887), vec2(0.421003, 0.027070), vec2(-0.817194, -0.271096), vec2(-0.705374, -0.668203));

float shadowPCF(vec3 P, vec3 N) {
  vec3 p = shadowCoord(P, N);
  if (p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0 || p.z > 1.0) return 1.0;
  float texel = 1.0 / float(textureSize(uShadow, 0).x);
  float a = 6.2831853 * fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
  mat2 R = mat2(cos(a), sin(a), -sin(a), cos(a));
  float s = 0.0;
  for (int i = 0; i < 8; i++) {
    vec2 o = R * POISSON[i] * texel * 1.6;
    s += texture(uShadow, vec3(p.xy + o, p.z - uShadowBias));
  }
  return s / 8.0;
}

float hash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

void main() {
  ivec2 p = ivec2(gl_FragCoord.xy);
  ivec2 fs = textureSize(uDepth, 0);
  float depth = texelFetch(uDepth, p, 0).r;
  vec3 ray = reconstructPos(vUv, depth >= 1.0 ? 1.0 : depth, uInvViewProj) - uCam;
  vec3 V = normalize(ray);

  // ---------------------------------------------------------------- sky
  if (depth >= 1.0) {
    vec3 sky = skyRadiance(V);
    float se = uSunDir.y;
    float mu = dot(V, uSunDir);
    float disc = smoothstep(0.99990, 0.99994, mu) * smoothstep(-0.03, 0.03, se);
    vec3 sunCol = mix(vec3(1.0, 0.85, 0.65), vec3(1.0, 0.5, 0.2), exp(-se * se * 14.0));
    sky += sunCol * disc * 60.0;
    float night = 1.0 - smoothstep(-0.25, -0.02, se);
    // stars
    vec3 sd = V * 140.0;
    vec3 cell = floor(sd);
    float h = hash12(cell.xy + cell.z * 17.0);
    vec3 fc = fract(sd) - 0.5;
    float star = step(0.9965, h) * smoothstep(0.35, 0.0, length(fc)) * (0.4 + 0.6 * hash12(cell.yz));
    sky += vec3(0.8, 0.85, 1.0) * star * night * smoothstep(0.0, 0.15, V.y) * 1.5;
    // moon
    vec3 moonDir = normalize(vec3(-uSunDir.x, -uSunDir.y, uSunDir.z));
    sky += vec3(0.75, 0.82, 1.0) * smoothstep(0.99965, 0.99975, dot(V, moonDir)) * night * 3.0;
    oColor = vec4(sky, 1.0);
    if (uView == 2 || uView == 3 || uView == 4 || uView == 1) oColor = vec4(0.02);
    return;
  }

  vec4 nrm = texelFetch(uGBNrm, p, 0);
  vec3 N = octDecode(nrm.xy * 2.0 - 1.0);
  vec3 albG = texelFetch(uGBAlb, p, 0).rgb;
  vec3 alb = pow(albG, vec3(2.2));
  int flag = int(nrm.a * 3.0 + 0.5);
  vec3 P = uCam + ray;
  if (uView == 2) { oColor = vec4(alb, 1.0); return; }
  if (uView == 3) { oColor = vec4(pow(N * 0.5 + 0.5, vec3(2.2)), 1.0); return; }
  if (flag == 1) { oColor = vec4(alb * 6.0, 1.0); return; }   // emissive
  if (flag == 2) { oColor = vec4(alb * 4.0, 1.0); return; }   // debug probe sphere

  float ndl = max(dot(N, uLightDir), 0.0);
  float sh = ndl > 0.0 ? shadowPCF(P, N) : 0.0;
  if (uView == 6) { oColor = vec4(vec3(sh), 1.0); return; }
  vec3 sun = uLightColor * ndl * sh;

  float lin = linearizeDepth(depth);
  vec3 gi;
  float ao = 1.0;
  if (uGIEnabled > 0) {
    vec4 g = upsampleGI(p, lin, N, fs);
    gi = g.rgb * uGIIntensity;
    ao = mix(1.0, g.a, uAOStrength);
  } else {
    // classic hemispherical ambient for A/B comparison
    vec3 top = skyRadiance(normalize(vec3(0.3, 1.0, 0.3))) * 0.85;
    vec3 bot = skyRadiance(vec3(1.0, 0.02, 0.0)) * 0.30 + vec3(0.02);
    gi = mix(bot, top, N.y * 0.5 + 0.5) * uGIIntensity;
    ao = 1.0;
  }
  if (uView == 4) { oColor = vec4(vec3(ao), 1.0); return; }
  gi *= ao;

  vec3 lights = pointLights(P, N);
  vec3 col;
  if (uView == 1) col = vec3(0.5) * gi;
  else if (uView == 5) col = alb * (sun + lights);
  else col = alb * (sun + gi + lights);

  // aerial perspective
  float dist = length(ray);
  float fogAmt = 1.0 - exp(-dist * uFog * exp(-max(P.y - 2.0, 0.0) * 0.035));
  vec3 fogCol = skyRadiance(normalize(vec3(V.x, 0.04, V.z)));
  if (uView == 0) col = mix(col, fogCol, clamp(fogAmt, 0.0, 0.9));

  oColor = vec4(col, 1.0);
}
