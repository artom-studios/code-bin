// ===========================================================================
// DRTV common library (prepended to every fragment shader that needs it)
// ===========================================================================
const float PI = 3.14159265359;

// ---- Octahedral mapping (must match math.ts) -------------------------------
vec3 octDecodeRaw(vec2 f) {
  vec3 n = vec3(f.x, f.y, 1.0 - abs(f.x) - abs(f.y));
  if (n.z < 0.0) {
    vec2 s = vec2(n.x >= 0.0 ? 1.0 : -1.0, n.y >= 0.0 ? 1.0 : -1.0);
    n.xy = (1.0 - abs(n.yx)) * s;
  }
  return n;
}
vec3 octDecode(vec2 f) { return normalize(octDecodeRaw(f)); }
vec2 octEncode(vec3 n) {
  n /= (abs(n.x) + abs(n.y) + abs(n.z));
  vec2 e = n.xy;
  if (n.z < 0.0) {
    vec2 s = vec2(e.x >= 0.0 ? 1.0 : -1.0, e.y >= 0.0 ? 1.0 : -1.0);
    e = (1.0 - abs(e.yx)) * s;
  }
  return e;
}

vec3 reconstructPos(vec2 uv, float depth, mat4 invVP) {
  vec4 w = invVP * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
  return w.xyz / w.w;
}

// ---- L1 spherical harmonics, pre-convolved with the cosine lobe ------------
// Stored per colour channel as vec4(c0, cY, cZ, cX). eval returns E(n)/PI.
// 3D SH textures are laid out (x, z, y) so each Y layer is one renderable slice.
vec3 volUVW(vec3 P, vec3 origin, float spacing, vec3 dims) {
  vec3 q = ((P - origin) / spacing + 0.5) / dims;   // dims = (nx, ny, nz)
  return q.xzy;
}
vec3 shEval(vec4 cr, vec4 cg, vec4 cb, vec3 n) {
  vec3 b = vec3(n.y, n.z, n.x);
  return max(vec3(cr.x + dot(cr.yzw, b), cg.x + dot(cg.yzw, b), cb.x + dot(cb.yzw, b)), vec3(0.0));
}

// ---- Environment ------------------------------------------------------------
uniform vec3 uSunDir;      // direction TO the sun (may be below the horizon)
uniform vec3 uLightDir;    // dominant directional light: sun by day, moon by night
uniform vec3 uLightColor;  // radiance-scaled colour of that light

vec3 skyRadiance(vec3 d) {
  float se = uSunDir.y;
  float day = smoothstep(-0.20, 0.15, se);
  float dusk = exp(-se * se * 14.0);
  float up = clamp(d.y, 0.0, 1.0);
  float g = pow(1.0 - up, 3.5);

  vec3 zenith = mix(vec3(0.003, 0.006, 0.018), vec3(0.13, 0.30, 0.72), day);
  vec3 horizon = mix(vec3(0.010, 0.014, 0.030), vec3(0.62, 0.74, 0.90), day);

  vec2 sh = normalize(uSunDir.xz + vec2(1e-4));
  vec2 dh = normalize(d.xz + vec2(1e-4));
  float az = pow(0.5 + 0.5 * dot(sh, dh), 2.0);
  vec3 warm = vec3(1.0, 0.42, 0.14) * (0.12 + 0.88 * az);
  float wf = dusk * (0.25 + 0.75 * smoothstep(-0.30, -0.05, se));
  horizon = mix(horizon, warm * 0.85, wf * 0.85);
  zenith = mix(zenith, vec3(0.20, 0.17, 0.36) * day, dusk * 0.35);

  vec3 col = mix(zenith, horizon, g);
  col = mix(col, horizon * 0.35, smoothstep(0.0, -0.25, d.y));

  float mu = max(dot(d, uSunDir), 0.0);
  vec3 sunCol = mix(vec3(1.0, 0.88, 0.70), vec3(1.0, 0.45, 0.15), dusk);
  col += sunCol * (pow(mu, 6.0) * 0.18 + pow(mu, 80.0) * 0.8) * smoothstep(-0.12, 0.02, se);
  return col;
}

// ---- Sun shadow map (one world-covering orthographic map) -----------------
uniform sampler2DShadow uShadow;
uniform mat4 uShadowVP;
uniform float uShadowBias;   // depth bias, normalised depth units
uniform float uShadowNBias;  // normal offset in metres

vec3 shadowCoord(vec3 P, vec3 N) {
  float ndl = clamp(dot(N, uLightDir), 0.0, 1.0);
  vec4 sc = uShadowVP * vec4(P + N * uShadowNBias * (1.6 - ndl), 1.0);
  return sc.xyz * 0.5 + 0.5;
}
float shadowTap1(vec3 P, vec3 N) {
  vec3 p = shadowCoord(P, N);
  if (p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0 || p.z > 1.0) return 1.0;
  return texture(uShadow, vec3(p.xy, p.z - uShadowBias));
}

// ---- Dynamic point lights -----------------------------------------------------
#define MAX_PL 16
uniform int uNumPL;
uniform vec4 uPL[MAX_PL];     // xyz position, w radius
uniform vec3 uPLC[MAX_PL];    // colour * intensity
uniform vec3 uPLMin[MAX_PL];  // optional confinement box
uniform vec3 uPLMax[MAX_PL];

vec3 pointLights(vec3 P, vec3 N) {
  vec3 acc = vec3(0.0);
  for (int i = 0; i < MAX_PL; i++) {
    if (i >= uNumPL) break;
    vec3 L = uPL[i].xyz - P;
    float d2 = dot(L, L);
    float r = uPL[i].w;
    if (d2 >= r * r) continue;
    if (any(lessThan(P, uPLMin[i])) || any(greaterThan(P, uPLMax[i]))) continue;
    float d = sqrt(d2);
    L /= d;
    float x = d / r;
    float f = clamp(1.0 - x * x * x * x, 0.0, 1.0);
    acc += uPLC[i] * (f * f / (d2 + 1.0)) * max(dot(N, L), 0.0);
  }
  return acc;
}
