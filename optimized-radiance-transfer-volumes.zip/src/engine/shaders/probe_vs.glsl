// Debug visualisation: one instanced sphere per probe, coloured by the probe's SH irradiance.
layout(location = 0) in vec3 aPos;
uniform mat4 uViewProj;
uniform vec3 uOrigin;
uniform float uSpacing;
uniform ivec3 uDims;
uniform int uCols;
uniform float uRadius;
uniform vec3 uCam;
uniform float uMaxDist;
uniform sampler2D uOff;
uniform sampler3D uShR, uShG, uShB;
flat out vec4 fR;
flat out vec4 fG;
flat out vec4 fB;
flat out float fValid;
out vec3 vN;
void main() {
  int id = gl_InstanceID;
  int ix = id % uDims.x;
  int iz = (id / uDims.x) % uDims.z;
  int iy = id / (uDims.x * uDims.z);
  int lc = iy % uCols, lr = iy / uCols;
  vec4 off = texelFetch(uOff, ivec2(lc * uDims.x + ix, lr * uDims.z + iz), 0);
  vec3 c = uOrigin + vec3(float(ix), float(iy), float(iz)) * uSpacing + off.xyz;
  fR = texelFetch(uShR, ivec3(ix, iz, iy), 0);
  fG = texelFetch(uShG, ivec3(ix, iz, iy), 0);
  fB = texelFetch(uShB, ivec3(ix, iz, iy), 0);
  fValid = off.w;
  vN = aPos;
  if (distance(c, uCam) > uMaxDist) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }
  gl_Position = uViewProj * vec4(c + aPos * uRadius, 1.0);
}
