// G-buffer fill. RT0: albedo (gamma-encoded) ; RT1: octahedral normal.xy, -, flags (alpha)
layout(location = 0) out vec4 oAlbedo;
layout(location = 1) out vec4 oNormal;
in vec3 vWorld;
in vec3 vN;
in vec4 vCol;

float hash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}
float vnoise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash12(i), hash12(i + vec2(1, 0)), f.x), mix(hash12(i + vec2(0, 1)), hash12(i + vec2(1, 1)), f.x), f.y);
}
float fbm(vec2 p) {
  float a = 0.5, s = 0.0;
  for (int i = 0; i < 3; i++) { s += a * vnoise(p); p *= 2.03; a *= 0.5; }
  return s / 0.875;
}

void main() {
  vec3 N = normalize(vN);
  int mat = int(vCol.a * 255.0 + 0.5);
  vec3 alb = vCol.rgb;
  float flag = 0.0;
  vec3 wp = vWorld;

  if (mat == 0) {            // terrain / rock
    float n = fbm(wp.xz * 1.1);
    alb *= 0.72 + 0.56 * n;
    alb *= 0.9 + 0.2 * vnoise(wp.xz * 8.0 + wp.y);
  } else if (mat == 1) {     // cut stone
    vec2 uv; vec2 bs;
    if (abs(N.y) > 0.7) { uv = wp.xz; bs = vec2(1.8, 1.8); }
    else if (abs(N.x) > abs(N.z)) { uv = vec2(wp.z, wp.y); bs = vec2(1.4, 0.7); }
    else { uv = vec2(wp.x, wp.y); bs = vec2(1.4, 0.7); }
    float row = floor(uv.y / bs.y);
    float u = uv.x / bs.x + 0.5 * mod(row, 2.0);
    vec2 cell = vec2(floor(u), row);
    vec2 f = vec2(fract(u), fract(uv.y / bs.y));
    float mortar = clamp(step(f.x, 0.035) + step(f.y, 0.05), 0.0, 1.0);
    alb *= (0.78 + 0.44 * hash12(cell)) * (1.0 - 0.38 * mortar) * (0.85 + 0.3 * fbm(uv * 2.5));
  } else if (mat == 2) {     // plaster
    alb *= 0.90 + 0.18 * fbm(vec2(wp.x + wp.z, wp.y) * 1.7);
    alb *= 0.96 + 0.08 * vnoise(wp.xz * 11.0 + wp.y * 7.0);
  } else if (mat == 3) {     // foliage
    alb *= 0.62 + 0.76 * vnoise(wp.xy * 4.0 + wp.z * 3.0);
  } else if (mat == 4) {     // wood
    alb *= 0.78 + 0.44 * vnoise(vec2(wp.x + wp.z, wp.y * 5.0));
  } else {                   // emissive
    flag = 1.0 / 3.0;
  }

  oAlbedo = vec4(clamp(alb, 0.0, 1.0), 1.0);
  oNormal = vec4(octEncode(N) * 0.5 + 0.5, 0.0, flag);
}
