layout(location = 0) out vec4 oAlbedo;
layout(location = 1) out vec4 oNormal;
flat in vec4 fR;
flat in vec4 fG;
flat in vec4 fB;
flat in float fValid;
in vec3 vN;
void main() {
  vec3 n = normalize(vN);
  vec3 c = shEval(fR, fG, fB, n);
  if (fValid < 0.5) c = vec3(2.0, 0.0, 2.0);
  oAlbedo = vec4(pow(clamp(c / 4.0, 0.0, 1.0), vec3(1.0 / 2.2)), 1.0);
  oNormal = vec4(octEncode(n) * 0.5 + 0.5, 0.0, 2.0 / 3.0);
}
