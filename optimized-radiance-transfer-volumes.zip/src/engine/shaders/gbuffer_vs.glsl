layout(location = 0) in vec3 aPos;
layout(location = 1) in vec4 aNrm;   // snorm8x4
layout(location = 2) in vec4 aCol;   // unorm8x4: albedo.rgb (gamma), material id
uniform mat4 uViewProj;
out vec3 vWorld;
out vec3 vN;
out vec4 vCol;
void main() {
  vWorld = aPos;
  vN = aNrm.xyz;
  vCol = aCol;
  gl_Position = uViewProj * vec4(aPos, 1.0);
}
