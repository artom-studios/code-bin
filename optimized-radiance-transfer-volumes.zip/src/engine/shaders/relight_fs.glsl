// ===========================================================================
// DRTV pass 1 - RELIGHT. One fragment per probe sample (8x8 octahedral tile / probe).
// Reads the baked surface cache (distance, normal, albedo) and computes the outgoing
// radiance of every hit surface under the CURRENT lighting:
//     L_out = albedo * ( sun * N.L * shadow + local lights + bounceGain * E_prev(P,N) )
// E_prev is the previous frame's probe irradiance => infinite-bounce feedback.
// Sky samples return the analytic sky radiance.
// ===========================================================================
layout(location = 0) out vec4 oRad;

uniform sampler2D uGeo;   // RGBA32F/16F: dist, oct.xy, flag
uniform sampler2D uAlb;   // RGBA8: albedo (gamma)
uniform sampler2D uOff;   // probe relocation offsets
uniform sampler3D uShR, uShG, uShB;   // this volume's SH (previous state)
uniform sampler3D uGlR, uGlG, uGlB;   // global volume SH (fallback for far hits)

uniform vec3 uOrigin;
uniform float uSpacing;
uniform ivec3 uDims;
uniform int uCols;
uniform vec3 uGOrigin;
uniform float uGSpacing;
uniform vec3 uGDims;
uniform float uBounce;

vec3 sampleVol(sampler3D r, sampler3D g, sampler3D b, vec3 P, vec3 N, vec3 origin, float spacing, vec3 dims) {
  vec3 uvw = volUVW(P, origin, spacing, dims);
  return shEval(texture(r, uvw), texture(g, uvw), texture(b, uvw), N);
}

void main() {
  ivec2 t = ivec2(gl_FragCoord.xy);
  ivec2 tile = t >> 3;
  ivec2 s = t & 7;
  int lc = tile.x / uDims.x;
  int ix = tile.x - lc * uDims.x;
  int lr = tile.y / uDims.z;
  int iz = tile.y - lr * uDims.z;
  int iy = lr * uCols + lc;

  vec4 geo = texelFetch(uGeo, t, 0);
  vec3 dir = octDecode((vec2(s) + 0.5) / 8.0 * 2.0 - 1.0);

  if (geo.w > 1.5) { oRad = vec4(0.0); return; }                       // invalid / back-face
  if (geo.w > 0.5) { oRad = vec4(min(skyRadiance(dir), vec3(64.0)), 1.0); return; } // sky

  vec4 off = texelFetch(uOff, tile, 0);
  vec3 pp = uOrigin + vec3(float(ix), float(iy), float(iz)) * uSpacing + off.xyz;
  vec3 P = pp + dir * geo.x;
  vec3 N = octDecode(geo.yz);
  vec3 alb = pow(texelFetch(uAlb, t, 0).rgb, vec3(2.2));

  float ndl = max(dot(N, uLightDir), 0.0);
  vec3 direct = uLightColor * ndl * (ndl > 0.0 ? shadowTap1(P, N) : 0.0);
  direct += pointLights(P, N);

  vec3 Pq = P + N * 0.3;
  vec3 q = (Pq - uOrigin) / uSpacing;
  bool inside = all(greaterThan(q, vec3(0.5))) && all(lessThan(q, vec3(uDims) - 1.5));
  vec3 ind = inside ? sampleVol(uShR, uShG, uShB, Pq, N, uOrigin, uSpacing, vec3(uDims))
                    : sampleVol(uGlR, uGlG, uGlB, Pq, N, uGOrigin, uGSpacing, uGDims);

  oRad = vec4(min(alb * (direct + ind * uBounce), vec3(64.0)), 1.0);
}
