// ===========================================================================
// DRTV pass 2 - SH PROJECTION. One fragment per probe of a volume slice.
// Integrates the relit 8x8 octahedral radiance tile (solid-angle weighted) into
// L1 SH, pre-convolved with the clamped-cosine lobe -> stored as E(n)/PI.
// Output is temporally filtered by fixed-function blending (constant alpha).
// ===========================================================================
layout(location = 0) out vec4 oR;
layout(location = 1) out vec4 oG;
layout(location = 2) out vec4 oB;

uniform sampler2D uRad;
uniform ivec3 uDims;
uniform int uCols;
uniform int uLayer;

void main() {
  ivec2 p = ivec2(gl_FragCoord.xy);
  int ix = p.x, iz = p.y, iy = uLayer;
  int lc = iy % uCols, lr = iy / uCols;
  ivec2 base = ivec2((lc * uDims.x + ix) * 8, (lr * uDims.z + iz) * 8);

  vec3 c0 = vec3(0.0), cx = vec3(0.0), cy = vec3(0.0), cz = vec3(0.0);
  float wsum = 0.0;
  for (int sy = 0; sy < 8; sy++) {
    for (int sx = 0; sx < 8; sx++) {
      vec2 f = (vec2(float(sx), float(sy)) + 0.5) / 8.0 * 2.0 - 1.0;
      vec3 pr = octDecodeRaw(f);
      float l = length(pr);
      vec3 d = pr / l;
      float w = 1.0 / (l * l * l);          // octahedral texel solid angle ~ 1/|p|^3
      vec3 L = texelFetch(uRad, base + ivec2(sx, sy), 0).rgb;
      c0 += L * w; cx += L * (d.x * w); cy += L * (d.y * w); cz += L * (d.z * w);
      wsum += w;
    }
  }
  float inv = 1.0 / wsum;
  // E/PI = c0/4pi*... : L00 term = mean radiance, L1 terms scaled by 2 (cos-lobe 2/3 * 3 basis norm)
  oR = vec4(c0.r * inv, 2.0 * cy.r * inv, 2.0 * cz.r * inv, 2.0 * cx.r * inv);
  oG = vec4(c0.g * inv, 2.0 * cy.g * inv, 2.0 * cz.g * inv, 2.0 * cx.g * inv);
  oB = vec4(c0.b * inv, 2.0 * cy.b * inv, 2.0 * cz.b * inv, 2.0 * cx.b * inv);
}
