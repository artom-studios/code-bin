// Half-resolution hemispherical SSAO used to restore contact detail the coarse probe grid cannot.
in vec2 vUv;
out vec4 oAO;

uniform sampler2D uDepth;
uniform sampler2D uGBNrm;
uniform mat4 uInvViewProj, uViewProj;
uniform vec3 uCam;
uniform float uRadius;
uniform int uScale;

float hash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

void main() {
  ivec2 fs = textureSize(uDepth, 0);
  ivec2 fp = min(ivec2(gl_FragCoord.xy) * uScale, fs - 1);
  float depth = texelFetch(uDepth, fp, 0).r;
  if (depth >= 1.0) { oAO = vec4(1.0); return; }
  vec3 N = octDecode(texelFetch(uGBNrm, fp, 0).xy * 2.0 - 1.0);
  vec3 P = reconstructPos((vec2(fp) + 0.5) / vec2(fs), depth, uInvViewProj);

  vec3 up = abs(N.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
  vec3 T = normalize(cross(up, N));
  vec3 B = cross(N, T);
  float ang = 6.2831853 * hash12(vec2(fp) * 0.7311 + 3.1);
  float ca = cos(ang), sa = sin(ang);
  vec3 T2 = T * ca + B * sa, B2 = -T * sa + B * ca;

  float occ = 0.0;
  const int TAPS = 12;
  for (int i = 0; i < TAPS; i++) {
    float fi = (float(i) + 0.5) / float(TAPS);
    float phi = float(i) * 2.39996323;
    float rr = sqrt(fi);
    vec3 k = vec3(cos(phi) * rr, sin(phi) * rr, sqrt(1.0 - fi));
    float sc = 0.15 + 0.85 * fi;
    vec3 S = P + N * 0.04 + (T2 * k.x + B2 * k.y + N * k.z) * uRadius * sc;
    vec4 c = uViewProj * vec4(S, 1.0);
    if (c.w <= 0.0) continue;
    vec2 suv = c.xy / c.w * 0.5 + 0.5;
    if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) continue;
    ivec2 sp = min(ivec2(suv * vec2(fs)), fs - 1);
    float sd = texelFetch(uDepth, sp, 0).r;
    if (sd >= 1.0) continue;
    vec3 Q = reconstructPos((vec2(sp) + 0.5) / vec2(fs), sd, uInvViewProj);
    float diff = distance(S, uCam) - distance(Q, uCam);
    if (diff > 0.04) occ += 1.0 - smoothstep(uRadius * 0.7, uRadius * 1.8, diff);
  }
  oAO = vec4(1.0 - occ / float(TAPS), 0.0, 0.0, 1.0);
}
