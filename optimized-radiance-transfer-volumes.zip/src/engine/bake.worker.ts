/// <reference lib="webworker" />
import { BVH } from './bvh';
import { bakeProbes, type BakeGeometry, type BakeVolumeParams } from './bake';

let bvh: BVH | null = null;
let geom: BakeGeometry | null = null;

self.onmessage = (e: MessageEvent) => {
  const m = e.data;
  if (m.type === 'init') {
    geom = m.geom as BakeGeometry;
    bvh = new BVH(geom.positions, geom.indices);
    (self as unknown as Worker).postMessage({ type: 'ready' });
  } else if (m.type === 'task' && bvh && geom) {
    const res = bakeProbes(bvh, geom, m.vol as BakeVolumeParams, m.start, m.end);
    (self as unknown as Worker).postMessage(
      { type: 'result', id: m.id, vol: m.volIndex, start: m.start, end: m.end, ...res },
      [res.geo.buffer, res.alb.buffer, res.off.buffer],
    );
  }
};
