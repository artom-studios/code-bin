/**
 * Engine facade used by the React UI: scene generation -> bake -> renderer -> main loop.
 */
import { Camera } from './camera';
import { Environment } from './env';
import { Renderer, defaultSettings, type FrameStats, type Settings } from './renderer';
import { generateScene, type SceneData } from './scene';
import { bakeScene, type BakeStats, type BakedVolume } from './bakeService';
import { exportDRTV } from './exportBake';
import type { Vec3 } from './math';

export type Progress = (frac: number, msg: string) => void;

export interface EngineInfo {
  triangles: number; vertices: number; trees: number; chunks: number;
  probes: number; volumes: { name: string; probes: number; spacing: number; dims: [number, number, number]; invalid: number; mb: number }[];
  bake: BakeStats; giMB: number; maxTex: number; renderer: string;
}

const LIGHT_COLORS: Vec3[] = [[1.0, 0.82, 0.6], [0.35, 0.8, 1.0], [1.0, 0.3, 0.7], [0.5, 1.0, 0.45], [1.0, 0.55, 0.2], [0.7, 0.5, 1.0]];

export class Engine {
  readonly camera: Camera;
  readonly env: Environment;
  readonly renderer: Renderer;
  readonly scene: SceneData;
  readonly baked: BakedVolume[];
  readonly info: EngineInfo;
  settings: Settings = { ...defaultSettings };
  timePlaying = false;
  /** hours of in-game time per real second */
  timeSpeed = 0.35;
  fps = 0;
  frameMs = 0;

  private raf = 0;
  private last = 0;
  private colorIdx = 0;
  private running = false;

  private constructor(canvas: HTMLCanvasElement, scene: SceneData, baked: BakedVolume[], bake: BakeStats) {
    this.scene = scene;
    this.baked = baked;
    this.env = new Environment(scene.lights);
    this.camera = new Camera(canvas);
    this.camera.setTour(scene.tour);
    this.renderer = new Renderer(canvas, scene, baked, this.env);
    const gl = this.renderer.gl;
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    this.info = {
      triangles: scene.triangleCount, vertices: scene.vertexCount, trees: scene.treeCount, chunks: scene.chunks.length,
      probes: this.renderer.gi.probeCount,
      volumes: this.renderer.gi.volumes.map((v) => ({
        name: v.baked.def.name, probes: v.baked.probeCount, spacing: v.baked.def.spacing, dims: v.baked.def.dims,
        invalid: v.baked.invalidProbes, mb: v.bytes / 1048576,
      })),
      bake, giMB: this.renderer.gi.gpuBytes / 1048576, maxTex: gl.getParameter(gl.MAX_TEXTURE_SIZE),
      renderer: dbg ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)) : 'WebGL2',
    };
    window.addEventListener('keydown', this.onKey);
  }

  static async create(canvas: HTMLCanvasElement, onProgress: Progress): Promise<Engine> {
    onProgress(0.0, 'Generating procedural scene…');
    await new Promise((r) => setTimeout(r, 30));
    const scene = generateScene();

    // query the real texture limit before baking (atlas layout depends on it)
    const probe = document.createElement('canvas').getContext('webgl2');
    if (!probe) throw new Error('WebGL2 is not available in this browser.');
    const maxTex = Math.min(4096, probe.getParameter(probe.MAX_TEXTURE_SIZE) as number);

    const { volumes, stats } = await bakeScene(scene, maxTex, (f, m) => onProgress(0.02 + f * 0.88, m));
    onProgress(0.92, 'Uploading probe surface caches to the GPU…');
    await new Promise((r) => setTimeout(r, 30));
    const engine = new Engine(canvas, scene, volumes, stats);
    onProgress(0.96, 'Relighting probes (converging multi-bounce)…');
    await new Promise((r) => setTimeout(r, 30));
    engine.renderer.warmup(engine.settings, 6);
    onProgress(1.0, 'Ready');
    return engine;
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    const loop = (now: number) => {
      if (!this.running) return;
      const dt = Math.min(0.1, (now - this.last) / 1000);
      this.last = now;
      this.frameMs += (dt * 1000 - this.frameMs) * 0.05;
      this.fps += (1 / Math.max(dt, 1e-4) - this.fps) * 0.05;
      if (this.timePlaying) this.env.setTime(this.env.timeOfDay + dt * this.timeSpeed);
      this.renderer.render(this.camera, dt, this.settings);
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  stop() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKey);
    this.camera.dispose();
  }

  get stats(): FrameStats { return this.renderer.stats; }

  setTime(h: number) { this.env.setTime(h); }

  addLightAtCamera() {
    const v = this.camera.view;
    const f: Vec3 = [-v[2], -v[6], -v[10]];
    const p = this.camera.pos;
    const c = LIGHT_COLORS[this.colorIdx++ % LIGHT_COLORS.length];
    this.env.addUserLight([p[0] + f[0] * 3.5, p[1] + f[1] * 3.5, p[2] + f[2] * 3.5], c);
  }
  clearLights() { this.env.clearUserLights(); }
  resetGI() { this.renderer.resetGI(); }

  exportBake() {
    const blob = exportDRTV(this.baked, this.scene);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'compound.drtv';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    return blob.size;
  }

  private onKey = (e: KeyboardEvent) => {
    if ((e.target as HTMLElement)?.tagName === 'INPUT' && (e.target as HTMLInputElement).type === 'text') return;
    const k = e.key.toLowerCase();
    if (k === 'f') this.addLightAtCamera();
    else if (k === 'g') this.clearLights();
    else if (k === 't') { if (this.camera.mode === 'tour') this.camera.mode = 'free'; else this.camera.startTour(); }
  };
}
