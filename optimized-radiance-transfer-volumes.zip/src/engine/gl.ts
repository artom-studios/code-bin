/**
 * Thin WebGL2 helper layer: programs, uniform cache, render targets and GPU timers.
 * Intentionally small so every call maps 1:1 to D3D11/Vulkan/Metal concepts when porting.
 */

/** Fixed texture-unit map. Every sampler in the pipeline owns a unique unit so that
 *  sampler types never alias on a unit (a WebGL validation rule). */
export const TU = {
  GEO: 0, ALB: 1, OFF: 2, SHADOW: 3,
  SH_R: 4, SH_G: 5, SH_B: 6,
  GL_R: 7, GL_G: 8, GL_B: 9,
  RAD: 10, DEPTH: 11, GB_ALB: 12, GB_NRM: 13, GI: 14, AO: 15,
} as const;

const HEADER = `#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
precision highp sampler3D;
precision highp sampler2DShadow;
`;

function compile(gl: WebGL2RenderingContext, type: number, src: string, name: string): WebGLShader {
  const sh = gl.createShader(type)!;
  gl.shaderSource(sh, src);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
    const log = gl.getShaderInfoLog(sh) || '';
    const lines = src.split('\n').map((l, i) => `${String(i + 1).padStart(4)}| ${l}`).join('\n');
    console.error(`Shader compile error in ${name}:\n${log}\n${lines}`);
    throw new Error(`Shader compile error in ${name}: ${log}`);
  }
  return sh;
}

export class Program {
  readonly prog: WebGLProgram;
  private locs = new Map<string, WebGLUniformLocation | null>();

  constructor(
    private gl: WebGL2RenderingContext,
    readonly name: string,
    vs: string,
    fs: string,
    attribs?: Record<string, number>,
  ) {
    const p = gl.createProgram()!;
    gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, HEADER + vs, name + '.vs'));
    gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, HEADER + fs, name + '.fs'));
    if (attribs) for (const [k, v] of Object.entries(attribs)) gl.bindAttribLocation(p, v, k);
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
      throw new Error(`Program link error in ${name}: ${gl.getProgramInfoLog(p)}`);
    }
    this.prog = p;
  }

  use() { this.gl.useProgram(this.prog); return this; }

  loc(n: string) {
    let l = this.locs.get(n);
    if (l === undefined) {
      l = this.gl.getUniformLocation(this.prog, n);
      this.locs.set(n, l);
    }
    return l;
  }

  /** Bind sampler uniforms to fixed texture units (call once after creation). */
  samplers(map: Record<string, number>) {
    this.use();
    for (const [k, v] of Object.entries(map)) {
      const l = this.loc(k);
      if (l) this.gl.uniform1i(l, v);
    }
    return this;
  }
  i1(n: string, v: number) { const l = this.loc(n); if (l) this.gl.uniform1i(l, v); }
  f1(n: string, v: number) { const l = this.loc(n); if (l) this.gl.uniform1f(l, v); }
  f2(n: string, a: number, b: number) { const l = this.loc(n); if (l) this.gl.uniform2f(l, a, b); }
  f3(n: string, a: number, b: number, c: number) { const l = this.loc(n); if (l) this.gl.uniform3f(l, a, b, c); }
  f4(n: string, a: number, b: number, c: number, d: number) { const l = this.loc(n); if (l) this.gl.uniform4f(l, a, b, c, d); }
  i3(n: string, a: number, b: number, c: number) { const l = this.loc(n); if (l) this.gl.uniform3i(l, a, b, c); }
  m4(n: string, m: Float32Array) { const l = this.loc(n); if (l) this.gl.uniformMatrix4fv(l, false, m); }
  f4v(n: string, v: Float32Array) { const l = this.loc(n); if (l) this.gl.uniform4fv(l, v); }
  f3v(n: string, v: Float32Array) { const l = this.loc(n); if (l) this.gl.uniform3fv(l, v); }
}

export function bindTex(gl: WebGL2RenderingContext, unit: number, target: number, tex: WebGLTexture | null) {
  gl.activeTexture(gl.TEXTURE0 + unit);
  gl.bindTexture(target, tex);
}

export interface Tex2DOpts {
  internal: number; format: number; type: number;
  filter?: number; wrap?: number;
  data?: ArrayBufferView | null;
}

export function createTex2D(gl: WebGL2RenderingContext, w: number, h: number, o: Tex2DOpts): WebGLTexture {
  const t = gl.createTexture()!;
  gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texImage2D(gl.TEXTURE_2D, 0, o.internal, w, h, 0, o.format, o.type, (o.data ?? null) as ArrayBufferView | null);
  const f = o.filter ?? gl.NEAREST;
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, f);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, f);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, o.wrap ?? gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, o.wrap ?? gl.CLAMP_TO_EDGE);
  return t;
}

export function createTex3D(gl: WebGL2RenderingContext, w: number, h: number, d: number, internal: number, format: number, type: number): WebGLTexture {
  const t = gl.createTexture()!;
  gl.bindTexture(gl.TEXTURE_3D, t);
  gl.texImage3D(gl.TEXTURE_3D, 0, internal, w, h, d, 0, format, type, null);
  gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_R, gl.CLAMP_TO_EDGE);
  return t;
}

export function checkFbo(gl: WebGL2RenderingContext, name: string) {
  const s = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
  if (s !== gl.FRAMEBUFFER_COMPLETE) throw new Error(`Framebuffer '${name}' incomplete: 0x${s.toString(16)}`);
}

export function createFbo(gl: WebGL2RenderingContext, name: string, colors: (WebGLTexture | null)[], depth?: WebGLTexture | null): WebGLFramebuffer {
  const f = gl.createFramebuffer()!;
  gl.bindFramebuffer(gl.FRAMEBUFFER, f);
  const bufs: number[] = [];
  colors.forEach((c, i) => {
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0 + i, gl.TEXTURE_2D, c, 0);
    bufs.push(gl.COLOR_ATTACHMENT0 + i);
  });
  if (colors.length === 0) { gl.drawBuffers([gl.NONE]); gl.readBuffer(gl.NONE); }
  else gl.drawBuffers(bufs);
  if (depth) gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, depth, 0);
  checkFbo(gl, name);
  return f;
}

/**
 * Asynchronous GPU timer based on EXT_disjoint_timer_query_webgl2.
 * Gracefully degrades to a no-op when the extension is unavailable.
 */
export class GpuTimer {
  private ext: any;
  private pending: { label: string; q: WebGLQuery }[] = [];
  private free: WebGLQuery[] = [];
  private active: { label: string; q: WebGLQuery } | null = null;
  readonly ms = new Map<string, number>();
  readonly supported: boolean;

  constructor(private gl: WebGL2RenderingContext) {
    this.ext = gl.getExtension('EXT_disjoint_timer_query_webgl2');
    this.supported = !!this.ext;
  }

  begin(label: string) {
    if (!this.ext || this.active) return;
    const q = this.free.pop() ?? this.gl.createQuery()!;
    this.gl.beginQuery(this.ext.TIME_ELAPSED_EXT, q);
    this.active = { label, q };
  }

  end() {
    if (!this.ext || !this.active) return;
    this.gl.endQuery(this.ext.TIME_ELAPSED_EXT);
    this.pending.push(this.active);
    this.active = null;
  }

  /** Call once per frame to harvest finished queries. */
  poll() {
    if (!this.ext) return;
    const gl = this.gl;
    const disjoint = gl.getParameter(this.ext.GPU_DISJOINT_EXT);
    const keep: typeof this.pending = [];
    for (const p of this.pending) {
      if (gl.getQueryParameter(p.q, gl.QUERY_RESULT_AVAILABLE)) {
        if (!disjoint) {
          const ns = gl.getQueryParameter(p.q, gl.QUERY_RESULT) as number;
          const prev = this.ms.get(p.label) ?? ns / 1e6;
          this.ms.set(p.label, prev + (ns / 1e6 - prev) * 0.1);
        }
        this.free.push(p.q);
      } else keep.push(p);
    }
    this.pending = keep.length > 64 ? keep.slice(-64) : keep;
  }
}
