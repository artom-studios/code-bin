import { useState, type ReactNode } from 'react';
import { cn } from '@/utils/cn';

export function Section({ title, children, defaultOpen = true, badge }: { title: string; children: ReactNode; defaultOpen?: boolean; badge?: ReactNode }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-white/5 last:border-0">
      <button onClick={() => setOpen(!open)} className="flex w-full items-center justify-between px-4 py-2.5 text-left hover:bg-white/[0.03] transition-colors">
        <span className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-300">
          {title}
          {badge}
        </span>
        <svg className={cn('h-3 w-3 text-zinc-500 transition-transform', open && 'rotate-90')} viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path d="M4 2l4 4-4 4" />
        </svg>
      </button>
      {open && <div className="space-y-3 px-4 pb-4 pt-1">{children}</div>}
    </div>
  );
}

export function Slider({ label, value, min, max, step, onChange, format }: {
  label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; format?: (v: number) => string;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <label className="block">
      <div className="mb-1 flex justify-between text-[11px]">
        <span className="text-zinc-400">{label}</span>
        <span className="font-mono text-zinc-200">{format ? format(value) : value.toFixed(2)}</span>
      </div>
      <input
        type="range" min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="drtv-range w-full"
        style={{ background: `linear-gradient(to right, #f59e0b ${pct}%, rgba(255,255,255,0.12) ${pct}%)` }}
      />
    </label>
  );
}

export function Toggle({ label, value, onChange, hint }: { label: string; value: boolean; onChange: (v: boolean) => void; hint?: string }) {
  return (
    <button onClick={() => onChange(!value)} className="flex w-full items-center justify-between text-left">
      <span className="text-[12px] text-zinc-300">
        {label}
        {hint && <span className="ml-2 text-[10px] text-zinc-500">{hint}</span>}
      </span>
      <span className={cn('relative h-4 w-8 rounded-full transition-colors', value ? 'bg-amber-500' : 'bg-white/15')}>
        <span className={cn('absolute top-0.5 h-3 w-3 rounded-full bg-white shadow transition-all', value ? 'left-[18px]' : 'left-0.5')} />
      </span>
    </button>
  );
}

export function Segmented<T extends string | number>({ options, value, onChange }: { options: { label: string; value: T }[]; value: T; onChange: (v: T) => void }) {
  return (
    <div className="flex flex-wrap gap-1">
      {options.map((o) => (
        <button
          key={String(o.value)} onClick={() => onChange(o.value)}
          className={cn(
            'rounded px-2 py-1 text-[11px] transition-colors',
            o.value === value ? 'bg-amber-500 font-semibold text-black' : 'bg-white/8 text-zinc-300 hover:bg-white/15',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Button({ children, onClick, variant = 'default', className }: { children: ReactNode; onClick: () => void; variant?: 'default' | 'primary'; className?: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'rounded-md px-3 py-1.5 text-[11px] font-medium transition-colors',
        variant === 'primary' ? 'bg-amber-500 text-black hover:bg-amber-400' : 'bg-white/10 text-zinc-200 hover:bg-white/20',
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Kbd({ children }: { children: ReactNode }) {
  return <kbd className="rounded border border-white/15 bg-white/10 px-1.5 py-0.5 font-mono text-[10px] text-zinc-200">{children}</kbd>;
}
