# DRTV – Deferred Radiance Transfer Volumes (WebGL2)

A production-structured, heavily optimised reproduction of the *Far Cry 3* global illumination system
on a 200 m procedural jungle-compound scene: hollow temple with light-well, village, gallery, 300 trees.

* Worker-pool CPU bake (BVH, probe relocation) → 33 k probes / 2.1 M rays in a few seconds
* Fully dynamic GPU relight + L1 SH + multi-bounce feedback, time-sliced, temporal blending
* Hierarchical volumes with edge blending, half-res deferred apply with bilateral upsample
* Time of day, dynamic lights (press **F**), debug views, probe visualiser, GPU pass timers
* `.drtv` export for your engine – see `docs/PORTING.md`

Controls: WASD/QE move · Shift sprint · drag look · F drop light · G clear · T tour/free · H hide UI.
