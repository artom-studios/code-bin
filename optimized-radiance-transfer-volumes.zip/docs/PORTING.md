# Deferred Radiance Transfer Volumes – porting guide

Reference implementation of the technique used for global illumination in *Far Cry 3*
(Gautron et al., GDC 2012), written for WebGL2/TypeScript with an engine-neutral structure.

## 1. Idea in one paragraph
Offline, every probe of a regular 3D grid captures a low-resolution **surface cache** of its
surroundings (hit distance, normal, albedo, sky/invalid flag) – *not* lighting. At runtime the
cache is **relit** on the GPU with the current sun/moon, sky, dynamic lights and the previous
frame's probe irradiance (multi-bounce feedback), **projected to L1 SH**, temporally blended
into 3D textures, and finally **applied deferred** by sampling those volumes from the G-buffer.
Time of day, dynamic lights and bounce all work with zero re-baking.

## 2. Source map
| File | Role | Port to |
|---|---|---|
| `bvh.ts`, `bake.ts`, `bake.worker.ts`, `bakeService.ts` | Offline bake (CPU ray tracing, probe relocation) | Your lightmapper / tool pipeline (can be replaced by GPU RT or cubemap capture) |
| `exportBake.ts` | `.drtv` binary format (documented in file header) | Load directly in the engine |
| `shaders/relight_fs.glsl` | Pass 1 – relight surface cache | Compute shader, 1 thread / sample |
| `shaders/sh_fs.glsl` | Pass 2 – SH projection + temporal blend | Compute shader, 1 group / probe (64 lanes = 64 samples, wave reduction) |
| `shaders/giapply_fs.glsl` | Pass 3 – deferred volume application | Volume box / scissored quad in your deferred lighting stage |
| `gi.ts` | Volume resources, scheduler, apply, debug | Engine GI module |
| `shaders/common.glsl` | Octahedral maps, SH eval, sky, shadow tap, light loop | Shared include |

## 3. Data formats
* **Probe grid**: `origin + (ix,iy,iz) * spacing (+ relocation offset)`; multiple volumes (coarse world + fine local) blended by an edge fade – later volumes override earlier ones with `src_alpha` blending.
* **Surface cache**: 8×8 octahedral tile per probe (64 rays). Atlas layout: layers (Y slices) are `nx*8 × nz*8` blocks tiled `cols × rows`.
  * `geo`  RGBA16F: `dist, oct.xy, flag` (0 surface, 1 sky, 2 invalid/back-face)
  * `alb`  RGBA8: sRGB albedo
  * `off`  RGBA16F, one texel per probe: relocation xyz + validity
* **SH volume**: 3× RGBA16F 3D textures (one per colour channel), texture dims `(nx, nz, ny)` so every Y layer is one render slice. Content is **E(n)/π, pre-convolved with the cosine lobe**: `vec4(c0, cY, cZ, cX)`; evaluate with `c0 + dot(c.yzw, n.yzx)`.
* **Memory** (this scene): 32,833 probes, 2.1 M samples ≈ 33 MB GPU (12 B/sample cache + 4 B radiance + SH).

## 4. Frame cost model
* Relight cost ∝ *updated probes × 64*. The scheduler updates `budget` Y-layers per frame (round-robin, un-initialised layers first). Typical: 6 layers ≈ 5 k probes ≈ 330 k texels/frame.
* Apply cost ∝ visible volume pixels at half resolution (bilateral depth/normal upsample in the lighting pass).
* Shadow map is re-rendered only when the light direction changes; one world-covering ortho map is shared by the main pass **and** the probe relight (the key trick that makes relighting hit points shadowed).

## 5. Porting checklist
1. Replace `bakeService` with your own bake; keep the `.drtv` layout or the atlas layout above.
2. Convert the fragment passes to compute (relight + SH can be fused: one group per probe, 64 threads, LDS reduction – removes the radiance texture entirely).
3. Store SH in whatever 3D format you like (L1 fits in 3×RGBA16F; L2 is a straightforward extension: change `sh_fs`, `shEval`).
4. Feed the engine's real sky/atmosphere to `skyRadiance()` and your CSM/shadow query to `shadowTap1()`.
5. Replace the dynamic light loop with your clustered light list (local lights bounce for free once they are in the relight pass).
6. Add engine-side probe validity / light-leak mitigation as needed (normal bias is already applied; relocation handles probes inside geometry).
7. Time-slice by importance (camera distance, dirty volumes) instead of plain round robin.

## 6. Known limitations (by design, same as the original)
* Local lights are unshadowed in the probe pass (the demo confines interior torches with an AABB).
* L1 SH is low-frequency: no glossy GI; contact detail comes from SSAO.
* Static geometry only for the bake; dynamic occluders need separate treatment (e.g. capsule AO).
