import type { ReactNode } from "react";

const H = ({ children }: { children: ReactNode }) => <h3 className="mt-7 text-[11px] font-semibold uppercase tracking-[0.16em] text-amber-300/90">{children}</h3>;
const P = ({ children }: { children: ReactNode }) => <p className="mt-2 text-[13px] leading-relaxed text-slate-400">{children}</p>;
const B = ({ children }: { children: ReactNode }) => <strong className="text-slate-200">{children}</strong>;

function Table({ head, rows }: { head: string[]; rows: string[][] }) {
  return (
    <div className="mt-3 overflow-x-auto rounded-xl border border-white/10">
      <table className="w-full min-w-[34rem] text-left text-[12px]">
        <thead className="bg-white/5 text-[10px] uppercase tracking-wider text-slate-400">
          <tr>
            {head.map((h) => (
              <th key={h} className="px-3 py-2 font-semibold">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-white/5 text-slate-400">
          {rows.map((r, i) => (
            <tr key={i}>
              {r.map((c, j) => (
                <td key={j} className={j === 0 ? "px-3 py-2 font-medium text-slate-200" : "px-3 py-2"}>
                  {c}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function AboutModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-3 backdrop-blur-sm sm:p-6" onClick={onClose}>
      <div className="relative max-h-full w-full max-w-3xl overflow-y-auto rounded-2xl border border-white/10 bg-slate-900 p-5 shadow-2xl sm:p-8" onClick={(e) => e.stopPropagation()}>
        <button type="button" onClick={onClose} className="absolute right-4 top-4 rounded-full bg-white/10 px-3 py-1 text-xs text-slate-200 hover:bg-white/20">
          Close
        </button>
        <h2 className="pr-16 text-xl font-semibold text-white">RadLUT v2: normal maps, dynamic objects, dynamic lights</h2>
        <P>
          The idea of v1 stays: a world-space table keyed by <B>(cell, face)</B> holds NxN radiance tiles, so there are no UVs and no lightmap unwrap, and runtime is one cheap lookup. v2 changes
          <em> what is stored</em> so the table can answer three more questions without growing the per-pixel cost much.
        </P>

        <H>The one structural change: split delta-light direct from smooth indirect</H>
        <P>
          v1 baked <code>cos(N·L)·visibility</code> into the tile. That freezes the normal and the light position into the data, which is exactly what normal maps, moving objects and moving
          lights break. v2 bakes only <B>visibility</B> (a soft 0..1 scalar per delta light) and the <B>indirect transfer</B>; the cosine and the distance falloff are evaluated per pixel with
          whatever normal and light position exist at runtime. The sky has no delta direction, so it stays a transfer channel and gets a baked directional gradient.
        </P>

        <H>1 · Normal maps: +0 fetches</H>
        <Table
          head={["Term", "How", "Cost"]}
          rows={[
            ["Sun / lamp direct", "baked visibility × analytic max(0, n′·L) (gated by the geometric normal)", "~10 ALU, exact"],
            ["Indirect", "isotropic wrap (1 + n′·N)/2 on the baked transfer", "1 dot"],
            ["Sky through the window", "baked 2-value luminance gradient along the face tangents: E(n′) = E·wrap + E_sky·(g_u δu + g_v δv)", "2 MAD, data in RGBA8"],
            ["Tangent frame", "free: faces are axis-aligned, bump is a solid world-space height field", "no UVs, no tangents"],
          ]}
        />
        <P>
          Measured at bake time against path-traced ground truth with tilted normals (see inspector): ignoring the map is ~20% off, analytic direct brings it to ~8%, and in sky-dominated
          lighting the gradient halves the error again (20% → 11%, the same floor as flat normals). The remaining error is lattice resolution and baked-indirect noise, not the relight model.
        </P>

        <H>2 · Dynamic objects: receive and cast</H>
        <Table
          head={["Part", "How", "Cost"]}
          rows={[
            ["Receive indirect", "L1 SH probe grid (0.5 m). Probes are gathered with ONE ray per direction that reads the finished LUT, so the bounce count is infinite and noise is near zero; baked in ~0.7 s", "CPU samples 8 probes per object per frame → 4 uniforms; 0 fetches"],
            ["Receive sun / lamp", "static visibility + SDF volume (RGBA8 3D, 10 cm), trilinear → soft static shadows on the object", "1 × 3D fetch / pixel"],
            ["Cast shadows", "analytic soft sphere shadows on the sun, the lamp and dynamic lights", "~12 ALU / sphere / light"],
            ["Cast occlusion + colour bleed", "indirect·(1 − occ) + occ·albedo·radiance, occ = solid angle × cos / π", "~12 ALU / sphere"],
          ]}
        />
        <P>
          Limits: the L1 probe is weak for a narrow window or sun-bounce (25% error in sky-only lighting, ~6% with the default lights); proxies are spheres; light bounced off a moving object onto
          the world is the cheap occ·radiance term, not transport.
        </P>

        <H>3 · Dynamic lights: three honest tiers</H>
        <Table
          head={["Tier", "What you get", "Cost", "Status"]}
          rows={[
            ["Gain / colour of baked lights", "exact, includes all bounces", "0", "v1, still free"],
            ["Free point light, direct", "analytic cos/d² with the normal-mapped normal, dynamic-sphere shadows", "~20 ALU / light", "implemented"],
            ["+ static shadows", "SDF soft shadow ray march (8 or 16 steps, early-out when unlit)", "8-16 × 3D fetch / light", "implemented, optional"],
            ["+ bounce", "heuristic fill tinted by the LUT's own chroma, softened by distance", "~12 ALU / light", "implemented, NOT physical"],
            ["Light on a rail / keyframes", "bake indirect at a few anchors and lerp: anchors are just extra transfer channels, which the low-rank coding absorbs at no fetch cost", "0 GPU", "not implemented"],
          ]}
        />
        <P>
          There is no way to get <em>correct</em> indirect for an arbitrarily moving light from a lookup alone: indirect depends on where the light hits. Use the rail / keyframe tier where
          you can, and the fill only as a mood. Use <B>Compare</B> + “Measure image error” to see the actual gap.
        </P>

        <H>Optimisation ledger</H>
        <Table
          head={["Change", "Effect", "Quality"]}
          rows={[
            ["Low-rank (PCA) light coding: 3 lights × RGB → 4 coefficients", "3 fetches → 1 RGBA16F + 1 RGBA8 aux (which also carries V and the gradient); 99.7% energy kept; adding lights adds no fetches until rank grows", "~+0.5 pt error"],
            ["Dense-grid index option", "no hashing at all: 1 integer fetch, ~6 int ops", "identical"],
            ["Perfect hash: power-of-two M and B, mask instead of %", "removes two integer divisions per face", "identical"],
            ["Perfect hash: face salt precomputed as a uniform, lighter 2nd mix", "−1 hash32, −1 multiply per face", "identical"],
            ["Atlas row = 128 tiles → shift/mask; 1/cell and 1/atlas as uniforms", "no divides in the fragment shader", "identical"],
            ["mediump colour math, highp only for position / hash / uv", "2× ALU rate on fp16-capable mobile GPUs", "identical (values < 65k)"],
            ["Visibility-only direct instead of baked cos·V", "exact spheres and normal maps, lamp falloff exact, smaller dynamic range → fewer coefficients", "better"],
            ["Probes from LUT gather instead of path tracing", "~100× fewer rays for the same noise; infinite bounces", "better"],
          ]}
        />
        <P>
          <B>Not implemented, still on the table:</B> (a) split static quads at cell borders and store the slot as a flat vertex attribute: removes the dependent index fetch completely; (b) per-vertex
          LUT evaluation for dynamic meshes; (c) face id as a vertex attribute for box meshes (skips the tri-planar weights); (d) ASTC / BC6H atlas compression (costs quality); (e) sharing tile borders
          instead of duplicating them (N=5 duplicates 1.56×); (f) a baked-only build that folds the gains into one fixed channel.
        </P>
        <P>
          <B>Rejected:</B> per-texel full L1 SH per light (4× data and ALU), per-texel ambient cube (6 fetches), per-pixel SH probe fetches for dynamic objects (4+ fetches for no visible gain).
        </P>

        <H>Honest caveats</H>
        <ul className="mt-2 space-y-1 text-[13px] text-slate-400">
          <li>• All timings in this repo were taken in a software GL; fetch counts are exact, ALU counts are hand counts. Profile on a real device before trusting the ranking of items.</li>
          <li>• Normal maps here are procedural solid height fields (a texture would add 1 fetch per material layer, nothing else changes).</li>
          <li>• Diffuse only. No glossy lobe; a specular term would reuse the sky gradient as a direction cue.</li>
          <li>• Dense grid memory grows with the bounding box; the perfect hash is the sparse fallback.</li>
        </ul>

        <H>Things to try</H>
        <ol className="mt-2 list-decimal space-y-1 pl-5 text-[13px] text-slate-400">
          <li>Normal maps: Off → Direct → +Dir while standing in front of the window; then Compare.</li>
          <li>Dynamic: drag the divider with Compare on; animation pauses so the reference can converge.</li>
          <li>Dynamic lights: toggle SDF shadows and bounce fill; switch the cell index between dense and hash (identical image).</li>
        </ol>
      </div>
    </div>
  );
}
