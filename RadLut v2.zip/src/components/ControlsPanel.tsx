import { GlassPanel, Section, Slider, Toggle, Seg, toHex, fromHex } from "./ui";
import { PRESETS } from "@/gi/camera";
import type { LightsState, LightState } from "@/gi/scene";
import { cn } from "@/utils/cn";
import { FeatureSections, type FeatureState } from "./FeatureSections";

export type Solo = "all" | "sun" | "sky" | "lamp";
export interface BakeSettings {
  step: number;
  N: number;
}

interface Props {
  lights: LightsState;
  setLight: (k: keyof LightsState, patch: Partial<LightState>) => void;
  solo: Solo;
  setSolo: (s: Solo) => void;
  exposure: number;
  setExposure: (v: number) => void;
  bake: BakeSettings;
  setBake: (b: BakeSettings) => void;
  preset: number;
  onPreset: (i: number) => void;
  tour: boolean;
  setTour: (v: boolean) => void;
  relights: number;
  rebakes: number;
  feat: FeatureState;
  setFeat: (p: Partial<FeatureState>) => void;
}

const LIGHT_META: { key: keyof LightsState; label: string; dot: string; max: number; note: string }[] = [
  { key: "sun", label: "Sun", dot: "bg-amber-300", max: 12, note: "directional · through window" },
  { key: "sky", label: "Sky", dot: "bg-sky-400", max: 6, note: "dome · seen via window" },
  { key: "lamp", label: "Lamp", dot: "bg-orange-400", max: 20, note: "point · hanging bulb" },
];

export function ControlsPanel(p: Props) {
  return (
    <GlassPanel title="Relight · zero rebakes" className="flex max-h-full flex-col overflow-hidden">
      <div className="min-h-0 flex-1 divide-y divide-white/5 overflow-y-auto">
        <FeatureSections f={p.feat} set={p.setFeat} />
        <Section title="Transfer channels" hint="LUT stores 1 table per light">
          <div className="space-y-3.5">
            {LIGHT_META.map((m) => {
              const l = p.lights[m.key];
              return (
                <div key={m.key} className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className={cn("h-2.5 w-2.5 rounded-full", m.dot, !l.on && "opacity-30")} />
                    <div className="flex-1 leading-tight">
                      <div className="text-xs font-medium text-slate-100">{m.label}</div>
                      <div className="text-[10px] text-slate-500">{m.note}</div>
                    </div>
                    <button
                      type="button"
                      title="Solo this channel (view its baked transfer only)"
                      onClick={() => p.setSolo(p.solo === m.key ? "all" : m.key)}
                      className={cn(
                        "rounded-md px-1.5 py-0.5 text-[10px] font-semibold transition-colors",
                        p.solo === m.key ? "bg-amber-400 text-slate-950" : "bg-white/10 text-slate-400 hover:text-white",
                      )}
                    >
                      SOLO
                    </button>
                    <input
                      type="color"
                      value={toHex(l.color)}
                      onChange={(e) => p.setLight(m.key, { color: fromHex(e.target.value) })}
                      className="h-6 w-6 cursor-pointer rounded border-0 bg-transparent p-0"
                      aria-label={`${m.label} colour`}
                    />
                    <Toggle checked={l.on} onChange={(v) => p.setLight(m.key, { on: v })} label={`${m.label} on/off`} />
                  </div>
                  <Slider
                    value={l.intensity}
                    min={0}
                    max={m.max}
                    step={0.05}
                    disabled={!l.on}
                    onChange={(v) => p.setLight(m.key, { intensity: v })}
                    format={(v) => v.toFixed(1)}
                  />
                </div>
              );
            })}
            <Slider label="Exposure" value={p.exposure} min={0.2} max={3} step={0.01} onChange={p.setExposure} format={(v) => `${v.toFixed(2)}×`} />
            <div className="flex items-center justify-between rounded-lg bg-white/[0.04] px-3 py-2 font-mono text-[11px]">
              <span className="text-slate-400">
                relights <span className="text-amber-300">{p.relights}</span>
              </span>
              <span className="text-slate-400">
                rebakes <span className="text-emerald-300">{p.rebakes}</span>
              </span>
            </div>
          </div>
        </Section>

        <Section title="Bake resolution" hint="changing this rebakes">
          <div className="space-y-2">
            <div>
              <div className="mb-1 text-[11px] text-slate-400">Lattice step</div>
              <Seg
                value={p.bake.step}
                onChange={(step) => p.setBake({ ...p.bake, step })}
                options={[
                  { value: 0.25, label: "25 cm" },
                  { value: 0.125, label: "12.5 cm" },
                  { value: 0.0625, label: "6 cm" },
                ]}
              />
            </div>
            <div>
              <div className="mb-1 text-[11px] text-slate-400">Tile size (texels per side)</div>
              <Seg
                value={p.bake.N}
                onChange={(N) => p.setBake({ ...p.bake, N })}
                options={[
                  { value: 2, label: "2²", title: "4x redundancy, finest keys" },
                  { value: 3, label: "3²" },
                  { value: 5, label: "5²" },
                  { value: 9, label: "9²" },
                ]}
              />
            </div>
            <p className="text-[10px] leading-relaxed text-slate-500">
              Tile covers <span className="font-mono text-slate-300">{(p.bake.step * (p.bake.N - 1) * 100).toFixed(0)} cm</span>. Small tiles duplicate
              border texels ({(((p.bake.N * p.bake.N) / ((p.bake.N - 1) * (p.bake.N - 1))) * 100 - 100).toFixed(0)}% extra); big tiles waste texels on
              partly covered cells. Watch the memory bars.
            </p>
          </div>
        </Section>

        <Section title="Camera">
          <div className="grid grid-cols-2 gap-1.5">
            {PRESETS.map((pr, i) => (
              <button
                key={pr.name}
                type="button"
                onClick={() => p.onPreset(i)}
                className={cn(
                  "rounded-lg px-2 py-1.5 text-left text-[11px] transition-colors",
                  i === p.preset && !p.tour ? "bg-white/15 text-white" : "bg-white/5 text-slate-400 hover:bg-white/10 hover:text-slate-100",
                )}
              >
                {pr.name}
              </button>
            ))}
            <button
              type="button"
              onClick={() => p.setTour(!p.tour)}
              className={cn(
                "rounded-lg px-2 py-1.5 text-left text-[11px] font-medium transition-colors",
                p.tour ? "bg-amber-400 text-slate-950" : "bg-white/5 text-slate-400 hover:bg-white/10 hover:text-slate-100",
              )}
            >
              {p.tour ? "● Auto tour" : "Auto tour"}
            </button>
          </div>
          <p className="text-[10px] leading-relaxed text-slate-500">Drag to look · WASD / QE to move · wheel to dolly · Shift = fast</p>
        </Section>
      </div>
    </GlassPanel>
  );
}
