import { Section, Slider, Toggle, Seg } from "./ui";

export interface FeatureState {
  nm: number;
  bump: number;
  idxMode: number;
  dynObjects: boolean;
  animate: boolean;
  nLights: number;
  lightGain: number;
  lShadow: number;
  fill: boolean;
}
export const FEATURE_DEFAULT: FeatureState = { nm: 3, bump: 1, idxMode: 1, dynObjects: true, animate: true, nLights: 1, lightGain: 1, lShadow: 1, fill: true };

const Row = ({ label, note, children }: { label: string; note?: string; children: React.ReactNode }) => (
  <div className="flex items-center gap-2">
    <div className="flex-1 leading-tight">
      <div className="text-xs font-medium text-slate-100">{label}</div>
      {note && <div className="text-[10px] text-slate-500">{note}</div>}
    </div>
    {children}
  </div>
);

export function FeatureSections({ f, set }: { f: FeatureState; set: (p: Partial<FeatureState>) => void }) {
  return (
    <>
      <Section title="Normal maps" hint="+0 texture fetches">
        <Seg
          value={f.nm}
          onChange={(v) => set({ nm: v })}
          options={[
            { value: 0, label: "Off", title: "geometric normal only" },
            { value: 1, label: "Direct", title: "analytic sun/lamp with the bumped normal; indirect is not relit" },
            { value: 2, label: "+Wrap", title: "+ isotropic wrap on the indirect" },
            { value: 3, label: "+Dir", title: "+ baked sky gradient (full method)" },
          ]}
        />
        <Slider label="Bump strength" value={f.bump} min={0} max={3} step={0.05} onChange={(v) => set({ bump: v })} format={(v) => v.toFixed(2) + "×"} disabled={f.nm === 0} />
        <p className="text-[10px] leading-relaxed text-slate-500">
          Solid world-space bump (no UVs / tangents). Direct light is baked as visibility only, so its response to the bumped normal is exact; the sky term carries a
          baked 2-value gradient.
        </p>
      </Section>

      <Section title="Dynamic objects" hint="receive + cast">
        <Row label="Moving balls" note="probe SH + visibility volume">
          <Toggle checked={f.dynObjects} onChange={(v) => set({ dynObjects: v })} label="dynamic objects" />
        </Row>
        <Row label="Animate" note="pauses automatically while comparing">
          <Toggle checked={f.animate} onChange={(v) => set({ animate: v })} label="animate" />
        </Row>
      </Section>

      <Section title="Dynamic lights" hint="not baked">
        <Seg
          value={f.nLights}
          onChange={(v) => set({ nLights: v })}
          options={[
            { value: 0, label: "0" },
            { value: 1, label: "1 orb" },
            { value: 2, label: "2 orbs" },
          ]}
        />
        <Slider label="Intensity" value={f.lightGain} min={0} max={3} step={0.05} onChange={(v) => set({ lightGain: v })} format={(v) => v.toFixed(2) + "×"} disabled={f.nLights === 0} />
        <div className="text-[11px] text-slate-400">Static-scene shadows</div>
        <Seg
          value={f.lShadow}
          onChange={(v) => set({ lShadow: v })}
          options={[
            { value: 0, label: "None" },
            { value: 1, label: "SDF · 8" },
            { value: 2, label: "SDF · 16" },
          ]}
        />
        <Row label="Bounce fill" note="LUT-tinted, heuristic">
          <Toggle checked={f.fill} onChange={(v) => set({ fill: v })} label="bounce fill" />
        </Row>
      </Section>

      <Section title="Cell index" hint="same atlas, 2 indexers">
        <Seg
          value={f.idxMode}
          onChange={(v) => set({ idxMode: v })}
          options={[
            { value: 1, label: "Dense grid", title: "1 integer fetch, no hashing" },
            { value: 0, label: "Perfect hash", title: "sparse, scales to big worlds" },
          ]}
        />
      </Section>
    </>
  );
}
