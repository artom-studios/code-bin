import { GlassPanel, Section, Stat, fmtBytes } from "./ui";
import type { BakeState } from "@/gi/useBaker";
import { cn } from "@/utils/cn";
import type { FeatureState } from "./FeatureSections";

function MemBar({ label, bytes, max, tone, note }: { label: string; bytes: number; max: number; tone: string; note?: string }) {
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between text-[11px]">
        <span className="text-slate-300">{label}</span>
        <span className="font-mono text-slate-100">{fmtBytes(bytes)}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-white/5">
        <div className={cn("h-full rounded-full transition-all duration-500", tone)} style={{ width: `${Math.max(2, (bytes / max) * 100)}%` }} />
      </div>
      {note && <div className="mt-0.5 text-[10px] text-slate-500">{note}</div>}
    </div>
  );
}

const Row = ({ k, v, sub }: { k: string; v: string; sub?: string }) => (
  <div className="flex items-baseline justify-between gap-2 border-b border-white/5 py-1 text-[11px] last:border-0">
    <span className="text-slate-400">{k}</span>
    <span className="text-right font-mono text-slate-100">
      {v}
      {sub && <span className="ml-1 text-[10px] text-slate-500">{sub}</span>}
    </span>
  </div>
);

export function InspectorPanel({
  bake,
  fps,
  tileN,
  step,
  feat,
  imgErr,
  canMeasure,
  onMeasure,
}: {
  bake: BakeState;
  fps: number;
  tileN: number;
  step: number;
  feat: FeatureState;
  imgErr: { err: number; spp: number } | null;
  canMeasure: boolean;
  onMeasure: () => void;
}) {
  const s = bake.stats;
  const v = bake.validation;
  const pca = bake.pca;
  const max = s ? Math.max(s.totalBytes, s.lightmapBytes, s.volumeBytes) : 1;
  const pct = (x: number) => `${(x * 100).toFixed(1)}%`;
  const dense = feat.idxMode === 1;
  const fetchesFlat = `${dense ? "1 int" : "1 int"} + 2`;
  return (
    <GlassPanel title="LUT inspector" className="flex max-h-full flex-col overflow-hidden" right={<span className="font-mono text-[11px] text-slate-400">{fps.toFixed(0)} fps</span>}>
      <div className="min-h-0 flex-1 divide-y divide-white/5 overflow-y-auto">
        <Section title="Bake" hint={bake.phase === "done" ? "converged" : bake.phase === "error" ? "error" : "progressive"}>
          <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-300 to-orange-400 transition-all"
              style={{ width: `${bake.phase === "done" ? 100 : ((bake.pass + bake.frac) / bake.passes) * 100}%` }}
            />
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            <Stat label="Pass" value={`${bake.pass}/${bake.passes}`} />
            <Stat label="Samples" value={`${bake.totalSpp}`} sub="spp / point" />
            <Stat label="Time" value={`${(bake.elapsedMs / 1000).toFixed(1)}s`} sub={bake.firstUsableMs ? `usable @ ${(bake.firstUsableMs / 1000).toFixed(1)}s` : "…"} />
          </div>
          {bake.probeMs > 0 && (
            <p className="text-[10px] text-slate-500">
              probe grid (LUT gather) {bake.probeMs.toFixed(0)} ms · visibility/SDF volume {(bake.volumeMs / 1000).toFixed(1)}s
            </p>
          )}
          {bake.error && <pre className="max-h-24 overflow-auto rounded bg-red-500/10 p-2 text-[10px] text-red-300">{bake.error}</pre>}
        </Section>

        {s && (
          <>
            <Section title="Table" hint="key = (cell xyz, face)">
              <div className="grid grid-cols-2 gap-1.5">
                <Stat label="Tiles (keys)" value={s.entries.toLocaleString()} sub={`${tileN}×${tileN} texels each`} />
                <Stat label="Radiance texels" value={(s.entries * tileN * tileN).toLocaleString()} sub={`${s.corners.toLocaleString()} unique samples`} />
                <Stat label="Atlas slots" value={s.slots.toLocaleString()} sub={`pow2 · load ${pct(s.load)}`} />
                <Stat label="Tile size" value={`${(step * (tileN - 1) * 100).toFixed(0)} cm`} sub={`${(step * 100).toFixed(1)} cm texels`} />
              </div>
              <div className="rounded-lg bg-white/[0.04] px-2.5 py-2 text-[11px] leading-relaxed text-slate-400">
                Index: dense grid <span className="font-mono text-slate-200">{fmtBytes(s.denseBytes)}</span> (0 ALU) or perfect hash{" "}
                <span className="font-mono text-slate-200">{fmtBytes(s.dispBytes)}</span> (built in {s.attempts} attempt{s.attempts > 1 ? "s" : ""}, max displacement {s.maxDisp}, mask-only: no integer
                division).
              </div>
            </Section>

            <Section title="Light-channel coding" hint="PCA, runtime-linear">
              {pca ? (
                <>
                  <div className="space-y-1">
                    {pca.energy.slice(0, 6).map((e, i) => (
                      <div key={i} className="flex items-center gap-2 text-[10px] text-slate-400">
                        <span className="w-10">K = {i + 1}</span>
                        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/5">
                          <div className={cn("h-full rounded-full", i + 1 === pca.k ? "bg-amber-400" : "bg-slate-500")} style={{ width: `${e * 100}%` }} />
                        </div>
                        <span className="w-12 text-right font-mono text-slate-300">{(e * 100).toFixed(2)}%</span>
                      </div>
                    ))}
                  </div>
                  <p className="text-[10px] leading-relaxed text-slate-500">
                    3 lights × RGB = 9 numbers per texel collapse onto {pca.k} coefficients ({pct(pca.energy[pca.k - 1])} of the energy, {pct(pca.err)} RMS). One RGBA16F fetch replaces three RGB9E5 fetches; the
                    basis is folded with the light gains on the CPU, so relighting is still free.
                  </p>
                </>
              ) : (
                <div className="text-[11px] text-slate-500">…</div>
              )}
            </Section>

            <Section title="Memory" hint="static tiles only">
              <div className="space-y-2.5">
                <MemBar label="RadLUT v2 (this)" bytes={s.totalBytes} max={max} tone="bg-gradient-to-r from-amber-300 to-orange-400" note="RGBA16F coefficients + RGBA8 (V_sun, V_lamp, g_u, g_v)" />
                <MemBar label="RadLUT v1 layout" bytes={s.v1AtlasBytes} max={max} tone="bg-slate-500" note="3 × RGB9E5 · no normal-map or dynamic-object data" />
                <MemBar label="UV lightmap (ideal)" bytes={s.lightmapBytes} max={max} tone="bg-slate-400" note="needs UV unwrap · +35% gutters/packing assumed" />
                <MemBar label="Irradiance volume" bytes={s.volumeBytes} max={max} tone="bg-slate-600" note="dense ambient cube · scales with volume³" />
              </div>
            </Section>

            <Section title="Runtime cost / pixel" hint="counted from the shader">
              <div className="rounded-lg bg-white/[0.04] px-2.5 py-1">
                <Row k="Flat surface, v1" v="1 int + 3" sub="filtered" />
                <Row k="Flat surface, v2" v={fetchesFlat} sub="filtered" />
                <Row k="Curved (3 faces), v1 → v2" v="3+9 → 3+6" />
                <Row k="+ normal map" v="+0 fetch" sub="~25 ALU" />
                <Row k="Dynamic object" v="1 × 3D" sub="no LUT" />
                <Row k="+ dyn light, no shadow" v="+0 fetch" sub="~20 ALU" />
                <Row k="+ SDF shadow (8 / 16)" v="+8 / +16 × 3D" sub="early-out" />
                <Row k="+ sphere shadow + AO" v="+0 fetch" sub="~35 ALU / sphere" />
              </div>
              <p className="text-[10px] leading-relaxed text-slate-500">
                Fetch counts are exact; ALU numbers are hand counts, not GPU profiles. Colour math is <code>mediump</code>; world position, hashing and atlas UVs stay <code>highp</code>.
              </p>
            </Section>
          </>
        )}

        <Section title="Accuracy vs path tracer" hint="held-out random points">
          {v ? (
            <>
              <div className="grid grid-cols-2 gap-1.5">
                <Stat label="Mean error" value={pct(v.meanRelErr)} sub={`flat normals · ${v.points} pts`} />
                <Stat label="Median / P90" value={`${(v.medianRelErr * 100).toFixed(1)} / ${(v.p90RelErr * 100).toFixed(0)}%`} />
                <Stat label="Dynamic probes" value={pct(v.dynRelErr)} sub={`${v.dynPoints} free-space pts`} />
                <Stat label="Key coverage" value={pct(v.coverage)} sub="LUT hit on every point" />
              </div>
              <div className="text-[11px] font-medium text-slate-300">Normal-mapped normals (tilt ≤ 43°)</div>
              <div className="rounded-lg bg-white/[0.04] px-2.5 py-1">
                <Row k="map ignored" v={pct(v.nm.ignore)} />
                <Row k="direct only" v={pct(v.nm.naive)} />
                <Row k="+ wrap" v={pct(v.nm.wrap)} />
                <Row k="+ sky gradient" v={pct(v.nm.dir)} />
              </div>
            </>
          ) : (
            <div className="text-[11px] text-slate-500">{bake.phase === "error" ? "—" : "Validating once the bake converges…"}</div>
          )}
          <p className="text-[10px] leading-relaxed text-slate-500">
            Luminance error of the lookup (float CPU mirror of the shader, 8-bit visibility) against 512-sample ground truth at points that are <em>not</em> lattice samples.
          </p>
          <button
            type="button"
            disabled={!canMeasure}
            onClick={onMeasure}
            className={cn("w-full rounded-lg px-3 py-2 text-xs font-semibold", canMeasure ? "bg-indigo-400 text-slate-950 hover:bg-indigo-300" : "bg-white/5 text-slate-500")}
          >
            {canMeasure ? "Measure image error now" : "Turn on Compare to measure the image"}
          </button>
          {imgErr && (
            <div className="rounded-lg bg-white/[0.04] px-2.5 py-2 text-[11px] text-slate-300">
              Whole-frame error vs path tracer: <span className="font-mono text-slate-100">{pct(imgErr.err)}</span> at {imgErr.spp} spp (includes reference noise).
            </div>
          )}
        </Section>
      </div>
    </GlassPanel>
  );
}
