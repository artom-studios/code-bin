import { buildMesh, type V3 } from "./scene";
import { ND, NL, DYN_SPHERES, DYN_LIGHTS, dynSpherePositions, dynLightPositions, sampleProbes, combineSH, VOL, VOL_DIM } from "./dynamic";
import { FlyCamera } from "./camera";
import { FULLSCREEN_VS, SKY_FS, SCENE_VS, SCENE_FS, REF_FS, COMPOSITE_FS } from "./shaders";
import type { LutLayout } from "./bake";

export interface RenderParams {
  mode: number; // 0 final, 1 irradiance only, 2 cells, 3 no GI
  exposure: number;
  gains: [V3, V3, V3]; // colour * intensity per transfer channel (sun, sky, lamp)
  skyGain: V3;
  bulb: V3;
  refOn: boolean;
  split: number; // fraction of the width (from the left) that shows the LUT; the rest shows the reference
  nm: number; // 0 normal map off, 1 direct only, 2 + wrap, 3 + sky gradient (full)
  bump: number;
  idxMode: number; // 0 perfect hash, 1 dense grid
  dynObjects: boolean;
  animate: boolean;
  nLights: number;
  lightGain: number;
  lShadow: number; // 0 none, 1 SDF-8, 2 SDF-16
  fill: boolean;
  fillK: number;
}

export interface FrameStats {
  fps: number;
  refSamples: number;
}

class Prog {
  p: WebGLProgram;
  private cache = new Map<string, WebGLUniformLocation | null>();
  constructor(
    private gl: WebGL2RenderingContext,
    vs: string,
    fs: string,
    attribs: string[] = [],
  ) {
    const mk = (type: number, src: string) => {
      const s = gl.createShader(type)!;
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
        const log = gl.getShaderInfoLog(s);
        const numbered = src
          .split("\n")
          .map((l, i) => `${i + 1}: ${l}`)
          .join("\n");
        throw new Error(`shader compile failed:\n${log}\n${numbered.slice(0, 6000)}`);
      }
      return s;
    };
    this.p = gl.createProgram()!;
    gl.attachShader(this.p, mk(gl.VERTEX_SHADER, vs));
    gl.attachShader(this.p, mk(gl.FRAGMENT_SHADER, fs));
    attribs.forEach((a, i) => gl.bindAttribLocation(this.p, i, a));
    gl.linkProgram(this.p);
    if (!gl.getProgramParameter(this.p, gl.LINK_STATUS)) throw new Error("link failed: " + gl.getProgramInfoLog(this.p));
  }
  use() {
    this.gl.useProgram(this.p);
  }
  u(name: string) {
    let l = this.cache.get(name);
    if (l === undefined) {
      l = this.gl.getUniformLocation(this.p, name);
      this.cache.set(name, l);
    }
    return l;
  }
}

export class RadRenderer {
  readonly cam = new FlyCamera();
  readonly gl: WebGL2RenderingContext;
  refSupported = false;
  lutReady = false;
  params: RenderParams = {
    mode: 0,
    exposure: 1,
    gains: [
      [1, 1, 1],
      [1, 1, 1],
      [1, 1, 1],
    ],
    skyGain: [1, 1, 1],
    bulb: [1, 1, 1],
    refOn: false,
    split: 0.5,
    nm: 3,
    bump: 1,
    idxMode: 1,
    dynObjects: true,
    animate: true,
    nLights: 1,
    lightGain: 1,
    lShadow: 1,
    fill: true,
    fillK: 0.12,
  };
  time = 0;
  onStats?: (s: FrameStats) => void;
  onInteract?: () => void;

  private canvas: HTMLCanvasElement;
  private sky: Prog;
  private scene: Prog;
  private ref: Prog;
  private comp: Prog;
  private emptyVao: WebGLVertexArrayObject;
  private meshVao: WebGLVertexArrayObject;
  private indexCount: number;

  private layout: LutLayout | null = null;
  private dispTex: WebGLTexture;
  private denseTex: WebGLTexture;
  private atlasA: WebGLTexture;
  private atlasB: WebGLTexture;
  private volTex: WebGLTexture;
  private volData: Uint8Array | null = null;
  private probes: Float32Array | null = null;
  private basis = new Float32Array(36);
  private sphereVao: WebGLVertexArrayObject;
  private sphereIdx = 0;
  probeCount = 0;

  private refTex: WebGLTexture[] = [];
  private refFbo: WebGLFramebuffer[] = [];
  private refW = 0;
  private refH = 0;
  private refCur = 0;
  private refFrame = 0;
  private refKey = "";
  private readonly REF_MAX = 1200;

  private raf = 0;
  private last = performance.now();
  private fpsAcc = 0;
  private fpsN = 0;
  private statT = 0;
  private disposed = false;
  private cleanup: (() => void)[] = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const gl = canvas.getContext("webgl2", { antialias: true, alpha: false, powerPreference: "high-performance" });
    if (!gl) throw new Error("WebGL2 is not available in this browser.");
    this.gl = gl;

    this.sky = new Prog(gl, FULLSCREEN_VS, SKY_FS);
    this.scene = new Prog(gl, SCENE_VS, SCENE_FS, ["aPos", "aNrm", "aAlb", "aMat"]);
    this.ref = new Prog(gl, FULLSCREEN_VS, REF_FS);
    this.comp = new Prog(gl, FULLSCREEN_VS, COMPOSITE_FS);
    this.emptyVao = gl.createVertexArray()!;

    // mesh
    const mesh = buildMesh();
    this.meshVao = gl.createVertexArray()!;
    gl.bindVertexArray(this.meshVao);
    const attr = (loc: number, data: Float32Array, size: number) => {
      const b = gl.createBuffer()!;
      gl.bindBuffer(gl.ARRAY_BUFFER, b);
      gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0);
    };
    attr(0, mesh.pos, 3);
    attr(1, mesh.nrm, 3);
    attr(2, mesh.alb, 3);
    attr(3, mesh.mat, 1);
    const ib = gl.createBuffer()!;
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, mesh.idx, gl.STATIC_DRAW);
    this.indexCount = mesh.idx.length;
    gl.bindVertexArray(null);

    // LUT textures
    this.dispTex = gl.createTexture()!;
    this.denseTex = gl.createTexture()!;
    this.atlasA = gl.createTexture()!;
    this.atlasB = gl.createTexture()!;
    this.volTex = gl.createTexture()!;

    // unit sphere for dynamic objects / light markers
    {
      const lat = 32;
      const lon = 64;
      const pos: number[] = [];
      const idx: number[] = [];
      for (let i = 0; i <= lat; i++)
        for (let j = 0; j <= lon; j++) {
          const th = (Math.PI * i) / lat;
          const ph = (2 * Math.PI * j) / lon;
          pos.push(Math.sin(th) * Math.cos(ph), Math.cos(th), Math.sin(th) * Math.sin(ph));
        }
      for (let i = 0; i < lat; i++)
        for (let j = 0; j < lon; j++) {
          const a0 = i * (lon + 1) + j;
          const b0 = a0 + lon + 1;
          idx.push(a0, a0 + 1, b0, a0 + 1, b0 + 1, b0);
        }
      this.sphereVao = gl.createVertexArray()!;
      gl.bindVertexArray(this.sphereVao);
      const pb = gl.createBuffer()!;
      gl.bindBuffer(gl.ARRAY_BUFFER, pb);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(pos), gl.STATIC_DRAW);
      for (const loc of [0, 1]) {
        gl.enableVertexAttribArray(loc);
        gl.vertexAttribPointer(loc, 3, gl.FLOAT, false, 0, 0);
      }
      const ib2 = gl.createBuffer()!;
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib2);
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint32Array(idx), gl.STATIC_DRAW);
      this.sphereIdx = idx.length;
      gl.bindVertexArray(null);
      gl.vertexAttrib3f(2, 1, 1, 1);
      gl.vertexAttrib1f(3, 0);
    }

    this.refSupported = !!(gl.getExtension("EXT_color_buffer_float") || gl.getExtension("EXT_color_buffer_half_float"));

    this.bindInput();
    const ro = new ResizeObserver(() => this.resize());
    ro.observe(canvas);
    this.cleanup.push(() => ro.disconnect());
    this.resize();
    this.raf = requestAnimationFrame(this.frame);
  }

  // -------------------------------------------------------------------------------------------
  setParams(p: Partial<RenderParams>) {
    this.params = { ...this.params, ...p };
  }

  private tex2D(t: WebGLTexture, filter: number) {
    const gl = this.gl;
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  }

  setLUT(layout: LutLayout | null, A: Uint16Array, B: Uint8Array, basis: Float32Array) {
    const gl = this.gl;
    if (layout) {
      this.layout = layout;
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
      this.tex2D(this.dispTex, gl.NEAREST);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.R16UI, layout.dispW, layout.dispH, 0, gl.RED_INTEGER, gl.UNSIGNED_SHORT, layout.disp);
      this.tex2D(this.denseTex, gl.NEAREST);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.R16UI, layout.dense.w, layout.dense.h, 0, gl.RED_INTEGER, gl.UNSIGNED_SHORT, layout.dense.data);
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 4);
    }
    if (!this.layout) return;
    this.basis.set(basis);
    this.tex2D(this.atlasA, gl.LINEAR);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, this.layout.atlasW, this.layout.atlasH, 0, gl.RGBA, gl.HALF_FLOAT, A);
    this.tex2D(this.atlasB, gl.LINEAR);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, this.layout.atlasW, this.layout.atlasH, 0, gl.RGBA, gl.UNSIGNED_BYTE, B);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 4);
    this.lutReady = true;
    this.refFrame = 0;
  }

  setVolume(data: Uint8Array) {
    const gl = this.gl;
    this.volData = data;
    gl.bindTexture(gl.TEXTURE_3D, this.volTex);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    gl.texImage3D(gl.TEXTURE_3D, 0, gl.RGBA8, VOL_DIM[0], VOL_DIM[1], VOL_DIM[2], 0, gl.RGBA, gl.UNSIGNED_BYTE, data);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 4);
    for (const [k, v] of [
      [gl.TEXTURE_MIN_FILTER, gl.LINEAR],
      [gl.TEXTURE_MAG_FILTER, gl.LINEAR],
      [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE],
      [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE],
      [gl.TEXTURE_WRAP_R, gl.CLAMP_TO_EDGE],
    ])
      gl.texParameteri(gl.TEXTURE_3D, k, v);
  }

  setProbes(data: Float32Array) {
    this.probes = data;
    this.probeCount = data.length / 37;
  }

  /** nearest-voxel read of the static visibility volume (CPU side, once per object per frame) */
  private volVis(p: V3): [number, number] {
    if (!this.volData) return [1, 1];
    const [nx, ny, nz] = VOL_DIM;
    const x = Math.max(0, Math.min(nx - 1, Math.floor((p[0] - VOL.min[0]) / VOL.step)));
    const y = Math.max(0, Math.min(ny - 1, Math.floor((p[1] - VOL.min[1]) / VOL.step)));
    const z = Math.max(0, Math.min(nz - 1, Math.floor((p[2] - VOL.min[2]) / VOL.step)));
    const o = ((z * ny + y) * nx + x) * 4;
    return [this.volData[o] / 255, this.volData[o + 1] / 255];
  }

  /**
   * Image error of the LUT view against the path-traced reference (mean |a-b| / mean b on gamma-decoded pixels).
   * Needs the reference to be on; call after it has accumulated some samples.
   */
  measure(): { err: number; spp: number } | null {
    const P = this.params;
    if (!P.refOn || !this.refSupported || this.refFrame < 2) return null;
    const gl = this.gl;
    const { W, H } = this;
    const save = P.split;
    const grab = (split: number) => {
      this.params = { ...P, split };
      this.draw(true);
      const buf = new Uint8Array(W * H * 4);
      gl.readPixels(0, 0, W, H, gl.RGBA, gl.UNSIGNED_BYTE, buf);
      return buf;
    };
    const a = grab(W + 1); // all LUT
    const b = grab(-1); // all reference
    this.params = { ...P, split: save };
    let num = 0;
    let den = 0;
    for (let i = 0; i < W * H; i++) {
      const o = i * 4;
      for (let c = 0; c < 3; c++) {
        const x = Math.pow(a[o + c] / 255, 2.2);
        const y = Math.pow(b[o + c] / 255, 2.2);
        num += Math.abs(x - y);
        den += y;
      }
    }
    return { err: num / Math.max(den, 1e-9), spp: this.refFrame };
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.cleanup.forEach((f) => f());
  }

  // -------------------------------------------------------------------------------------------
  private W = 2;
  private H = 2;

  private resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(2, Math.floor(this.canvas.clientWidth * dpr));
    const h = Math.max(2, Math.floor(this.canvas.clientHeight * dpr));
    if (w !== this.W || h !== this.H || this.canvas.width !== w) {
      this.W = w;
      this.H = h;
      this.canvas.width = w;
      this.canvas.height = h;
    }
  }

  private bindInput() {
    const c = this.canvas;
    let dragging = false;
    let lx = 0;
    let ly = 0;
    const down = (e: PointerEvent) => {
      dragging = true;
      lx = e.clientX;
      ly = e.clientY;
      c.setPointerCapture(e.pointerId);
      this.onInteract?.();
    };
    const move = (e: PointerEvent) => {
      if (!dragging) return;
      this.cam.look(e.clientX - lx, e.clientY - ly);
      lx = e.clientX;
      ly = e.clientY;
    };
    const up = (e: PointerEvent) => {
      dragging = false;
      if (c.hasPointerCapture(e.pointerId)) c.releasePointerCapture(e.pointerId);
    };
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      this.cam.dolly(-e.deltaY * 0.0025);
      this.onInteract?.();
    };
    const kd = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === "INPUT" || (e.target as HTMLElement)?.tagName === "SELECT") return;
      const k = e.key.toLowerCase();
      this.cam.keys.add(k);
      if (e.shiftKey) this.cam.keys.add("shift");
      if (["w", "a", "s", "d", "q", "e", "arrowup", "arrowdown", "arrowleft", "arrowright"].includes(k)) this.onInteract?.();
    };
    const ku = (e: KeyboardEvent) => {
      this.cam.keys.delete(e.key.toLowerCase());
      if (!e.shiftKey) this.cam.keys.delete("shift");
    };
    const blur = () => this.cam.keys.clear();
    c.addEventListener("pointerdown", down);
    c.addEventListener("pointermove", move);
    c.addEventListener("pointerup", up);
    c.addEventListener("pointercancel", up);
    c.addEventListener("wheel", wheel, { passive: false });
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    window.addEventListener("blur", blur);
    this.cleanup.push(() => {
      c.removeEventListener("pointerdown", down);
      c.removeEventListener("pointermove", move);
      c.removeEventListener("pointerup", up);
      c.removeEventListener("pointercancel", up);
      c.removeEventListener("wheel", wheel);
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      window.removeEventListener("blur", blur);
    });
  }

  private ensureRefTargets(w: number, h: number) {
    const gl = this.gl;
    if (this.refW === w && this.refH === h && this.refTex.length) return true;
    this.refTex.forEach((t) => gl.deleteTexture(t));
    this.refFbo.forEach((f) => gl.deleteFramebuffer(f));
    this.refTex = [];
    this.refFbo = [];
    for (let i = 0; i < 2; i++) {
      const t = gl.createTexture()!;
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, w, h, 0, gl.RGBA, gl.HALF_FLOAT, null);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      const f = gl.createFramebuffer()!;
      gl.bindFramebuffer(gl.FRAMEBUFFER, f);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
      if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) {
        this.refSupported = false;
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        return false;
      }
      this.refTex.push(t);
      this.refFbo.push(f);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    this.refW = w;
    this.refH = h;
    this.refFrame = 0;
    return true;
  }

  private setCameraUniforms(p: Prog, aspect: number) {
    const gl = this.gl;
    const { f, r, u } = this.cam.basis();
    gl.uniform3f(p.u("uCamR"), r[0], r[1], r[2]);
    gl.uniform3f(p.u("uCamU"), u[0], u[1], u[2]);
    gl.uniform3f(p.u("uCamF"), f[0], f[1], f[2]);
    gl.uniform1f(p.u("uTanHalf"), Math.tan(this.cam.fov / 2));
    gl.uniform1f(p.u("uAspect"), aspect);
  }

  // ---- dynamic content (CPU side: positions, per-object probe sampling) ----------------------------
  private dynPos: V3[] = [];
  private lightPos: V3[] = [];
  private lightGain: V3[] = [];
  private dynSH: Float32Array[] = Array.from({ length: ND }, () => new Float32Array(12));
  private dynRad: V3[] = Array.from({ length: ND }, () => [0, 0, 0] as V3);

  private updateDyn() {
    const P = this.params;
    this.dynPos = dynSpherePositions(this.time);
    this.lightPos = dynLightPositions(this.time);
    this.lightGain = DYN_LIGHTS.map((l) => [l.color[0] * l.intensity * P.lightGain, l.color[1] * l.intensity * P.lightGain, l.color[2] * l.intensity * P.lightGain] as V3);
    const sh = new Float32Array(36);
    const lamp: V3 = [0, 2.45, -1.6];
    for (let i = 0; i < ND; i++) {
      const c = this.dynPos[i];
      if (this.probes) sampleProbes(this.probes, c[0], c[1], c[2], sh);
      else sh.fill(0);
      combineSH(sh, P.gains, this.dynSH[i]);
      const [vs, vl] = this.volVis(c);
      const d2 = Math.max(1, (c[0] - lamp[0]) ** 2 + (c[1] - lamp[1]) ** 2 + (c[2] - lamp[2]) ** 2);
      for (let k = 0; k < 3; k++) this.dynRad[i][k] = this.dynSH[i][k] + P.gains[0][k] * vs * 0.16 + (P.gains[2][k] * vl * 0.16) / d2;
    }
  }

  private setDynUniforms(p: Prog) {
    const gl = this.gl;
    const P = this.params;
    const C = new Float32Array(ND * 4);
    const A = new Float32Array(ND * 3);
    const R = new Float32Array(ND * 3);
    for (let i = 0; i < ND; i++) {
      C.set([this.dynPos[i][0], this.dynPos[i][1], this.dynPos[i][2], DYN_SPHERES[i].radius], i * 4);
      A.set(DYN_SPHERES[i].albedo, i * 3);
      R.set(this.dynRad[i], i * 3);
    }
    gl.uniform1i(p.u("uDynOn"), P.dynObjects ? 1 : 0);
    gl.uniform4fv(p.u("uDynC"), C);
    gl.uniform3fv(p.u("uDynAlb"), A);
    gl.uniform3fv(p.u("uDynRad"), R);
    const LP = new Float32Array(NL * 4);
    const LC = new Float32Array(NL * 3);
    for (let j = 0; j < NL; j++) {
      LP.set([this.lightPos[j][0], this.lightPos[j][1], this.lightPos[j][2], DYN_LIGHTS[j].radius], j * 4);
      LC.set(this.lightGain[j], j * 3);
    }
    gl.uniform1i(p.u("uNL"), P.nLights);
    gl.uniform4fv(p.u("uLP"), LP);
    gl.uniform3fv(p.u("uLC"), LC);
  }

  private frame = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.frame);
    const dt = Math.min(0.1, (now - this.last) / 1000);
    this.last = now;
    this.fpsAcc += dt;
    this.fpsN++;
    this.statT += dt;
    this.cam.update(dt);
    if (this.params.animate && !this.params.refOn) this.time += dt;
    this.resize();
    try {
      this.draw();
    } catch (e) {
      console.error(e);
    }
    if (this.statT > 0.5) {
      this.onStats?.({ fps: this.fpsN / this.fpsAcc, refSamples: this.refFrame });
      this.fpsAcc = 0;
      this.fpsN = 0;
      this.statT = 0;
    }
  };

  private draw(_measuring = false) {
    const gl = this.gl;
    const { W, H } = this;
    const P = this.params;
    const aspect = W / H;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, W, H);
    gl.clearColor(0, 0, 0, 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // --- sky
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.CULL_FACE);
    this.sky.use();
    this.setCameraUniforms(this.sky, aspect);
    gl.uniform2f(this.sky.u("uRes"), W, H);
    gl.uniform1f(this.sky.u("uExposure"), P.exposure);
    gl.uniform3f(this.sky.u("uSkyGain"), P.skyGain[0], P.skyGain[1], P.skyGain[2]);
    gl.bindVertexArray(this.emptyVao);
    gl.drawArrays(gl.TRIANGLES, 0, 3);

    // --- scene with the radiance LUT
    this.updateDyn();
    if (this.lutReady && this.layout) {
      const L = this.layout;
      gl.enable(gl.DEPTH_TEST);
      gl.enable(gl.CULL_FACE);
      gl.cullFace(gl.BACK);
      const s = this.scene;
      s.use();
      gl.uniformMatrix4fv(s.u("uVP"), false, this.cam.viewProj(aspect));
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, P.idxMode === 1 ? this.denseTex : this.dispTex);
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, this.atlasA);
      gl.activeTexture(gl.TEXTURE2);
      gl.bindTexture(gl.TEXTURE_2D, this.atlasB);
      gl.activeTexture(gl.TEXTURE3);
      gl.bindTexture(gl.TEXTURE_3D, this.volTex);
      gl.uniform1i(s.u("uIdx"), 0);
      gl.uniform1i(s.u("uAtlasA"), 1);
      gl.uniform1i(s.u("uAtlasB"), 2);
      gl.uniform1i(s.u("uVol"), 3);
      gl.uniform3f(s.u("uGO"), L.GO[0], L.GO[1], L.GO[2]);
      gl.uniform1f(s.u("uInvCell"), 1 / L.cell);
      gl.uniform1f(s.u("uTileN"), L.N);
      gl.uniform2f(s.u("uInvAtlas"), 1 / L.atlasW, 1 / L.atlasH);
      gl.uniform1i(s.u("uIdxMode"), P.idxMode);
      gl.uniform1uiv(s.u("uSalt"), new Uint32Array(L.salts));
      gl.uniform1ui(s.u("uMMask"), L.M - 1);
      gl.uniform1ui(s.u("uBMask"), L.B - 1);
      gl.uniform3i(s.u("uIdxMin"), L.dense.min[0], L.dense.min[1], L.dense.min[2]);
      gl.uniform3i(s.u("uIdxDim"), L.dense.dim[0], L.dense.dim[1], L.dense.dim[2]);
      const MA = new Float32Array(12);
      const MS = new Float32Array(12);
      for (let k = 0; k < 4; k++)
        for (let c = 0; c < 3; c++) {
          let all = 0;
          for (let ch = 0; ch < 3; ch++) all += P.gains[ch][c] * this.basis[k * 9 + ch * 3 + c];
          MA[k * 3 + c] = all;
          MS[k * 3 + c] = P.gains[1][c] * this.basis[k * 9 + 3 + c];
        }
      gl.uniform3fv(s.u("uMA"), MA);
      gl.uniform3fv(s.u("uMS"), MS);
      gl.uniform3f(s.u("uGSun"), P.gains[0][0], P.gains[0][1], P.gains[0][2]);
      gl.uniform3f(s.u("uGLamp"), P.gains[2][0], P.gains[2][1], P.gains[2][2]);
      gl.uniform1i(s.u("uMode"), P.mode);
      gl.uniform1i(s.u("uNM"), P.nm);
      gl.uniform1f(s.u("uBump"), P.bump);
      gl.uniform1f(s.u("uExposure"), P.exposure);
      gl.uniform3f(s.u("uBulb"), P.bulb[0], P.bulb[1], P.bulb[2]);
      gl.uniform3f(s.u("uVolMin"), VOL.min[0], VOL.min[1], VOL.min[2]);
      gl.uniform3f(s.u("uVolInv"), 1 / VOL.size[0], 1 / VOL.size[1], 1 / VOL.size[2]);
      gl.uniform1i(s.u("uLShadow"), P.lShadow);
      gl.uniform1i(s.u("uFill"), P.fill ? 1 : 0);
      gl.uniform1f(s.u("uFillK"), P.fillK);
      this.setDynUniforms(s);
      // static world
      gl.uniform1i(s.u("uSelf"), -1);
      gl.bindVertexArray(this.meshVao);
      gl.drawElements(gl.TRIANGLES, this.indexCount, gl.UNSIGNED_INT, 0);
      // dynamic objects + light markers
      gl.bindVertexArray(this.sphereVao);
      if (P.dynObjects)
        for (let i = 0; i < ND; i++) {
          const c = this.dynPos[i];
          gl.uniform1i(s.u("uSelf"), i);
          gl.uniform3f(s.u("uObjC"), c[0], c[1], c[2]);
          gl.uniform1f(s.u("uObjR"), DYN_SPHERES[i].radius);
          const al = DYN_SPHERES[i].albedo;
          gl.uniform3f(s.u("uObjAlb"), al[0], al[1], al[2]);
          gl.uniform3fv(s.u("uSH"), this.dynSH[i]);
          gl.drawElements(gl.TRIANGLES, this.sphereIdx, gl.UNSIGNED_INT, 0);
        }
      for (let j = 0; j < P.nLights; j++) {
        const c = this.lightPos[j];
        const g = this.lightGain[j];
        const m = Math.max(g[0], g[1], g[2]) + 1e-4;
        const k = (1.5 + 0.3 * m) / m;
        gl.uniform1i(s.u("uSelf"), -2 - j);
        gl.uniform3f(s.u("uObjC"), c[0], c[1], c[2]);
        gl.uniform1f(s.u("uObjR"), 0.08);
        gl.uniform3f(s.u("uMarker"), g[0] * k, g[1] * k, g[2] * k);
        gl.drawElements(gl.TRIANGLES, this.sphereIdx, gl.UNSIGNED_INT, 0);
      }
      gl.bindVertexArray(null);
      gl.activeTexture(gl.TEXTURE0);
    }

    // --- reference path tracer (right side of the split)
    if (P.refOn && this.refSupported) {
      const rw = Math.max(2, Math.floor(W * 0.5));
      const rh = Math.max(2, Math.floor(H * 0.5));
      if (!this.ensureRefTargets(rw, rh)) return;
      const key = [this.cam.version, W, H, JSON.stringify(P.gains), JSON.stringify(P.skyGain), JSON.stringify(P.bulb), P.nm, P.bump, P.dynObjects, P.nLights, P.lightGain, this.time.toFixed(3)].join("|");
      if (key !== this.refKey) {
        this.refKey = key;
        this.refFrame = 0;
      }
      if (this.refFrame < this.REF_MAX) {
        this.refFrame++;
        const src = this.refCur;
        const dst = 1 - this.refCur;
        gl.bindFramebuffer(gl.FRAMEBUFFER, this.refFbo[dst]);
        gl.viewport(0, 0, rw, rh);
        gl.disable(gl.DEPTH_TEST);
        gl.disable(gl.CULL_FACE);
        const r = this.ref;
        r.use();
        this.setCameraUniforms(r, aspect);
        const pos = this.cam.pos;
        gl.uniform3f(r.u("uCamPos"), pos[0], pos[1], pos[2]);
        gl.uniform2f(r.u("uRes"), rw, rh);
        gl.uniform1f(r.u("uFrame"), this.refFrame);
        gl.uniform3f(r.u("uSunGain"), P.gains[0][0], P.gains[0][1], P.gains[0][2]);
        gl.uniform3f(r.u("uSkyGain"), P.gains[1][0], P.gains[1][1], P.gains[1][2]);
        gl.uniform3f(r.u("uLampGain"), P.gains[2][0], P.gains[2][1], P.gains[2][2]);
        gl.uniform3f(r.u("uBulb"), P.bulb[0], P.bulb[1], P.bulb[2]);
        gl.uniform1i(r.u("uBumpOn"), P.nm > 0 ? 1 : 0);
        gl.uniform1f(r.u("uBump"), P.bump);
        this.setDynUniforms(r);
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, this.refTex[src]);
        gl.uniform1i(r.u("uPrev"), 0);
        gl.bindVertexArray(this.emptyVao);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
        this.refCur = dst;
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        gl.viewport(0, 0, W, H);
      }
      const c = this.comp;
      c.use();
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.refTex[this.refCur]);
      gl.uniform1i(c.u("uTex"), 0);
      gl.uniform2f(c.u("uRes"), W, H);
      gl.uniform1f(c.u("uSplitPx"), P.split * W);
      gl.uniform1f(c.u("uExposure"), P.exposure);
      gl.bindVertexArray(this.emptyVao);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    }
  }
}
