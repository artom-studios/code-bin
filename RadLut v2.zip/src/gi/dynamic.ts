// Dynamic content that is NOT part of the bake: moving spheres (objects) and moving point lights.
// Also the shared volume / probe-grid definitions used by the baker (producer) and renderer + validation (consumers).
import type { V3 } from "./scene";

/** Static visibility + SDF volume (RGBA8 3D texture):  R = sun visibility, G = lamp visibility, B = distance / 1 m, A = 1 */
export const VOL = { min: [-4.5, -0.5, -4.5] as V3, size: [9, 4.5, 9] as V3, step: 0.1 };
export const VOL_DIM: [number, number, number] = [
  Math.round(VOL.size[0] / VOL.step),
  Math.round(VOL.size[1] / VOL.step),
  Math.round(VOL.size[2] / VOL.step),
];
export const SDF_RANGE = 1.0;

/** Irradiance probe grid (L1 SH per transfer channel).  36 floats + 1 validity flag per probe. */
export const PROBES = { min: [-4, 0, -4] as V3, step: 0.5, dim: [17, 8, 17] as [number, number, number] };
export const PROBE_STRIDE = 37;

export interface DynSphere {
  name: string;
  radius: number;
  albedo: V3;
  mat: number;
}
export const DYN_SPHERES: DynSphere[] = [
  { name: "red ball", radius: 0.32, albedo: [0.78, 0.1, 0.08], mat: 3 },
  { name: "blue ball", radius: 0.24, albedo: [0.12, 0.3, 0.85], mat: 3 },
  { name: "white ball", radius: 0.4, albedo: [0.86, 0.86, 0.82], mat: 3 },
];
export const ND = DYN_SPHERES.length;

export interface DynLight {
  name: string;
  color: V3;
  intensity: number;
  radius: number; // range of the smooth window
}
export const DYN_LIGHTS: DynLight[] = [
  { name: "cyan orb", color: [0.35, 0.82, 1.0], intensity: 4, radius: 5 },
  { name: "magenta orb", color: [1.0, 0.3, 0.55], intensity: 3, radius: 4.5 },
];
export const NL = DYN_LIGHTS.length;

export function dynSpherePositions(t: number): V3[] {
  const r0 = DYN_SPHERES[0].radius;
  const r1 = DYN_SPHERES[1].radius;
  const r2 = DYN_SPHERES[2].radius;
  return [
    [2.0 * Math.cos(0.5 * t), r0, -1.6 + 1.9 * Math.sin(0.5 * t)],
    [1.2 + 0.8 * Math.sin(0.7 * t), r1 + 0.9 * Math.abs(Math.sin(1.3 * t)), 2.1 + 0.8 * Math.cos(0.7 * t)],
    [-2.0 + 0.3 * Math.sin(0.4 * t), r2, 0.2 + 1.8 * Math.sin(0.31 * t)],
  ];
}

export function dynLightPositions(t: number): V3[] {
  return [
    [2.2 * Math.cos(0.35 * t), 1.55 + 0.3 * Math.sin(0.9 * t), 2.6 * Math.sin(0.35 * t)],
    [1.6 * Math.sin(0.25 * t + 1), 1.1 + 0.2 * Math.sin(0.7 * t), 2.6 * Math.cos(0.25 * t + 1)],
  ];
}

/** Trilinear sample of the probe grid at p (validity weighted). out: 36 floats [ch*12 + (A rgb | Bx rgb | By rgb | Bz rgb)] */
export function sampleProbes(probes: Float32Array, px: number, py: number, pz: number, out: Float32Array | Float64Array): boolean {
  out.fill(0);
  const { min, step, dim } = PROBES;
  const gx = (px - min[0]) / step;
  const gy = (py - min[1]) / step;
  const gz = (pz - min[2]) / step;
  const x0 = Math.max(0, Math.min(dim[0] - 2, Math.floor(gx)));
  const y0 = Math.max(0, Math.min(dim[1] - 2, Math.floor(gy)));
  const z0 = Math.max(0, Math.min(dim[2] - 2, Math.floor(gz)));
  const fx = Math.max(0, Math.min(1, gx - x0));
  const fy = Math.max(0, Math.min(1, gy - y0));
  const fz = Math.max(0, Math.min(1, gz - z0));
  let ws = 0;
  for (let k = 0; k < 8; k++) {
    const dx = k & 1;
    const dy = (k >> 1) & 1;
    const dz = (k >> 2) & 1;
    const w = (dx ? fx : 1 - fx) * (dy ? fy : 1 - fy) * (dz ? fz : 1 - fz);
    if (w <= 0) continue;
    const id = ((z0 + dz) * dim[1] + (y0 + dy)) * dim[0] + (x0 + dx);
    const o = id * PROBE_STRIDE;
    if (probes[o + 36] < 0.5) continue;
    ws += w;
    for (let q = 0; q < 36; q++) out[q] += w * probes[o + q];
  }
  if (ws <= 0) return false;
  for (let q = 0; q < 36; q++) out[q] /= ws;
  return true;
}

/** Fold the three transfer channels with the runtime light gains -> 4 vec3 (A, Bx, By, Bz):  R(n) = A + Bx nx + By ny + Bz nz */
export function combineSH(sh36: ArrayLike<number>, gains: [V3, V3, V3], out12: Float32Array | Float64Array) {
  out12.fill(0);
  for (let ch = 0; ch < 3; ch++)
    for (let t = 0; t < 4; t++)
      for (let c = 0; c < 3; c++) out12[t * 3 + c] += gains[ch][c] * sh36[ch * 12 + t * 3 + c];
}
