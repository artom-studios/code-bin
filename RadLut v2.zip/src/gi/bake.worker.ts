/// <reference lib="webworker" />
import { RadBaker, BAKE_PASSES, type BakeConfig, type BakeStats, type LutLayout, type Validation, type PcaInfo } from "./bake";

export type WorkerIn = { type: "bake"; cfg: BakeConfig };
export type WorkerOut =
  | { type: "layout"; layout: LutLayout; stats: BakeStats; t: number }
  | { type: "volume"; data: Uint8Array; t: number }
  | { type: "progress"; pass: number; frac: number }
  | { type: "pass"; pass: number; spp: number; totalSpp: number; A: Uint16Array; B: Uint8Array; basis: Float32Array; pca: PcaInfo; t: number }
  | { type: "probes"; data: Float32Array; t: number; ms: number }
  | { type: "done"; validation: Validation; t: number }
  | { type: "error"; message: string };

const PASSES = BAKE_PASSES;
const ctx = self as unknown as DedicatedWorkerGlobalScope;

ctx.onmessage = (ev: MessageEvent<WorkerIn>) => {
  if (ev.data.type !== "bake") return;
  try {
    const t0 = performance.now();
    const baker = new RadBaker(ev.data.cfg);
    baker.prepare();
    const post = (m: WorkerOut, tr?: Transferable[]) => ctx.postMessage(m, tr ?? []);
    post({ type: "layout", layout: baker.layout(), stats: baker.stats, t: performance.now() - t0 });
    const vol = baker.buildVolume();
    post({ type: "volume", data: vol.slice(), t: performance.now() - t0 });
    const sendProbes = () => {
      const t1 = performance.now();
      const data = baker.bakeProbes();
      post({ type: "probes", data: data.slice(), t: performance.now() - t0, ms: performance.now() - t1 }, []);
    };
    PASSES.forEach((spp, k) => {
      baker.runPass(spp, (frac) => post({ type: "progress", pass: k, frac }));
      const { A, B } = baker.pack();
      post(
        { type: "pass", pass: k, spp, totalSpp: baker.totalSpp, A, B, basis: baker.basis.slice(), pca: baker.pca, t: performance.now() - t0 },
        [A.buffer, B.buffer],
      );
      if (k === 1) sendProbes();
    });
    sendProbes();
    const validation = baker.validate();
    post({ type: "done", validation, t: performance.now() - t0 });
  } catch (e) {
    ctx.postMessage({ type: "error", message: String((e as Error)?.stack ?? e) } satisfies WorkerOut);
  }
};
