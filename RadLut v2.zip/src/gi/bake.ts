// RadLUT baker (v2).
//
//   1. enumerate (cell, face) keys touched by the rendered surfaces         -> sparse set of tiles
//   2. every tile is an NxN lattice of samples projected on the surface along the face axis
//   3. per lattice point:  filtered *visibility* of the delta lights (sun, lamp)           -> analytic direct at runtime
//                          path-traced *indirect transfer* (sun / sky / lamp, RGB)        -> low-rank coded (PCA)
//                          first-order directional gradient of the sky transfer           -> normal maps
//   4. denoise the indirect part on the lattice, PCA-code the 9-vector into K coefficients
//   5. build the cell -> slot index (perfect hash and dense grid) and pack: RGBA16F coefficients + RGBA8 aux
//   6. static visibility/SDF volume + SH probe grid (gathered from the finished LUT) for dynamic objects / lights
//
import { buildMesh, bakedSurfaceArea, ROOM, DEFAULT_LIGHTS, SUN_DIR, LAMP_POS, type Mesh, type V3 } from "./scene";
import { buildPerfectHash, buildDenseIndex, cellBits, lookupSlot, toHalf, hash32, SW, type PerfectHash, type DenseIndex } from "./hash";
import {
  axisCast,
  insideSolid,
  directAt,
  visFiltered,
  visAt,
  sdfAt,
  closest,
  hit,
  occluded,
  pathIndirect,
  seedRng,
  EPS,
  type AxisHit,
} from "./trace";
import { skyInto } from "./scene";
import { VOL, VOL_DIM, SDF_RANGE, PROBES, PROBE_STRIDE, sampleProbes } from "./dynamic";

export const PCA_K = 4;
const NA = 11; // accumulator width: 9 transfer + 2 gradient

export interface BakeConfig {
  step: number; // lattice spacing in metres
  N: number; // texels per tile side
}

export interface LutLayout {
  step: number;
  cell: number;
  N: number;
  n: number;
  M: number;
  B: number;
  salts: number[];
  SW: number; // tiles per atlas row
  atlasW: number;
  atlasH: number;
  GO: V3;
  disp: Uint16Array;
  dispW: number;
  dispH: number;
  dense: { min: V3; dim: V3; w: number; h: number; data: Uint16Array };
}

export interface BakeStats {
  entries: number;
  slots: number;
  load: number;
  corners: number;
  maxDisp: number;
  attempts: number;
  atlasBytes: number;
  dispBytes: number;
  denseBytes: number;
  totalBytes: number;
  v1AtlasBytes: number;
  area: number;
  lightmapBytes: number;
  volumeBytes: number;
  enumSamples: number;
  prepMs: number;
}

export interface PcaInfo {
  k: number;
  energy: number[]; // cumulative energy captured by 1..9 components
  err: number; // relative RMS error of the K-term reconstruction (default light gains)
}

export interface NormalMapValidation {
  ignore: number; // normal map ignored (flat LUT)
  naive: number; // analytic direct with the bumped normal, indirect un-relit
  wrap: number; // + isotropic wrap on the indirect
  dir: number; // + sky gradient (full method)
}

export interface Validation {
  points: number;
  meanRelErr: number;
  medianRelErr: number;
  p90RelErr: number;
  coverage: number;
  nm: NormalMapValidation;
  dynPoints: number;
  dynRelErr: number;
}

const DISP_W = 256;

/** samples-per-lattice-point of every progressive pass (the table is usable after the first one) */
export const BAKE_PASSES = [8, 8, 16, 32, 64, 64];

function jacobiEig(A: number[][], n: number) {
  const V: number[][] = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j): number => (i === j ? 1 : 0)));
  for (let sweep = 0; sweep < 80; sweep++) {
    let off = 0;
    for (let p = 0; p < n; p++) for (let q = p + 1; q < n; q++) off += A[p][q] * A[p][q];
    if (off < 1e-22) break;
    for (let p = 0; p < n; p++)
      for (let q = p + 1; q < n; q++) {
        if (Math.abs(A[p][q]) < 1e-300) continue;
        const theta = (A[q][q] - A[p][p]) / (2 * A[p][q]);
        const t = Math.sign(theta || 1) / (Math.abs(theta) + Math.sqrt(theta * theta + 1));
        const c = 1 / Math.sqrt(t * t + 1);
        const s = t * c;
        for (let k = 0; k < n; k++) {
          const akp = A[k][p];
          const akq = A[k][q];
          A[k][p] = c * akp - s * akq;
          A[k][q] = s * akp + c * akq;
        }
        for (let k = 0; k < n; k++) {
          const apk = A[p][k];
          const aqk = A[q][k];
          A[p][k] = c * apk - s * aqk;
          A[q][k] = s * apk + c * aqk;
        }
        for (let k = 0; k < n; k++) {
          const vkp = V[k][p];
          const vkq = V[k][q];
          V[k][p] = c * vkp - s * vkq;
          V[k][q] = s * vkp + c * vkq;
        }
      }
  }
  const vals = Array.from({ length: n }, (_, i) => A[i][i]);
  const order = vals.map((_, i) => i).sort((a, b) => vals[b] - vals[a]);
  return { vals: order.map((i) => vals[i]), vecs: order.map((i) => V.map((row) => row[i])) }; // vecs[k][q]
}

export class RadBaker {
  readonly cfg: BakeConfig;
  readonly cell: number;
  readonly GO: V3;
  readonly mesh: Mesh;

  n = 0;
  corners = 0;
  totalSpp = 0;
  passIndex = 0;
  hash!: PerfectHash;
  stats!: BakeStats;

  private entryMap = new Map<number, number>();
  private ecx: number[] = [];
  private ecy: number[] = [];
  private ecz: number[] = [];
  private ef: number[] = [];
  private ecid!: Int32Array;
  private slotEntry!: Int32Array;

  private cpos!: Float64Array;
  private cnrm!: Float64Array;
  private vis!: Float32Array;
  private acc!: Float64Array;
  private nbr!: Int32Array;
  private final!: Float32Array;
  private hat!: Float32Array;
  private grad!: Float32Array;
  private coef!: Float32Array;
  basis!: Float32Array;
  private cface!: Uint8Array;
  private dense!: DenseIndex;

  constructor(cfg: BakeConfig) {
    this.cfg = cfg;
    this.cell = cfg.step * (cfg.N - 1);
    this.GO = [0.137 * this.cell, 0.291 * this.cell, 0.419 * this.cell];
    this.mesh = buildMesh();
  }

  private keyNum(cx: number, cy: number, cz: number, f: number) {
    return (((cz + 512) * 1024 + (cy + 512)) * 1024 + (cx + 512)) * 8 + f;
  }

  // ---------------------------------------------------------------------------------------------
  prepare() {
    const t0 = performance.now();
    const { cell, GO } = this;
    const { N, step } = this.cfg;
    const { pos, nrm, mat, idx } = this.mesh;

    // ---- 1. enumerate keys ------------------------------------------------------------------
    const h = step / 3;
    const dil = 0.5 * h + 0.01;
    const cnt: number[] = [];
    const sp: number[] = []; // 3 per entry
    const sn: number[] = [];
    let enumSamples = 0;

    const register = (px: number, py: number, pz: number, nx: number, ny: number, nz: number) => {
      const p = [px, py, pz];
      const nv = [nx, ny, nz];
      for (let ax = 0; ax < 3; ax++) {
        const nn = nv[ax];
        if (nn * nn < 0.01) continue;
        const f = 2 * ax + (nn < 0 ? 1 : 0);
        const x0 = Math.floor((px - dil - GO[0]) / cell);
        const x1 = Math.floor((px + dil - GO[0]) / cell);
        const y0 = Math.floor((py - dil - GO[1]) / cell);
        const y1 = Math.floor((py + dil - GO[1]) / cell);
        const z0 = Math.floor((pz - dil - GO[2]) / cell);
        const z1 = Math.floor((pz + dil - GO[2]) / cell);
        for (let cz = z0; cz <= z1; cz++)
          for (let cy = y0; cy <= y1; cy++)
            for (let cx = x0; cx <= x1; cx++) {
              const key = this.keyNum(cx, cy, cz, f);
              let id = this.entryMap.get(key);
              if (id === undefined) {
                id = this.ecx.length;
                this.entryMap.set(key, id);
                this.ecx.push(cx);
                this.ecy.push(cy);
                this.ecz.push(cz);
                this.ef.push(f);
                cnt.push(0);
                sp.push(0, 0, 0);
                sn.push(0, 0, 0);
              }
              cnt[id]++;
              sp[id * 3] += p[0];
              sp[id * 3 + 1] += p[1];
              sp[id * 3 + 2] += p[2];
              sn[id * 3] += nx;
              sn[id * 3 + 1] += ny;
              sn[id * 3 + 2] += nz;
            }
        void p;
      }
    };

    for (let t = 0; t < idx.length; t += 3) {
      const i0 = idx[t];
      const i1 = idx[t + 1];
      const i2 = idx[t + 2];
      if (mat[i0] < 0) continue;
      const e1x = pos[i1 * 3] - pos[i0 * 3];
      const e1y = pos[i1 * 3 + 1] - pos[i0 * 3 + 1];
      const e1z = pos[i1 * 3 + 2] - pos[i0 * 3 + 2];
      const e2x = pos[i2 * 3] - pos[i0 * 3];
      const e2y = pos[i2 * 3 + 1] - pos[i0 * 3 + 1];
      const e2z = pos[i2 * 3 + 2] - pos[i0 * 3 + 2];
      const n1 = Math.max(1, Math.ceil(Math.hypot(e1x, e1y, e1z) / h));
      const n2 = Math.max(1, Math.ceil(Math.hypot(e2x, e2y, e2z) / h));
      for (let i = 0; i <= n1; i++) {
        const a = i / n1;
        for (let j = 0; j <= n2; j++) {
          const b = j / n2;
          if (a + b > 1 + 1e-9) continue;
          const w0 = 1 - a - b;
          const px = pos[i0 * 3] + e1x * a + e2x * b;
          const py = pos[i0 * 3 + 1] + e1y * a + e2y * b;
          const pz = pos[i0 * 3 + 2] + e1z * a + e2z * b;
          let nx = nrm[i0 * 3] * w0 + nrm[i1 * 3] * a + nrm[i2 * 3] * b;
          let ny = nrm[i0 * 3 + 1] * w0 + nrm[i1 * 3 + 1] * a + nrm[i2 * 3 + 1] * b;
          let nz = nrm[i0 * 3 + 2] * w0 + nrm[i1 * 3 + 2] * a + nrm[i2 * 3 + 2] * b;
          const il = 1 / Math.hypot(nx, ny, nz);
          nx *= il;
          ny *= il;
          nz *= il;
          register(px, py, pz, nx, ny, nz);
          enumSamples++;
        }
      }
    }
    const n = this.ecx.length;
    this.n = n;

    // ---- 2. perfect hash --------------------------------------------------------------------
    const bits = new Uint32Array(n);
    const faces = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      bits[i] = cellBits(this.ecx[i], this.ecy[i], this.ecz[i]);
      faces[i] = this.ef[i];
    }
    this.hash = buildPerfectHash(bits, faces, 0.9, 3);
    this.slotEntry = new Int32Array(this.hash.M).fill(-1);
    for (let i = 0; i < n; i++) {
      const s = this.hash.slotOf[i];
      if (lookupSlot(this.hash, bits[i], faces[i]) !== s) throw new Error("hash mismatch");
      this.slotEntry[s] = i;
    }

    // ---- 3. lattice corners -----------------------------------------------------------------
    const NN = N * N;
    this.ecid = new Int32Array(n * NN).fill(-1);
    const cornerMap = new Map<number, number>();
    const cpos: number[] = [0, 0, 0];
    const cnrm: number[] = [0, 1, 0];
    const cF: number[] = [0];
    const cI: number[] = [0];
    const cJ: number[] = [0];
    const cFree: boolean[] = [true]; // fallback samples are not part of the lattice (no denoiser neighbours)
    let thinFallbacks = 0;
    const hitOut: AxisHit = { h: 0, nx: 0, ny: 0, nz: 0 };
    const mar = 0.5 * step;
    const tol = 0.6 * cell;
    const nbCells = [0, 0, 0];

    for (let e = 0; e < n; e++) {
      const f = this.ef[e];
      const a = f >> 1;
      const u = (a + 1) % 3;
      const v = (a + 2) % 3;
      nbCells[0] = this.ecx[e];
      nbCells[1] = this.ecy[e];
      nbCells[2] = this.ecz[e];
      const slabLo = GO[a] + nbCells[a] * cell;
      const lo = slabLo - mar;
      const hi = slabLo + cell + mar;
      const href = sp[e * 3 + a] / cnt[e];
      const base = e * NN;
      for (let j = 0; j < N; j++) {
        for (let i = 0; i < N; i++) {
          const lu = GO[u] + nbCells[u] * cell + i * step;
          const lv = GO[v] + nbCells[v] * cell + j * step;
          if (!axisCast(f, lu, lv, lo, hi, href, tol, hitOut)) continue;
          const p = [0, 0, 0];
          p[u] = lu;
          p[v] = lv;
          p[a] = hitOut.h;
          if (insideSolid(p[0] + hitOut.nx * EPS, p[1] + hitOut.ny * EPS, p[2] + hitOut.nz * EPS)) continue;
          const I = nbCells[u] * (N - 1) + i;
          const J = nbCells[v] * (N - 1) + j;
          const Q = Math.round(hitOut.h * 1000) + 8192;
          const ckey = (((f * 4096 + (I + 2048)) * 4096 + (J + 2048)) * 16384) + Q;
          let cid = cornerMap.get(ckey);
          if (cid === undefined) {
            cid = cF.length;
            cornerMap.set(ckey, cid);
            cpos.push(p[0], p[1], p[2]);
            cnrm.push(hitOut.nx, hitOut.ny, hitOut.nz);
            cF.push(f);
            cI.push(I);
            cJ.push(J);
            cFree.push(false);
          }
          this.ecid[base + j * N + i] = cid;
        }
      }
      // Features thinner than the lattice step (table legs, ...) may miss every lattice point:
      // fall back to one sample at the tile's mean surface point so the face is not black.
      let anyValid = false;
      for (let k = 0; k < NN; k++) if (this.ecid[base + k] >= 0) anyValid = true;
      if (!anyValid) {
        const rx = sp[e * 3] / cnt[e];
        const ry = sp[e * 3 + 1] / cnt[e];
        const rz = sp[e * 3 + 2] / cnt[e];
        let qx = sn[e * 3];
        let qy = sn[e * 3 + 1];
        let qz = sn[e * 3 + 2];
        const ql = Math.hypot(qx, qy, qz) || 1;
        qx /= ql;
        qy /= ql;
        qz /= ql;
        if (!insideSolid(rx + qx * EPS, ry + qy * EPS, rz + qz * EPS)) {
          const cid = cF.length;
          cpos.push(rx, ry, rz);
          cnrm.push(qx, qy, qz);
          cF.push(f);
          cI.push(0);
          cJ.push(0);
          cFree.push(true);
          this.ecid.fill(cid, base, base + NN);
          thinFallbacks++;
        }
      }
      // fill invalid texels from valid neighbours (buried / off-surface lattice points)
      for (let it = 0; it < N; it++) {
        let changed = false;
        const snapshot = this.ecid.slice(base, base + NN);
        for (let j = 0; j < N; j++)
          for (let i = 0; i < N; i++) {
            if (snapshot[j * N + i] >= 0) continue;
            let c = -1;
            if (i > 0 && snapshot[j * N + i - 1] >= 0) c = snapshot[j * N + i - 1];
            else if (i < N - 1 && snapshot[j * N + i + 1] >= 0) c = snapshot[j * N + i + 1];
            else if (j > 0 && snapshot[(j - 1) * N + i] >= 0) c = snapshot[(j - 1) * N + i];
            else if (j < N - 1 && snapshot[(j + 1) * N + i] >= 0) c = snapshot[(j + 1) * N + i];
            if (c >= 0) {
              this.ecid[base + j * N + i] = c;
              changed = true;
            }
          }
        if (!changed) break;
      }
      for (let k = 0; k < NN; k++) if (this.ecid[base + k] < 0) this.ecid[base + k] = 0; // fully buried: black
    }

    const C = cF.length;
    this.corners = C;
    this.cpos = Float64Array.from(cpos);
    this.cnrm = Float64Array.from(cnrm);

    // ---- 4. lattice adjacency for the denoiser ---------------------------------------------
    const lat = new Map<number, number[]>();
    for (let c = 1; c < C; c++) {
      if (cFree[c]) continue;
      const k = (cF[c] * 4096 + (cI[c] + 2048)) * 4096 + (cJ[c] + 2048);
      const l = lat.get(k);
      if (l) l.push(c);
      else lat.set(k, [c]);
    }
    this.nbr = new Int32Array(C * 8).fill(-1);
    const offs = [
      [-1, 0],
      [1, 0],
      [0, -1],
      [0, 1],
      [-1, -1],
      [1, -1],
      [-1, 1],
      [1, 1],
    ];
    for (let c = 1; c < C; c++) {
      if (cFree[c]) continue;
      for (let o = 0; o < 8; o++) {
        const k = (cF[c] * 4096 + (cI[c] + offs[o][0] + 2048)) * 4096 + (cJ[c] + offs[o][1] + 2048);
        const l = lat.get(k);
        if (!l) continue;
        const expect = step * (o < 4 ? 1 : Math.SQRT2);
        let best = -1;
        let bd = expect * 1.5;
        for (const q of l) {
          const d = Math.hypot(
            this.cpos[q * 3] - this.cpos[c * 3],
            this.cpos[q * 3 + 1] - this.cpos[c * 3 + 1],
            this.cpos[q * 3 + 2] - this.cpos[c * 3 + 2],
          );
          const nd =
            this.cnrm[q * 3] * this.cnrm[c * 3] + this.cnrm[q * 3 + 1] * this.cnrm[c * 3 + 1] + this.cnrm[q * 3 + 2] * this.cnrm[c * 3 + 2];
          if (d < bd && nd > 0.8) {
            bd = d;
            best = q;
          }
        }
        this.nbr[c * 8 + o] = best;
      }
    }

    // ---- 5. filtered visibility of the delta lights on every lattice point -------------------
    this.cface = Uint8Array.from(cF);
    this.vis = new Float32Array(C * 2);
    const v2 = new Float64Array(2);
    for (let c = 1; c < C; c++) {
      visFiltered(
        this.cpos[c * 3],
        this.cpos[c * 3 + 1],
        this.cpos[c * 3 + 2],
        this.cnrm[c * 3],
        this.cnrm[c * 3 + 1],
        this.cnrm[c * 3 + 2],
        cFree[c] ? 0.5 * step : 1.25 * step,
        v2,
      );
      this.vis[c * 2] = v2[0];
      this.vis[c * 2 + 1] = v2[1];
    }
    this.acc = new Float64Array(C * NA);
    this.final = new Float32Array(C * 9);
    this.hat = new Float32Array(C * 9);
    this.grad = new Float32Array(C * 2);
    this.coef = new Float32Array(C * PCA_K);
    this.basis = new Float32Array(PCA_K * 9);

    // ---- 6. dense index + stats -------------------------------------------------------------
    const M = this.hash.M;
    this.dense = buildDenseIndex(this.ecx, this.ecy, this.ecz, this.ef, this.hash.slotOf, M);
    const rows = Math.ceil(M / SW);
    const atlasBytes = SW * N * rows * N * (8 + 4); // RGBA16F + RGBA8
    const dispBytes = this.hash.B * 2;
    const area = bakedSurfaceArea(this.mesh);
    const vol = (ROOM.max[0] - ROOM.min[0]) * (ROOM.max[1] - ROOM.min[1]) * (ROOM.max[2] - ROOM.min[2]);
    this.stats = {
      entries: n,
      slots: M,
      load: n / M,
      corners: C - 1,
      maxDisp: this.hash.maxDisp,
      attempts: this.hash.attempts,
      atlasBytes,
      dispBytes,
      denseBytes: this.dense.bytes,
      totalBytes: atlasBytes + dispBytes,
      v1AtlasBytes: SW * N * Math.ceil(Math.ceil(n / 0.9) / SW) * N * 12,
      area,
      lightmapBytes: (area / (step * step)) * 1.35 * 4 * 3,
      volumeBytes: (vol / (step * step * step)) * 6 * 4 * 3,
      enumSamples,
      prepMs: performance.now() - t0,
    };
    void thinFallbacks;
  }

  layout(): LutLayout {
    const { N, step } = this.cfg;
    const M = this.hash.M;
    const rows = Math.ceil(M / SW);
    const dispH = Math.ceil(this.hash.B / DISP_W);
    const disp = new Uint16Array(DISP_W * dispH);
    disp.set(this.hash.disp);
    const d = this.dense;
    return {
      step,
      cell: this.cell,
      N,
      n: this.n,
      M,
      B: this.hash.B,
      salts: Array.from(this.hash.salts),
      SW,
      atlasW: SW * N,
      atlasH: rows * N,
      GO: this.GO,
      disp,
      dispW: DISP_W,
      dispH,
      dense: { min: d.min, dim: d.dim, w: d.w, h: d.h, data: d.data },
    };
  }

  // ---------------------------------------------------------------------------------------------
  runPass(spp: number, onProgress?: (f: number) => void) {
    const C = this.corners;
    const tmp = new Float64Array(NA);
    const base = this.totalSpp;
    for (let c = 1; c < C; c++) {
      seedRng(Math.imul(c, 2654435761) ^ Math.imul(this.passIndex + 1, 0x9e3779b1));
      const ou = hash32(c * 7 + 1) / 4294967296;
      const ov = hash32(c * 13 + 5) / 4294967296;
      tmp.fill(0);
      const a = this.cface[c] >> 1;
      pathIndirect(
        this.cpos[c * 3],
        this.cpos[c * 3 + 1],
        this.cpos[c * 3 + 2],
        this.cnrm[c * 3],
        this.cnrm[c * 3 + 1],
        this.cnrm[c * 3 + 2],
        spp,
        base,
        ou,
        ov,
        tmp,
        (a + 1) % 3,
        (a + 2) % 3,
      );
      const o = c * NA;
      for (let q = 0; q < NA; q++) this.acc[o + q] += tmp[q];
      if (onProgress && (c & 255) === 0) onProgress(c / C);
    }
    this.totalSpp += spp;
    this.passIndex++;
    this.refresh();
  }

  /** denoise (lattice blur of the indirect part), derive the gradient ratios, PCA-code the 9-vector */
  private refresh() {
    const C = this.corners;
    const inv = 1 / this.totalSpp;
    let src = new Float32Array(C * NA);
    for (let i = 0; i < src.length; i++) src[i] = this.acc[i] * inv;
    const iters = this.totalSpp < 32 ? 2 : 1;
    for (let it = 0; it < iters; it++) {
      const dst = new Float32Array(C * NA);
      for (let c = 1; c < C; c++) {
        let w = 4;
        const o = c * NA;
        for (let q = 0; q < NA; q++) dst[o + q] = src[o + q] * 4;
        for (let k = 0; k < 8; k++) {
          const nb = this.nbr[c * 8 + k];
          if (nb < 0) continue;
          const wk = k < 4 ? 2 : 1;
          w += wk;
          for (let q = 0; q < NA; q++) dst[o + q] += src[nb * NA + q] * wk;
        }
        const iw = 1 / w;
        for (let q = 0; q < NA; q++) dst[o + q] *= iw;
      }
      src = dst;
    }
    for (let c = 1; c < this.corners; c++) {
      const o = c * NA;
      for (let q = 0; q < 9; q++) this.final[c * 9 + q] = src[o + q];
      const el = 0.2126 * src[o + 3] + 0.7152 * src[o + 4] + 0.0722 * src[o + 5];
      if (el > 2e-3) {
        this.grad[c * 2] = Math.max(-1, Math.min(1, src[o + 9] / el));
        this.grad[c * 2 + 1] = Math.max(-1, Math.min(1, src[o + 10] / el));
      } else {
        this.grad[c * 2] = 0;
        this.grad[c * 2 + 1] = 0;
      }
    }
    this.fitPCA();
  }

  /**
   * Every light is linear, so the 3 lights x RGB = 9-vector of every lattice point lives in a low dimensional
   * subspace (light visibility is mostly a *scalar* field per light, colour comes from a handful of bleed patterns).
   * Uncentred PCA over all lattice points, weighted by the default light gains, K = 4 coefficients per texel.
   * Runtime:  R = sum_k coef_k * M_k   with M_k = sum_light gain_light * basis_light,k   (CPU, once per frame).
   */
  private fitPCA() {
    const C = this.corners;
    const K = PCA_K;
    const L = (l: { color: V3; intensity: number }) => (0.2126 * l.color[0] + 0.7152 * l.color[1] + 0.0722 * l.color[2]) * l.intensity;
    const sc = [L(DEFAULT_LIGHTS.sun), L(DEFAULT_LIGHTS.sky), L(DEFAULT_LIGHTS.lamp)];
    const S = [sc[0], sc[0], sc[0], sc[1], sc[1], sc[1], sc[2], sc[2], sc[2]];
    const M = Array.from({ length: 9 }, () => new Array(9).fill(0));
    const y = new Float64Array(9);
    for (let c = 1; c < C; c++) {
      for (let q = 0; q < 9; q++) y[q] = this.final[c * 9 + q] * S[q];
      for (let i = 0; i < 9; i++) for (let j = i; j < 9; j++) M[i][j] += y[i] * y[j];
    }
    for (let i = 0; i < 9; i++) for (let j = 0; j < i; j++) M[i][j] = M[j][i];
    let trace = 0;
    for (let i = 0; i < 9; i++) trace += M[i][i];
    const { vals, vecs } = jacobiEig(M, 9);
    const energy: number[] = [];
    let cum = 0;
    for (let k = 0; k < 9; k++) {
      cum += Math.max(0, vals[k]);
      energy.push(trace > 0 ? cum / trace : 1);
    }
    for (let k = 0; k < K; k++) for (let q = 0; q < 9; q++) this.basis[k * 9 + q] = vecs[k][q] / S[q];
    let errNum = 0;
    let errDen = 0;
    for (let c = 1; c < C; c++) {
      for (let q = 0; q < 9; q++) y[q] = this.final[c * 9 + q] * S[q];
      for (let k = 0; k < K; k++) {
        let d = 0;
        for (let q = 0; q < 9; q++) d += vecs[k][q] * y[q];
        this.coef[c * K + k] = d;
      }
      for (let q = 0; q < 9; q++) {
        let h = 0;
        for (let k = 0; k < K; k++) h += this.coef[c * K + k] * this.basis[k * 9 + q];
        this.hat[c * 9 + q] = h;
        const e = (h - this.final[c * 9 + q]) * S[q];
        errNum += e * e;
        errDen += y[q] * y[q];
      }
    }
    this.pca = { k: K, energy, err: Math.sqrt(errNum / Math.max(errDen, 1e-12)) };
  }

  pca: PcaInfo = { k: PCA_K, energy: [], err: 0 };

  /** the two GPU atlases: RGBA16F coefficients and RGBA8 (V_sun, V_lamp, g_u, g_v) */
  pack(): { A: Uint16Array; B: Uint8Array } {
    const { N } = this.cfg;
    const K = PCA_K;
    const M = this.hash.M;
    const rows = Math.ceil(M / SW);
    const W = SW * N;
    const H = rows * N;
    const A = new Uint16Array(W * H * 4);
    const B = new Uint8Array(W * H * 4);
    for (let i = 0; i < W * H; i++) {
      B[i * 4 + 2] = 128;
      B[i * 4 + 3] = 128;
    }
    for (let e = 0; e < this.n; e++) {
      const slot = this.hash.slotOf[e];
      const tx = (slot % SW) * N;
      const ty = Math.floor(slot / SW) * N;
      for (let j = 0; j < N; j++)
        for (let i = 0; i < N; i++) {
          const cid = this.ecid[e * N * N + j * N + i];
          const at = ((ty + j) * W + tx + i) * 4;
          for (let k = 0; k < K; k++) A[at + k] = toHalf(this.coef[cid * K + k]);
          B[at] = Math.round(this.vis[cid * 2] * 255);
          B[at + 1] = Math.round(this.vis[cid * 2 + 1] * 255);
          B[at + 2] = Math.round((this.grad[cid * 2] * 0.5 + 0.5) * 255);
          B[at + 3] = Math.round((this.grad[cid * 2 + 1] * 0.5 + 0.5) * 255);
        }
    }
    return { A, B };
  }

  // ---------------------------------------------------------------------------------------------
  // CPU mirror of the fragment shader (float, un-packed except 8-bit visibility / gradient)
  // ---------------------------------------------------------------------------------------------
  /** bilinear tile fetch: out[0..8] indirect transfer, [9..10] visibility, [11..12] gradient. false when the key is missing */
  private sampleFace(px: number, py: number, pz: number, f: number, out: Float64Array): boolean {
    const { N } = this.cfg;
    const a = f >> 1;
    const q = [(px - this.GO[0]) / this.cell, (py - this.GO[1]) / this.cell, (pz - this.GO[2]) / this.cell];
    const c = [Math.floor(q[0]), Math.floor(q[1]), Math.floor(q[2])];
    const fr = [q[0] - c[0], q[1] - c[1], q[2] - c[2]];
    const present = this.entryMap.has(this.keyNum(c[0], c[1], c[2], f));
    const slot = lookupSlot(this.hash, cellBits(c[0], c[1], c[2]), f);
    const e = this.slotEntry[slot];
    out.fill(0);
    if (e < 0) return false;
    const fu = fr[(a + 1) % 3] * (N - 1);
    const fv = fr[(a + 2) % 3] * (N - 1);
    const i0 = Math.min(Math.floor(fu), N - 2);
    const j0 = Math.min(Math.floor(fv), N - 2);
    const tu = fu - i0;
    const tv = fv - j0;
    const b = e * N * N;
    const ids = [this.ecid[b + j0 * N + i0], this.ecid[b + j0 * N + i0 + 1], this.ecid[b + (j0 + 1) * N + i0], this.ecid[b + (j0 + 1) * N + i0 + 1]];
    const ws = [(1 - tu) * (1 - tv), tu * (1 - tv), (1 - tu) * tv, tu * tv];
    for (let k = 0; k < 4; k++) {
      const id = ids[k];
      const w = ws[k];
      for (let q2 = 0; q2 < 9; q2++) out[q2] += w * this.hat[id * 9 + q2];
      out[9] += w * Math.round(this.vis[id * 2] * 255) / 255;
      out[10] += w * Math.round(this.vis[id * 2 + 1] * 255) / 255;
      out[11] += w * (Math.round((this.grad[id * 2] * 0.5 + 0.5) * 255) / 255 * 2 - 1);
      out[12] += w * (Math.round((this.grad[id * 2 + 1] * 0.5 + 0.5) * 255) / 255 * 2 - 1);
    }
    return present;
  }

  /**
   * mode 0: normal map ignored      1: analytic direct with the bumped normal, indirect un-relit
   *      2: + isotropic wrap        3: + sky gradient (full method)
   * G: runtime gains [sun, sky, lamp].  Returns radiance for albedo 1.
   */
  shade(p: V3, ng: V3, ns: V3, mode: number, G: V3[], out: Float64Array): boolean {
    const tmp = new Float64Array(13);
    out.fill(0);
    let ws = 0;
    let vs = 0;
    let vl = 0;
    let ok = true;
    const wrap = mode >= 2 ? 0.5 * (1 + ns[0] * ng[0] + ns[1] * ng[1] + ns[2] * ng[2]) : 1;
    for (let ax = 0; ax < 3; ax++) {
      const w = ng[ax] * ng[ax];
      if (w <= 0.03) continue;
      const f = 2 * ax + (ng[ax] < 0 ? 1 : 0);
      if (!this.sampleFace(p[0], p[1], p[2], f, tmp)) ok = false;
      ws += w;
      const ua = (ax + 1) % 3;
      const va = (ax + 2) % 3;
      const du = ns[ua] - ng[ua];
      const dv = ns[va] - ng[va];
      for (let c = 0; c < 3; c++) {
        const eAll = G[0][c] * tmp[c] + G[1][c] * tmp[3 + c] + G[2][c] * tmp[6 + c];
        const eSky = G[1][c] * tmp[3 + c];
        out[c] += w * (eAll * wrap + (mode === 3 ? eSky * (tmp[11] * du + tmp[12] * dv) : 0));
      }
      vs += w * tmp[9];
      vl += w * tmp[10];
    }
    if (ws > 0) {
      for (let c = 0; c < 3; c++) out[c] /= ws;
      vs /= ws;
      vl /= ws;
    }
    const n = mode === 0 ? ng : ns;
    const cs = Math.max(0, n[0] * SUN_DIR[0] + n[1] * SUN_DIR[1] + n[2] * SUN_DIR[2]);
    const lx = LAMP_POS[0] - p[0];
    const ly = LAMP_POS[1] - p[1];
    const lz = LAMP_POS[2] - p[2];
    const d2 = lx * lx + ly * ly + lz * lz;
    const cl = Math.max(0, (n[0] * lx + n[1] * ly + n[2] * lz) / Math.sqrt(d2));
    for (let c = 0; c < 3; c++) out[c] = Math.max(0, out[c]) + (G[0][c] * vs * cs) / Math.PI + (G[2][c] * vl * cl) / (Math.PI * d2);
    return ok;
  }

  /** channel-separated radiance (indirect from the LUT + exact direct) at a surface point, for the probe gather */
  private channelsAt(px: number, py: number, pz: number, nx: number, ny: number, nz: number, out9: Float64Array) {
    const tmp = new Float64Array(13);
    const nv = [nx, ny, nz];
    out9.fill(0);
    let ws = 0;
    for (let ax = 0; ax < 3; ax++) {
      const w = nv[ax] * nv[ax];
      if (w <= 0.03) continue;
      this.sampleFace(px, py, pz, 2 * ax + (nv[ax] < 0 ? 1 : 0), tmp);
      ws += w;
      for (let q = 0; q < 9; q++) out9[q] += w * tmp[q];
    }
    if (ws > 0) for (let q = 0; q < 9; q++) out9[q] /= ws;
    directAt(px, py, pz, nx, ny, nz, out9);
  }

  // ---------------------------------------------------------------------------------------------
  // Dynamic-object support data
  // ---------------------------------------------------------------------------------------------
  volume!: Uint8Array;

  /** RGBA8 3D volume: static sun / lamp visibility + SDF.  Voxels inside solids are filled from free neighbours. */
  buildVolume(): Uint8Array {
    const [nx, ny, nz] = VOL_DIM;
    const total = nx * ny * nz;
    const vs = new Float32Array(total * 2);
    const sd = new Float32Array(total);
    const solid = new Uint8Array(total);
    const v2 = new Float64Array(2);
    const s = VOL.step;
    for (let z = 0; z < nz; z++)
      for (let y = 0; y < ny; y++)
        for (let x = 0; x < nx; x++) {
          const id = (z * ny + y) * nx + x;
          const px = VOL.min[0] + (x + 0.5) * s;
          const py = VOL.min[1] + (y + 0.5) * s;
          const pz = VOL.min[2] + (z + 0.5) * s;
          const d = sdfAt(px, py, pz);
          sd[id] = d;
          if (d < 0) {
            solid[id] = 1;
            continue;
          }
          visAt(px, py, pz, v2);
          vs[id * 2] = v2[0];
          vs[id * 2 + 1] = v2[1];
        }
    // dilate visibility into solids (2 rings) so trilinear filtering near surfaces does not darken
    for (let pass = 0; pass < 2; pass++) {
      const next = vs.slice();
      const mark = solid.slice();
      for (let z = 0; z < nz; z++)
        for (let y = 0; y < ny; y++)
          for (let x = 0; x < nx; x++) {
            const id = (z * ny + y) * nx + x;
            if (!solid[id]) continue;
            let a = 0;
            let b = 0;
            let cnt = 0;
            for (let k = 0; k < 6; k++) {
              const xx = x + (k === 0 ? 1 : k === 1 ? -1 : 0);
              const yy = y + (k === 2 ? 1 : k === 3 ? -1 : 0);
              const zz = z + (k === 4 ? 1 : k === 5 ? -1 : 0);
              if (xx < 0 || yy < 0 || zz < 0 || xx >= nx || yy >= ny || zz >= nz) continue;
              const j = (zz * ny + yy) * nx + xx;
              if (solid[j]) continue;
              a += vs[j * 2];
              b += vs[j * 2 + 1];
              cnt++;
            }
            if (cnt) {
              next[id * 2] = a / cnt;
              next[id * 2 + 1] = b / cnt;
              mark[id] = 0;
            }
          }
      vs.set(next);
      solid.set(mark);
    }
    const out = new Uint8Array(total * 4);
    for (let i = 0; i < total; i++) {
      out[i * 4] = Math.round(vs[i * 2] * 255);
      out[i * 4 + 1] = Math.round(vs[i * 2 + 1] * 255);
      out[i * 4 + 2] = Math.round(Math.max(0, Math.min(1, sd[i] / SDF_RANGE)) * 255);
      out[i * 4 + 3] = 255;
    }
    this.volume = out;
    return out;
  }

  volSample(px: number, py: number, pz: number, out3: Float64Array) {
    const [nx, ny, nz] = VOL_DIM;
    const gx = (px - VOL.min[0]) / VOL.step - 0.5;
    const gy = (py - VOL.min[1]) / VOL.step - 0.5;
    const gz = (pz - VOL.min[2]) / VOL.step - 0.5;
    const x0 = Math.max(0, Math.min(nx - 2, Math.floor(gx)));
    const y0 = Math.max(0, Math.min(ny - 2, Math.floor(gy)));
    const z0 = Math.max(0, Math.min(nz - 2, Math.floor(gz)));
    const fx = Math.max(0, Math.min(1, gx - x0));
    const fy = Math.max(0, Math.min(1, gy - y0));
    const fz = Math.max(0, Math.min(1, gz - z0));
    out3.fill(0);
    for (let k = 0; k < 8; k++) {
      const dx = k & 1;
      const dy = (k >> 1) & 1;
      const dz = (k >> 2) & 1;
      const w = (dx ? fx : 1 - fx) * (dy ? fy : 1 - fy) * (dz ? fz : 1 - fz);
      const o = (((z0 + dz) * ny + (y0 + dy)) * nx + (x0 + dx)) * 4;
      for (let c = 0; c < 3; c++) out3[c] += (w * this.volume[o + c]) / 255;
    }
  }

  probes!: Float32Array;

  /**
   * Irradiance probes by *single-bounce gather from the finished LUT*: one ray per direction, at the hit we read the
   * (already multi-bounce, denoised) LUT + exact direct light -> infinite bounces for the price of one ray, almost
   * noise free.  Stored as L1 SH per transfer channel: R(n) = A + B.n   (A = mean L, B = 2 mean(L w)).
   */
  bakeProbes(R = 192): Float32Array {
    const { dim, step, min } = PROBES;
    const np = dim[0] * dim[1] * dim[2];
    const out = new Float32Array(np * PROBE_STRIDE);
    const c9 = new Float64Array(9);
    const sk = new Float64Array(3);
    const acc = new Float64Array(36);
    for (let z = 0; z < dim[2]; z++)
      for (let y = 0; y < dim[1]; y++)
        for (let x = 0; x < dim[0]; x++) {
          const id = (z * dim[1] + y) * dim[0] + x;
          const px = min[0] + x * step;
          const py = min[1] + y * step;
          const pz = min[2] + z * step;
          const o = id * PROBE_STRIDE;
          if (insideSolid(px, py, pz) || sdfAt(px, py, pz) < 0.04) continue;
          seedRng(id * 7919 + 13);
          const phi0 = hash32(id * 31 + 7) / 4294967296 * 6.2831853;
          acc.fill(0);
          for (let i = 0; i < R; i++) {
            const dy = 1 - (2 * (i + 0.5)) / R;
            const r = Math.sqrt(Math.max(0, 1 - dy * dy));
            const ph = phi0 + i * 2.399963229728653;
            const dx = r * Math.cos(ph);
            const dz = r * Math.sin(ph);
            const L = [0, 0, 0, 0, 0, 0, 0, 0, 0];
            if (!closest(px, py, pz, dx, dy, dz, 1e9)) {
              skyInto(dx, dy, dz, sk);
              L[3] = sk[0];
              L[4] = sk[1];
              L[5] = sk[2];
            } else {
              const hx = px + dx * hit.t;
              const hy = py + dy * hit.t;
              const hz = pz + dz * hit.t;
              const nx2 = hit.nx;
              const ny2 = hit.ny;
              const nz2 = hit.nz;
              this.channelsAt(hx + nx2 * 1e-3, hy + ny2 * 1e-3, hz + nz2 * 1e-3, nx2, ny2, nz2, c9);
              const alb = [hit.ar, hit.ag, hit.ab];
              for (let ch = 0; ch < 3; ch++) for (let c = 0; c < 3; c++) L[ch * 3 + c] = alb[c] * c9[ch * 3 + c];
            }
            for (let ch = 0; ch < 3; ch++)
              for (let c = 0; c < 3; c++) {
                const l = L[ch * 3 + c];
                const b = ch * 12 + c;
                acc[b] += l;
                acc[b + 3] += l * dx;
                acc[b + 6] += l * dy;
                acc[b + 9] += l * dz;
              }
          }
          for (let ch = 0; ch < 3; ch++)
            for (let c = 0; c < 3; c++) {
              const b = ch * 12 + c;
              out[o + b] = acc[b] / R;
              out[o + b + 3] = (2 * acc[b + 3]) / R;
              out[o + b + 6] = (2 * acc[b + 6]) / R;
              out[o + b + 9] = (2 * acc[b + 9]) / R;
            }
          out[o + 36] = 1;
        }
    this.probes = out;
    return out;
  }

  // ---------------------------------------------------------------------------------------------
  /** Compare the LUT against fresh high-sample path tracing at random held-out surface points / free-space points. */
  validate(points = 140, spp = 512): Validation {
    const { pos, nrm, mat, idx } = this.mesh;
    const tris: number[] = [];
    const cum: number[] = [];
    let total = 0;
    for (let t = 0; t < idx.length; t += 3) {
      const i0 = idx[t];
      if (mat[i0] < 0) continue;
      const i1 = idx[t + 1];
      const i2 = idx[t + 2];
      const ax = pos[i1 * 3] - pos[i0 * 3];
      const ay = pos[i1 * 3 + 1] - pos[i0 * 3 + 1];
      const az = pos[i1 * 3 + 2] - pos[i0 * 3 + 2];
      const bx = pos[i2 * 3] - pos[i0 * 3];
      const by = pos[i2 * 3 + 1] - pos[i0 * 3 + 1];
      const bz = pos[i2 * 3 + 2] - pos[i0 * 3 + 2];
      total += 0.5 * Math.hypot(ay * bz - az * by, az * bx - ax * bz, ax * by - ay * bx);
      tris.push(t);
      cum.push(total);
    }
    seedRng(0xc0ffee);
    let s = 0x1234567;
    const rand = () => {
      s ^= s << 13;
      s ^= s >>> 17;
      s ^= s << 5;
      return (s >>> 0) / 4294967296;
    };
    const G: V3[] = [DEFAULT_LIGHTS.sun, DEFAULT_LIGHTS.sky, DEFAULT_LIGHTS.lamp].map((l) => [l.color[0] * l.intensity, l.color[1] * l.intensity, l.color[2] * l.intensity] as V3);
    const lum3 = (v: ArrayLike<number>) => 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
    const fold = (v9: ArrayLike<number>, out3: Float64Array) => {
      for (let c = 0; c < 3; c++) out3[c] = G[0][c] * v9[c] + G[1][c] * v9[3 + c] + G[2][c] * v9[6 + c];
    };
    const lut = new Float64Array(3);
    const gt9 = new Float64Array(9);
    const gt3 = new Float64Array(3);
    const errs: number[] = [];
    let covered = 0;
    let tested = 0;
    let sumAbs = 0;
    let sumGt = 0;
    const nmAbs = [0, 0, 0, 0];
    let nmGt = 0;
    let guard = 0;
    while (tested < points && guard++ < points * 20) {
      const r = rand() * total;
      let lo = 0;
      let hi = cum.length - 1;
      while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (cum[mid] < r) lo = mid + 1;
        else hi = mid;
      }
      const t = tris[lo];
      const i0 = idx[t];
      const i1 = idx[t + 1];
      const i2 = idx[t + 2];
      let a = rand();
      let b = rand();
      if (a + b > 1) {
        a = 1 - a;
        b = 1 - b;
      }
      const w0 = 1 - a - b;
      const P: V3 = [
        pos[i0 * 3] * w0 + pos[i1 * 3] * a + pos[i2 * 3] * b,
        pos[i0 * 3 + 1] * w0 + pos[i1 * 3 + 1] * a + pos[i2 * 3 + 1] * b,
        pos[i0 * 3 + 2] * w0 + pos[i1 * 3 + 2] * a + pos[i2 * 3 + 2] * b,
      ];
      let nx = nrm[i0 * 3] * w0 + nrm[i1 * 3] * a + nrm[i2 * 3] * b;
      let ny = nrm[i0 * 3 + 1] * w0 + nrm[i1 * 3 + 1] * a + nrm[i2 * 3 + 1] * b;
      let nz = nrm[i0 * 3 + 2] * w0 + nrm[i1 * 3 + 2] * a + nrm[i2 * 3 + 2] * b;
      const il = 1 / Math.hypot(nx, ny, nz);
      nx *= il;
      ny *= il;
      nz *= il;
      if (insideSolid(P[0] + nx * EPS, P[1] + ny * EPS, P[2] + nz * EPS)) continue; // buried face
      tested++;
      const NG: V3 = [nx, ny, nz];
      // ---- flat normal ----------------------------------------------------------------------
      const ok = this.shade(P, NG, NG, 0, G, lut);
      if (ok) covered++;
      gt9.fill(0);
      directAt(P[0], P[1], P[2], nx, ny, nz, gt9);
      const ind = new Float64Array(11);
      pathIndirect(P[0], P[1], P[2], nx, ny, nz, spp, 0, rand(), rand(), ind);
      for (let k = 0; k < 9; k++) gt9[k] += ind[k] / spp;
      fold(gt9, gt3);
      const a1 = lum3(lut);
      const b1 = lum3(gt3);
      sumAbs += Math.abs(a1 - b1);
      sumGt += b1;
      errs.push(Math.abs(a1 - b1) / Math.max(b1, 1e-3));
      // ---- tilted shading normal (what a normal map does) ----------------------------------
      const ang = rand() * 0.75; // up to ~43 degrees
      const az = rand() * Math.PI * 2;
      let tx: number, ty: number, tz: number;
      if (Math.abs(nx) > 0.9) [tx, ty, tz] = [-nz, 0, nx];
      else [tx, ty, tz] = [0, nz, -ny];
      const tl = 1 / Math.hypot(tx, ty, tz);
      tx *= tl;
      ty *= tl;
      tz *= tl;
      const bx = ny * tz - nz * ty;
      const by = nz * tx - nx * tz;
      const bz = nx * ty - ny * tx;
      const sa = Math.sin(ang) * Math.cos(az);
      const sb = Math.sin(ang) * Math.sin(az);
      const NS: V3 = [nx * Math.cos(ang) + tx * sa + bx * sb, ny * Math.cos(ang) + ty * sa + by * sb, nz * Math.cos(ang) + tz * sa + bz * sb];
      // ground truth: exact direct with shading normal (gated by the geometric one) + path traced indirect
      gt9.fill(0);
      const ox = P[0] + nx * EPS;
      const oy = P[1] + ny * EPS;
      const oz = P[2] + nz * EPS;
      const cgs = nx * SUN_DIR[0] + ny * SUN_DIR[1] + nz * SUN_DIR[2];
      const css = NS[0] * SUN_DIR[0] + NS[1] * SUN_DIR[1] + NS[2] * SUN_DIR[2];
      if (cgs > 0 && css > 0 && !occluded(ox, oy, oz, SUN_DIR[0], SUN_DIR[1], SUN_DIR[2], 1e9)) for (let c = 0; c < 3; c++) gt9[c] += css / Math.PI;
      const lx = LAMP_POS[0] - ox;
      const ly = LAMP_POS[1] - oy;
      const lz = LAMP_POS[2] - oz;
      const l2 = lx * lx + ly * ly + lz * lz;
      const l = Math.sqrt(l2);
      const cgl = (nx * lx + ny * ly + nz * lz) / l;
      const csl = (NS[0] * lx + NS[1] * ly + NS[2] * lz) / l;
      if (cgl > 0 && csl > 0 && !occluded(ox, oy, oz, lx / l, ly / l, lz / l, l)) for (let c = 0; c < 3; c++) gt9[6 + c] += csl / (Math.PI * l2);
      ind.fill(0);
      pathIndirect(P[0], P[1], P[2], nx, ny, nz, spp, 0, rand(), rand(), ind, -1, -1, NS[0], NS[1], NS[2]);
      for (let k = 0; k < 9; k++) gt9[k] += ind[k] / spp;
      fold(gt9, gt3);
      const gl = lum3(gt3);
      nmGt += gl;
      for (let m = 0; m < 4; m++) {
        this.shade(P, NG, NS, m, G, lut);
        nmAbs[m] += Math.abs(lum3(lut) - gl);
      }
    }
    errs.sort((x, y) => x - y);

    // ---- dynamic objects: free-space probes + visibility volume vs path tracing -----------------------
    let dynAbs = 0;
    let dynGt = 0;
    let dynN = 0;
    const vol3 = new Float64Array(3);
    const sh = new Float64Array(36);
    guard = 0;
    while (this.probes && dynN < 90 && guard++ < 4000) {
      const px = -3.6 + rand() * 7.2;
      const py = 0.3 + rand() * 2.8;
      const pz = -3.6 + rand() * 7.2;
      if (insideSolid(px, py, pz) || sdfAt(px, py, pz) < 0.2) continue;
      const u = rand() * 2 - 1;
      const ph = rand() * Math.PI * 2;
      const rr = Math.sqrt(1 - u * u);
      const n: V3 = [rr * Math.cos(ph), u, rr * Math.sin(ph)];
      dynN++;
      gt9.fill(0);
      directAt(px, py, pz, n[0], n[1], n[2], gt9);
      const ind = new Float64Array(11);
      pathIndirect(px, py, pz, n[0], n[1], n[2], spp, 0, rand(), rand(), ind);
      for (let k = 0; k < 9; k++) gt9[k] += ind[k] / spp;
      fold(gt9, gt3);
      sampleProbes(this.probes, px, py, pz, sh);
      this.volSample(px, py, pz, vol3);
      let lumM = 0;
      const R3 = [0, 0, 0];
      for (let ch = 0; ch < 3; ch++)
        for (let c = 0; c < 3; c++) {
          const v = sh[ch * 12 + c] + sh[ch * 12 + 3 + c] * n[0] + sh[ch * 12 + 6 + c] * n[1] + sh[ch * 12 + 9 + c] * n[2];
          R3[c] += G[ch][c] * Math.max(0, v);
        }
      const cs = Math.max(0, n[0] * SUN_DIR[0] + n[1] * SUN_DIR[1] + n[2] * SUN_DIR[2]);
      const lx = LAMP_POS[0] - px;
      const ly = LAMP_POS[1] - py;
      const lz = LAMP_POS[2] - pz;
      const d2 = lx * lx + ly * ly + lz * lz;
      const cl = Math.max(0, (n[0] * lx + n[1] * ly + n[2] * lz) / Math.sqrt(d2));
      for (let c = 0; c < 3; c++) R3[c] += (G[0][c] * vol3[0] * cs) / Math.PI + (G[2][c] * vol3[1] * cl) / (Math.PI * d2);
      lumM = lum3(R3);
      const lumG = lum3(gt3);
      dynAbs += Math.abs(lumM - lumG);
      dynGt += lumG;
    }
    const nmNorm = Math.max(nmGt, 1e-9);
    return {
      points: tested,
      meanRelErr: sumAbs / Math.max(sumGt, 1e-9),
      medianRelErr: errs[Math.floor(errs.length / 2)] ?? 0,
      p90RelErr: errs[Math.floor(errs.length * 0.9)] ?? 0,
      coverage: tested ? covered / tested : 1,
      nm: { ignore: nmAbs[0] / nmNorm, naive: nmAbs[1] / nmNorm, wrap: nmAbs[2] / nmNorm, dir: nmAbs[3] / nmNorm },
      dynPoints: dynN,
      dynRelErr: dynAbs / Math.max(dynGt, 1e-9),
    };
  }
}
