import { useEffect, useState } from "react";
import BakeWorker from "./bake.worker?worker&inline";
import { BAKE_PASSES, type BakeConfig, type BakeStats, type LutLayout, type Validation, type PcaInfo } from "./bake";
import type { RadRenderer } from "./renderer";
import type { WorkerOut } from "./bake.worker";

export interface BakeState {
  phase: "idle" | "prep" | "baking" | "done" | "error";
  pass: number; // finished passes
  passes: number;
  totalSpp: number;
  frac: number; // progress inside the running pass
  stats: BakeStats | null;
  validation: Validation | null;
  pca: PcaInfo | null;
  probeMs: number;
  volumeMs: number;
  elapsedMs: number;
  firstUsableMs: number;
  error?: string;
}

const INITIAL: BakeState = {
  phase: "idle",
  pass: 0,
  passes: BAKE_PASSES.length,
  totalSpp: 0,
  frac: 0,
  stats: null,
  validation: null,
  pca: null,
  probeMs: 0,
  volumeMs: 0,
  elapsedMs: 0,
  firstUsableMs: 0,
};

/** Runs the progressive baker in a worker and streams every refinement pass straight into the GPU atlases. */
export function useBaker(renderer: RadRenderer | null, cfg: BakeConfig): BakeState {
  const [state, setState] = useState<BakeState>(INITIAL);

  useEffect(() => {
    if (!renderer) return;
    setState({ ...INITIAL, phase: "prep" });
    const worker = new BakeWorker();
    let layout: LutLayout | null = null;
    let applied = false;
    worker.onmessage = (ev: MessageEvent<WorkerOut>) => {
      const m = ev.data;
      switch (m.type) {
        case "layout":
          layout = m.layout;
          setState((s) => ({ ...s, phase: "baking", stats: m.stats, elapsedMs: m.t }));
          break;
        case "progress":
          setState((s) => ({ ...s, frac: m.frac }));
          break;
        case "volume":
          renderer.setVolume(m.data);
          setState((s) => ({ ...s, volumeMs: m.t }));
          break;
        case "probes":
          renderer.setProbes(m.data);
          setState((s) => ({ ...s, probeMs: m.ms }));
          break;
        case "pass":
          renderer.setLUT(applied ? null : layout, m.A, m.B, m.basis);
          applied = true;
          setState((s) => ({
            ...s,
            pass: m.pass + 1,
            totalSpp: m.totalSpp,
            pca: m.pca,
            frac: 0,
            elapsedMs: m.t,
            firstUsableMs: s.firstUsableMs || m.t,
          }));
          break;
        case "done":
          setState((s) => ({ ...s, phase: "done", validation: m.validation, elapsedMs: m.t }));
          break;
        case "error":
          console.error(m.message);
          setState((s) => ({ ...s, phase: "error", error: m.message }));
          break;
      }
    };
    worker.postMessage({ type: "bake", cfg });
    return () => worker.terminate();
  }, [renderer, cfg.step, cfg.N]); // eslint-disable-line react-hooks/exhaustive-deps

  return state;
}
