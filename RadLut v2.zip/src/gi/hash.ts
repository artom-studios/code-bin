// Index structures for the radiance LUT.
//
// key  = (cell.x, cell.y, cell.z, face)          -- world-space, no UVs
//
// Two interchangeable indexers (the atlas layout is identical, only the cell->slot step differs):
//
//  * PERFECT HASH ("hash & displace", CHD style).  Sparse, scales to huge worlds.
//        h0   = hash32(cellBits ^ faceSalt[f])          (faceSalt precomputed -> one hash32 less than v1)
//        slot = mix(h0 + disp[h0 & (B-1)] * K) & (M-1)  (M, B are powers of two -> no integer division / modulo)
//
//  * DENSE GRID.  slot = idx[((z*dy + y)*dx + x)*6 + f].  Zero ALU, one fetch.  Memory ~ bbox volume.
//
// The same integer ops are reproduced bit-for-bit in GLSL (uint arithmetic wraps mod 2^32).

export const KMUL = 0x9e3779b1;
export const CELL_BIAS = 512;
export const SW = 128; // tiles per atlas row (power of two -> shifts in GLSL)
export const SW_SHIFT = 7;

export function hash32(x: number): number {
  x >>>= 0;
  x ^= x >>> 16;
  x = Math.imul(x, 0x7feb352d) >>> 0;
  x ^= x >>> 15;
  x = Math.imul(x, 0x846ca68b) >>> 0;
  x ^= x >>> 16;
  return x >>> 0;
}

export function cellBits(cx: number, cy: number, cz: number): number {
  return ((cx + CELL_BIAS) & 1023) | (((cy + CELL_BIAS) & 1023) << 10) | (((cz + CELL_BIAS) & 1023) << 20);
}

export function faceSalt(face: number, seed: number): number {
  return hash32((Math.imul(face, KMUL) + seed) >>> 0);
}

export function baseHash(bits: number, salt: number): number {
  return hash32((bits ^ salt) >>> 0);
}

/** Second-level mix (1 multiply cheaper than a full hash32).  Must match GLSL `slotMix`. */
export function slotMix(h0: number, d: number, mask: number): number {
  let x = (h0 + Math.imul(d, KMUL)) >>> 0;
  x ^= x >>> 15;
  x = Math.imul(x, 0x2c1b3c6d) >>> 0;
  x ^= x >>> 12;
  return (x >>> 0) & mask;
}

const pow2ceil = (n: number) => {
  let p = 1;
  while (p < n) p <<= 1;
  return p;
};

export interface PerfectHash {
  seed: number;
  salts: Uint32Array; // 6 face salts
  M: number; // atlas slots (power of two)
  B: number; // displacement buckets (power of two)
  disp: Uint16Array; // length B
  slotOf: Int32Array; // slot per input key
  maxDisp: number;
  attempts: number;
}

export function buildPerfectHash(bits: Uint32Array, faces: Uint8Array, load = 0.9, lambda = 3): PerfectHash {
  const n = bits.length;
  const M = pow2ceil(Math.max(8, Math.ceil(n / load)));
  const B = pow2ceil(Math.max(1, Math.ceil(n / lambda)));
  const mask = M - 1;
  const bmask = B - 1;

  for (let attempt = 0; attempt < 64; attempt++) {
    const seed = (0xa511e9b3 + Math.imul(attempt + 1, KMUL)) >>> 0;
    const salts = new Uint32Array(6);
    for (let f = 0; f < 6; f++) salts[f] = faceSalt(f, seed);
    const h0 = new Uint32Array(n);
    const bucketCount = new Int32Array(B);
    for (let i = 0; i < n; i++) {
      h0[i] = baseHash(bits[i], salts[faces[i]]);
      bucketCount[h0[i] & bmask]++;
    }
    const start = new Int32Array(B + 1);
    for (let b = 0; b < B; b++) start[b + 1] = start[b] + bucketCount[b];
    const fill = new Int32Array(B);
    const items = new Int32Array(n);
    for (let i = 0; i < n; i++) {
      const b = h0[i] & bmask;
      items[start[b] + fill[b]++] = i;
    }
    const order = Array.from({ length: B }, (_, i) => i).sort((a, b) => bucketCount[b] - bucketCount[a]);

    const taken = new Uint8Array(M);
    const stamp = new Int32Array(M);
    let stampId = 0;
    const disp = new Uint16Array(B);
    const slotOf = new Int32Array(n).fill(-1);
    let maxDisp = 0;
    let ok = true;

    for (const b of order) {
      const cnt = bucketCount[b];
      if (cnt === 0) continue;
      let found = false;
      for (let d = 0; d < 65535; d++) {
        stampId++;
        let good = true;
        for (let k = 0; k < cnt; k++) {
          const s = slotMix(h0[items[start[b] + k]], d, mask);
          if (taken[s] || stamp[s] === stampId) {
            good = false;
            break;
          }
          stamp[s] = stampId;
        }
        if (good) {
          disp[b] = d;
          for (let k = 0; k < cnt; k++) {
            const it = items[start[b] + k];
            const s = slotMix(h0[it], d, mask);
            taken[s] = 1;
            slotOf[it] = s;
          }
          if (d > maxDisp) maxDisp = d;
          found = true;
          break;
        }
      }
      if (!found) {
        ok = false;
        break;
      }
    }
    if (ok) return { seed, salts, M, B, disp, slotOf, maxDisp, attempts: attempt + 1 };
  }
  throw new Error("perfect hash construction failed");
}

/** Mirror of the GLSL lookup: key -> atlas slot. */
export function lookupSlot(ph: PerfectHash, bits: number, face: number): number {
  const h0 = baseHash(bits, ph.salts[face]);
  const d = ph.disp[h0 & (ph.B - 1)];
  return slotMix(h0, d, ph.M - 1);
}

// ---- dense grid index ---------------------------------------------------------------------------
export interface DenseIndex {
  min: [number, number, number];
  dim: [number, number, number];
  w: number; // texture width (4096 = 12 bit shift in GLSL)
  h: number;
  data: Uint16Array;
  emptySlot: number;
  bytes: number;
}

export function buildDenseIndex(cx: number[], cy: number[], cz: number[], cf: number[], slotOf: Int32Array, M: number): DenseIndex {
  const n = cx.length;
  const mn: [number, number, number] = [1e9, 1e9, 1e9];
  const mx: [number, number, number] = [-1e9, -1e9, -1e9];
  for (let i = 0; i < n; i++) {
    const c = [cx[i], cy[i], cz[i]];
    for (let k = 0; k < 3; k++) {
      mn[k] = Math.min(mn[k], c[k]);
      mx[k] = Math.max(mx[k], c[k]);
    }
  }
  // one cell of empty padding on each side: GLSL clamps lookups into the box and lands on an empty cell
  const min: [number, number, number] = [mn[0] - 1, mn[1] - 1, mn[2] - 1];
  const dim: [number, number, number] = [mx[0] - mn[0] + 3, mx[1] - mn[1] + 3, mx[2] - mn[2] + 3];
  const used = new Uint8Array(M);
  for (let i = 0; i < n; i++) used[slotOf[i]] = 1;
  let emptySlot = 0;
  while (emptySlot < M && used[emptySlot]) emptySlot++;
  if (emptySlot >= M) throw new Error("atlas has no free slot for the dense index");
  const total = dim[0] * dim[1] * dim[2] * 6;
  const w = 4096;
  const h = Math.ceil(total / w);
  const data = new Uint16Array(w * h).fill(emptySlot);
  for (let i = 0; i < n; i++) {
    const lin = (((cz[i] - min[2]) * dim[1] + (cy[i] - min[1])) * dim[0] + (cx[i] - min[0])) * 6 + cf[i];
    data[lin] = slotOf[i];
  }
  return { min, dim, w, h, data, emptySlot, bytes: total * 2 };
}

// ---- number formats -----------------------------------------------------------------------------
const f32 = new Float32Array(1);
const u32 = new Uint32Array(f32.buffer);

/** float32 -> IEEE half (round to nearest, saturating) */
export function toHalf(v: number): number {
  f32[0] = v;
  const x = u32[0];
  const sign = (x >>> 16) & 0x8000;
  const e = ((x >>> 23) & 0xff) - 127 + 15;
  const m = x & 0x7fffff;
  if (e >= 31) return sign | 0x7bff;
  if (e <= 0) {
    if (e < -10) return sign;
    const sh = 14 - e;
    return sign | (((m | 0x800000) + (1 << (sh - 1))) >> sh);
  }
  return sign | ((e << 10) + ((m + 0x1000) >> 13));
}

export function fromHalf(h: number): number {
  const s = h & 0x8000 ? -1 : 1;
  const e = (h >> 10) & 31;
  const m = h & 1023;
  if (e === 0) return s * m * Math.pow(2, -24);
  if (e === 31) return s * 65504;
  return s * (1 + m / 1024) * Math.pow(2, e - 15);
}
