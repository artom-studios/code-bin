import type { V3 } from "./scene";

export interface CamPreset {
  name: string;
  pos: V3;
  target: V3;
}

export const PRESETS: CamPreset[] = [
  { name: "Sun patch", pos: [-2.7, 1.65, -3.4], target: [0.2, 0.45, 2.2] },
  { name: "Sofa & red wall", pos: [3.3, 1.5, 3.1], target: [-3.2, 0.7, -0.2] },
  { name: "Table & lamp", pos: [-1.9, 1.4, 1.2], target: [0.2, 1.0, -2.0] },
  { name: "Window", pos: [0.4, 1.7, -3.5], target: [0.0, 1.5, 4.0] },
  { name: "Green corner", pos: [-3.4, 1.9, 3.4], target: [3.4, 0.8, -1.6] },
];

const BOUNDS = { min: [-3.7, 0.3, -3.7], max: [3.7, 3.2, 3.7] };

function lookAngles(pos: V3, target: V3) {
  const dx = target[0] - pos[0];
  const dy = target[1] - pos[1];
  const dz = target[2] - pos[2];
  return { yaw: Math.atan2(dx, -dz), pitch: Math.asin(dy / Math.hypot(dx, dy, dz)) };
}

const ease = (t: number) => t * t * (3 - 2 * t);
const wrap = (a: number) => {
  while (a > Math.PI) a -= 2 * Math.PI;
  while (a < -Math.PI) a += 2 * Math.PI;
  return a;
};

export class FlyCamera {
  pos: V3 = [0, 1.6, 0];
  yaw = 0;
  pitch = 0;
  fov = (66 * Math.PI) / 180;
  keys = new Set<string>();
  tour = true;
  preset = 0;
  private anim: { t: number; dur: number; p0: V3; p1: V3; y0: number; y1: number; q0: number; q1: number } | null = null;
  private dwell = 0;
  version = 0;

  constructor() {
    this.goPreset(0, true);
  }

  goPreset(i: number, instant = false) {
    const pr = PRESETS[((i % PRESETS.length) + PRESETS.length) % PRESETS.length];
    this.preset = ((i % PRESETS.length) + PRESETS.length) % PRESETS.length;
    const a = lookAngles(pr.pos, pr.target);
    if (instant) {
      this.pos = [...pr.pos] as V3;
      this.yaw = a.yaw;
      this.pitch = a.pitch;
      this.anim = null;
    } else {
      this.anim = {
        t: 0,
        dur: 2.2,
        p0: [...this.pos] as V3,
        p1: [...pr.pos] as V3,
        y0: this.yaw,
        y1: this.yaw + wrap(a.yaw - this.yaw),
        q0: this.pitch,
        q1: a.pitch,
      };
    }
    this.dwell = 0;
    this.version++;
  }

  interrupt() {
    this.anim = null;
    this.tour = false;
  }

  look(dx: number, dy: number) {
    this.interrupt();
    this.yaw += dx * 0.0035;
    this.pitch = Math.max(-1.45, Math.min(1.45, this.pitch - dy * 0.0035));
    this.version++;
  }

  dolly(amount: number) {
    this.interrupt();
    const f = this.forward();
    for (let k = 0; k < 3; k++) this.pos[k] += f[k] * amount;
    this.clamp();
    this.version++;
  }

  forward(): V3 {
    const cp = Math.cos(this.pitch);
    return [cp * Math.sin(this.yaw), Math.sin(this.pitch), -cp * Math.cos(this.yaw)];
  }

  basis() {
    const f = this.forward();
    const r: V3 = [Math.cos(this.yaw), 0, Math.sin(this.yaw)];
    const u: V3 = [r[1] * f[2] - r[2] * f[1], r[2] * f[0] - r[0] * f[2], r[0] * f[1] - r[1] * f[0]];
    return { f, r, u };
  }

  private clamp() {
    for (let k = 0; k < 3; k++) this.pos[k] = Math.max(BOUNDS.min[k], Math.min(BOUNDS.max[k], this.pos[k]));
  }

  update(dt: number) {
    if (this.anim) {
      const a = this.anim;
      a.t += dt;
      const e = ease(Math.min(1, a.t / a.dur));
      for (let k = 0; k < 3; k++) this.pos[k] = a.p0[k] + (a.p1[k] - a.p0[k]) * e;
      this.yaw = a.y0 + (a.y1 - a.y0) * e;
      this.pitch = a.q0 + (a.q1 - a.q0) * e;
      if (a.t >= a.dur) this.anim = null;
      this.version++;
    } else if (this.tour) {
      this.dwell += dt;
      if (this.dwell > 6) this.goPreset(this.preset + 1);
    }
    if (this.keys.size) {
      const { f, r } = this.basis();
      const sp = (this.keys.has("shift") ? 4.2 : 2.1) * dt;
      let mx = 0;
      let mz = 0;
      let my = 0;
      if (this.keys.has("w") || this.keys.has("arrowup")) mz += 1;
      if (this.keys.has("s") || this.keys.has("arrowdown")) mz -= 1;
      if (this.keys.has("d") || this.keys.has("arrowright")) mx += 1;
      if (this.keys.has("a") || this.keys.has("arrowleft")) mx -= 1;
      if (this.keys.has("e")) my += 1;
      if (this.keys.has("q")) my -= 1;
      if (mx || mz || my) {
        this.interrupt();
        const fl = Math.hypot(f[0], f[2]) || 1;
        this.pos[0] += ((f[0] / fl) * mz + r[0] * mx) * sp;
        this.pos[2] += ((f[2] / fl) * mz + r[2] * mx) * sp;
        this.pos[1] += my * sp;
        this.clamp();
        this.version++;
      }
    }
  }

  viewProj(aspect: number): Float32Array {
    const { f, r, u } = this.basis();
    const p = this.pos;
    const dot = (a: V3, b: V3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
    // column-major view matrix
    const V = [r[0], u[0], -f[0], 0, r[1], u[1], -f[1], 0, r[2], u[2], -f[2], 0, -dot(r, p), -dot(u, p), dot(f, p), 1];
    const n = 0.05;
    const fa = 80;
    const t = 1 / Math.tan(this.fov / 2);
    const P = [t / aspect, 0, 0, 0, 0, t, 0, 0, 0, 0, (fa + n) / (n - fa), -1, 0, 0, (2 * fa * n) / (n - fa), 0];
    const out = new Float32Array(16);
    for (let c = 0; c < 4; c++)
      for (let rr = 0; rr < 4; rr++) {
        let s = 0;
        for (let k = 0; k < 4; k++) s += P[k * 4 + rr] * V[c * 4 + k];
        out[c * 4 + rr] = s;
      }
    return out;
  }
}
