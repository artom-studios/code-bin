import { sceneGLSL } from "./scene";
import { ND, NL } from "./dynamic";

const HEAD = `#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
precision highp sampler3D;
precision highp usampler2D;
#define ND ${ND}
#define NL ${NL}
`;

const COMMON = HEAD + sceneGLSL();

// ---------------------------------------------------------------------------------------------
// Full-screen triangle (no attributes)
// ---------------------------------------------------------------------------------------------
export const FULLSCREEN_VS = `#version 300 es
void main() {
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
`;

// ---------------------------------------------------------------------------------------------
// Sky backdrop (visible through the window)
// ---------------------------------------------------------------------------------------------
export const SKY_FS =
  COMMON +
  `
uniform vec3 uCamR, uCamU, uCamF;
uniform float uTanHalf, uAspect, uExposure;
uniform vec2 uRes;
uniform vec3 uSkyGain;
out vec4 fragColor;
void main() {
  vec2 ndc = gl_FragCoord.xy / uRes * 2.0 - 1.0;
  vec3 d = normalize(uCamF + uCamR * (ndc.x * uTanHalf * uAspect) + uCamU * (ndc.y * uTanHalf));
  fragColor = vec4(tonemapACES(uSkyGain * skyRadiance(d) * uExposure), 1.0);
}
`;


// ---- dynamic content: spheres (objects) and point lights, shared by the LUT shader and the reference ------------------
const DYN_GLSL = `
uniform int uDynOn;                // 0: no dynamic objects
uniform vec4 uDynC[ND];            // xyz centre, w radius
uniform vec3 uDynAlb[ND];
uniform vec3 uDynRad[ND];          // mean outgoing radiance (albedo 1) -> colour bleeding onto the world
uniform int uNL;                   // active dynamic point lights
uniform vec4 uLP[NL];              // xyz position, w range
uniform vec3 uLC[NL];              // colour * intensity

// analytic soft shadow of a sphere along a ray (penumbra grows with occluder distance)
float sphShadow(vec3 ro, vec3 rd, float dist, vec4 s) {
  vec3 oc = ro - s.xyz;
  float b = dot(oc, rd);
  float t = -b;
  if (t <= 0.0 || t > dist + s.w) return 1.0;
  float d = sqrt(max(0.0, dot(oc, oc) - b * b));
  float w = 0.12 * s.w + 0.04 * t;
  return smoothstep(s.w - w, s.w + w, d);
}
// fraction of the cosine-weighted hemisphere covered by a sphere (solid angle * cos / pi)
float sphOcc(vec3 p, vec3 n, vec4 s) {
  vec3 d = s.xyz - p;
  float l2 = dot(d, d);
  float nl = dot(n, d) * inversesqrt(l2);
  return clamp(s.w * s.w / l2 * max(nl, 0.0), 0.0, 1.0);
}
vec3 markerCol(int j) {
  float m = max(max(uLC[j].x, uLC[j].y), uLC[j].z) + 1e-4;
  return uLC[j] / m * (1.5 + 0.3 * m);
}
float lightWindow(float d2, float range) {
  float w = clamp(1.0 - d2 / (range * range), 0.0, 1.0);
  return w * w;
}
`;


// ---------------------------------------------------------------------------------------------
// Scene rasteriser with the RadLUT lookup (v2: 1 index fetch + 2 filtered fetches per face)
// ---------------------------------------------------------------------------------------------
export const SCENE_VS = `#version 300 es
precision highp float;
in vec3 aPos;
in vec3 aNrm;
in vec3 aAlb;
in float aMat;
uniform mat4 uVP;
uniform int uSelf;        // -1 static world, >=0 dynamic sphere, <=-2 emissive light marker
uniform vec3 uObjC;
uniform float uObjR;
uniform vec3 uObjAlb;
out vec3 vP;
out vec3 vN;
out vec3 vAlb;
flat out float vMat;
void main() {
  bool inst = uSelf != -1;
  vec3 pos = inst ? uObjC + aPos * uObjR : aPos;
  vP = pos;
  vN = aNrm;
  vAlb = inst ? uObjAlb : aAlb;
  vMat = inst ? 3.0 : aMat;
  gl_Position = uVP * vec4(pos, 1.0);
}
`;

export const SCENE_FS =
  COMMON +
  DYN_GLSL +
  `
// ---- RadLUT ----------------------------------------------------------------------------------
uniform usampler2D uIdx;      // perfect hash: displacement table (R16UI) | dense: slot per (cell, face) (R16UI)
uniform sampler2D uAtlasA;    // RGBA16F : 4 PCA coefficients of the 9-vector (3 lights x RGB)
uniform sampler2D uAtlasB;    // RGBA8   : V_sun, V_lamp, g_u, g_v
uniform sampler3D uVol;       // RGBA8   : static sun/lamp visibility, SDF (dynamic objects / lights)
uniform vec3  uGO;
uniform float uInvCell;
uniform float uTileN;
uniform vec2  uInvAtlas;
uniform int   uIdxMode;       // 0 perfect hash, 1 dense grid
uniform uint  uSalt[6];
uniform uint  uMMask, uBMask;
uniform ivec3 uIdxMin, uIdxDim;
uniform vec3  uMA[4];         // basis folded with all light gains
uniform vec3  uMS[4];         // basis folded with the sky gain only (directional term)
uniform vec3  uGSun, uGLamp;
uniform int   uMode;          // 0 final, 1 irradiance, 2 cells, 3 no GI
uniform int   uNM;            // 0 normal map off, 1 direct only, 2 + wrap, 3 + sky gradient
uniform float uBump;
uniform float uExposure;
uniform vec3  uBulb;
uniform int   uSelf;
uniform vec3  uObjC;
uniform vec3  uMarker;
uniform vec3  uSH[4];         // per-object irradiance probe (A, Bx, By, Bz), gains folded in
uniform vec3  uVolMin, uVolInv;
uniform int   uLShadow;       // 0 none, 1 SDF 8 steps, 2 SDF 16 steps
uniform int   uFill;
uniform float uFillK;

uint hash32(uint x) {
  x ^= x >> 16; x *= 0x7feb352du;
  x ^= x >> 15; x *= 0x846ca68bu;
  x ^= x >> 16;
  return x;
}

uint slotOf(ivec3 c, int f) {
  if (uIdxMode == 1) {
    ivec3 q = clamp(c - uIdxMin, ivec3(0), uIdxDim - 1);
    int lin = ((q.z * uIdxDim.y + q.y) * uIdxDim.x + q.x) * 6 + f;
    return texelFetch(uIdx, ivec2(lin & 4095, lin >> 12), 0).r;
  }
  uint k = (uint(c.x + 512) & 1023u) | ((uint(c.y + 512) & 1023u) << 10) | ((uint(c.z + 512) & 1023u) << 20);
  uint h0 = hash32(k ^ uSalt[f]);
  uint b = h0 & uBMask;
  uint d = texelFetch(uIdx, ivec2(int(b & 255u), int(b >> 8u)), 0).r;
  uint x = h0 + d * 0x9e3779b1u;
  x ^= x >> 15; x *= 0x2c1b3c6du; x ^= x >> 12;
  return x & uMMask;
}

void faceFetch(vec3 p, int f, out vec4 A, out vec4 B) {
  vec3 q = (p - uGO) * uInvCell;
  vec3 fl = floor(q);
  vec3 fr = q - fl;
  uint slot = slotOf(ivec3(fl), f);
  int a = f >> 1;
  int ua = a == 2 ? 0 : a + 1;
  int va = ua == 2 ? 0 : ua + 1;
  vec2 t = vec2(fr[ua], fr[va]);
  vec2 tile = vec2(float(slot & 127u), float(slot >> 7u)) * uTileN;
  vec2 uv = (tile + 0.5 + t * (uTileN - 1.0)) * uInvAtlas;
  A = textureLod(uAtlasA, uv, 0.0);
  B = textureLod(uAtlasB, uv, 0.0);
}

// one tile of the tri-planar blend: indirect (+ normal-map relight) and light visibility
void accFace(vec3 p, int f, float wt, vec3 n, vec3 ng, float wrap, inout mediump vec3 R, inout vec2 V, inout mediump vec3 flatR) {
  vec4 A, B;
  faceFetch(p, f, A, B);
  mediump vec3 eAll = A.x * uMA[0] + A.y * uMA[1] + A.z * uMA[2] + A.w * uMA[3];
  mediump vec3 r = eAll * wrap;
  if (uNM == 3) {
    mediump vec3 eSky = A.x * uMS[0] + A.y * uMS[1] + A.z * uMS[2] + A.w * uMS[3];
    int a = f >> 1;
    int ua = a == 2 ? 0 : a + 1;
    int va = ua == 2 ? 0 : ua + 1;
    vec2 g = B.zw * 2.0 - 1.0;
    r += eSky * dot(g, vec2(n[ua] - ng[ua], n[va] - ng[va]));
  }
  R += wt * r;
  flatR += wt * eAll;
  V += wt * B.xy;
}

float sdfTex(vec3 p) { return textureLod(uVol, (p - uVolMin) * uVolInv, 0.0).b; }
float sdfShadow(vec3 ro, vec3 rd, float dist, int steps) {
  float res = 1.0;
  float t = 0.06;
  for (int i = 0; i < 16; i++) {
    if (i >= steps) break;
    float h = sdfTex(ro + rd * t);
    res = min(res, 8.0 * h / t);
    t += clamp(h, 0.03, 0.35);
    if (res < 0.02 || t >= dist - 0.05) break;
  }
  return smoothstep(0.0, 1.0, clamp(res, 0.0, 1.0));
}

// total radiance for albedo 1 at a surface point
mediump vec3 lighting(vec3 p, vec3 ng, vec3 n) {
  mediump vec3 R = vec3(0.0);
  mediump vec3 flatR = vec3(0.0);
  vec2 V = vec2(0.0);
  if (uSelf >= 0) {
    // dynamic object: SH probe (per object uniform) + static visibility volume
    V = textureLod(uVol, (p - uVolMin) * uVolInv, 0.0).rg;
    R = max(uSH[0] + uSH[1] * n.x + uSH[2] * n.y + uSH[3] * n.z, 0.0);
    flatR = R;
  } else {
    vec3 w = ng * ng;
    float wrap = uNM >= 2 ? 0.5 + 0.5 * dot(n, ng) : 1.0;
    float ws = 0.0;
    if (w.x > 0.03) { accFace(p, ng.x < 0.0 ? 1 : 0, w.x, n, ng, wrap, R, V, flatR); ws += w.x; }
    if (w.y > 0.03) { accFace(p, ng.y < 0.0 ? 3 : 2, w.y, n, ng, wrap, R, V, flatR); ws += w.y; }
    if (w.z > 0.03) { accFace(p, ng.z < 0.0 ? 5 : 4, w.z, n, ng, wrap, R, V, flatR); ws += w.z; }
    float iw = 1.0 / max(ws, 1e-4);
    R = max(R * iw, 0.0);
    flatR *= iw;
    V *= iw;
  }

  // ---- dynamic objects: shadow the delta lights, occlude + bounce the indirect ---------------
  vec3 toLamp = LAMP_POS - p;
  float dLamp = length(toLamp);
  toLamp /= dLamp;
  float shSun = 1.0;
  float shLamp = 1.0;
  float keep = 1.0;
  mediump vec3 bounce = vec3(0.0);
  if (uDynOn != 0) {
    for (int i = 0; i < ND; i++) {
      if (i == uSelf) continue;
      shSun *= sphShadow(p, SUN_DIR, 1e9, uDynC[i]);
      shLamp *= sphShadow(p, toLamp, dLamp, uDynC[i]);
      float occ = sphOcc(p, ng, uDynC[i]);
      keep *= 1.0 - occ;
      bounce += occ * uDynAlb[i] * uDynRad[i];
    }
  }
  R = R * keep + bounce;

  // ---- sun + lamp: baked visibility x analytic cosine / falloff (exact for normal-mapped normals) --
  float gs = clamp(dot(ng, SUN_DIR) * 20.0, 0.0, 1.0);
  float gl = clamp(dot(ng, toLamp) * 20.0, 0.0, 1.0);
  R += uGSun * (V.x * shSun * gs * max(dot(n, SUN_DIR), 0.0) * 0.3183099);
  R += uGLamp * (V.y * shLamp * gl * max(dot(n, toLamp), 0.0) * 0.3183099 / (dLamp * dLamp));

  // ---- dynamic point lights: analytic direct, soft shadows (spheres analytic, static scene via SDF) + fill ----
  for (int j = 0; j < NL; j++) {
    if (j >= uNL) break;
    vec3 l = uLP[j].xyz - p;
    float d2 = dot(l, l);
    float d = sqrt(d2);
    l /= d;
    float win = lightWindow(d2, uLP[j].w);
    if (win <= 0.0) continue;
    float cs = max(dot(n, l), 0.0) * clamp(dot(ng, l) * 20.0, 0.0, 1.0);
    float sh = 1.0;
    if (uDynOn != 0) {
      for (int i = 0; i < ND; i++) {
        if (i == uSelf) continue;
        sh *= sphShadow(p, l, d, uDynC[i]);
      }
    }
    if (uLShadow > 0 && cs > 0.0) sh *= sdfShadow(p + ng * 0.02, l, d, uLShadow == 1 ? 8 : 16);
    R += uLC[j] * (cs * sh * win * 0.3183099 / (d2 + 0.01));
    if (uFill != 0) {
      mediump vec3 tint = flatR / (dot(flatR, vec3(0.2126, 0.7152, 0.0722)) + 0.02);
      R += uLC[j] * tint * (uFillK * win / (d2 + 1.0) * (0.3 + 0.7 * sh));
    }
  }
  return R;
}

vec3 cellView(vec3 p, vec3 n) {
  vec3 an = abs(n);
  int a = an.x > an.y ? (an.x > an.z ? 0 : 2) : (an.y > an.z ? 1 : 2);
  int f = 2 * a + (n[a] < 0.0 ? 1 : 0);
  vec3 q = (p - uGO) * uInvCell;
  vec3 fl = floor(q);
  vec3 fr = q - fl;
  uint h0 = hash32((uint(int(fl.x) + 512) & 1023u) | ((uint(int(fl.y) + 512) & 1023u) << 10) | ((uint(int(fl.z) + 512) & 1023u) << 20) ^ uint(f * 7919));
  vec3 cc = 0.3 + 0.7 * vec3(float(h0 & 255u), float((h0 >> 8u) & 255u), float((h0 >> 16u) & 255u)) / 255.0;
  int ua = a == 2 ? 0 : a + 1;
  int va = ua == 2 ? 0 : ua + 1;
  vec2 t = vec2(fr[ua], fr[va]);
  vec2 ts = t * (uTileN - 1.0);
  float aa = clamp(max(fwidth(ts.x), fwidth(ts.y)), 0.001, 0.2);
  float dd = length(ts - floor(ts + 0.5));
  float dotm = 1.0 - smoothstep(0.16 - aa, 0.16 + aa, dd);
  vec2 edge = min(t, 1.0 - t);
  float ew = max(fwidth(t.x), fwidth(t.y)) * 1.2;
  float line = 1.0 - smoothstep(ew * 0.5, ew * 1.5, min(edge.x, edge.y));
  vec3 E = lighting(p, n, n);
  float l = clamp(dot(E, vec3(0.3, 0.6, 0.1)) * 0.35, 0.0, 1.0);
  vec3 col = cc * (0.28 + 0.72 * l);
  col = mix(col, vec3(0.02), dotm * 0.85);
  col = mix(col, vec3(1.0), line * 0.9);
  return pow(col, vec3(1.0 / 2.2));
}

in vec3 vP;
in vec3 vN;
in vec3 vAlb;
flat in float vMat;
out vec4 fragColor;

void main() {
  if (uSelf <= -2) {
    fragColor = vec4(tonemapACES(uMarker * uExposure), 1.0);
    return;
  }
  vec3 ng = normalize(vN);
  vec3 col;
  int mat = int(vMat + 0.5);
  if (vMat < -1.5) {
    col = vec3(0.01);
  } else if (vMat < -0.5) {
    col = uBulb;
  } else {
    vec3 alb = vAlb * albedoPattern(mat, uSelf >= 0 ? vP - uObjC : vP);
    if (uMode == 1) alb = vec3(0.7);
    if (uMode == 2) {
      fragColor = vec4(cellView(vP, ng), 1.0);
      return;
    }
    vec3 n = uNM > 0 ? shadingNormal(mat, uSelf >= 0 ? vP - uObjC : vP, ng, uBump) : ng;
    vec3 E;
    if (uMode == 3) {
      E = mix(vec3(0.06, 0.055, 0.05), vec3(0.2, 0.21, 0.23), n.y * 0.5 + 0.5);
    } else {
      E = lighting(vP, ng, n);
    }
    col = alb * E;
  }
  fragColor = vec4(tonemapACES(col * uExposure), 1.0);
}
`;


// ---------------------------------------------------------------------------------------------
// Reference: progressive GPU path tracer of the very same analytic scene (incl. dynamic content + normal maps)
// ---------------------------------------------------------------------------------------------
export const REF_FS =
  COMMON +
  DYN_GLSL +
  `
uniform vec3 uCamPos, uCamR, uCamU, uCamF;
uniform float uTanHalf, uAspect, uFrame;
uniform vec2 uRes;
uniform sampler2D uPrev;
uniform vec3 uSunGain, uSkyGain, uLampGain, uBulb;
uniform int uBumpOn;
uniform float uBump;
out vec4 fragColor;

uint rngS;
uint pcg(uint v) {
  uint state = v * 747796405u + 2891336453u;
  uint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;
  return (word >> 22u) ^ word;
}
float rnd() {
  rngS = pcg(rngS);
  return min(float(rngS) * (1.0 / 4294967296.0), 0.99999994);
}

vec3 gOrigin;
bool intersect(vec3 ro, vec3 rd, out float tHit, out vec3 nHit, out vec3 albHit, out int matHit) {
  float best = 1e20;
  bool found = false;
  gOrigin = vec3(0.0);
  vec3 inv = 1.0 / rd;
  for (int i = 0; i < NB; i++) {
    vec3 t1 = (B_MIN[i] - ro) * inv;
    vec3 t2 = (B_MAX[i] - ro) * inv;
    vec3 tmn = min(t1, t2);
    vec3 tmx = max(t1, t2);
    float tn = max(max(tmn.x, tmn.y), tmn.z);
    float tf = min(min(tmx.x, tmx.y), tmx.z);
    if (tn <= tf && tn > 1e-4 && tn < best) {
      best = tn;
      found = true;
      nHit = -sign(rd) * step(tmn.yzx, tmn.xyz) * step(tmn.zxy, tmn.xyz);
      albHit = B_ALB[i];
      matHit = B_MAT[i];
      gOrigin = vec3(0.0);
    }
  }
  for (int i = 0; i < NS; i++) {
    vec3 oc = ro - S_C[i].xyz;
    float b = dot(oc, rd);
    float c = dot(oc, oc) - S_C[i].w * S_C[i].w;
    float disc = b * b - c;
    if (disc > 0.0) {
      float t = -b - sqrt(disc);
      if (t > 1e-4 && t < best) {
        best = t;
        found = true;
        nHit = (ro + rd * t - S_C[i].xyz) / S_C[i].w;
        albHit = S_ALB[i];
        matHit = S_MAT[i];
        gOrigin = vec3(0.0);
      }
    }
  }
  if (uDynOn != 0) {
    for (int i = 0; i < ND; i++) {
      vec3 oc = ro - uDynC[i].xyz;
      float b = dot(oc, rd);
      float c = dot(oc, oc) - uDynC[i].w * uDynC[i].w;
      float disc = b * b - c;
      if (disc > 0.0) {
        float t = -b - sqrt(disc);
        if (t > 1e-4 && t < best) {
          best = t;
          found = true;
          nHit = (ro + rd * t - uDynC[i].xyz) / uDynC[i].w;
          albHit = uDynAlb[i];
          matHit = 3;
          gOrigin = uDynC[i].xyz;
        }
      }
    }
  }
  tHit = best;
  return found;
}

bool occluded(vec3 ro, vec3 rd, float tmax) {
  vec3 inv = 1.0 / rd;
  for (int i = 0; i < NB; i++) {
    vec3 t1 = (B_MIN[i] - ro) * inv;
    vec3 t2 = (B_MAX[i] - ro) * inv;
    vec3 tmn = min(t1, t2);
    vec3 tmx = max(t1, t2);
    float tn = max(max(tmn.x, tmn.y), tmn.z);
    float tf = min(min(tmx.x, tmx.y), tmx.z);
    if (tn <= tf && tn > 1e-4 && tn < tmax) return true;
  }
  for (int i = 0; i < NS; i++) {
    vec3 oc = ro - S_C[i].xyz;
    float b = dot(oc, rd);
    float c = dot(oc, oc) - S_C[i].w * S_C[i].w;
    float disc = b * b - c;
    if (disc > 0.0) {
      float t = -b - sqrt(disc);
      if (t > 1e-4 && t < tmax) return true;
    }
  }
  if (uDynOn != 0) {
    for (int i = 0; i < ND; i++) {
      vec3 oc = ro - uDynC[i].xyz;
      float b = dot(oc, rd);
      float c = dot(oc, oc) - uDynC[i].w * uDynC[i].w;
      float disc = b * b - c;
      if (disc > 0.0) {
        float t = -b - sqrt(disc);
        if (t > 1e-4 && t < tmax) return true;
      }
    }
  }
  return false;
}

vec3 cosDir(vec3 n) {
  float r1 = rnd();
  float r2 = rnd();
  float phi = 6.2831853 * r1;
  float sr = sqrt(r2);
  vec3 t = abs(n.x) > 0.9 ? vec3(-n.z, 0.0, n.x) : vec3(0.0, n.z, -n.y);
  t = normalize(t);
  vec3 b = cross(n, t);
  return normalize(t * (cos(phi) * sr) + b * (sin(phi) * sr) + n * sqrt(1.0 - r2));
}

vec3 trace(vec3 ro, vec3 rd) {
  vec3 L = vec3(0.0);
  vec3 thr = vec3(1.0);
  for (int b = 0; b <= 4; b++) {
    float t; vec3 n; vec3 alb; int mat;
    bool h = intersect(ro, rd, t, n, alb, mat);
    vec3 org = gOrigin;
    if (b == 0) {
      vec3 oc = ro - LAMP_POS;
      float bb = dot(oc, rd);
      float cc = dot(oc, oc) - BULB_R * BULB_R;
      float disc = bb * bb - cc;
      if (disc > 0.0) {
        float tb = -bb - sqrt(disc);
        if (tb > 0.0 && (!h || tb < t)) return uBulb;
      }
      for (int j = 0; j < NL; j++) {
        if (j >= uNL) break;
        vec3 oc2 = ro - uLP[j].xyz;
        float b2 = dot(oc2, rd);
        float c2 = dot(oc2, oc2) - 0.0064;
        float d2 = b2 * b2 - c2;
        if (d2 > 0.0) {
          float tb = -b2 - sqrt(d2);
          if (tb > 0.0 && (!h || tb < t)) return markerCol(j);
        }
      }
    }
    if (!h) {
      L += thr * uSkyGain * skyRadiance(rd);
      break;
    }
    vec3 p = ro + rd * t;
    thr *= alb * albedoPattern(mat, p - org);
    vec3 ns = n;
    if (b == 0 && uBumpOn != 0) ns = shadingNormal(mat, p - org, n, uBump);
    vec3 o = p + n * 3e-3;
    float cs = dot(ns, SUN_DIR);
    if (cs > 0.0 && dot(n, SUN_DIR) > 0.0 && !occluded(o, SUN_DIR, 1e20)) L += thr * uSunGain * (cs * 0.3183099);
    vec3 lv = LAMP_POS - o;
    float l2 = dot(lv, lv);
    float l = sqrt(l2);
    float cl = dot(ns, lv) / l;
    if (cl > 0.0 && dot(n, lv) > 0.0 && !occluded(o, lv / l, l)) L += thr * uLampGain * (cl * 0.3183099 / l2);
    for (int j = 0; j < NL; j++) {
      if (j >= uNL) break;
      vec3 dv = uLP[j].xyz - o;
      float dd2 = dot(dv, dv);
      float dd = sqrt(dd2);
      float cj = dot(ns, dv) / dd;
      float win = lightWindow(dd2, uLP[j].w);
      if (cj > 0.0 && win > 0.0 && dot(n, dv) > 0.0 && !occluded(o, dv / dd, dd)) L += thr * uLC[j] * (cj * win * 0.3183099 / (dd2 + 0.01));
    }
    if (b == 4) break;
    vec3 nd = cosDir(ns);
    if (ns != n) {
      for (int k = 0; k < 6; k++) {
        if (dot(nd, n) > 0.02) break;
        nd = cosDir(ns);
      }
      if (dot(nd, n) <= 0.02) nd = cosDir(n);
    }
    rd = nd;
    ro = o;
  }
  return L;
}

void main() {
  uvec2 px = uvec2(gl_FragCoord.xy);
  rngS = pcg(px.x + pcg(px.y + pcg(uint(uFrame) * 9781u + 1u)));
  vec2 jit = vec2(rnd(), rnd());
  vec2 ndc = ((gl_FragCoord.xy - 0.5 + jit) / uRes) * 2.0 - 1.0;
  vec3 rd = normalize(uCamF + uCamR * (ndc.x * uTanHalf * uAspect) + uCamU * (ndc.y * uTanHalf));
  vec3 c = min(trace(uCamPos, rd), vec3(24.0));
  if (any(isnan(c))) c = vec3(0.0);
  if (uFrame <= 1.0) {
    fragColor = vec4(c, 1.0);
  } else {
    vec3 prev = texture(uPrev, gl_FragCoord.xy / uRes).rgb;
    fragColor = vec4(mix(prev, c, 1.0 / uFrame), 1.0);
  }
}
`;

export const COMPOSITE_FS =
  COMMON +
  `
uniform sampler2D uTex;
uniform vec2 uRes;
uniform float uSplitPx, uExposure;
out vec4 fragColor;
void main() {
  if (gl_FragCoord.x < uSplitPx) discard;
  vec3 c = texture(uTex, gl_FragCoord.xy / uRes).rgb;
  fragColor = vec4(tonemapACES(c * uExposure), 1.0);
}
`;
