import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { RadRenderer } from "@/gi/renderer";
import { useBaker } from "@/gi/useBaker";
import { DEFAULT_LIGHTS, type LightsState, type LightState, type V3 } from "@/gi/scene";
import { ControlsPanel, type BakeSettings, type Solo } from "@/components/ControlsPanel";
import { InspectorPanel } from "@/components/InspectorPanel";
import { AboutModal } from "@/components/AboutModal";
import { FEATURE_DEFAULT, type FeatureState } from "@/components/FeatureSections";
import { Seg } from "@/components/ui";
import { cn } from "@/utils/cn";

const MODES = [
  { value: 0, label: "Final", title: "albedo × RadLUT" },
  { value: 1, label: "Irradiance", title: "the lookup alone, flat grey albedo" },
  { value: 2, label: "Cells", title: "hashed tiles and stored samples" },
  { value: 3, label: "No GI", title: "flat ambient fallback" },
];

const isWide = () => typeof window !== "undefined" && window.innerWidth >= 1100;

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const [renderer, setRenderer] = useState<RadRenderer | null>(null);
  const [glError, setGlError] = useState<string | null>(null);

  const [lights, setLights] = useState<LightsState>(DEFAULT_LIGHTS);
  const [solo, setSolo] = useState<Solo>("all");
  const [exposure, setExposure] = useState(1);
  const [bakeCfg, setBakeCfg] = useState<BakeSettings>({ step: 0.125, N: 5 });
  const [mode, setMode] = useState(0);
  const [refOn, setRefOn] = useState(false);
  const [split, setSplit] = useState(0.5);
  const [tour, setTour] = useState(true);
  const [preset, setPreset] = useState(0);
  const [fps, setFps] = useState(0);
  const [refSamples, setRefSamples] = useState(0);
  const [relights, setRelights] = useState(0);
  const [rebakes, setRebakes] = useState(0);
  const [showControls, setShowControls] = useState(isWide);
  const [showInspector, setShowInspector] = useState(isWide);
  const [showAbout, setShowAbout] = useState(false);
  const lastRelight = useRef(0);
  const [feat, setFeatState] = useState<FeatureState>(FEATURE_DEFAULT);
  const [imgErr, setImgErr] = useState<{ err: number; spp: number } | null>(null);
  const setFeat = (p: Partial<FeatureState>) => setFeatState((f) => ({ ...f, ...p }));

  // ---- renderer lifecycle -------------------------------------------------------------------
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let r: RadRenderer | null = null;
    try {
      r = new RadRenderer(canvas);
      r.onStats = (s) => {
        setFps(s.fps);
        setRefSamples(s.refSamples);
        setPreset(r!.cam.preset);
      };
      r.onInteract = () => setTour(false);
      (window as unknown as { __rad: RadRenderer }).__rad = r;
      setRenderer(r);
    } catch (e) {
      setGlError(String((e as Error).message ?? e));
    }
    return () => {
      r?.dispose();
      setRenderer(null);
    };
  }, []);

  const bake = useBaker(renderer, bakeCfg);

  useEffect(() => {
    if (renderer) renderer.cam.tour = tour;
  }, [renderer, tour]);

  // ---- derive GPU params --------------------------------------------------------------------
  const gains = useMemo<[V3, V3, V3]>(() => {
    const g = (k: keyof LightsState): V3 => {
      const l = lights[k];
      const s = l.on && (solo === "all" || solo === k) ? l.intensity : 0;
      return [l.color[0] * s, l.color[1] * s, l.color[2] * s];
    };
    return [g("sun"), g("sky"), g("lamp")];
  }, [lights, solo]);

  useEffect(() => {
    if (!renderer) return;
    const l = lights.lamp;
    const lampLive = l.on && (solo === "all" || solo === "lamp");
    const k = 1.2 + l.intensity * 0.35;
    const bulb: V3 = lampLive ? [l.color[0] * k, l.color[1] * k, l.color[2] * k] : [0.05, 0.05, 0.05];
    renderer.setParams({ mode, exposure, gains, skyGain: gains[1], bulb, refOn, split, ...feat });
  }, [renderer, mode, exposure, gains, lights.lamp, solo, refOn, split, feat]);

  // ---- handlers -----------------------------------------------------------------------------
  const touchRelight = useCallback(() => {
    const now = performance.now();
    if (now - lastRelight.current > 450) setRelights((n) => n + 1);
    lastRelight.current = now;
  }, []);
  const setLight = (k: keyof LightsState, patch: Partial<LightState>) => {
    touchRelight();
    setLights((s) => ({ ...s, [k]: { ...s[k], ...patch } }));
  };
  const changeBake = (b: BakeSettings) => {
    if (b.step === bakeCfg.step && b.N === bakeCfg.N) return;
    setRebakes((n) => n + 1);
    setBakeCfg(b);
  };
  const gotoPreset = (i: number) => {
    setTour(false);
    if (renderer) {
      renderer.cam.tour = false;
      renderer.cam.goPreset(i);
    }
    setPreset(i);
  };
  const togglePanel = (which: "controls" | "inspector") => {
    const narrow = !isWide();
    if (which === "controls") {
      setShowControls((v) => !v);
      if (narrow) setShowInspector(false);
    } else {
      setShowInspector((v) => !v);
      if (narrow) setShowControls(false);
    }
  };

  // split divider dragging
  const dragging = useRef(false);
  const onDividerMove = (e: React.PointerEvent) => {
    if (!dragging.current || !stageRef.current) return;
    const rect = stageRef.current.getBoundingClientRect();
    setSplit(Math.min(0.95, Math.max(0.05, (e.clientX - rect.left) / rect.width)));
  };

  const refUnsupported = refOn && renderer && !renderer.refSupported;
  const baking = bake.phase === "prep" || bake.phase === "baking";

  if (glError) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 p-8 text-center text-slate-300">
        <div className="max-w-md space-y-3">
          <div className="text-xl font-semibold text-white">WebGL2 is required</div>
          <p className="text-sm text-slate-400">RadLUT uses integer textures, RGB9E5 atlases and float render targets. {glError}</p>
        </div>
      </div>
    );
  }

  return (
    <div ref={stageRef} className="relative h-screen w-screen overflow-hidden bg-black font-sans text-slate-200 select-none">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full cursor-grab touch-none active:cursor-grabbing" />

      {/* brand + status */}
      <div className="pointer-events-none absolute left-3 top-3 z-20 flex max-w-[calc(100vw-1.5rem)] flex-col gap-2 sm:left-4 sm:top-4">
        <div className="pointer-events-auto flex w-fit items-center gap-3 self-start rounded-2xl border border-white/10 bg-slate-950/70 py-2 pl-2.5 pr-4 shadow-xl shadow-black/40 backdrop-blur-xl">
          <div className="grid h-9 w-9 grid-cols-3 gap-[2px] rounded-lg bg-black/60 p-1.5">
            {[0.25, 0.5, 1, 0.45, 0.9, 0.6, 1, 0.55, 0.3].map((o, i) => (
              <span key={i} className="rounded-[1px] bg-amber-400" style={{ opacity: o }} />
            ))}
          </div>
          <div className="leading-tight">
            <div className="text-sm font-semibold tracking-tight text-white">
              RadLUT <span className="hidden font-normal text-slate-400 sm:inline">· UV-free baked GI</span>
            </div>
            <div className="hidden text-[11px] text-slate-400 sm:block">baked radiance table · normal maps · dynamic objects &amp; lights</div>
          </div>
        </div>
        <div
          className={cn(
            "pointer-events-auto flex w-fit items-center gap-2 rounded-full border px-3 py-1 text-[11px] backdrop-blur-xl",
            baking ? "border-amber-400/30 bg-amber-400/10 text-amber-200" : bake.phase === "error" ? "border-red-400/30 bg-red-400/10 text-red-200" : "border-emerald-400/30 bg-emerald-400/10 text-emerald-200",
          )}
        >
          <span className={cn("h-1.5 w-1.5 rounded-full", baking ? "animate-pulse bg-amber-300" : bake.phase === "error" ? "bg-red-400" : "bg-emerald-400")} />
          {bake.phase === "error"
            ? "bake failed"
            : baking
              ? bake.pass === 0
                ? "baking first pass…"
                : `refining · ${bake.totalSpp} spp · pass ${bake.pass}/${bake.passes}`
              : `baked · ${bake.totalSpp} spp in ${(bake.elapsedMs / 1000).toFixed(1)}s`}
        </div>
      </div>

      {/* nav */}
      <div className="pointer-events-none absolute right-3 top-3 z-30 flex gap-1.5 sm:right-4 sm:top-4">
        {[
          { k: "controls", label: "Controls", on: showControls, fn: () => togglePanel("controls") },
          { k: "inspector", label: "Inspector", on: showInspector, fn: () => togglePanel("inspector") },
        ].map((b) => (
          <button
            key={b.k}
            type="button"
            onClick={b.fn}
            className={cn(
              "pointer-events-auto rounded-full border px-2.5 py-1.5 text-[11px] font-medium backdrop-blur-xl transition-colors sm:px-3.5 sm:text-xs",
              b.on ? "border-white/30 bg-white/20 text-white" : "border-white/10 bg-slate-950/70 text-slate-300 hover:text-white",
            )}
          >
            {b.label}
          </button>
        ))}
        <button
          type="button"
          onClick={() => setShowAbout(true)}
          className="pointer-events-auto rounded-full bg-amber-400 px-2.5 py-1.5 text-[11px] font-semibold text-slate-950 shadow-lg shadow-amber-500/20 hover:bg-amber-300 sm:px-3.5 sm:text-xs"
        >
          <span className="sm:hidden">About</span>
          <span className="hidden sm:inline">How it works</span>
        </button>
      </div>

      {/* panels */}
      {showControls && (
        <div className="pointer-events-none absolute left-3 right-3 top-[7.5rem] bottom-20 z-20 flex sm:right-auto sm:left-4 sm:w-[19.5rem]">
          <ControlsPanel
            lights={lights}
            setLight={setLight}
            solo={solo}
            setSolo={(s) => {
              touchRelight();
              setSolo(s);
            }}
            exposure={exposure}
            setExposure={(v) => {
              touchRelight();
              setExposure(v);
            }}
            bake={bakeCfg}
            setBake={changeBake}
            preset={preset}
            onPreset={gotoPreset}
            tour={tour}
            setTour={(v) => {
              setTour(v);
              if (v && renderer) renderer.cam.tour = true;
            }}
            relights={relights}
            rebakes={rebakes}
            feat={feat}
            setFeat={setFeat}
          />
        </div>
      )}
      {showInspector && (
        <div className="pointer-events-none absolute left-3 right-3 top-[7.5rem] bottom-20 z-20 flex sm:left-auto sm:right-4 sm:top-[3.9rem] sm:w-[19.5rem]">
          <InspectorPanel
            bake={bake}
            fps={fps}
            tileN={bakeCfg.N}
            step={bakeCfg.step}
            feat={feat}
            imgErr={imgErr}
            canMeasure={refOn && refSamples > 8}
            onMeasure={() => setImgErr(renderer?.measure() ?? null)}
          />
        </div>
      )}

      {/* compare divider */}
      {refOn && !refUnsupported && (
        <>
          <div className="pointer-events-none absolute inset-y-0 z-10" style={{ left: `${split * 100}%` }}>
            <div className="absolute inset-y-0 -ml-px w-0.5 bg-white/90 shadow-[0_0_12px_rgba(255,255,255,0.6)]" />
            <button
              type="button"
              aria-label="Drag to compare"
              onPointerDown={(e) => {
                dragging.current = true;
                e.currentTarget.setPointerCapture(e.pointerId);
              }}
              onPointerMove={onDividerMove}
              onPointerUp={() => (dragging.current = false)}
              className="pointer-events-auto absolute top-1/2 -ml-5 -mt-5 flex h-10 w-10 cursor-ew-resize touch-none items-center justify-center rounded-full bg-white text-slate-900 shadow-xl"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                <path d="M8 6l-6 6 6 6M16 6l6 6-6 6" />
              </svg>
            </button>
          </div>
          <div className="pointer-events-none absolute bottom-[4.9rem] z-10 -translate-x-full pr-3" style={{ left: `${split * 100}%` }}>
            <span className="whitespace-nowrap rounded-full bg-amber-400 px-2.5 py-1 text-[11px] font-semibold text-slate-950">RadLUT · baked lookup</span>
          </div>
          <div className="pointer-events-none absolute bottom-[4.9rem] z-10 pl-3" style={{ left: `${split * 100}%` }}>
            <span className="whitespace-nowrap rounded-full bg-indigo-400 px-2.5 py-1 text-[11px] font-semibold text-slate-950">
              Path tracer · {refSamples} spp
            </span>
          </div>
        </>
      )}
      {refUnsupported && (
        <div className="absolute bottom-24 left-1/2 z-20 -translate-x-1/2 rounded-xl bg-red-500/20 px-3 py-2 text-xs text-red-200 backdrop-blur">
          This GPU cannot render to float textures, so the reference path tracer is unavailable.
        </div>
      )}

      {/* loading */}
      {bake.pass === 0 && bake.phase !== "error" && (
        <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center bg-slate-950/80">
          <div className="text-center">
            <div className="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-2 border-white/10 border-t-amber-400" />
            <div className="text-sm font-medium text-white">Baking the radiance LUT</div>
            <div className="mt-1 text-xs text-slate-400">finding tiles · projecting lattice · path tracing · perfect hashing</div>
          </div>
        </div>
      )}

      {/* bottom toolbar */}
      <div className="pointer-events-none absolute inset-x-0 bottom-3 z-30 flex justify-center px-3 sm:bottom-4">
        <div className="pointer-events-auto flex max-w-full items-center gap-2 overflow-x-auto rounded-2xl border border-white/10 bg-slate-950/75 p-1.5 shadow-2xl shadow-black/50 backdrop-blur-xl">
          <Seg value={mode} onChange={setMode} options={MODES} className="min-w-[14.5rem] bg-white/5 sm:min-w-[17rem]" />
          <button
            type="button"
            onClick={() => setRefOn((v) => !v)}
            className={cn(
              "shrink-0 rounded-xl px-3 py-2 text-xs font-semibold transition-colors sm:px-4",
              refOn ? "bg-indigo-400 text-slate-950" : "bg-white/10 text-slate-200 hover:bg-white/20",
            )}
          >
            <span className="sm:hidden">{refOn ? "Hide ref" : "Compare"}</span>
            <span className="hidden sm:inline">{refOn ? "Hide reference" : "Compare to path tracer"}</span>
          </button>
        </div>
      </div>

      {showAbout && <AboutModal onClose={() => setShowAbout(false)} />}
    </div>
  );
}
