import json
A=json.load(open("analysis.json")); D=json.load(open("devil.json")); ST=json.load(open("stress.json")); C=json.load(open("canary_results.json")); DEV1=json.load(open("dev1.json"))
out={"meta":{"cpu":"Intel Xeon @ 2.6GHz (AVX-512), 4 vCPU sandbox, pinned to 1 core","compiler":"g++ 12.2 -O3 -march=native -funroll-loops -ffp-contract=off","N":100000,"frames":300,"warm":30,"confirm_seeds":"2001-2010","dev_seeds":"101-103"},
 "canary":{"aa":{k:{"noise_floor_pct":v["noise_floor_pct"],"cv_pct":v["cv_pct"]} for k,v in C.items()}},
 "confirm":{"gate_failures":A["gate_failures"],"runs":A["runs"],"n_seeds":A["n_seeds"],"table":A["table"],"paired":A["paired"],"h5":A["h5"]},
 "verdict":A["verdict"],"devil":D,"stress":ST,
 "dev_first_attempt":{sc:{rt:DEV1[sc][rt]["total"] for rt in ["arch","archf","sparse","bm00","bm11","bm12"]} for sc in DEV1},
 "portable":json.load(open("portable.json")),"audit":{"sanitizer_runs":52,"sanitizer_failures":0,"determinism_checked":4,"devil_runs":200,"devil_gate_failures":0,"stress_runs":234,"portable_runs":300},"repro_code":open("reproduce.py").read()}
open("../src/data/results.json","w").write(json.dumps(out,indent=1).replace("NaN","null")); print("exported", len(json.dumps(out)))
