
================ PRE-REGISTRATION (frozen before any candidate/dev run) ================
Platform: sandbox x86-64 Xeon 2.6GHz (AVX-512), g++ 12 -O3 -march=native -funroll-loops -ffp-contract=off, pinned to 1 core. N=100,000 entities, 300 frames (30 warm-up), metric = total ns per entity-frame (structural phase + update phase).
Candidate C = bm11 "SFBT": bitmap-presence table + fused one-pass kernel + PER-BLOCK adaptive dispatch (scan vs branchless blend, by block popcount).
Tuned Baseline = per scenario, the best (lowest mean on DEV seeds) of {arch (deferred+prefetch archetype ECS), archf (fused archetype ECS), sparse (owning-group sparse-set ECS), bm00 (StaticEcs-style bitmap ECS)}; chosen on dev seeds, then frozen.
HYPOTHESIS H1 (primary): "By introducing a fused, per-block adaptive bitmap-table kernel (bm11), total ns/entity-frame in scenario HEAVY (10% toggles + 1% spawn/despawn per frame) improves by >= 15% over the Tuned Baseline while remaining bit-exact with the oracle."
Secondary: H2 CLUSTERED improves >= 15%; H3 MODERATE improves >= 10%; H4 STATIC is non-inferior (candidate no worse than +5%).
Mechanism-delta hypothesis H5: bm11 beats the better of its non-adaptive siblings (bm10 scan-only, bm12 blend-only) by >= 5% in CLUSTERED (heterogeneous density) -> only then is the *adaptive-dispatch delta* credited.
Noise floor from Phase 4 A/A: static 4.11%, heavy 2.26% (95% CI half-width, 10 pairs). Canaries: corrupt output rejected; 11-20% injected delay detected.
SEEDS: dev = [101,102,103] (only these may be used to tune BM_THR in {4,8,16} and BM_THRT in {8,24,48} and to select the baseline). Confirmatory = [2001..2010], untouched until code hash is re-frozen after tuning.
Improvement metric: per-seed paired (1 - cand/baseline), mean and 95% CI with t(9)=2.262. Correctness gate: checksum + live count must equal oracle in EVERY run (any failure = candidate invalid).
KILL CRITERIA (any one => FALSIFIED):
  K1 gate failure in any confirmatory run.
  K2 H1: lower bound of the 95% CI of heavy improvement < 10%  (or mean < 15% => H1 not confirmed).
  K3 H5: adaptive dispatch gives < 5% over best non-adaptive sibling in CLUSTERED -> the novel delta is rejected (prior-art components alone explain gain).
  K4 Devil's tuner (Phase 7): a baseline-only tweak closes >= 80% of the gap -> candidate not credited.
  K5 H4: static regression > +5% => candidate is not a general replacement (reported as limitation, verdict PROMISING at best).
Source hashes (sha256/16): {"common.hpp": "088c0614ecdbfcbe", "oracle.hpp": "5270a1f1d36844b8", "baseline_arch.hpp": "2ec3e9d3bb067253", "baseline_sparse.hpp": "985be5a91079a720", "candidates.hpp": "f1041651e53b837f", "bench.cpp": "7fa5dafb07b4c83f", "harness.py": "9b1505452db189dd"}
=========================================================================================

=== AMENDMENTS (logged before any confirmatory seed was touched) ===
A1: first dev run of bm* (AoS Vec3, scalar lane loops) was catastrophically slow (bm11 heavy 15.7 ns vs archetype 5.8). Compiler report: loops not vectorized. Fixed by field-level SoA + 32-lane kernels for the WHOLE bm family. Original saved as candidates_v0_aos_FAILED_DEV.hpp.
A2: staggered SoA array bases (4K aliasing guard). Re-added AoS unfused bitmap (bma00) so the prior-art bitmap baseline keeps its best layout (anti-strawman).
Frozen from DEV seeds: baseline(static)=archf, baseline(moderate)=archf, baseline(heavy)=bma00, baseline(clustered)=bma00. BM_THRT=48, BM_THR=8.
Kill criteria / hypotheses unchanged from pre-registration. Dev-seed early warning noted: bm10/bm12 >= bm11 in clustered.
Re-frozen hashes: {'common.hpp': '088c0614ecdbfcbe', 'oracle.hpp': '5270a1f1d36844b8', 'baseline_arch.hpp': '2ec3e9d3bb067253', 'baseline_sparse.hpp': '985be5a91079a720', 'candidates.hpp': '54d0102392dcfffc', 'candidates_aos.hpp': 'def8c9d6f1c910bb', 'bench.cpp': '613504ea5dfa4dd4', 'harness.py': '9b1505452db189dd'}
