#!/usr/bin/env python3
"""Minimal reproduction (stdlib only, needs g++ >= 9). Run from lab/:  python3 reproduce.py
1) builds bench.cpp  2) gates EVERY runtime bit-for-bit against the naive oracle  3) paired timing on 5 seeds, N=100k.
Full protocol scripts: verify_oracle.py, profile_tune.py, canary.py, dev3.py, confirm.py+analyze.py, devil.py, stress.py"""
import harness as H, statistics as S, math
b = H.build("bench", flags=["-O3", "-march=native", "-funroll-loops", "-ffp-contract=off"])
RT = ["archf", "bma00", "flag", "bm12", "bm11"]; SEEDS = [11, 12, 13, 14, 15]; N, F, W = 100000, 300, 30
for sc in ["static", "heavy"]:
    res = {rt: [] for rt in RT}
    for s in SEEDS:
        o = H.run(b, "oracle", sc, s, N, F, W)
        for rt in RT:
            r = H.run(b, rt, sc, s, N, F, W); assert H.gate(r, o), f"GATE FAIL {rt} {sc} {s}"; res[rt].append(r["total_ns"])
    print(f"-- {sc}: ns/entity-frame mean +/- 95% CI (n={len(SEEDS)}), all runs bit-exact vs oracle")
    for rt in RT:
        m = S.fmean(res[rt]); h = H.T975[len(SEEDS) - 1] * S.stdev(res[rt]) / math.sqrt(len(SEEDS)); print(f"   {rt:6s} {m:.3f} +/- {h:.3f}")
