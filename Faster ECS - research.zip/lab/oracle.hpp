// ORACLE: deliberately naive, independent of every optimized runtime.
// Trusted because: (1) one std::unordered_map<id, struct> - no layout tricks, no caches, no indices to corrupt;
// (2) every system is a plain loop over ALL entities with an explicit `if (flag)`;
// (3) templated on scalar type: T=float is bit-exact reference, T=double bounds float rounding drift (convergence check).
#pragma once
#include "common.hpp"
#include <unordered_map>

template <class T> struct Oracle {
  struct V { T x, y, z; };
  struct E { u32 uid; V pos, vel; T hp; u32 tags; bool cold; T acc; };
  std::unordered_map<u32, E> m; u32 next = 0;
  explicit Oracle(u32) {}
  u32 spawn(const SpawnData& s) {
    u32 id = next++;
    m[id] = E{s.uid, {(T)s.pos.x, (T)s.pos.y, (T)s.pos.z}, {(T)s.vel.x, (T)s.vel.y, (T)s.vel.z}, (T)s.hp, s.tags, s.cold, (T)0};
    return id;
  }
  void despawn(u32 id) { m.erase(id); }
  void toggle(u32 id, u32 tag) { m[id].tags ^= tag; }
  void update(float dtf) {
    const T dt = (T)dtf;
    for (auto& kv : m) { E& e = kv.second; e.pos.x += e.vel.x * dt; e.pos.y += e.vel.y * dt; e.pos.z += e.vel.z * dt; }
    for (auto& kv : m) { E& e = kv.second; if (e.tags & TAG_BURN) e.hp -= (T)0.01f; }
    for (auto& kv : m) { E& e = kv.second; if (e.tags & TAG_SLOW) {
      e.vel.x = e.vel.x * (T)0.99f + (T)0.005f; e.vel.y = e.vel.y * (T)0.99f + (T)0.005f; e.vel.z = e.vel.z * (T)0.99f + (T)0.005f; } }
    for (auto& kv : m) { E& e = kv.second; if (e.tags & TAG_STUN) e.pos.y -= (T)0.1f * dt; }
    for (auto& kv : m) { E& e = kv.second; if (e.cold) e.acc += e.pos.x * (T)0.001f; }
    for (auto& kv : m) { E& e = kv.second; if ((e.tags & (TAG_BURN | TAG_SLOW)) == (TAG_BURN | TAG_SLOW)) e.hp -= (T)0.02f; }
  }
  template <class F> void visit(F&& f) {
    for (auto& kv : m) { E& e = kv.second;
      Vec3 p{(float)e.pos.x, (float)e.pos.y, (float)e.pos.z}, v{(float)e.vel.x, (float)e.vel.y, (float)e.vel.z};
      f(e.uid, p, v, (float)e.hp, e.tags, e.cold, (float)e.acc); }
  }
  double energy() {  // double accumulation of the whole state, used for the convergence check
    double s = 0; for (auto& kv : m) { E& e = kv.second; s += (double)e.pos.x + e.pos.y + e.pos.z + e.vel.x + e.vel.y + e.vel.z + e.hp + (e.cold ? e.acc : 0); } return s;
  }
};
