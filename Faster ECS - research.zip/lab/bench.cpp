// Benchmark driver. usage: bench <runtime> <scenario> <seed> <N> <frames> <warm>
#include <string>
// Prints one JSON line. Workload is identical (same RNG stream) for every runtime.
#include "common.hpp"
#include "oracle.hpp"
#include "baseline_arch.hpp"
#include "baseline_sparse.hpp"
#include "candidates.hpp"
#include "candidates_aos.hpp"
#include "baseline_flags.hpp"

static double g_hot = 1.0;  // fraction of live list that toggles target (clustered scenario)
struct Result { double structNs, updNs, energy; u64 checksum, live; };

template <class W> u64 checksumOf(W& w) {
  u64 s = 0; w.visit([&](u32 uid, const Vec3& p, const Vec3& v, float hp, u32 tags, bool cold, float acc) { s += entHash(uid, p, v, hp, tags, cold, acc); }); return s;
}
template <class W> double energyOf(W& w) {
  double s = 0; w.visit([&](u32, const Vec3& p, const Vec3& v, float hp, u32, bool cold, float acc) { s += (double)p.x + p.y + p.z + v.x + v.y + v.z + hp + (cold ? acc : 0.f); }); return s;
}
double energyOf(Oracle<double>& w) { return w.energy(); }
template <class W> u64 liveOf(W& w) { u64 c = 0; w.visit([&](u32, const Vec3&, const Vec3&, float, u32, bool, float) { c++; }); return c; }

template <class W> Result runWorkload(u64 seed, u32 N, int frames, int warm, double toggleRate, double churnRate) {
  W* w = new W(N * 2 + 4096);
  std::vector<u32> live; live.reserve((size_t)N * 2);
  Rng r(seed ^ 0xABCDEF12345ull); u32 nextUid = 0;
  auto doSpawn = [&] { SpawnData s = makeSpawn(seed, nextUid++); live.push_back(w->spawn(s)); };
  for (u32 i = 0; i < N; i++) doSpawn();
  u32 K = (u32)(toggleRate * N + 0.5), D = (u32)(churnRate * N + 0.5);
  double sNs = 0, uNs = 0;
  for (int f = 0; f < frames; f++) {
    auto t0 = std::chrono::steady_clock::now();
    for (u32 i = 0; i < K; i++) { u32 ix = r.below(std::max<u32>(1, (u32)(live.size() * g_hot))); w->toggle(live[ix], 1u << r.below(3)); }
    for (u32 i = 0; i < D; i++) { u32 ix = r.below((u32)live.size()); w->despawn(live[ix]); live[ix] = live.back(); live.pop_back(); }
    for (u32 i = 0; i < D; i++) doSpawn();
    auto t1 = std::chrono::steady_clock::now();
    w->update(DT);
    auto t2 = std::chrono::steady_clock::now();
    if (f >= warm) { sNs += std::chrono::duration<double, std::nano>(t1 - t0).count(); uNs += std::chrono::duration<double, std::nano>(t2 - t1).count(); }
  }
  Result res; double den = (double)(frames - warm) * N;
  res.structNs = sNs / den; res.updNs = uNs / den; res.checksum = checksumOf(*w); res.energy = energyOf(*w); res.live = liveOf(*w);
  delete w; return res;
}

int main(int argc, char** argv) {
  if (argc < 7) { fprintf(stderr, "usage: bench runtime scenario seed N frames warm\n"); return 2; }
  std::string rt = argv[1], sc = argv[2]; u64 seed = strtoull(argv[3], 0, 10); u32 N = (u32)atoi(argv[4]); int frames = atoi(argv[5]), warm = atoi(argv[6]);
  double tg = 0, ch = 0;
  if (sc == "static") { tg = 0; ch = 0; } else if (sc == "moderate") { tg = 0.01; ch = 0.001; } else if (sc == "heavy") { tg = 0.10; ch = 0.01; }
  else if (sc == "extreme") { tg = 0.30; ch = 0.03; } else if (sc == "clustered") { tg = 0.10; ch = 0.01; g_hot = 0.1; } else if (sc == "toggleonly") { tg = 0.10; ch = 0; } else { fprintf(stderr, "bad scenario\n"); return 2; }
  Result R;
  if (rt == "oracle") R = runWorkload<Oracle<float>>(seed, N, frames, warm, tg, ch);
  else if (rt == "oracle64") R = runWorkload<Oracle<double>>(seed, N, frames, warm, tg, ch);
  else if (rt == "arch") R = runWorkload<ArchWorld>(seed, N, frames, warm, tg, ch);
  else if (rt == "sparse") R = runWorkload<SparseWorld>(seed, N, frames, warm, tg, ch);
  else if (rt == "flag") R = runWorkload<FlagWorld>(seed, N, frames, warm, tg, ch);
  else if (rt == "flagp") R = runWorkload<FlagPWorld>(seed, N, frames, warm, tg, ch);
  else if (rt == "archf") R = runWorkload<ArchFWorld>(seed, N, frames, warm, tg, ch);
  else if (rt == "arch_nop") R = runWorkload<ArchNopWorld>(seed, N, frames, warm, tg, ch);
  else if (rt == "arch_slow") R = runWorkload<ArchSlowWorld>(seed, N, frames, warm, tg, ch);
#define BMR(F, M) else if (rt == "bm" #F #M) R = runWorkload<BitmapWorld<F, M>>(seed, N, frames, warm, tg, ch);
  else if (rt == "bma00") R = runWorkload<BitmapAosWorld<0, 0>>(seed, N, frames, warm, tg, ch);
  BMR(0, 0) BMR(0, 1) BMR(0, 2) BMR(1, 0) BMR(1, 1) BMR(1, 2)
  else { fprintf(stderr, "bad runtime\n"); return 2; }
  printf("{\"rt\":\"%s\",\"sc\":\"%s\",\"seed\":%llu,\"N\":%u,\"struct_ns\":%.6f,\"upd_ns\":%.6f,\"total_ns\":%.6f,\"checksum\":\"%016llx\",\"energy\":%.6f,\"live\":%llu",
         rt.c_str(), sc.c_str(), (unsigned long long)seed, N, R.structNs, R.updNs, R.structNs + R.updNs, (unsigned long long)R.checksum, R.energy, (unsigned long long)R.live);
#ifdef PROFILE_SYS
  printf(",\"sys_ns\":["); for (int i = 0; i < 6; i++) printf("%s%.4f", i ? "," : "", g_sys[i] / ((double)(frames - 0) * N)); printf("]");
#endif
  printf("}\n"); return 0;
}
