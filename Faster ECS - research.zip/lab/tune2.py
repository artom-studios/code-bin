import harness as H, statistics as S
b=H.build("bench",flags=["-O3","-march=native","-funroll-loops","-ffp-contract=off"])
for sc in ["static","heavy"]:
    for rt in ["oracle","arch","sparse"]:
        r1=H.run(b,rt,sc,5,3000,60,0)
    print(sc,"check", {rt:H.run(b,rt,sc,5,3000,60,0)["checksum"] for rt in ["oracle","arch","sparse"]})
    for rt in ["arch","sparse"]:
        xs=[H.run(b,rt,sc,11,100000,200,20) for _ in range(5)]
        print(f"{sc:7s} {rt:6s} struct={S.median(x['struct_ns'] for x in xs):.3f} upd={S.median(x['upd_ns'] for x in xs):.3f} total={S.median(x['total_ns'] for x in xs):.3f}")
