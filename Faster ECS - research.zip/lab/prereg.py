import hashlib, json, time
files=["common.hpp","oracle.hpp","baseline_arch.hpp","baseline_sparse.hpp","candidates.hpp","bench.cpp","harness.py"]
h={f:hashlib.sha256(open(f,'rb').read()).hexdigest()[:16] for f in files}
txt=f"""
================ PRE-REGISTRATION (frozen before any candidate/dev run) ================
Platform: sandbox x86-64 Xeon 2.6GHz (AVX-512), g++ 12 -O3 -march=native -funroll-loops -ffp-contract=off, pinned to 1 core. N=100,000 entities, 300 frames (30 warm-up), metric = total ns per entity-frame (structural phase + update phase).
Candidate C = bm11 "SFBT": bitmap-presence table + fused one-pass kernel + PER-BLOCK adaptive dispatch (scan vs branchless blend, by block popcount).
Tuned Baseline = per scenario, the best (lowest mean on DEV seeds) of {{arch (deferred+prefetch archetype ECS), archf (fused archetype ECS), sparse (owning-group sparse-set ECS), bm00 (StaticEcs-style bitmap ECS)}}; chosen on dev seeds, then frozen.
HYPOTHESIS H1 (primary): "By introducing a fused, per-block adaptive bitmap-table kernel (bm11), total ns/entity-frame in scenario HEAVY (10% toggles + 1% spawn/despawn per frame) improves by >= 15% over the Tuned Baseline while remaining bit-exact with the oracle."
Secondary: H2 CLUSTERED improves >= 15%; H3 MODERATE improves >= 10%; H4 STATIC is non-inferior (candidate no worse than +5%).
Mechanism-delta hypothesis H5: bm11 beats the better of its non-adaptive siblings (bm10 scan-only, bm12 blend-only) by >= 5% in CLUSTERED (heterogeneous density) -> only then is the *adaptive-dispatch delta* credited.
Noise floor from Phase 4 A/A: static 4.11%, heavy 2.26% (95% CI half-width, 10 pairs). Canaries: corrupt output rejected; 11-20% injected delay detected.
SEEDS: dev = [101,102,103] (only these may be used to tune BM_THR in {{4,8,16}} and BM_THRT in {{8,24,48}} and to select the baseline). Confirmatory = [2001..2010], untouched until code hash is re-frozen after tuning.
Improvement metric: per-seed paired (1 - cand/baseline), mean and 95% CI with t(9)=2.262. Correctness gate: checksum + live count must equal oracle in EVERY run (any failure = candidate invalid).
KILL CRITERIA (any one => FALSIFIED):
  K1 gate failure in any confirmatory run.
  K2 H1: lower bound of the 95% CI of heavy improvement < 10%  (or mean < 15% => H1 not confirmed).
  K3 H5: adaptive dispatch gives < 5% over best non-adaptive sibling in CLUSTERED -> the novel delta is rejected (prior-art components alone explain gain).
  K4 Devil's tuner (Phase 7): a baseline-only tweak closes >= 80% of the gap -> candidate not credited.
  K5 H4: static regression > +5% => candidate is not a general replacement (reported as limitation, verdict PROMISING at best).
Source hashes (sha256/16): {json.dumps(h)}
=========================================================================================
"""
print(txt); open("prereg.md","w").write(txt)
