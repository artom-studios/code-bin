# Phase 3 Invalidation Matrix (searches executed this session)
| Candidate | Closest prior work (found) | Verdict |
|---|---|---|
| 1 Stigmergic block table (mask table + 64-blocks + summaries) | StaticEcs (Felid-Force-Studios): inverted hierarchical bitmap ECS, 4096>256>64 blocks, add/remove = bit flip, no archetype moves | KILLED as novel. KEPT as competitor "Baseline C" (bm00 = unfused, bit-scan-only). |
| 2 Marshalling-yard batched relocation | Unity EntityCommandBuffer / Bevy Commands (grouped replay by destination archetype); a console-engine PR measured deferral alone NOT helping | KILLED as novel. Deferred+prefetch already inside tuned `arch` baseline. |
| 7 Fused predicated kernel | Sub0ECS v2 "system fusion": per-partition (archetype-like) fused loops, 3.5-5.3x vs sequential passes | KILLED as novel for archetype stores. Added `archf` (fused archetype ECS) as strongest baseline. |
| 9 SFBT = fused kernel over a mask-bitmap table with PER-BLOCK adaptive dispatch (scan vs branchless-blend by block popcount) | None found that fuses systems on a bitmap-presence store, nor that picks scan/blend per 64-lane block. | SURVIVES as a *combination* delta (not a fundamental invention). |
Selected: C-SFBT = bm11 (FUSE=1, MODE=adaptive). Ablation siblings: bm10 (fused, scan-only), bm12 (fused, blend-only), bm01 (adaptive, unfused), bm02 (unfused blend), bm00 (StaticEcs-like).
