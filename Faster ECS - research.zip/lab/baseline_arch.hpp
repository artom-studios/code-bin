// BASELINE A: archetype-SoA ECS (flecs / Bevy / Unity-chunk lineage).
// Tuned: raw aligned columns (no value-init), swap-remove, 16 pre-created archetypes (edge lookup = XOR),
// per-system tight loops over __restrict SoA pointers so the compiler auto-vectorizes.
#pragma once
#include "common.hpp"

struct ArchWorld {
  struct Arch { Col<Vec3> pos, vel; Col<Health> hp; Col<Cold> cold; Col<u32> ent; };
  struct Rec { u32 mask, row; };
  Arch a[16]; std::vector<Rec> rec; std::vector<u32> freeL;
  explicit ArchWorld(u32 cap) { rec.reserve(cap); for (auto& A : a) { A.pos.reserve(1024); A.vel.reserve(1024); A.hp.reserve(1024); A.ent.reserve(1024); } }
  u32 spawn(const SpawnData& s) {
    flush();
    u32 m = s.tags | (s.cold ? 8u : 0u), e;
    if (!freeL.empty()) { e = freeL.back(); freeL.pop_back(); } else { e = (u32)rec.size(); rec.push_back({}); }
    Arch& A = a[m]; rec[e] = {m, A.ent.n};
    A.pos.push(s.pos); A.vel.push(s.vel); A.hp.push(Health{s.hp, s.uid}); if (m & 8) A.cold.push(Cold{}); A.ent.push(e);
    return e;
  }
  inline void removeRow(Arch& A, u32 row, bool cold) {
    u32 last = A.ent.n - 1;
    if (row != last) {
      A.pos.d[row] = A.pos.d[last]; A.vel.d[row] = A.vel.d[last]; A.hp.d[row] = A.hp.d[last];
      if (cold) A.cold.d[row] = A.cold.d[last];
      u32 mv = A.ent.d[last]; A.ent.d[row] = mv; rec[mv].row = row;
    }
    A.pos.n--; A.vel.n--; A.hp.n--; if (cold) A.cold.n--; A.ent.n--;
  }
  std::vector<u32> qE, qT;  // command buffer for structural changes (tuned: deferred + software-prefetch pipeline)
  void despawn(u32 e) { flush(); Rec r = rec[e]; removeRow(a[r.mask], r.row, r.mask & 8); freeL.push_back(e); }
  void toggle(u32 e, u32 tag) { qE.push_back(e); qT.push_back(tag); }
  void flush() {
    size_t n = qE.size(); if (!n) return;
    for (size_t i = 0; i < n; i++) {
      if (i + 16 < n) __builtin_prefetch(&rec[qE[i + 16]]);
      if (i + 8 < n) { Rec r = rec[qE[i + 8]]; Arch& S = a[r.mask]; __builtin_prefetch(S.pos.d + r.row, 1); __builtin_prefetch(S.vel.d + r.row, 1); __builtin_prefetch(S.hp.d + r.row, 1);
        if (S.ent.n) { u32 l = S.ent.n - 1; __builtin_prefetch(S.ent.d + l); __builtin_prefetch(&rec[S.ent.d[l]], 1); } }
      toggleNow(qE[i], qT[i]);
    }
    qE.clear(); qT.clear();
  }
  void toggleNow(u32 e, u32 tag) {
    Rec r = rec[e]; u32 nm = r.mask ^ tag; Arch& S = a[r.mask]; Arch& D = a[nm];
    D.pos.push(S.pos.d[r.row]); D.vel.push(S.vel.d[r.row]); D.hp.push(S.hp.d[r.row]);
    if (r.mask & 8) D.cold.push(S.cold.d[r.row]);
    D.ent.push(e);
    removeRow(S, r.row, r.mask & 8);
    rec[e] = {nm, D.ent.n - 1};
  }
  void update(float dt) {
    flush();
    { SYS(0) for (int m = 0; m < 16; m++) { Arch& A = a[m]; u32 n = A.ent.n; Vec3* __restrict p = A.pos.d; const Vec3* __restrict v = A.vel.d;
        for (u32 i = 0; i < n; i++) { p[i].x += v[i].x * dt; p[i].y += v[i].y * dt; p[i].z += v[i].z * dt; } } }
    { SYS(1) for (int m = 0; m < 16; m++) if (m & TAG_BURN) { Arch& A = a[m]; u32 n = A.ent.n; Health* __restrict h = A.hp.d;
        for (u32 i = 0; i < n; i++) h[i].hp -= 0.01f; } }
    { SYS(2) for (int m = 0; m < 16; m++) if (m & TAG_SLOW) { Arch& A = a[m]; u32 n = A.ent.n; Vec3* __restrict v = A.vel.d;
        for (u32 i = 0; i < n; i++) { v[i].x = v[i].x * 0.99f + 0.005f; v[i].y = v[i].y * 0.99f + 0.005f; v[i].z = v[i].z * 0.99f + 0.005f; } } }
    { SYS(3) for (int m = 0; m < 16; m++) if (m & TAG_STUN) { Arch& A = a[m]; u32 n = A.ent.n; Vec3* __restrict p = A.pos.d;
        for (u32 i = 0; i < n; i++) p[i].y -= 0.1f * dt; } }
    { SYS(4) for (int m = 0; m < 16; m++) if (m & 8) { Arch& A = a[m]; u32 n = A.ent.n; Cold* __restrict c = A.cold.d; const Vec3* __restrict p = A.pos.d;
        for (u32 i = 0; i < n; i++) c[i].acc += p[i].x * 0.001f; } }
    { SYS(5) for (int m = 0; m < 16; m++) if ((m & 3) == 3) { Arch& A = a[m]; u32 n = A.ent.n; Health* __restrict h = A.hp.d;
        for (u32 i = 0; i < n; i++) h[i].hp -= 0.02f; } }
  }
  template <class F> void visit(F&& f) {
    flush();
    for (int m = 0; m < 16; m++) { Arch& A = a[m];
      for (u32 i = 0; i < A.ent.n; i++) f(A.hp.d[i].uid, A.pos.d[i], A.vel.d[i], A.hp.d[i].hp, (u32)(m & 7), (m & 8) != 0, (m & 8) ? A.cold.d[i].acc : 0.f); }
  }
};

// ---- BASELINE A2 (strongest archetype variant): per-archetype FUSED kernel, compile-time specialised on the mask (Sub0ECS-style fusion).
template <int M> static inline void fusedArch(ArchWorld::Arch& A, float dt) {
  u32 n = A.ent.n; Vec3* __restrict p = A.pos.d; Vec3* __restrict v = A.vel.d; Health* __restrict h = A.hp.d; Cold* __restrict c = A.cold.d;
  for (u32 i = 0; i < n; i++) {
    Vec3 pp = p[i], vv = v[i]; float hp = h[i].hp;
    pp.x += vv.x * dt; pp.y += vv.y * dt; pp.z += vv.z * dt;
    if constexpr (M & 1) hp -= 0.01f;
    if constexpr (M & 2) { vv.x = vv.x * 0.99f + 0.005f; vv.y = vv.y * 0.99f + 0.005f; vv.z = vv.z * 0.99f + 0.005f; }
    if constexpr (M & 4) pp.y -= 0.1f * dt;
    if constexpr (M & 8) c[i].acc += pp.x * 0.001f;
    if constexpr ((M & 3) == 3) hp -= 0.02f;
    p[i] = pp; if constexpr (M & 2) v[i] = vv; if constexpr (M & 1) h[i].hp = hp;
  }
}
struct ArchFWorld : ArchWorld {
  using ArchWorld::ArchWorld;
  void update(float dt) {
    flush();
#define FA(k) case k: fusedArch<k>(a[k], dt); break;
    for (int m = 0; m < 16; m++) { switch (m) { FA(0) FA(1) FA(2) FA(3) FA(4) FA(5) FA(6) FA(7) FA(8) FA(9) FA(10) FA(11) FA(12) FA(13) FA(14) FA(15) } }
#undef FA
  }
};
// ---- canary runtimes (harness validation only) ----
struct ArchNopWorld : ArchWorld { using ArchWorld::ArchWorld; void update(float) { flush(); } };  // "all-zero / corrupt output": does nothing
struct ArchSlowWorld : ArchWorld {  // artificial delay (~5%): spin
  u32 spinN; explicit ArchSlowWorld(u32 cap) : ArchWorld(cap), spinN((cap / 64) * (getenv("SLOW_X") ? atoi(getenv("SLOW_X")) : 1)) {}
  void update(float dt) { ArchWorld::update(dt); volatile u32 sink = 0; for (u32 k = 0; k < spinN; k++) sink = sink + k; }
};
