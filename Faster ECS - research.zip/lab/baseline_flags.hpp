// DEVIL'S TUNER baseline tweak: "flag column" ECS. One dense table (no archetype moves), volatile state kept as bits of a
// per-entity status BYTE (the standard ECS advice: "use a flag field instead of add/remove component"), fused branchless kernel.
// NO bitmap words, NO per-block adaptivity, NO block summaries -> if this matches bm11/bm12 the "novel runtime" is just known advice.
#pragma once
#include "common.hpp"
struct FlagWorld {
  float *PX, *PY, *PZ, *VX, *VY, *VZ, *HP, *AC; u32* UID; u32* FL;  // (u32 lanes: u8 flags defeated if-conversion/vectorization in gcc) FL: 1 burn,2 slow,4 stun,8 acc,16 alive
  u32 cap, nslots = 0; std::vector<void*> raws; std::vector<u32> freeL;
  static void* zalloc(size_t bytes) { bytes = (bytes + 63) & ~(size_t)63; void* p = aligned_alloc(64, bytes); memset(p, 0, bytes); return p; }
  float* fa(size_t n) { void* p = zalloc(n * 4 + 13 * 1088); raws.push_back(p); return (float*)((char*)p + ((raws.size() - 1) % 13) * 1088); }
  explicit FlagWorld(u32 capHint) {
    cap = ((capHint + 63) / 64) * 64;
    PX = fa(cap); PY = fa(cap); PZ = fa(cap); VX = fa(cap); VY = fa(cap); VZ = fa(cap); HP = fa(cap); AC = fa(cap); UID = (u32*)fa(cap);
    FL = (u32*)fa(cap);
  }
  ~FlagWorld() { for (void* p : raws) free(p); }
  u32 spawn(const SpawnData& s) {
    u32 e; if (!freeL.empty()) { e = freeL.back(); freeL.pop_back(); } else e = nslots++;
    PX[e] = s.pos.x; PY[e] = s.pos.y; PZ[e] = s.pos.z; VX[e] = s.vel.x; VY[e] = s.vel.y; VZ[e] = s.vel.z; HP[e] = s.hp; UID[e] = s.uid; AC[e] = 0.f;
    FL[e] = s.tags | (s.cold ? 8u : 0u) | 16u; return e;
  }
  void despawn(u32 e) { FL[e] = 0; freeL.push_back(e); }
  void toggle(u32 e, u32 tg) { FL[e] ^= tg; }
  static inline void lane32(float* __restrict px, float* __restrict py, float* __restrict pz, float* __restrict vx, float* __restrict vy, float* __restrict vz,
                            float* __restrict hp, float* __restrict ac, const u32* __restrict fl, float dt) {
    for (int i = 0; i < 32; i++) {
      u32 f = fl[i];
      float x = px[i] + vx[i] * dt, y = py[i] + vy[i] * dt, z = pz[i] + vz[i] * dt;
      float h = hp[i]; h -= (f & 1u) != 0 ? 0.01f : 0.f;
      bool s = (f & 2u) != 0;
      float nx = s ? vx[i] * 0.99f + 0.005f : vx[i], ny = s ? vy[i] * 0.99f + 0.005f : vy[i], nz = s ? vz[i] * 0.99f + 0.005f : vz[i];
      y -= (f & 4u) != 0 ? 0.1f * dt : 0.f; ac[i] += (f & 8u) != 0 ? x * 0.001f : 0.f; h -= (f & 3u) == 3u ? 0.02f : 0.f;
      px[i] = x; py[i] = y; pz[i] = z; vx[i] = nx; vy[i] = ny; vz[i] = nz; hp[i] = h;
    }
  }
  void update(float dt) {
    u32 n = (nslots + 63) & ~63u;
    for (u32 o = 0; o < n; o += 32) lane32(PX + o, PY + o, PZ + o, VX + o, VY + o, VZ + o, HP + o, AC + o, FL + o, dt);
  }
  template <class F> void visit(F&& f) {
    for (u32 e = 0; e < nslots; e++) { u32 m = FL[e]; if (!(m & 16)) continue; bool c = m & 8;
      f(UID[e], Vec3{PX[e], PY[e], PZ[e]}, Vec3{VX[e], VY[e], VZ[e]}, HP[e], (u32)(m & 7), c, c ? AC[e] : 0.f); }
  }
};

// ---- Portable variant: no ternary/bool in the lane loop. 0/1 float factors where exact (x - 0.0f == x), bitwise integer select for blends
// (what blendv / NEON vbsl do). Designed so SSE4.2 / AVX2 / NEON compilers if-convert without relying on AVX-512 mask registers.
static inline float selbits(u32 m, float a, float b) { u32 ua, ub; memcpy(&ua, &a, 4); memcpy(&ub, &b, 4); u32 r = (ua & m) | (ub & ~m); float f; memcpy(&f, &r, 4); return f; }
struct FlagPWorld : FlagWorld {
  using FlagWorld::FlagWorld;
  static inline void lane32p(float* __restrict px, float* __restrict py, float* __restrict pz, float* __restrict vx, float* __restrict vy, float* __restrict vz,
                             float* __restrict hp, float* __restrict ac, const u32* __restrict fl, float dt) {
    const float dy = 0.1f * dt;
    for (int i = 0; i < 32; i++) {
      int f = (int)fl[i];
      float bf = (float)(f & 1), tf = (float)((f >> 2) & 1), cf = (float)((f >> 3) & 1), bsf = (float)(((f & 3) == 3) ? 1 : 0);
      u32 sm = 0u - (u32)((f >> 1) & 1);
      float x = px[i] + vx[i] * dt, y = py[i] + vy[i] * dt, z = pz[i] + vz[i] * dt;
      float h = hp[i]; h -= bf * 0.01f;
      float nx = selbits(sm, vx[i] * 0.99f + 0.005f, vx[i]), ny = selbits(sm, vy[i] * 0.99f + 0.005f, vy[i]), nz = selbits(sm, vz[i] * 0.99f + 0.005f, vz[i]);
      y -= tf * dy; ac[i] += cf * (x * 0.001f); h -= bsf * 0.02f;
      px[i] = x; py[i] = y; pz[i] = z; vx[i] = nx; vy[i] = ny; vz[i] = nz; hp[i] = h;
    }
  }
  void update(float dt) {
    u32 n = (nslots + 63) & ~63u;
    for (u32 o = 0; o < n; o += 32) lane32p(PX + o, PY + o, PZ + o, VX + o, VY + o, VZ + o, HP + o, AC + o, FL + o, dt);
  }
};
