import harness as H, statistics as S, json
b = H.build("bench", flags=["-O3","-march=native","-funroll-loops","-ffp-contract=off"])
RT=["arch","archf","sparse","bm00","bm01","bm02","bm10","bm11","bm12"]
print("== small-scale correctness gate (N=5000, 120 frames) ==")
bad=0
for sc in ["static","moderate","heavy","clustered","extreme"]:
    for seed in [101,102]:
        o=H.run(b,"oracle",sc,seed,5000,120,0)
        for rt in RT:
            ok=H.gate(H.run(b,rt,sc,seed,5000,120,0),o)
            if not ok: bad+=1; print("  GATE FAIL",rt,sc,seed)
print("gate failures:",bad)
print("== DEV timings, N=100k, 300 frames, dev seeds 101-103 (mean total ns/entity-frame; struct/upd split) ==")
dev={}
for sc in ["static","moderate","heavy","clustered"]:
    R={rt:[] for rt in RT}
    for s in [101,102,103]:
        o=H.oracle_checksum(b,sc,s,100000,300,30)
        for rt in RT:
            r=H.run(b,rt,sc,s,100000,300,30); r["ok"]=H.gate(r,o); R[rt].append(r)
    dev[sc]={rt:{"total":S.fmean(x["total_ns"] for x in v),"struct":S.fmean(x["struct_ns"] for x in v),"upd":S.fmean(x["upd_ns"] for x in v),"gate":all(x["ok"] for x in v)} for rt,v in R.items()}
    print(f"-- {sc}")
    for rt in RT: d=dev[sc][rt]; print(f"   {rt:6s} total={d['total']:.3f} (struct {d['struct']:.3f} + upd {d['upd']:.3f})  gate={d['gate']}")
json.dump(dev,open("dev1.json","w"),indent=1)
