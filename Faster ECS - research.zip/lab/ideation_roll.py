import secrets, json, urllib.request
domains=["fungal mycelial networks","power-grid phase synchronization","postal sorting & routing","adaptive immunology (clonal selection)","ant-colony stigmergy","tidal/coastal sediment transport","air-traffic control sectors","library card catalogs","coral reef zonation","railway marshalling yards","bird-flock murmuration","cell-cycle checkpoints","telephone exchange switching","bee-hive thermoregulation","glacier flow"]
ops=["segmentation","inversion","counterweight","dynamic deadband","quantization","lazy evaluation/ debt","phase-lock","hysteresis"]
pick=lambda L,k:[L[secrets.randbelow(len(L))] for _ in range(k)] if k==1 else (lambda p:[L[i] for i in p])(__import__('random').SystemRandom().sample(range(len(L)),k))
roll={"domains":pick(domains,3),"operators":pick(ops,2),"entropy_hex":secrets.token_hex(8)}
arts=[]
for _ in range(2):
    try:
        req=urllib.request.Request("https://en.wikipedia.org/api/rest_v1/page/random/summary",headers={"User-Agent":"research-sandbox/1.0"})
        d=json.load(urllib.request.urlopen(req,timeout=15)); arts.append({"title":d["title"],"extract":d.get("extract","")[:300]})
    except Exception as e: arts.append({"error":str(e)})
roll["wikipedia"]=arts
print(json.dumps(roll,indent=1)); json.dump(roll,open("ideation_roll.json","w"),indent=1)
