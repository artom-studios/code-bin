"""Stdlib-only harness: build, run, statistics. (No numpy in sandbox.)"""
import json, math, statistics, subprocess, os, sys
LAB = os.path.dirname(os.path.abspath(__file__))
T975 = {1:12.706,2:4.303,3:3.182,4:2.776,5:2.571,6:2.447,7:2.365,8:2.306,9:2.262,10:2.228,11:2.201,12:2.179,
        13:2.160,14:2.145,15:2.131,16:2.120,17:2.110,18:2.101,19:2.093,20:2.086,29:2.045}

def build(out="bench", extra=(), flags=("-O3","-march=native","-ffp-contract=off"), cands=False):
    cmd = ["g++","-std=c++17",*flags,*extra]
    if cands: cmd.append("-DWITH_CANDIDATES")
    cmd += [os.path.join(LAB,"bench.cpp"),"-o",os.path.join(LAB,out)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode: print(r.stderr); raise SystemExit("build failed")
    return os.path.join(LAB,out)

def run(binp, rt, sc, seed, N, frames, warm):
    r = subprocess.run([binp,rt,sc,str(seed),str(N),str(frames),str(warm)], capture_output=True, text=True)
    if r.returncode: raise RuntimeError(r.stderr)
    return json.loads(r.stdout.strip().splitlines()[-1])

def ci95(xs):
    n = len(xs); m = statistics.fmean(xs)
    if n < 2: return m, 0.0, 0.0
    sd = statistics.stdev(xs); t = T975.get(n-1, 1.96)
    return m, sd, t*sd/math.sqrt(n)

import shutil, time
PIN = ["taskset","-c","2"] if shutil.which("taskset") else []
_orig_run = run
def run(binp, rt, sc, seed, N, frames, warm):
    r = subprocess.run([*PIN, binp,rt,sc,str(seed),str(N),str(frames),str(warm)], capture_output=True, text=True)
    if r.returncode: raise RuntimeError(r.stderr)
    return json.loads(r.stdout.strip().splitlines()[-1])

_ORACLE = {}
def oracle_checksum(binp, sc, seed, N, frames, warm):
    k = (sc, seed, N, frames)
    if k not in _ORACLE: _ORACLE[k] = run(binp, "oracle", sc, seed, N, frames, warm)
    return _ORACLE[k]

def gate(res, orc):
    """Correctness gate: bit-exact checksum + live count vs the oracle."""
    return res["checksum"] == orc["checksum"] and res["live"] == orc["live"]

def welch(a, b):
    """returns (mean_a, mean_b, rel_diff_pct of b vs a, 95% half-width pct of diff)"""
    ma, mb = statistics.fmean(a), statistics.fmean(b)
    se = math.sqrt(statistics.variance(a)/len(a) + statistics.variance(b)/len(b))
    return ma, mb, 100*(mb-ma)/ma, 100*2.101*se/ma
