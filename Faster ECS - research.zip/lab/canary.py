import harness as H, statistics as S, json
b = H.build("bench", flags=["-O3","-march=native","-funroll-loops","-ffp-contract=off"])
N,F,W = 100000, 300, 30
seeds = list(range(901, 911))
out = {}
print("PIN =", H.PIN)
for sc in ["static","heavy"]:
    orc = H.oracle_checksum(b, sc, seeds[0], N, F, W)
    A=[];B=[]
    for s in seeds:  # interleaved A/B, fresh process each
        ra = H.run(b,"arch",sc,s,N,F,W); rb = H.run(b,"arch",sc,s,N,F,W)
        A.append(ra["total_ns"]); B.append(rb["total_ns"])
    ma,mb,rel,hw = H.welch(A,B)
    cv = 100*S.stdev(A)/S.fmean(A)
    floor = max(abs(rel), hw)
    print(f"[A/A] {sc:7s} meanA={ma:.4f} meanB={mb:.4f} ns  diff={rel:+.2f}%  95%CI half-width={hw:.2f}%  run-to-run CV={cv:.2f}%  => NOISE FLOOR ~ {floor:.2f}%")
    out[sc]={"noise_floor_pct":floor,"cv_pct":cv,"A":A,"B":B}
    # canary (a): corrupt/all-zero output must FAIL gate
    ok_good = H.gate(H.run(b,"arch",sc,seeds[0],N,F,W), orc)
    ok_nop  = H.gate(H.run(b,"arch_nop",sc,seeds[0],N,F,W), orc)
    print(f"[canary a] {sc}: gate(arch)={ok_good} (expect True)  gate(arch_nop all-zero update)={ok_nop} (expect False) -> {'OK' if ok_good and not ok_nop else 'HARNESS INVALID'}")
    # canary (b): artificial ~5% delay must be detected as a significant slowdown
    D=[H.run(b,"arch_slow",sc,s,N,F,W)["total_ns"] for s in seeds]
    ma,md,rel,hw = H.welch(A,D)
    detected = (rel-hw) > 0
    print(f"[canary b] {sc}: arch_slow vs arch: {rel:+.2f}% +/- {hw:.2f}% (slow gate correct={H.gate(H.run(b,'arch_slow',sc,seeds[0],N,F,W),orc)}) -> {'DETECTED' if detected else 'MISSED -> HARNESS INVALID'}")
json.dump(out,open("canary_results.json","w"),indent=1)
