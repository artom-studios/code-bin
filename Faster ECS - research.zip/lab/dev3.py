import harness as H, statistics as S, json, os
b = H.build("bench", flags=["-O3","-march=native","-funroll-loops","-ffp-contract=off"])
RT=["arch","archf","sparse","bma00","bm00","bm01","bm10","bm11","bm12"]
bad=0
for sc in ["static","heavy","clustered"]:
    o=H.run(b,"oracle",sc,101,5000,120,0)
    for rt in RT+["bm02"]:
        if not H.gate(H.run(b,rt,sc,101,5000,120,0),o): bad+=1; print("GATE FAIL",rt,sc)
print("small gate failures:",bad)
def runenv(rt,sc,s,env):
    old={k:os.environ.get(k) for k in env}
    os.environ.update(env)
    try: return H.run(b,rt,sc,s,100000,300,30)
    finally:
        for k,v in old.items():
            if v is None: os.environ.pop(k,None)
            else: os.environ[k]=v
res={}
for sc in ["static","moderate","heavy","clustered"]:
    print(f"-- {sc}")
    for rt in RT:
        v=[]; ok=True
        for s in [101,102,103]:
            o=H.oracle_checksum(b,sc,s,100000,300,30); r=H.run(b,rt,sc,s,100000,300,30); ok&=H.gate(r,o); v.append(r)
        res[(sc,rt)]=S.fmean(x["total_ns"] for x in v)
        print(f"   {rt:6s} total={res[(sc,rt)]:.3f} (struct {S.fmean(x['struct_ns'] for x in v):.3f} + upd {S.fmean(x['upd_ns'] for x in v):.3f}) gate={ok}")
print("== threshold grid on DEV seeds (mean total ns) ==")
for sc in ["static","moderate","heavy","clustered"]:
    row=[]
    for T in [8,24,48]:
        row.append(f"bm11 THRT={T}: "+f"{S.fmean(runenv('bm11',sc,s,{'BM_THRT':str(T)})['total_ns'] for s in [101,102,103]):.3f}")
    for T in [4,8,16]:
        row.append(f"bm01 THR={T}: "+f"{S.fmean(runenv('bm01',sc,s,{'BM_THR':str(T)})['total_ns'] for s in [101,102,103]):.3f}")
    print(f"   {sc:9s}", " | ".join(row))
