import harness as H, json, statistics as S, math
b = H.build("bench", flags=["-O3","-march=native","-funroll-loops","-ffp-contract=off"])
RT=["archf","bma00","flag","bm12","bm11"]; SEEDS=list(range(2001,2011)); N,F,W=100000,300,30
FROZEN={"static":"archf","moderate":"archf","heavy":"bma00","clustered":"bma00"}
for sc in FROZEN:
    o=H.run(b,"oracle",sc,7,5000,120,0)
    assert H.gate(H.run(b,"flag",sc,7,5000,120,0),o), "flag gate fail small"
R={}; bad=0
for i,s in enumerate(SEEDS):
    for sc in FROZEN:
        o=H.oracle_checksum(b,sc,s,N,F,W)
        for rt in RT[i%5:]+RT[:i%5]:
            r=H.run(b,rt,sc,s,N,F,W); bad+= (not H.gate(r,o)); R.setdefault((sc,rt),{})[s]=r
print("gate failures:",bad)
out={}
for sc in FROZEN:
    row={rt:S.fmean(R[(sc,rt)][s]["total_ns"] for s in SEEDS) for rt in RT}
    def imp(c,bse):
        x=[100*(1-R[(sc,c)][s]["total_ns"]/R[(sc,bse)][s]["total_ns"]) for s in SEEDS]; return S.fmean(x), 2.262*S.stdev(x)/math.sqrt(10)
    base=FROZEN[sc]; gap=row[base]-row["bm11"]; closure=100*(row[base]-row["flag"])/gap if gap>0 else float('nan')
    fvb=imp("flag","bm11"); fvb12=imp("flag","bm12")
    ci=lambda rt: 2.262*S.stdev([R[(sc,rt)][s]["total_ns"] for s in SEEDS])/math.sqrt(10)
    print(f"{sc:9s} " + "  ".join(f"{rt}={row[rt]:.3f}+/-{ci(rt):.3f}" for rt in RT) + f" | gap(base-bm11)={gap:.3f}ns  flag closes {closure:.0f}% of gap | flag vs bm11: {fvb[0]:+.1f}%+/-{fvb[1]:.1f}  flag vs bm12: {fvb12[0]:+.1f}%+/-{fvb12[1]:.1f}")
    out[sc]={"row":row,"ci":{rt:ci(rt) for rt in RT},"closure_pct":closure,"flag_vs_bm11":fvb,"flag_vs_bm12":fvb12,"base":base}
json.dump(out,open("devil.json","w"),indent=1)
