// Shared types, deterministic RNG, workload definition, hashing. Used by oracle, baselines, candidates.
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <chrono>
#include <algorithm>
typedef uint32_t u32; typedef uint64_t u64; typedef uint8_t u8;

static constexpr float DT = 1.0f / 60.0f;
enum { TAG_BURN = 1, TAG_SLOW = 2, TAG_STUN = 4 };

static inline u64 splitmix(u64& s) {
  u64 z = (s += 0x9E3779B97F4A7C15ull);
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
  return z ^ (z >> 31);
}
struct Rng {
  u64 s; explicit Rng(u64 x) : s(x) {}
  u64 next() { return splitmix(s); }
  u32 below(u32 n) { return (u32)(((next() >> 32) * (u64)n) >> 32); }
  float f01() { return (float)(next() >> 40) * (1.0f / 16777216.0f); }
};
struct Vec3 { float x, y, z; };
struct Health { float hp; u32 uid; };
struct Cold { float acc; };  // hot field split out of any fat payload (baseline tuning after profiling: 64B struct wasted a cache line per 4B touched)

static inline u32 fbits(float f) { u32 u; memcpy(&u, &f, 4); return u; }
static inline u64 mix64(u64 x) {
  x ^= x >> 33; x *= 0xff51afd7ed558ccdull; x ^= x >> 33; x *= 0xc4ceb9fe1a85ec53ull; x ^= x >> 33; return x;
}
static inline u64 entHash(u32 uid, const Vec3& p, const Vec3& v, float hp, u32 tags, bool cold, float acc) {
  u64 h = mix64(uid + 1ull);
  h = mix64(h ^ fbits(p.x) ^ ((u64)fbits(p.y) << 32));
  h = mix64(h ^ fbits(p.z) ^ ((u64)fbits(v.x) << 32));
  h = mix64(h ^ fbits(v.y) ^ ((u64)fbits(v.z) << 32));
  h = mix64(h ^ fbits(hp) ^ ((u64)tags << 32) ^ ((u64)cold << 40));
  h = mix64(h ^ (cold ? fbits(acc) : 0xC01Dull));
  return h;
}
struct SpawnData { u32 uid; Vec3 pos, vel; float hp; u32 tags; bool cold; };
static inline SpawnData makeSpawn(u64 seed, u32 uid) {
  Rng s(seed * 0x1234567ull + (u64)uid * 0x9E3779B1ull + 1);
  SpawnData d; d.uid = uid;
  d.pos = {s.f01() * 1000.f, s.f01() * 1000.f, s.f01() * 1000.f};
  d.vel = {s.f01() - .5f, s.f01() - .5f, s.f01() - .5f};
  d.hp = 50.f + s.f01() * 50.f;
  d.tags = 0;
  for (int i = 0; i < 3; i++) if (s.f01() < 0.05f) d.tags |= (1u << i);
  d.cold = (s.next() & 1) != 0;
  return d;
}

// ---- optional per-system profiling (compile with -DPROFILE_SYS) ----
#ifdef PROFILE_SYS
static double g_sys[8];
struct SysTimer {
  int i; std::chrono::steady_clock::time_point t;
  explicit SysTimer(int i_) : i(i_), t(std::chrono::steady_clock::now()) {}
  ~SysTimer() { g_sys[i] += std::chrono::duration<double, std::nano>(std::chrono::steady_clock::now() - t).count(); }
};
#define SYS(i) SysTimer _st##i(i);
#else
#define SYS(i)
#endif

// growable aligned column (no value-init, memcpy growth)
template <class T> struct Col {
  T* d = nullptr; u32 n = 0, cap = 0;
  Col() {}
  Col(const Col&) = delete; Col& operator=(const Col&) = delete;
  ~Col() { free(d); }
  void reserve(u32 c) {
    if (c > cap) {
      size_t bytes = ((size_t)c * sizeof(T) + 63) & ~(size_t)63;
      T* nd = (T*)aligned_alloc(64, bytes);
      if (n) memcpy(nd, d, (size_t)n * sizeof(T));
      free(d); d = nd; cap = c;
    }
  }
  inline void push(const T& v) { if (n == cap) reserve(cap ? cap * 2 : 64); d[n++] = v; }
};
