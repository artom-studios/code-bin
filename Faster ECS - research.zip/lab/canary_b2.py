import harness as H, json, os
b = H.build("bench", flags=["-O3","-march=native","-funroll-loops","-ffp-contract=off"])
N,F,W=100000,300,30; seeds=list(range(901,911)); res=json.load(open("canary_results.json"))
for sc,x in [("static","1"),("heavy","8"),("heavy","16")]:
    os.environ["SLOW_X"]=x
    A=res[sc]["A"]; D=[H.run(b,"arch_slow",sc,s,N,F,W)["total_ns"] for s in seeds]
    ma,md,rel,hw=H.welch(A,D)
    print(f"[canary b rescaled] {sc} SLOW_X={x}: arch_slow {md:.4f} vs arch {ma:.4f}: {rel:+.2f}% +/- {hw:.2f}% -> {'DETECTED' if rel-hw>0 else 'MISSED'}")
