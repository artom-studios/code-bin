import harness as H, statistics as S
N,F,W=100000,200,20
print("== per-system profile (ns per entity-frame; sys order: move,burn,slow,stun,coldread,burn&slow) ==")
bp=H.build("bench_prof",extra=["-DPROFILE_SYS"])
for sc in ["static","heavy"]:
    for rt in ["arch","sparse"]:
        r=H.run(bp,rt,sc,11,N,F,W)
        print(f"{sc:7s} {rt:6s} struct={r['struct_ns']:.3f} upd={r['upd_ns']:.3f} total={r['total_ns']:.3f} | sys_ns(all frames)={[round(x,3) for x in r['sys_ns']]}")
print("== anti-sandbagging: compiler flag sweep (median of 5 runs, total_ns/entity-frame) ==")
flagsets={"O2":["-O2","-ffp-contract=off"],
          "O3":["-O3","-ffp-contract=off"],
          "O3+native":["-O3","-march=native","-ffp-contract=off"],
          "O3+native+unroll":["-O3","-march=native","-funroll-loops","-ffp-contract=off"],
          "O3+native+LTO+nopie":["-O3","-march=native","-flto","-fno-plt","-fno-pie","-no-pie","-ffp-contract=off"]}
for name,fl in flagsets.items():
    b=H.build("bench_f",flags=fl)
    out=[]
    for rt in ["arch","sparse"]:
        for sc in ["static","heavy"]:
            xs=[H.run(b,rt,sc,11,N,F,W)["total_ns"] for _ in range(5)]
            out.append(f"{rt}/{sc}={S.median(xs):.3f}")
    print(f"{name:22s}", "  ".join(out))
