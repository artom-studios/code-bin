import harness as H
b = H.build()
ok=True
for sc in ["static","moderate","heavy","extreme"]:
    for seed in [1,2]:
        res={rt:H.run(b,rt,sc,seed,3000,60,0) for rt in ["oracle","oracle64","arch","sparse"]}
        o=res["oracle"]
        match = all(res[k]["checksum"]==o["checksum"] and res[k]["live"]==o["live"] for k in ["arch","sparse"])
        rel = abs(res["oracle64"]["energy"]-o["energy"])/abs(o["energy"])
        print(f"{sc:9s} seed={seed} checksum arch/sparse==oracle: {match}  live={o['live']}  float32-vs-float64 energy rel.diff={rel:.3e}")
        ok &= match and rel<1e-4
print("ORACLE VERIFICATION", "PASS" if ok else "FAIL")
