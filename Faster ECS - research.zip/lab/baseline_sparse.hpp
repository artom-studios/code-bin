// BASELINE B: sparse-set ECS with an owning group (EnTT lineage).
// Pos/Vel/Health are one "owning group": spawn/despawn keep the three packed arrays aligned, so the hot
// movement system is a linear SoA sweep. Tags and Cold are independent sparse-set pools -> a tag toggle is
// an O(1) 4-byte push/swap-remove with NO component data movement (this is the best case for structural churn).
#pragma once
#include "common.hpp"

struct SparseWorld {
  static constexpr u32 NONE = ~0u;
  Col<Vec3> pos, vel; Col<Health> hp; Col<u32> gEnt; std::vector<u32> gIdx;
  struct Tag { std::vector<u32> sp; Col<u32> d; };
  Tag tag[3];
  std::vector<u32> cSp; Col<u32> cEnt; Col<Cold> cData;
  std::vector<u32> freeL; u32 nslots = 0;
  explicit SparseWorld(u32 cap) { gIdx.reserve(cap); cSp.reserve(cap); for (auto& t : tag) t.sp.reserve(cap);
    pos.reserve(cap); vel.reserve(cap); hp.reserve(cap); gEnt.reserve(cap); cEnt.reserve(cap); cData.reserve(cap); for (auto& t : tag) t.d.reserve(cap); }
  inline void tagAdd(int i, u32 e) { Tag& t = tag[i]; t.sp[e] = t.d.n; t.d.push(e); }
  inline void tagRemove(int i, u32 e) { Tag& t = tag[i]; u32 ix = t.sp[e]; u32 mv = t.d.d[--t.d.n]; t.d.d[ix] = mv; t.sp[mv] = ix; t.sp[e] = NONE; }
  u32 spawn(const SpawnData& s) {
    u32 e;
    if (!freeL.empty()) { e = freeL.back(); freeL.pop_back(); }
    else { e = nslots++; gIdx.push_back(NONE); cSp.push_back(NONE); for (auto& t : tag) t.sp.push_back(NONE); }
    gIdx[e] = gEnt.n; gEnt.push(e); pos.push(s.pos); vel.push(s.vel); hp.push(Health{s.hp, s.uid});
    for (int i = 0; i < 3; i++) if (s.tags & (1u << i)) tagAdd(i, e);
    if (s.cold) { cSp[e] = cEnt.n; cEnt.push(e); cData.push(Cold{}); }
    return e;
  }
  void despawn(u32 e) {
    u32 r = gIdx[e]; u32 last = gEnt.n - 1; u32 mv = gEnt.d[last];
    pos.d[r] = pos.d[last]; vel.d[r] = vel.d[last]; hp.d[r] = hp.d[last]; gEnt.d[r] = mv; gIdx[mv] = r;
    pos.n--; vel.n--; hp.n--; gEnt.n--; gIdx[e] = NONE;
    for (int i = 0; i < 3; i++) if (tag[i].sp[e] != NONE) tagRemove(i, e);
    u32 ci = cSp[e];
    if (ci != NONE) { u32 cl = cEnt.n - 1; u32 cm = cEnt.d[cl]; cEnt.d[ci] = cm; cData.d[ci] = cData.d[cl]; cSp[cm] = ci; cEnt.n--; cData.n--; cSp[e] = NONE; }
    freeL.push_back(e);
  }
  void toggle(u32 e, u32 tg) { int i = __builtin_ctz(tg); if (tag[i].sp[e] != NONE) tagRemove(i, e); else tagAdd(i, e); }
  void update(float dt) {
    { SYS(0) u32 n = gEnt.n; Vec3* __restrict p = pos.d; const Vec3* __restrict v = vel.d;
      for (u32 i = 0; i < n; i++) { p[i].x += v[i].x * dt; p[i].y += v[i].y * dt; p[i].z += v[i].z * dt; } }
    { SYS(1) Tag& t = tag[0]; for (u32 i = 0; i < t.d.n; i++) hp.d[gIdx[t.d.d[i]]].hp -= 0.01f; }
    { SYS(2) Tag& t = tag[1]; for (u32 i = 0; i < t.d.n; i++) { Vec3& v = vel.d[gIdx[t.d.d[i]]]; v.x = v.x * 0.99f + 0.005f; v.y = v.y * 0.99f + 0.005f; v.z = v.z * 0.99f + 0.005f; } }
    { SYS(3) Tag& t = tag[2]; for (u32 i = 0; i < t.d.n; i++) pos.d[gIdx[t.d.d[i]]].y -= 0.1f * dt; }
    { SYS(4) for (u32 i = 0; i < cEnt.n; i++) cData.d[i].acc += pos.d[gIdx[cEnt.d[i]]].x * 0.001f; }
    { SYS(5) Tag& a = tag[0]; Tag& b = tag[1]; Tag& s = a.d.n <= b.d.n ? a : b; Tag& o = (&s == &a) ? b : a;
      for (u32 i = 0; i < s.d.n; i++) { u32 e = s.d.d[i]; if (o.sp[e] != NONE) hp.d[gIdx[e]].hp -= 0.02f; } }
  }
  template <class F> void visit(F&& f) {
    for (u32 r = 0; r < gEnt.n; r++) { u32 e = gEnt.d[r]; u32 tg = 0; for (int i = 0; i < 3; i++) if (tag[i].sp[e] != NONE) tg |= 1u << i;
      u32 ci = cSp[e]; f(hp.d[r].uid, pos.d[r], vel.d[r], hp.d[r].hp, tg, ci != NONE, ci != NONE ? cData.d[ci].acc : 0.f); }
  }
};
