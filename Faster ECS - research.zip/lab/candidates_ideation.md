# Phase 2 output: 10 candidate mechanisms (mapped onto MEASURED bottleneck)
Measured bottleneck (tuned archetype ECS, N=100k): heavy churn: 4.1 of 5.7 ns/entity-frame = structural moves (~12 dependent cache misses/toggle);
static: 1.12 ns/entity-frame, memory-bandwidth bound on the move system; multi-pass over pos/vel/hp = repeated streaming.
Dice: domains = bee-hive thermoregulation, railway marshalling yards, ant-colony stigmergy; operators = dynamic deadband, counterweight.
Wikipedia stimuli: "Palatine raphe" (midline seam separating two halves), "Sasson Guetta" (office held for a fixed term, 2023-2026 -> membership with expiry).
 1. STIGMERGIC BLOCK TABLE (ant stigmergy): marks (tags) live IN the entity's own mask byte; no central registry/archetype. Dense id-ordered SoA, 64-entity blocks, per-block summary bitmaps; toggle = 1 byte flip (L2-resident), query = AND of block words + bit-scan. 
 2. MARSHALLING-YARD BATCH RELOCATION (railway): radix-classify queued structural changes by (src,dst) archetype "track", move rows in bulk in row order.
 3. DEADBAND LAZY RELOCATION (bee deadband): physically relocate only after a tag state persists >= k frames; flapping entities stay put. Needs overlay lookup -> query cost.
 4. SEAM-PARTITIONED DENSE ARRAY (palatine raphe): entities with a tag kept in prefix before a movable seam; toggle = swap across seam. (== EnTT owning group; likely prior art.)
 5. TERM-LIMITED TAG LEASES (Guetta term): status effects carry expiry frame; removal needs no structural op. (Changes semantics; not exactly comparable here.)
 6. PHEROMONE-DECAY SUMMARIES (ant + counterweight): eager set / lazy clear of block-summary bits (evaporate when scan finds block empty).
 7. FUSED PREDICATED KERNEL: all systems fused into ONE pass per 64-lane block, loading pos/vel/hp/acc once, tags applied as lane masks (blend) -> removes 4-5 extra streaming passes.
 8. COUNTERWEIGHT RE-CLUSTERING (deadband trigger): background stable sort of entities by tag mask when fragmentation exceeds a deadband -> runs, SIMD-friendly; counterweights toggles.
 9. SUMMARY-GUIDED SPARSE FUSION: candidate 1 + 7: fused kernel runs full-SIMD blocks when block summary says "dense", bit-scan path when sparse (per-block adaptive).
10. HOT-FIELD LANE DEMOTION: fp16/quantized lanes for far entities (rejected: breaks bit-exactness gate).
Shortlist for prior-art triage: (1) Stigmergic block table, (2) marshalling-yard batch relocation, (7/9) fused predicated kernel.
