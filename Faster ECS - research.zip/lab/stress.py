import harness as H, json, statistics as S, time
FL=["-O3","-funroll-loops","-ffp-contract=off"]
BIN={"avx512":H.build("bench",flags=[*FL,"-march=native"]),"avx2":H.build("bench_avx2",flags=[*FL,"-march=haswell"]),"sse42":H.build("bench_sse42",flags=[*FL,"-march=x86-64-v2"])}
RT=["arch","archf","bma00","flag","bm12","bm11"]; SEEDS=[3001,3002,3003]
SET=[("avx512",10000,1500,150,s) for s in ["static","heavy","clustered"]]+[("avx512",1000000,60,10,s) for s in ["static","heavy","clustered"]]+[("avx512",100000,300,30,"extreme")]
SET+=[(isa,100000,300,30,s) for isa in ["avx2","sse42"] for s in ["static","heavy","clustered"]]
out=[]
for (isa,N,F,W,sc) in SET:
    row={}
    for si,s in enumerate(SEEDS):
        o=H.oracle_checksum(BIN["avx512"],sc,s,N,F,W)
        for rt in RT[si:]+RT[:si]:
            r=H.run(BIN[isa],rt,sc,s,N,F,W); ok=H.gate(r,o)
            row.setdefault(rt,[]).append((r["total_ns"],r["struct_ns"],r["upd_ns"],ok))
    rec={"isa":isa,"N":N,"sc":sc,"rt":{rt:{"total":S.fmean(x[0] for x in v),"struct":S.fmean(x[1] for x in v),"upd":S.fmean(x[2] for x in v),"sd":S.stdev(x[0] for x in v),"gate":all(x[3] for x in v)} for rt,v in row.items()}}
    out.append(rec); json.dump(out,open("stress.json","w"))
    print(f"{isa:6s} N={N:8d} {sc:9s} "+" ".join(f"{rt}={rec['rt'][rt]['total']:.2f}" for rt in RT)+" gates="+str(all(rec['rt'][rt]['gate'] for rt in RT)),flush=True)
print("ALL DONE",flush=True)
