// CANDIDATE FAMILY: bitmap-presence table (entities never move; tags are bits in per-block 64-bit words)
// FUSE=1: one pass over each 64-lane block applies ALL systems (loads pos/vel/hp/acc once).
// MODE   : 0 = scan set bits only (StaticEcs-like), 1 = ADAPTIVE per block (scan if sparse, branchless lane-blend if dense), 2 = blend only.
// bm00 = prior-art competitor (unfused scan-only); bm11 = candidate SFBT; the rest are ablations.
#pragma once
#include "common.hpp"
static int g_thrA = 8;    // unfused: popcount threshold for scan->blend per system/block   (dev-tunable via env BM_THR)
static int g_thrATA = 24;  // fused: sum of popcounts(burn,slow,stun) threshold for scan->blend (dev-tunable via env BM_THRT)

template <int FUSE, int MODE> struct BitmapAosWorld {
  Vec3 *P, *V; Health* H; float* A; u64* W[5];  // W: 0 burn,1 slow,2 stun,3 acc,4 alive
  u32 cap, nslots = 0, nblk; std::vector<u32> freeL;
  static void* zalloc(size_t bytes) { bytes = (bytes + 63) & ~(size_t)63; void* p = aligned_alloc(64, bytes); memset(p, 0, bytes); return p; }
  explicit BitmapAosWorld(u32 capHint) {
    cap = ((capHint + 63) / 64) * 64; nblk = cap / 64;
    P = (Vec3*)zalloc((size_t)cap * sizeof(Vec3)); V = (Vec3*)zalloc((size_t)cap * sizeof(Vec3)); H = (Health*)zalloc((size_t)cap * sizeof(Health)); A = (float*)zalloc((size_t)cap * 4);
    for (int k = 0; k < 5; k++) W[k] = (u64*)zalloc((size_t)nblk * 8);
    if (const char* s = getenv("BM_THR")) g_thrA = atoi(s);
    if (const char* s = getenv("BM_THRT")) g_thrATA = atoi(s);
  }
  ~BitmapAosWorld() { free(P); free(V); free(H); free(A); for (int k = 0; k < 5; k++) free(W[k]); }
  u32 spawn(const SpawnData& s) {
    u32 e; if (!freeL.empty()) { e = freeL.back(); freeL.pop_back(); } else e = nslots++;
    P[e] = s.pos; V[e] = s.vel; H[e] = Health{s.hp, s.uid}; A[e] = 0.f;
    u64 bit = 1ull << (e & 63); u32 b = e >> 6;
    for (int i = 0; i < 3; i++) if (s.tags & (1u << i)) W[i][b] |= bit;
    if (s.cold) W[3][b] |= bit;
    W[4][b] |= bit; return e;
  }
  void despawn(u32 e) { u64 nb = ~(1ull << (e & 63)); u32 b = e >> 6; for (int k = 0; k < 5; k++) W[k][b] &= nb; freeL.push_back(e); }
  void toggle(u32 e, u32 tg) { W[__builtin_ctz(tg)][e >> 6] ^= 1ull << (e & 63); }

  static inline void laneFull(Vec3& p, Vec3& v, Health& h, float& a, u32 bu, u32 sl, u32 st, u32 ac, float dt) {
    Vec3 pp = p, vv = v; float hp = h.hp;
    pp.x += vv.x * dt; pp.y += vv.y * dt; pp.z += vv.z * dt;
    hp -= bu ? 0.01f : 0.f;
    vv.x = sl ? vv.x * 0.99f + 0.005f : vv.x; vv.y = sl ? vv.y * 0.99f + 0.005f : vv.y; vv.z = sl ? vv.z * 0.99f + 0.005f : vv.z;
    pp.y -= st ? 0.1f * dt : 0.f;
    a += ac ? pp.x * 0.001f : 0.f;
    hp -= (bu & sl) ? 0.02f : 0.f;
    p = pp; v = vv; h.hp = hp;
  }
  inline void fusedBlock(u32 b, float dt) {
    u64 bu = W[0][b], sl = W[1][b], st = W[2][b], ac = W[3][b]; u32 base = b << 6;
    bool dense;
    if (MODE == 2) dense = true; else if (MODE == 0) dense = false;
    else dense = (__builtin_popcountll(bu) + __builtin_popcountll(sl) + __builtin_popcountll(st)) > g_thrATA;
    Vec3* __restrict p = P + base; Vec3* __restrict v = V + base; Health* __restrict h = H + base; float* __restrict a = A + base;
    if (dense) {
      for (int i = 0; i < 64; i++) laneFull(p[i], v[i], h[i], a[i], (bu >> i) & 1, (sl >> i) & 1, (st >> i) & 1, (ac >> i) & 1, dt);
    } else {
      for (int i = 0; i < 64; i++) {
        p[i].x += v[i].x * dt; p[i].y += v[i].y * dt; p[i].z += v[i].z * dt;
        a[i] += ((ac >> i) & 1) ? p[i].x * 0.001f : 0.f;
      }
      for (u64 w = bu; w; w &= w - 1) h[__builtin_ctzll(w)].hp -= 0.01f;
      for (u64 w = sl; w; w &= w - 1) { Vec3& x = v[__builtin_ctzll(w)]; x.x = x.x * 0.99f + 0.005f; x.y = x.y * 0.99f + 0.005f; x.z = x.z * 0.99f + 0.005f; }
      for (u64 w = st; w; w &= w - 1) p[__builtin_ctzll(w)].y -= 0.1f * dt;
      for (u64 w = bu & sl; w; w &= w - 1) h[__builtin_ctzll(w)].hp -= 0.02f;
    }
  }
  template <class Scan, class Dense> inline void runSys(u64 w, u32 base, Scan&& scan, Dense&& dense) {
    if (!w) return;
    if (MODE == 0 || (MODE == 1 && __builtin_popcountll(w) <= g_thrA)) { while (w) { scan(base + (u32)__builtin_ctzll(w)); w &= w - 1; } }
    else dense(base, w);
  }
  void unfused(u32 nb, float dt) {
    for (u32 b = 0; b < nb; b++) { Vec3* __restrict p = P + (b << 6); const Vec3* __restrict v = V + (b << 6);
      for (int i = 0; i < 64; i++) { p[i].x += v[i].x * dt; p[i].y += v[i].y * dt; p[i].z += v[i].z * dt; } }
    for (u32 b = 0; b < nb; b++) runSys(W[0][b], b << 6, [&](u32 e) { H[e].hp -= 0.01f; },
        [&](u32 base, u64 w) { for (int i = 0; i < 64; i++) H[base + i].hp -= ((w >> i) & 1) ? 0.01f : 0.f; });
    for (u32 b = 0; b < nb; b++) runSys(W[1][b], b << 6, [&](u32 e) { Vec3& x = V[e]; x.x = x.x * 0.99f + 0.005f; x.y = x.y * 0.99f + 0.005f; x.z = x.z * 0.99f + 0.005f; },
        [&](u32 base, u64 w) { for (int i = 0; i < 64; i++) { Vec3& x = V[base + i]; bool s = (w >> i) & 1;
          x.x = s ? x.x * 0.99f + 0.005f : x.x; x.y = s ? x.y * 0.99f + 0.005f : x.y; x.z = s ? x.z * 0.99f + 0.005f : x.z; } });
    for (u32 b = 0; b < nb; b++) runSys(W[2][b], b << 6, [&](u32 e) { P[e].y -= 0.1f * dt; },
        [&](u32 base, u64 w) { for (int i = 0; i < 64; i++) P[base + i].y -= ((w >> i) & 1) ? 0.1f * dt : 0.f; });
    for (u32 b = 0; b < nb; b++) runSys(W[3][b], b << 6, [&](u32 e) { A[e] += P[e].x * 0.001f; },
        [&](u32 base, u64 w) { for (int i = 0; i < 64; i++) A[base + i] += ((w >> i) & 1) ? P[base + i].x * 0.001f : 0.f; });
    for (u32 b = 0; b < nb; b++) runSys(W[0][b] & W[1][b], b << 6, [&](u32 e) { H[e].hp -= 0.02f; },
        [&](u32 base, u64 w) { for (int i = 0; i < 64; i++) H[base + i].hp -= ((w >> i) & 1) ? 0.02f : 0.f; });
  }
  void update(float dt) {
    u32 nb = (nslots + 63) >> 6;
    if (FUSE) { for (u32 b = 0; b < nb; b++) fusedBlock(b, dt); } else unfused(nb, dt);
  }
  template <class F> void visit(F&& f) {
    for (u32 e = 0; e < nslots; e++) { u32 b = e >> 6, i = e & 63; if (!((W[4][b] >> i) & 1)) continue;
      u32 tg = (u32)((W[0][b] >> i) & 1) | ((u32)((W[1][b] >> i) & 1) << 1) | ((u32)((W[2][b] >> i) & 1) << 2); bool c = (W[3][b] >> i) & 1;
      f(H[e].uid, P[e], V[e], H[e].hp, tg, c, c ? A[e] : 0.f); }
  }
};
