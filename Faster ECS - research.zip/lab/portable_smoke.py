import harness as H
FL=["-O3","-funroll-loops","-ffp-contract=off"]
for isa,m in [("avx512","native"),("avx2","haswell"),("sse42","x86-64-v2")]:
    b=H.build("bench_"+isa,flags=[*FL,"-march="+m])
    for sc in ["static","heavy"]:
        o=H.run(b,"oracle",sc,101,100000,300,30)
        print("DEV",isa,sc," ".join(f"{rt}={H.run(b,rt,sc,101,100000,300,30)['total_ns']:.2f}" for rt in ["archf","flag","flagp"]), "gate flagp:",H.gate(H.run(b,"flagp",sc,101,100000,300,30),o))
