import harness as H, statistics as S, json
b = H.build("bench", flags=["-O3","-march=native","-funroll-loops","-ffp-contract=off"])
RT=["bm00","bm01","bm02","bm10","bm11","bm12"]
bad=0
for sc in ["static","moderate","heavy","clustered","extreme"]:
    for seed in [101,102]:
        o=H.run(b,"oracle",sc,seed,5000,120,0)
        for rt in RT:
            if not H.gate(H.run(b,rt,sc,seed,5000,120,0),o): bad+=1; print("GATE FAIL",rt,sc,seed)
print("A1 small-scale gate failures:",bad)
dev={}
base=json.load(open("dev1.json"))
for sc in ["static","moderate","heavy","clustered"]:
    R={rt:[] for rt in RT}
    for s in [101,102,103]:
        o=H.oracle_checksum(b,sc,s,100000,300,30)
        for rt in RT:
            r=H.run(b,rt,sc,s,100000,300,30); r["ok"]=H.gate(r,o); R[rt].append(r)
    print(f"-- {sc}  (dev1 baselines: arch={base[sc]['arch']['total']:.3f} archf={base[sc]['archf']['total']:.3f} sparse={base[sc]['sparse']['total']:.3f})")
    for rt in RT:
        v=R[rt]; print(f"   {rt:5s} total={S.fmean(x['total_ns'] for x in v):.3f} (struct {S.fmean(x['struct_ns'] for x in v):.3f} + upd {S.fmean(x['upd_ns'] for x in v):.3f}) gate={all(x['ok'] for x in v)}")
