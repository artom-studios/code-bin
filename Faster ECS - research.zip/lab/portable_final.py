import harness as H, json, statistics as S, math
FL=["-O3","-funroll-loops","-ffp-contract=off"]
BIN={"avx512":H.build("bench",flags=[*FL,"-march=native"]),"avx2":H.build("bench_avx2",flags=[*FL,"-march=haswell"]),"sse42":H.build("bench_sse42",flags=[*FL,"-march=x86-64-v2"])}
RT=["arch","archf","bma00","flag","flagp"]; SEEDS=[4001,4002,4003,4004,4005]; N,F,W=100000,300,30
out=[]
for isa in BIN:
    for sc in ["static","moderate","heavy","clustered"]:
        row={}
        for si,s in enumerate(SEEDS):
            o=H.oracle_checksum(BIN["avx512"],sc,s,N,F,W)
            for rt in RT[si%5:]+RT[:si%5]:
                r=H.run(BIN[isa],rt,sc,s,N,F,W); row.setdefault(rt,[]).append((r["total_ns"],H.gate(r,o)))
        rec={"isa":isa,"sc":sc,"rt":{rt:{"mean":S.fmean(x[0] for x in v),"ci":2.776*S.stdev(x[0] for x in v)/math.sqrt(len(v)),"gate":all(x[1] for x in v)} for rt,v in row.items()}}
        out.append(rec); print(f"{isa:6s} {sc:9s} "+"  ".join(f"{rt}={rec['rt'][rt]['mean']:.2f}+/-{rec['rt'][rt]['ci']:.2f}" for rt in RT)+"  gates="+str(all(rec['rt'][rt]['gate'] for rt in RT)),flush=True)
json.dump(out,open("portable.json","w"))
