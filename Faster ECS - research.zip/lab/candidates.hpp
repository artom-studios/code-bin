// CANDIDATE FAMILY (Amendment A1: field-level SoA + 32-lane vector-friendly kernels; shared by ALL bm variants).
// Bitmap-presence table: entities never move; tags are bits in per-64-block words. Handle == slot.
// FUSE=1: one pass per 64-lane block applies ALL systems. MODE: 0 = scan set bits only (StaticEcs-like), 1 = ADAPTIVE per block, 2 = branchless blend only.
// bm00 = prior-art competitor (unfused scan-only); bm11 = candidate SFBT; others are ablations.
#pragma once
#include "common.hpp"
static int g_thr = 8;    // unfused: popcount threshold scan->blend (system,block)    env BM_THR
static int g_thrT = 48;  // fused: popcount(burn)+popcount(slow)+popcount(stun) threshold  env BM_THRT

template <int FUSE, int MODE> struct BitmapWorld {
  float *PX, *PY, *PZ, *VX, *VY, *VZ, *HP, *AC; u32* UID; u64* W[5];  // W: 0 burn,1 slow,2 stun,3 acc,4 alive
  u32 cap, nslots = 0, nblk; std::vector<u32> freeL;
  static void* zalloc(size_t bytes) { bytes = (bytes + 63) & ~(size_t)63; void* p = aligned_alloc(64, bytes); memset(p, 0, bytes); return p; }
  std::vector<void*> raws;  // Amendment A2: stagger SoA array bases (avoid 4K-aliasing / L1 set conflicts across 9 streams)
  float* fa(size_t n) { void* p = zalloc(n * 4 + 13 * 1088); raws.push_back(p); return (float*)((char*)p + ((raws.size() - 1) % 13) * 1088); }
  explicit BitmapWorld(u32 capHint) {
    cap = ((capHint + 63) / 64) * 64; nblk = cap / 64;
    PX = fa(cap); PY = fa(cap); PZ = fa(cap); VX = fa(cap); VY = fa(cap); VZ = fa(cap); HP = fa(cap); AC = fa(cap); UID = (u32*)fa(cap);
    for (int k = 0; k < 5; k++) W[k] = (u64*)zalloc((size_t)nblk * 8);
    if (const char* s = getenv("BM_THR")) g_thr = atoi(s);
    if (const char* s = getenv("BM_THRT")) g_thrT = atoi(s);
  }
  ~BitmapWorld() { for (void* p : raws) free(p); for (int k = 0; k < 5; k++) free(W[k]); }
  u32 spawn(const SpawnData& s) {
    u32 e; if (!freeL.empty()) { e = freeL.back(); freeL.pop_back(); } else e = nslots++;
    PX[e] = s.pos.x; PY[e] = s.pos.y; PZ[e] = s.pos.z; VX[e] = s.vel.x; VY[e] = s.vel.y; VZ[e] = s.vel.z; HP[e] = s.hp; UID[e] = s.uid; AC[e] = 0.f;
    u64 bit = 1ull << (e & 63); u32 b = e >> 6;
    for (int i = 0; i < 3; i++) if (s.tags & (1u << i)) W[i][b] |= bit;
    if (s.cold) W[3][b] |= bit;
    W[4][b] |= bit; return e;
  }
  void despawn(u32 e) { u64 nb = ~(1ull << (e & 63)); u32 b = e >> 6; for (int k = 0; k < 5; k++) W[k][b] &= nb; freeL.push_back(e); }
  void toggle(u32 e, u32 tg) { W[__builtin_ctz(tg)][e >> 6] ^= 1ull << (e & 63); }

  // ---- fused dense kernel for 32 lanes (branchless, auto-vectorizable) ----
  static inline void dense32(float* __restrict px, float* __restrict py, float* __restrict pz, float* __restrict vx, float* __restrict vy, float* __restrict vz,
                             float* __restrict hp, float* __restrict ac, u32 bu, u32 sl, u32 st, u32 am, float dt) {
    for (int i = 0; i < 32; i++) {
      bool b = (bu >> i) & 1, s = (sl >> i) & 1, t = (st >> i) & 1, c = (am >> i) & 1;
      float x = px[i] + vx[i] * dt, y = py[i] + vy[i] * dt, z = pz[i] + vz[i] * dt;
      float h = hp[i]; h -= b ? 0.01f : 0.f;
      float nx = s ? vx[i] * 0.99f + 0.005f : vx[i], ny = s ? vy[i] * 0.99f + 0.005f : vy[i], nz = s ? vz[i] * 0.99f + 0.005f : vz[i];
      y -= t ? 0.1f * dt : 0.f;
      ac[i] += c ? x * 0.001f : 0.f;
      h -= (b & s) ? 0.02f : 0.f;
      px[i] = x; py[i] = y; pz[i] = z; vx[i] = nx; vy[i] = ny; vz[i] = nz; hp[i] = h;
    }
  }
  static inline void move32(float* __restrict px, float* __restrict py, float* __restrict pz, const float* __restrict vx, const float* __restrict vy, const float* __restrict vz,
                            float* __restrict ac, u32 am, float dt) {
    for (int i = 0; i < 32; i++) {
      float x = px[i] + vx[i] * dt; px[i] = x; py[i] += vy[i] * dt; pz[i] += vz[i] * dt;
      ac[i] += ((am >> i) & 1) ? x * 0.001f : 0.f;
    }
  }
  inline void fusedBlock(u32 b, float dt) {
    u64 bu = W[0][b], sl = W[1][b], st = W[2][b], ac = W[3][b]; u32 base = b << 6;
    bool dense;
    if (MODE == 2) dense = true; else if (MODE == 0) dense = false;
    else dense = (__builtin_popcountll(bu) + __builtin_popcountll(sl) + __builtin_popcountll(st)) > g_thrT;
    if (dense) {
      for (int h = 0; h < 2; h++) { u32 o = base + 32 * h, sh = 32 * h;
        dense32(PX + o, PY + o, PZ + o, VX + o, VY + o, VZ + o, HP + o, AC + o, (u32)(bu >> sh), (u32)(sl >> sh), (u32)(st >> sh), (u32)(ac >> sh), dt); }
    } else {
      for (int h = 0; h < 2; h++) { u32 o = base + 32 * h; move32(PX + o, PY + o, PZ + o, VX + o, VY + o, VZ + o, AC + o, (u32)(ac >> (32 * h)), dt); }
      for (u64 w = bu; w; w &= w - 1) HP[base + __builtin_ctzll(w)] -= 0.01f;
      for (u64 w = sl; w; w &= w - 1) { u32 e = base + (u32)__builtin_ctzll(w); VX[e] = VX[e] * 0.99f + 0.005f; VY[e] = VY[e] * 0.99f + 0.005f; VZ[e] = VZ[e] * 0.99f + 0.005f; }
      for (u64 w = st; w; w &= w - 1) PY[base + __builtin_ctzll(w)] -= 0.1f * dt;
      for (u64 w = bu & sl; w; w &= w - 1) HP[base + __builtin_ctzll(w)] -= 0.02f;
    }
  }
  // ---- unfused systems ----
  template <class Scan, class Dense32> inline void runSys(u64 w, u32 base, Scan&& scan, Dense32&& dense32f) {
    if (!w) return;
    if (MODE == 0 || (MODE == 1 && __builtin_popcountll(w) <= g_thr)) { while (w) { scan(base + (u32)__builtin_ctzll(w)); w &= w - 1; } }
    else { dense32f(base, (u32)w); dense32f(base + 32, (u32)(w >> 32)); }
  }
  void unfused(u32 nb, float dt) {
    for (u32 b = 0; b < nb; b++) { u32 o = b << 6; float* __restrict px = PX + o; float* __restrict py = PY + o; float* __restrict pz = PZ + o;
      const float* __restrict vx = VX + o; const float* __restrict vy = VY + o; const float* __restrict vz = VZ + o;
      for (int i = 0; i < 64; i++) { px[i] += vx[i] * dt; py[i] += vy[i] * dt; pz[i] += vz[i] * dt; } }
    for (u32 b = 0; b < nb; b++) runSys(W[0][b], b << 6, [&](u32 e) { HP[e] -= 0.01f; },
        [&](u32 o, u32 w) { float* __restrict hp = HP + o; for (int i = 0; i < 32; i++) hp[i] -= ((w >> i) & 1) ? 0.01f : 0.f; });
    for (u32 b = 0; b < nb; b++) runSys(W[1][b], b << 6, [&](u32 e) { VX[e] = VX[e] * 0.99f + 0.005f; VY[e] = VY[e] * 0.99f + 0.005f; VZ[e] = VZ[e] * 0.99f + 0.005f; },
        [&](u32 o, u32 w) { float* __restrict vx = VX + o; float* __restrict vy = VY + o; float* __restrict vz = VZ + o;
          for (int i = 0; i < 32; i++) { bool s = (w >> i) & 1; vx[i] = s ? vx[i] * 0.99f + 0.005f : vx[i]; vy[i] = s ? vy[i] * 0.99f + 0.005f : vy[i]; vz[i] = s ? vz[i] * 0.99f + 0.005f : vz[i]; } });
    for (u32 b = 0; b < nb; b++) runSys(W[2][b], b << 6, [&](u32 e) { PY[e] -= 0.1f * dt; },
        [&](u32 o, u32 w) { float* __restrict py = PY + o; for (int i = 0; i < 32; i++) py[i] -= ((w >> i) & 1) ? 0.1f * dt : 0.f; });
    for (u32 b = 0; b < nb; b++) runSys(W[3][b], b << 6, [&](u32 e) { AC[e] += PX[e] * 0.001f; },
        [&](u32 o, u32 w) { float* __restrict ac = AC + o; const float* __restrict px = PX + o; for (int i = 0; i < 32; i++) ac[i] += ((w >> i) & 1) ? px[i] * 0.001f : 0.f; });
    for (u32 b = 0; b < nb; b++) runSys(W[0][b] & W[1][b], b << 6, [&](u32 e) { HP[e] -= 0.02f; },
        [&](u32 o, u32 w) { float* __restrict hp = HP + o; for (int i = 0; i < 32; i++) hp[i] -= ((w >> i) & 1) ? 0.02f : 0.f; });
  }
  void update(float dt) {
    u32 nb = (nslots + 63) >> 6;
    if (FUSE) { for (u32 b = 0; b < nb; b++) fusedBlock(b, dt); } else unfused(nb, dt);
  }
  template <class F> void visit(F&& f) {
    for (u32 e = 0; e < nslots; e++) { u32 b = e >> 6, i = e & 63; if (!((W[4][b] >> i) & 1)) continue;
      u32 tg = (u32)((W[0][b] >> i) & 1) | ((u32)((W[1][b] >> i) & 1) << 1) | ((u32)((W[2][b] >> i) & 1) << 2); bool c = (W[3][b] >> i) & 1;
      f(UID[e], Vec3{PX[e], PY[e], PZ[e]}, Vec3{VX[e], VY[e], VZ[e]}, HP[e], tg, c, c ? AC[e] : 0.f); }
  }
};
