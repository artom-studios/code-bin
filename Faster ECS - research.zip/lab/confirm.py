import harness as H, json, sys, time
b = H.build("bench", flags=["-O3","-march=native","-funroll-loops","-ffp-contract=off"])
RT=["arch","archf","sparse","bma00","bm00","bm01","bm10","bm11","bm12"]
SEEDS=list(range(2001,2011)); N,F,W=100000,300,30
out=[]
for si,s in enumerate(SEEDS):
    for sc in ["static","moderate","heavy","clustered"]:
        o=H.oracle_checksum(b,sc,s,N,F,W)
        order=RT[si%len(RT):]+RT[:si%len(RT)]   # rotate run order per seed
        for rt in order:
            r=H.run(b,rt,sc,s,N,F,W); r["gate"]=H.gate(r,o); out.append(r)
    json.dump(out,open("confirm.json","w")); print("seed",s,"done",time.strftime("%X"),flush=True)
print("ALL DONE",flush=True)
