"""Confirmatory analysis exactly as pre-registered. Paired per-seed improvement = 1 - cand/baseline; t(9)=2.262."""
import json, math, statistics as S
D = json.load(open("confirm.json"))
T9 = 2.262
SC = ["static", "moderate", "heavy", "clustered"]
FROZEN = {"static": "archf", "moderate": "archf", "heavy": "bma00", "clustered": "bma00"}
by = {}
for r in D: by.setdefault((r["sc"], r["rt"]), {})[r["seed"]] = r
seeds = sorted({r["seed"] for r in D})
def vec(sc, rt, key="total_ns"): return [by[(sc, rt)][s][key] for s in seeds]
def ci(xs):
    m = S.fmean(xs); sd = S.stdev(xs); return m, sd, T9 * sd / math.sqrt(len(xs))
def paired_impr(sc, cand, base):
    a, b = vec(sc, cand), vec(sc, base); return ci([100 * (1 - x / y) for x, y in zip(a, b)])
out = {"gate_failures": sum(1 for r in D if not r["gate"]), "runs": len(D), "n_seeds": len(seeds), "table": {}, "paired": {}, "verdict": {}}
RT = sorted({r["rt"] for r in D}, key=lambda x: ["arch", "archf", "sparse", "bma00", "bm00", "bm01", "bm10", "bm11", "bm12"].index(x))
print(f"runs={len(D)} seeds={len(seeds)} GATE FAILURES={out['gate_failures']}")
for sc in SC:
    print(f"\n=== {sc} (N=100k, 10 confirmatory seeds): total ns / entity-frame, mean +/- 95% CI (SD) ===")
    out["table"][sc] = {}
    for rt in RT:
        m, sd, h = ci(vec(sc, rt)); ms, _, hs = ci(vec(sc, rt, "struct_ns")); mu, _, hu = ci(vec(sc, rt, "upd_ns"))
        out["table"][sc][rt] = {"mean": m, "sd": sd, "ci": h, "struct": ms, "upd": mu}
        tag = "  <== frozen baseline" if rt == FROZEN[sc] else ""
        print(f"  {rt:6s} {m:7.3f} +/- {h:5.3f} (SD {sd:5.3f})   struct {ms:6.3f}  upd {mu:6.3f}{tag}")
    best_base = min(["arch", "archf", "sparse", "bma00", "bm00"], key=lambda r: out["table"][sc][r]["mean"])
    out["paired"][sc] = {}
    for cand in ["bm11", "bm10", "bm12"]:
        m, sd, h = paired_impr(sc, cand, FROZEN[sc]); m2, sd2, h2 = paired_impr(sc, cand, best_base)
        out["paired"][sc][cand] = {"vs_frozen": [m, h], "vs_best_on_confirm": [m2, h2], "best_on_confirm": best_base}
        print(f"  improvement {cand} vs frozen baseline {FROZEN[sc]}: {m:+.1f}% +/- {h:.1f}% | vs best-on-confirm ({best_base}): {m2:+.1f}% +/- {h2:.1f}%")
# H5: adaptive vs best non-adaptive sibling, per seed, clustered and others
print("\n=== H5: bm11 (adaptive) vs best non-adaptive sibling min(bm10, bm12), paired per seed ===")
out["h5"] = {}
for sc in SC:
    imp = [100 * (1 - by[(sc, "bm11")][s]["total_ns"] / min(by[(sc, "bm10")][s]["total_ns"], by[(sc, "bm12")][s]["total_ns"])) for s in seeds]
    m, sd, h = ci(imp); out["h5"][sc] = [m, h]; print(f"  {sc:9s}: {m:+.1f}% +/- {h:.1f}%")
# verdict per pre-registered criteria
h1m, h1h = out["paired"]["heavy"]["bm11"]["vs_frozen"]
K1 = out["gate_failures"] > 0
K2 = (h1m - h1h) < 10 or h1m < 15
h5m = out["h5"]["clustered"][0]
K3 = h5m < 5
st = -out["paired"]["static"]["bm11"]["vs_frozen"][0]  # regression % (positive = worse)
K5 = st > 5
out["verdict"] = {"K1_gate_failure": K1, "K2_H1_not_met": K2, "H1_heavy_improvement": [h1m, h1h], "K3_adaptive_delta_rejected": K3, "H5_clustered": h5m,
                  "K5_static_regression": K5, "static_regression_pct": st,
                  "H2_clustered": out["paired"]["clustered"]["bm11"]["vs_frozen"], "H3_moderate": out["paired"]["moderate"]["bm11"]["vs_frozen"]}
print("\nVERDICT INPUTS:", json.dumps(out["verdict"], indent=1))
json.dump(out, open("analysis.json", "w"), indent=1)
