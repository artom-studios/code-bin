import type { ReactNode } from "react";

export function Section({ id, kicker, title, children }: { id?: string; kicker?: string; title: string; children: ReactNode }) {
  return (
    <section id={id} className="mx-auto w-full max-w-6xl px-5 py-10 sm:px-8">
      {kicker && <p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-400">{kicker}</p>}
      <h2 className="mt-2 text-2xl font-semibold tracking-tight text-white sm:text-3xl">{title}</h2>
      <div className="mt-6 space-y-6 text-slate-300">{children}</div>
    </section>
  );
}

export type Tone = "green" | "red" | "amber" | "violet" | "slate" | "sky";
const toneCls: Record<Tone, string> = {
  green: "bg-emerald-500/15 text-emerald-300 ring-emerald-500/30",
  red: "bg-rose-500/15 text-rose-300 ring-rose-500/30",
  amber: "bg-amber-500/15 text-amber-300 ring-amber-500/30",
  violet: "bg-violet-500/15 text-violet-300 ring-violet-500/30",
  slate: "bg-slate-500/15 text-slate-300 ring-slate-500/30",
  sky: "bg-sky-500/15 text-sky-300 ring-sky-500/30",
};
export function Pill({ tone = "slate", children }: { tone?: Tone; children: ReactNode }) {
  return <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${toneCls[tone]}`}>{children}</span>;
}

const barCls: Record<Tone, string> = {
  green: "bg-emerald-500",
  red: "bg-rose-500",
  amber: "bg-amber-500",
  violet: "bg-violet-500",
  slate: "bg-slate-500",
  sky: "bg-sky-500",
};
export interface BarRow { label: string; value: number; ci?: number; tone?: Tone; note?: string }

export function Bars({ rows, unit = "ns" }: { rows: BarRow[]; unit?: string }) {
  const max = Math.max(...rows.map((r) => r.value + (r.ci ?? 0)));
  return (
    <div className="space-y-2">
      {rows.map((r) => (
        <div key={r.label} className="grid grid-cols-[minmax(0,9.5rem)_1fr] items-center gap-3 sm:grid-cols-[minmax(0,15rem)_1fr]">
          <div className="truncate text-xs text-slate-300 sm:text-sm" title={r.label}>{r.label}</div>
          <div className="relative h-7 rounded bg-slate-800/70">
            <div className={`absolute inset-y-0 left-0 rounded ${barCls[r.tone ?? "slate"]} opacity-80`} style={{ width: `${(r.value / max) * 100}%` }} />
            {r.ci !== undefined && r.ci > 0 && (
              <div className="absolute top-1/2 h-[3px] -translate-y-1/2 rounded bg-white/90" style={{ left: `${((r.value - r.ci) / max) * 100}%`, width: `${((2 * r.ci) / max) * 100}%` }} />
            )}
            <div className="absolute inset-y-0 left-2 flex items-center text-xs font-semibold text-white drop-shadow">
              {r.value.toFixed(2)} {unit}
              {r.ci !== undefined && <span className="ml-1 font-normal text-white/80">±{r.ci.toFixed(2)}</span>}
              {r.note && <span className="ml-2 font-normal text-white/80">{r.note}</span>}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export function Card({ title, children, tone }: { title?: string; children: ReactNode; tone?: Tone }) {
  const ring = tone ? { green: "ring-emerald-500/40", red: "ring-rose-500/40", amber: "ring-amber-500/40", violet: "ring-violet-500/40", slate: "ring-slate-700", sky: "ring-sky-500/40" }[tone] : "ring-slate-800";
  return (
    <div className={`rounded-2xl bg-slate-900/70 p-5 ring-1 ${ring}`}>
      {title && <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-200">{title}</h3>}
      {children}
    </div>
  );
}

export function Stat({ label, value, sub, tone = "slate" }: { label: string; value: string; sub?: string; tone?: Tone }) {
  const c = { green: "text-emerald-300", red: "text-rose-300", amber: "text-amber-300", violet: "text-violet-300", slate: "text-white", sky: "text-sky-300" }[tone];
  return (
    <div className="rounded-2xl bg-slate-900/70 p-5 ring-1 ring-slate-800">
      <div className="text-xs uppercase tracking-wide text-slate-400">{label}</div>
      <div className={`mt-1 text-3xl font-semibold ${c}`}>{value}</div>
      {sub && <div className="mt-1 text-xs text-slate-400">{sub}</div>}
    </div>
  );
}
