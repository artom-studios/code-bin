import raw from "@/data/results.json";
import { Bars, Card, Pill, Section, Stat, type BarRow, type Tone } from "@/components/ui";

interface RtStat { mean: number; sd: number; ci: number; struct: number; upd: number }
interface Paired { vs_frozen: [number, number]; vs_best_on_confirm: [number, number]; best_on_confirm: string }
interface Results {
  meta: { cpu: string; compiler: string; N: number; frames: number; warm: number; confirm_seeds: string; dev_seeds: string };
  canary: { aa: Record<string, { noise_floor_pct: number; cv_pct: number }> };
  confirm: { gate_failures: number; runs: number; n_seeds: number; table: Record<string, Record<string, RtStat>>; paired: Record<string, Record<string, Paired>>; h5: Record<string, [number, number]> };
  verdict: { H1_heavy_improvement: [number, number]; H5_clustered: number; static_regression_pct: number; H2_clustered: [number, number]; H3_moderate: [number, number] };
  devil: Record<string, { row: Record<string, number>; ci: Record<string, number>; closure_pct: number; base: string }>;
  stress: { isa: string; N: number; sc: string; rt: Record<string, { total: number; gate: boolean }> }[];
  portable: { isa: string; sc: string; rt: Record<string, { mean: number; ci: number; gate: boolean }> }[];
  dev_first_attempt: Record<string, Record<string, number>>;
  audit: { sanitizer_runs: number; sanitizer_failures: number; determinism_checked: number; devil_runs: number; devil_gate_failures: number; stress_runs: number; portable_runs: number };
  repro_code: string;
}
const R = raw as unknown as Results;

const NAMES: Record<string, string> = {
  arch: "Archetype ECS (deferred + prefetch)",
  archf: "Archetype ECS + fused kernels",
  sparse: "Sparse-set ECS (owning group)",
  bma00: "Bitmap ECS (StaticEcs-style)",
  bm00: "Bitmap ECS, SoA",
  bm01: "SFBT unfused, adaptive",
  bm10: "SFBT fused, scan-only",
  bm11: "SFBT adaptive (pre-registered candidate)",
  bm12: "Fused blend-only (no adaptivity)",
  flag: "Flag column, ternary kernel",
  flagp: "Flag column, bitwise-select kernel",
};
const SC_TITLE: Record<string, string> = {
  static: "Static scene (no structural change)",
  moderate: "Moderate churn (1% toggles, 0.1% spawn/despawn per frame)",
  heavy: "Heavy churn (10% toggles, 1% spawn/despawn per frame)",
  clustered: "Clustered churn (10% toggles in a hot 10% region)",
};
const FROZEN: Record<string, string> = { static: "archf", moderate: "archf", heavy: "bma00", clustered: "bma00" };
const ISA_NAME: Record<string, string> = { avx512: "AVX-512 (native)", avx2: "AVX2 (console-class x86 proxy)", sse42: "SSE4.2 / 128-bit (mobile NEON-width proxy)" };

const f2 = (x: number) => x.toFixed(2);
const f1 = (x: number) => x.toFixed(1);
const pm = (v: [number, number]) => `${v[0] >= 0 ? "+" : ""}${f1(v[0])}% ± ${f1(v[1])}%`;

function pr(isa: string, sc: string) { return R.portable.find((p) => p.isa === isa && p.sc === sc)!; }
function bestArch(p: { rt: Record<string, { mean: number }> }) { return Math.min(p.rt.arch.mean, p.rt.archf.mean); }

export default function Page() {
  const heavy512 = pr("avx512", "heavy"), heavy2 = pr("avx2", "heavy"), heavy128 = pr("sse42", "heavy");
  const sp512 = bestArch(heavy512) / heavy512.rt.flagp.mean;
  const sp2 = bestArch(heavy2) / heavy2.rt.flagp.mean;
  const sp128 = bestArch(heavy128) / heavy128.rt.flagp.mean;
  const stat512 = pr("avx512", "static");
  const staticPenalty = 100 * (stat512.rt.flagp.mean / stat512.rt.archf.mean - 1);
  const totalGateRuns = R.confirm.runs + R.audit.devil_runs + R.audit.stress_runs + R.audit.portable_runs;
  const v = R.verdict;
  const dv = Object.entries(R.devil);

  const tone = (rt: string, sc: string): Tone => (rt === FROZEN[sc] ? "amber" : rt === "bm11" ? "violet" : rt === "flag" || rt === "flagp" ? "green" : "slate");

  return (
    <main className="min-h-screen bg-slate-950 pb-20">
      {/* HERO */}
      <header className="border-b border-slate-800 bg-gradient-to-b from-slate-900 to-slate-950">
        <div className="mx-auto max-w-6xl px-5 py-14 sm:px-8">
          <div className="flex flex-wrap gap-2">
            <Pill tone="red">Pre-registered candidate: FALSIFIED</Pill>
            <Pill tone="green">Hybrid recommendation: confirmed on fresh seeds</Pill>
            <Pill tone="sky">Measured on x86 only — ARM/console silicon untested</Pill>
          </div>
          <h1 className="mt-5 max-w-4xl text-4xl font-semibold leading-tight tracking-tight text-white sm:text-5xl">
            Is there a game runtime faster than ECS? We tried to invent one, then tried to break the result.
          </h1>
          <p className="mt-5 max-w-3xl text-lg text-slate-300">
            A novel runtime (a fused, per-block adaptive bitmap table) beat tuned ECS by up to {f1(v.H1_heavy_improvement[0])}% under heavy churn and was then <strong className="text-rose-300">falsified</strong>:
            a boring baseline tweak reproduced the gain, and the novel mechanism added nothing. What survives is a measured, portable recommendation for 2026:
            <strong className="text-emerald-300"> keep stable data in fused archetype tables and put volatile state in flag columns</strong>, instead of moving entities between archetypes.
          </p>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat tone="green" label="Heavy churn, AVX-512" value={`${f1(sp512)}×`} sub={`${f2(heavy512.rt.flagp.mean)} vs ${f2(bestArch(heavy512))} ns/entity-frame (best archetype ECS)`} />
            <Stat tone="green" label="Heavy churn, AVX2 (console-class)" value={`${f1(sp2)}×`} sub={`${f2(heavy2.rt.flagp.mean)} vs ${f2(bestArch(heavy2))} ns, bitwise-select kernel`} />
            <Stat tone="amber" label="Heavy churn, 128-bit SIMD (mobile proxy)" value={`${f1(sp128)}×`} sub={`${f2(heavy128.rt.flagp.mean)} vs ${f2(bestArch(heavy128))} ns, SSE4.2 as NEON-width proxy`} />
            <Stat tone="red" label="Static scene penalty" value={`+${f1(staticPenalty)}%`} sub={`flag table is slower than fused archetype ECS when nothing changes`} />
          </div>
        </div>
      </header>

      {/* RECOMMENDATION */}
      <Section id="recommendation" kicker="The answer" title="Best choice for 2026: Hybrid = fused archetype tables + flag columns">
        <div className="grid gap-5 lg:grid-cols-2">
          <Card title="The design rules (what the data supports)" tone="green">
            <ol className="list-decimal space-y-2 pl-5 text-sm">
              <li><strong className="text-white">Stable-shape data</strong> (transform, velocity, health, render proxies) lives in archetype SoA tables with <em>one fused kernel per archetype</em>. This was the fastest design in static scenes in every ISA tested.</li>
              <li><strong className="text-white">Volatile gameplay state</strong> (burning, slowed, stunned, AI mode, visibility) is a <em>bit in a u32 flags column</em>, never an add/remove-component. Structural cost fell from about {f1(R.confirm.table.heavy.archf.struct)} ns to about {f1(R.confirm.table.heavy.bm12.struct)} ns per entity-frame (heavy churn).</li>
              <li><strong className="text-white">Kernels are fixed 32-lane SoA loops with bitwise selects</strong>, not <code className="rounded bg-slate-800 px-1">cond ? a : b</code>. With ternaries the same code collapsed to {f1(pr("avx2", "heavy").rt.flag.mean)} ns on AVX2; the bitwise form held {f2(pr("avx2", "heavy").rt.flagp.mean)} ns.</li>
              <li><strong className="text-white">Real structural changes stay deferred</strong> in a command buffer with a software-prefetch pipeline. That alone took the archetype baseline from 10.9 to about 5.8 ns (heavy) during baseline tuning.</li>
              <li><strong className="text-white">Do not pick sparse-set storage for multi-component iteration.</strong> It was the slowest design in most of our scenarios ({f1(R.confirm.table.heavy.sparse.mean)} ns heavy vs {f1(R.confirm.table.heavy.bma00.mean)} ns bitmap).</li>
              <li><strong className="text-white">Build with <code className="rounded bg-slate-800 px-1">-ffp-contract=off</code> and gate every change on a bit-exact oracle.</strong> Three of our kernels were silently 5–15× slower from failed auto-vectorization; only the compiler report and the oracle caught it.</li>
            </ol>
          </Card>
          <Card title="Platform guidance, with evidence level" tone="sky">
            <div className="space-y-3 text-sm">
              <div><Pill tone="green">MEASURED</Pill> <strong className="text-white">x86-64 desktop / AVX-512:</strong> hybrid {f1(sp512)}× faster than best archetype ECS in heavy churn; {f2(pr("avx512", "static").rt.archf.mean)} ns fused archetype wins static scenes.</div>
              <div><Pill tone="sky">PROXY</Pill> <strong className="text-white">PS5 / Xbox Series class (publicly reported Zen 2 CPUs with AVX2):</strong> measured via an AVX2 build on a Xeon, not on the consoles. Hybrid {f1(sp2)}× in heavy churn with the bitwise-select kernel. Console memory systems and compilers differ.</div>
              <div><Pill tone="sky">PROXY</Pill> <strong className="text-white">Mobile / Switch-class Arm (NEON, 128-bit):</strong> only an SSE4.2 128-bit build was tested, giving {f1(sp128)}×. This says the approach does not need wide SIMD; it does <em>not</em> measure Arm cores, small caches, big.LITTLE scheduling or thermals.</div>
              <div><Pill tone="amber">UNTESTED</Pill> Real consoles, real phones, Clang/MSVC/Apple/Android toolchains, multithreading, rendering, physics. Re-run <code className="rounded bg-slate-800 px-1">lab/reproduce.py</code> on target hardware before committing to the design.</div>
            </div>
          </Card>
        </div>
        <Card title="Which layout for which data">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="text-xs uppercase tracking-wide text-slate-400"><tr><th className="py-2 pr-3">Data / workload</th><th className="pr-3">Use</th><th>Evidence in this study</th></tr></thead>
              <tbody className="divide-y divide-slate-800">
                <tr><td className="py-2 pr-3">Hot, always-present, stable shape</td><td className="pr-3 text-white">Archetype SoA + fused kernel</td><td>Best static: {f2(pr("avx512", "static").rt.archf.mean)} ns</td></tr>
                <tr><td className="py-2 pr-3">Frequently toggled status / mode</td><td className="pr-3 text-white">Flag column (bitwise-select fused kernel)</td><td>{f2(pr("avx512", "heavy").rt.flagp.mean)} ns vs {f2(bestArch(pr("avx512", "heavy")))} ns archetype (heavy)</td></tr>
                <tr><td className="py-2 pr-3">Spawn / despawn churn</td><td className="pr-3 text-white">Slot free-list, no entity moves</td><td>Flag/bitmap designs have no moves; archetype moves cost ~12 cache misses each (profiled)</td></tr>
                <tr><td className="py-2 pr-3">Rare structural change</td><td className="pr-3 text-white">Archetype command buffer + prefetch</td><td>Tuned baseline 10.9 → 5.8 ns (heavy)</td></tr>
                <tr><td className="py-2 pr-3">Large optional components</td><td className="pr-3 text-white">Not measured here</td><td><Pill tone="amber">UNTESTED</Pill> flag tables store dense columns for every slot</td></tr>
              </tbody>
            </table>
          </div>
        </Card>
      </Section>

      {/* PORTABILITY TRAP */}
      <Section id="portability" kicker="The surprising finding" title="The same hybrid collapses on narrower SIMD unless the kernel is written portably">
        <p>
          With <code className="rounded bg-slate-800 px-1">cond ? a : b</code> lane selects, gcc 12 only vectorized the kernel when AVX-512 mask registers were available. On AVX2 and SSE4.2 it fell back to branchy scalar code. Rewriting the selects as 0/1 factors (exact because <code className="rounded bg-slate-800 px-1">x − 0.0f == x</code>) plus integer bitwise selects restored the speed, still bit-exact against the oracle. This is exactly the form console and mobile compilers can map to <code className="rounded bg-slate-800 px-1">blendv</code> / NEON <code className="rounded bg-slate-800 px-1">vbsl</code>, but we have not run it on those targets.
        </p>
        <div className="grid gap-5 lg:grid-cols-3">
          {["avx512", "avx2", "sse42"].map((isa) => {
            const p = pr(isa, "heavy");
            const rows: BarRow[] = ["arch", "archf", "bma00", "flag", "flagp"].map((rt) => ({ label: NAMES[rt], value: p.rt[rt].mean, ci: p.rt[rt].ci, tone: rt === "flagp" ? "green" : rt === "flag" ? "red" : "slate" }));
            return (
              <Card key={isa} title={`Heavy churn · ${ISA_NAME[isa]}`}>
                <Bars rows={rows} />
              </Card>
            );
          })}
        </div>
        <p className="text-xs text-slate-400">5 fresh seeds (4001–4005), N = {R.meta.N.toLocaleString()}, bars = mean ns per entity-frame, whisker = 95% CI (t, n=5). All {R.audit.portable_runs} runs matched the oracle bit-for-bit.</p>
      </Section>

      {/* CONFIRMATORY RESULTS */}
      <Section id="results" kicker="Phase 6" title="Confirmatory results: pre-registered candidate vs tuned baselines">
        <p>
          Ten frozen confirmatory seeds ({R.meta.confirm_seeds}), N = {R.meta.N.toLocaleString()}, {R.meta.frames} frames ({R.meta.warm} warm-up), one fresh process per run, run order rotated per seed, every run checked against the oracle:
          <strong className="text-white"> {R.confirm.runs - R.confirm.gate_failures}/{R.confirm.runs} bit-exact</strong>. <span className="text-amber-300">Amber</span> = baseline frozen on dev seeds, <span className="text-violet-300">violet</span> = pre-registered candidate.
        </p>
        <div className="grid gap-5 lg:grid-cols-2">
          {Object.keys(SC_TITLE).map((sc) => {
            const t = R.confirm.table[sc];
            const rows: BarRow[] = ["arch", "archf", "sparse", "bma00", "bm10", "bm11", "bm12"].map((rt) => ({ label: NAMES[rt], value: t[rt].mean, ci: t[rt].ci, tone: tone(rt, sc) }));
            const pc = R.confirm.paired[sc].bm11.vs_frozen;
            return (
              <Card key={sc} title={SC_TITLE[sc]}>
                <Bars rows={rows} />
                <p className="mt-3 text-xs text-slate-400">Candidate vs frozen baseline ({NAMES[FROZEN[sc]]}): <span className={pc[0] >= 0 ? "text-emerald-300" : "text-rose-300"}>{pm(pc)}</span> (paired, positive = faster)</p>
              </Card>
            );
          })}
        </div>
      </Section>

      {/* VERDICT */}
      <Section id="verdict" kicker="Phase 8" title="Verdict against the pre-registered criteria">
        <Card tone="red">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead className="text-xs uppercase tracking-wide text-slate-400"><tr><th className="py-2 pr-3">Criterion (frozen before any candidate run)</th><th className="pr-3">Observed</th><th>Status</th></tr></thead>
              <tbody className="divide-y divide-slate-800">
                <tr><td className="py-2 pr-3">K1 · every run bit-exact with oracle</td><td className="pr-3">{R.confirm.gate_failures} failures in {R.confirm.runs} runs</td><td><Pill tone="green">PASS</Pill></td></tr>
                <tr><td className="py-2 pr-3">H1 · heavy churn ≥ 15% faster (CI lower bound ≥ 10%)</td><td className="pr-3">{pm(v.H1_heavy_improvement)}</td><td><Pill tone="green">PASS</Pill></td></tr>
                <tr><td className="py-2 pr-3">H2 · clustered ≥ 15% faster</td><td className="pr-3">{pm(v.H2_clustered)}</td><td><Pill tone="green">PASS</Pill></td></tr>
                <tr><td className="py-2 pr-3">H3 · moderate ≥ 10% faster</td><td className="pr-3">{pm(v.H3_moderate)}</td><td><Pill tone="green">PASS</Pill></td></tr>
                <tr><td className="py-2 pr-3">H4/K5 · static no worse than +5%</td><td className="pr-3">{f1(v.static_regression_pct)}% slower than fused archetype ECS</td><td><Pill tone="red">FAIL</Pill></td></tr>
                <tr><td className="py-2 pr-3">H5/K3 · adaptive dispatch ≥ 5% better than best non-adaptive sibling (clustered)</td><td className="pr-3">{pm(R.confirm.h5.clustered)}</td><td><Pill tone="red">FAIL</Pill></td></tr>
                <tr><td className="py-2 pr-3">K4 · baseline-only tweak must not close ≥ 80% of the gap</td><td className="pr-3">flag column closed {dv.filter(([k]) => k !== "static").map(([k, d]) => `${k} ${d.closure_pct.toFixed(0)}%`).join(", ")}</td><td><Pill tone="red">FAIL</Pill></td></tr>
              </tbody>
            </table>
          </div>
          <p className="mt-4 text-sm text-slate-200">
            <strong className="text-rose-300">FALSIFIED</strong> as a novel mechanism: three kill criteria fired. The speedup is real and reproducible, but it comes from combining known techniques (a dense table with status flags, fused kernels, no structural moves). Related prior art found in triage: StaticEcs (bitmap ECS) and Sub0ECS (system fusion). The &ldquo;adaptive per-block dispatch&rdquo; delta contributed nothing measurable.
          </p>
        </Card>
      </Section>

      {/* ABLATION + DEVIL */}
      <Section id="ablation" kicker="Phase 7" title="Ablation and Devil's Tuner">
        <div className="grid gap-5 lg:grid-cols-2">
          <Card title="Mechanism ablation (heavy churn, 10 seeds)">
            <Bars
              rows={[
                { label: "Archetype ECS + fused kernels (no table)", value: R.confirm.table.heavy.archf.mean, ci: R.confirm.table.heavy.archf.ci },
                { label: "Remove fusion → SFBT unfused adaptive", value: R.confirm.table.heavy.bm01.mean, ci: R.confirm.table.heavy.bm01.ci, tone: "red" },
                { label: "Remove blend → fused scan-only", value: R.confirm.table.heavy.bm10.mean, ci: R.confirm.table.heavy.bm10.ci, tone: "red" },
                { label: "Full candidate (adaptive)", value: R.confirm.table.heavy.bm11.mean, ci: R.confirm.table.heavy.bm11.ci, tone: "violet" },
                { label: "Remove adaptivity → fused blend-only", value: R.confirm.table.heavy.bm12.mean, ci: R.confirm.table.heavy.bm12.ci, tone: "green" },
              ]}
            />
            <p className="mt-3 text-xs text-slate-400">Removing fusion or the blend path hurts a lot; removing the novel adaptive dispatch changes nothing (or helps: clustered {pm(R.confirm.h5.clustered)} for adaptive vs best sibling). So adaptivity is not the cause.</p>
          </Card>
          <Card title="Devil's Tuner: baseline-only tweak, no bitmap, no adaptivity" tone="green">
            <div className="space-y-4">
              {dv.map(([sc, d]) => (
                <div key={sc}>
                  <div className="mb-1 text-xs uppercase tracking-wide text-slate-400">{sc}</div>
                  <Bars
                    rows={[
                      { label: NAMES[d.base], value: d.row[d.base], ci: d.ci[d.base], tone: "amber" },
                      { label: NAMES.flag, value: d.row.flag, ci: d.ci.flag, tone: "green" },
                      { label: NAMES.bm11, value: d.row.bm11, ci: d.ci.bm11, tone: "violet" },
                    ]}
                  />
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs text-slate-400">The flag-column table (ternary kernel, AVX-512 build) closes most of the candidate gap in every churn scenario. In static scenes the best known baseline still wins.</p>
          </Card>
        </div>
      </Section>

      {/* STRESS */}
      <Section id="stress" kicker="Phase 7" title="Stress envelope: entity count, extreme churn, SIMD width">
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-left text-sm">
              <thead className="text-xs uppercase tracking-wide text-slate-400">
                <tr><th className="py-2 pr-3">ISA build</th><th className="pr-3">N</th><th className="pr-3">Scenario</th>{["arch", "archf", "bma00", "flag", "bm12", "bm11"].map((rt) => <th key={rt} className="pr-3">{rt}</th>)}</tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {R.stress.map((s, i) => {
                  const best = Math.min(...["arch", "archf", "bma00", "flag", "bm12", "bm11"].map((rt) => s.rt[rt].total));
                  return (
                    <tr key={i}>
                      <td className="py-2 pr-3">{s.isa}</td><td className="pr-3">{s.N.toLocaleString()}</td><td className="pr-3">{s.sc}</td>
                      {["arch", "archf", "bma00", "flag", "bm12", "bm11"].map((rt) => (
                        <td key={rt} className={`pr-3 tabular-nums ${s.rt[rt].total === best ? "font-semibold text-emerald-300" : ""}`}>{f2(s.rt[rt].total)}</td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-xs text-slate-400">3 seeds per row (3001–3003), mean ns per entity-frame, best per row in green, all {R.audit.stress_runs} runs bit-exact. Rows labelled avx2 / sse42 use the ternary kernels (the portability trap above); the bitwise-select fix is shown in the portability section. At N = 1,000,000 the heavy-churn gap widens as archetype moves become memory-bound.</p>
        </Card>
      </Section>

      {/* PROCESS LOG */}
      <Section id="audit" kicker="Honesty log" title="Adversarial audit, harness validation, and everything that went wrong">
        <div className="grid gap-5 lg:grid-cols-2">
          <Card title="Harness validation (Phase 4)">
            <ul className="list-disc space-y-2 pl-5 text-sm">
              <li>A/A noise floor, baseline vs itself, 10 pairs: static {f2(R.canary.aa.static.noise_floor_pct)}%, heavy {f2(R.canary.aa.heavy.noise_floor_pct)}% (95% CI). Every claimed gain is many times larger.</li>
              <li>Corrupt-output canary (update does nothing) was rejected by the oracle gate in both scenarios.</li>
              <li>Artificial delay canary: a ~1.6% delay was <em>not</em> detected in heavy (below the floor, as it should be); a scaled 14–20% delay was detected. Harness resolution is therefore about 3–4%.</li>
              <li>Oracle: naive map-of-structs, plus a float64 twin. float32 vs float64 state drift stayed below 1e-7 relative.</li>
            </ul>
          </Card>
          <Card title="Audit results (Phase 8)">
            <ul className="list-disc space-y-2 pl-5 text-sm">
              <li>ASan + UBSan + LeakSanitizer: {R.audit.sanitizer_failures} failures in {R.audit.sanitizer_runs} runs (13 runtimes × 4 scenarios).</li>
              <li>State leakage: one fresh process per run, per-seed rotated run order, deterministic checksums repeated for {R.audit.determinism_checked} runtimes.</li>
              <li>Oracle-matching runs across all experiments: {totalGateRuns}, zero mismatches in the final code.</li>
              <li>Sources hashed at pre-registration and re-hashed at each amendment (see <code className="rounded bg-slate-800 px-1">lab/prereg.md</code>).</li>
            </ul>
          </Card>
          <Card title="What went wrong (kept on the record)" tone="amber">
            <ul className="list-disc space-y-2 pl-5 text-sm">
              <li>First dev run of the candidate was catastrophically slow ({f1(R.dev_first_attempt.heavy.bm11)} ns heavy vs {f1(R.dev_first_attempt.heavy.archf)} ns archetype): the compiler had not vectorized it. Fixed with SoA + 32-lane kernels (Amendment A1) before any confirmatory seed was touched.</li>
              <li>My own 64-byte component layout initially sandbagged the baselines (a full cache line per 4 bytes touched). Fixed before testing candidates; baselines also got deferred prefetched moves and fused kernels.</li>
              <li>The first Devil&apos;s Tuner baseline was 8–17 ns, also from failed vectorization. It was fixed and re-run rather than reported as a failure to match.</li>
              <li>The bitmap prior art got slower under SoA, so its AoS version was kept as the baseline (anti-strawman).</li>
              <li>The &ldquo;hybrid&rdquo; recommendation is post-hoc (not pre-registered); it was replicated on fresh seeds (4001–4005) but chosen after seeing confirmatory data.</li>
            </ul>
          </Card>
          <Card title="Limitations" tone="amber">
            <ul className="list-disc space-y-2 pl-5 text-sm">
              <li>One synthetic workload (3 tags, 1 optional component, 6 systems), single-threaded, one Xeon, gcc 12 only.</li>
              <li>No Arm, console, or phone hardware. AVX2 and SSE4.2 are proxies, not equivalents.</li>
              <li>Flag columns allocate dense storage for every slot, so memory grows for large optional components (untested).</li>
              <li>No multithreading, rendering, physics, pathfinding, or cache-pressure from other subsystems.</li>
              <li>Statistics are paired means with t-intervals over 10 (or 3–5) seeds, not a full power analysis.</li>
            </ul>
          </Card>
        </div>
      </Section>

      {/* REPRO */}
      <Section id="repro" kicker="Reproduction" title="Run it yourself">
        <Card>
          <pre className="overflow-x-auto text-xs leading-relaxed text-slate-200">{`# needs g++ >= 9 and python3 (stdlib only)
cd lab
python3 verify_oracle.py     # baselines vs oracle, float32 vs float64
python3 canary.py            # A/A noise floor + broken canaries
python3 confirm.py && python3 analyze.py   # 10 frozen seeds, pre-registered stats
python3 devil.py             # Devil's Tuner
python3 portable_final.py    # AVX-512 / AVX2 / SSE4.2 portability
python3 reproduce.py         # quick end-to-end check (below)`}</pre>
        </Card>
        <Card title="lab/reproduce.py">
          <pre className="max-h-96 overflow-auto text-xs leading-relaxed text-slate-200">{R.repro_code}</pre>
        </Card>
        <p className="text-xs text-slate-500">Platform: {R.meta.cpu}; {R.meta.compiler}. Results are from code executed in this sandbox; no number on this page was typed by hand.</p>
      </Section>
    </main>
  );
}
