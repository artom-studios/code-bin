import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Beyond ECS: a benchmarked game-runtime study for 2026",
  description:
    "A pre-registered, oracle-checked comparison of archetype, sparse-set, bitmap and flag-column game runtimes, with falsified claims, ablations and platform guidance.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-950 text-slate-200 antialiased">{children}</body>
    </html>
  );
}
